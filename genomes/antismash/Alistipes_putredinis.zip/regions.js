var recordData = [
 {
  "length": 1705,
  "seq_id": "NZ_JAXXHX010000001.1",
  "regions": []
 },
 {
  "length": 2217,
  "seq_id": "NZ_JAXXHX010000002.1",
  "regions": []
 },
 {
  "length": 2722,
  "seq_id": "NZ_JAXXHX010000003.1",
  "regions": []
 },
 {
  "length": 38663,
  "seq_id": "NZ_JAXXHX010000004.1",
  "regions": []
 },
 {
  "length": 15708,
  "seq_id": "NZ_JAXXHX010000005.1",
  "regions": []
 },
 {
  "length": 41232,
  "seq_id": "NZ_JAXXHX010000006.1",
  "regions": []
 },
 {
  "length": 72270,
  "seq_id": "NZ_JAXXHX010000007.1",
  "regions": []
 },
 {
  "length": 155226,
  "seq_id": "NZ_JAXXHX010000008.1",
  "regions": []
 },
 {
  "length": 3244,
  "seq_id": "NZ_JAXXHX010000009.1",
  "regions": []
 },
 {
  "length": 44458,
  "seq_id": "NZ_JAXXHX010000010.1",
  "regions": []
 },
 {
  "length": 4652,
  "seq_id": "NZ_JAXXHX010000011.1",
  "regions": []
 },
 {
  "length": 41746,
  "seq_id": "NZ_JAXXHX010000012.1",
  "regions": []
 },
 {
  "length": 116478,
  "seq_id": "NZ_JAXXHX010000013.1",
  "regions": [
   {
    "start": 13938,
    "end": 34207,
    "idx": 1,
    "orfs": [
     {
      "start": 14750,
      "end": 15847,
      "strand": 1,
      "locus_tag": "ctg13_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,750 - 15,847,\n (total: 1098 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAACATTGAAAATCGGCGATCTGCTGGCCCGTCTTCCCATCATTCAGGGCGGTATGGGCGTAGGCATCTCCCTCTCGGGACTCGCATCGGCCGTAGCCAACCAAGGCGGTGTGGGAGTGATCTCCTCGGCCGGACTGGGCGTCATCTACCGGGAACACTCCAAAGACTACAATACGGCAAGCATCTGGGGCCTGCGCGAAGAGCTGCGCAAAGCCCGTGAAAAGACCAAAGGTATCATCGGCGTCAATGTCATGGTGGCCATGTCCAACTTCGCAGACATGGTCAGAACGGCCATCGCAGAGAAGGCCGACATCATCTTCTCGGGGGCCGGTATGCCCCTCAACCTGCCGTCGTTCCTGACCAAAGGCAGCAAGACGAAGTTGGCTCCGATCGTTTCGTCGGCCCGAGCCGCCAAGCTCATCTGCGAGAAATGGCTCGCCAACTACAAATACGTTCCCGACGCGATCGTGGTCGAGGGACCCAAGGCCGGCGGACACCTGGGCTACAAGCCGGAACAGATCACCGACGAACACTTCTCGCTGGAGCGGCTGCTGCCCGAAATCGTTTCGGAAGTCCGTCGTTTCGGCACGGCGCACGACACGCACATCCCGGTCATCGCAGCAGGCGGCATCTACACGGGCGAAGACATTTATCGCATCATGGAGCTGGGCGCCGACGGTGTCCAGATGGGCACGCGCTTCGTCACCACGGAGGAGTGCGACGCCTCGACGGAGTTCAAGCGGAGTTACATCGAAGCCTCTCAACAGGACATAGAGATCATCCAAAGTCCGGTGGGTATGCCGGGGCGGGCCATCCACAACTCTTTCCTGGAACGGGTGAAACAAGGGTTGAAACAGCCCAAAAGCTGTCCGTTCAACTGTATCAAGACCTGCGACGTAACCCACAGCCCCTACTGCATCATCATGGCCCTCTACAACGCCTTCAAAGGCAACCTGTCGGCAGGATACGCTTTCGCCGGCGTCAATGCCTGGCGAGCCGAAAAGATCGAGAGCGTGAAAGAGCTGATGACGAACCTTATCGACGAATTCGACCGTTTCAGCCTGAAAAAACAGTTGGCGAAACTGAAAAAATAA",
      "translation": "MKTLKIGDLLARLPIIQGGMGVGISLSGLASAVANQGGVGVISSAGLGVIYREHSKDYNTASIWGLREELRKAREKTKGIIGVNVMVAMSNFADMVRTAIAEKADIIFSGAGMPLNLPSFLTKGSKTKLAPIVSSARAAKLICEKWLANYKYVPDAIVVEGPKAGGHLGYKPEQITDEHFSLERLLPEIVSEVRRFGTAHDTHIPVIAAGGIYTGEDIYRIMELGADGVQMGTRFVTTEECDASTEFKRSYIEASQQDIEIIQSPVGMPGRAIHNSFLERVKQGLKQPKSCPFNCIKTCDVTHSPYCIIMALYNAFKGNLSAGYAFAGVNAWRAEKIESVKELMTNLIDEFDRFSLKKQLAKLKK",
      "product": ""
     },
     {
      "start": 16364,
      "end": 18046,
      "strand": 1,
      "locus_tag": "ctg13_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,364 - 18,046,\n (total: 1683 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGAATTCAGACCCGCACTTCTCACATCCCTGAAGCACTACTCCCGGGAGAAATTCACCGCCGACCTCATGGCCGGCATCATCGTCGGCATCGTGGCCCTGCCGCTGGCGATCGCCTTCGGCATCGCATCGGGCGTTTCACCGGAAAAAGGCATCATCACGGCCATCATCGCCGGCTTCCTCACATCGGCGCTCGGCGGCAGTCGCGTACAGATCGGCGGCCCCACAGGTGCATTCATCGTGATCGTCTATGGCATCATCCAACAGTACGGCATCGAGGGACTGACCGTCGCCACGATCATGGCGGGCGTATTCCTGATCCTGCTGGGACTCTTCCGCCTGGGGACGATCATCAAATTCATTCCCTACCCGATCGTCGTCGGTTTCACCAGCGGTATCGCCGTGACGATCTTCACCACGCAGATCAAGGATCTGTTCGGCCTCACGACCCCCGAAATGCCGGGCGACTTCGCCGGGAAGTGGATGGTCTACTTCCAGAATTTCGGGACGATCGACCTCTGGGCAACGGCCGTAGGCGTTATCAGCGTCGCCATCATCGCCCTCACGCCCCGCTTCTCGAAAAAGATACCCGGTTCGCTGATCGCTATCGTCGTTATGACGCTGGCCGTCTATCTGCTGAAACGCTACGCCGGAATCGACTCCGTCGAAACCATCGGCGACCGATTCACGATCAACTCCCAACTGCCCGACGCGGTCATCCCCGCCCTCTCATGGGAAGGGATGAAAGGACTGCTGCCCGCAGCTATCACCATCGCCGTACTGGGCGCCATCGAATCGCTGCTGTCGGCAACGGTCGCCGACGGCGTGACGGGGGACAAGCACAACTCCAACCAGGAACTCGTGGCCCAAGGTATCGCCAACGTGGTGACGCCTCTGTTCGGCGGCATTCCCGCCACCGGAGCCATCGCCCGCACGATGACCAATATCAACAACGGCGGCCGCACGCCGGTCGCAGGCGTCATCCATGCCGTCGTACTGCTGCTGATCTTCCTGTTCCTGATGCCGCTGGCGCAATATATCCCAATGGCCTGCCTGGCAGGCGTGCTGGTAGTGGTATCGTACAACATGAGCGAATGGCGCACGTTCCGGGCTCTGATGAAGAATCCCCGCTCGGATGTCGCGGTGCTGTTGGTCACCTTCCTGCTGACGGTCATCATCGACCTGACGGTGGCCATCGAAGTCGGACTGGTACTCGCCTGCCTGCTCTTCATGCGGCGCGTGATGGAAACTACCGACATCTCGGTCATCCGCAACGAAATAGACCCCGGTAAGGAGTCGGACCTCGAGTCGCACGAAGAGCACCTCATCATCCCCCGAGGCGTCGAAGTATATGAAATCGACGGTCCCTACTTCTTCGGCATCGCCAACAAATTCGAGGAACAGATGGTGCAGCTCGGCGACCACGCACAGGTGCGGATCATCCGTATGCGAAAGGTCCCCTTCATCGACTCGACGGGCATCCATAACCTCACGAACCTCTGCCGCATATCGCAACAGGAAAATACCCGCATCATCCTTTCGGGCGTCAATCCCAAAGTACACGAAGTCCTGCACAAAGCGGGATTCTACTCCCTGCTGGGCGAGGAAAACATCTGCCCGAATATCAATGCGGCGCTCCGACGGGCCAAAGAACTGGTTGTCGAACCGAAAGAGAAATAG",
      "translation": "MIEFRPALLTSLKHYSREKFTADLMAGIIVGIVALPLAIAFGIASGVSPEKGIITAIIAGFLTSALGGSRVQIGGPTGAFIVIVYGIIQQYGIEGLTVATIMAGVFLILLGLFRLGTIIKFIPYPIVVGFTSGIAVTIFTTQIKDLFGLTTPEMPGDFAGKWMVYFQNFGTIDLWATAVGVISVAIIALTPRFSKKIPGSLIAIVVMTLAVYLLKRYAGIDSVETIGDRFTINSQLPDAVIPALSWEGMKGLLPAAITIAVLGAIESLLSATVADGVTGDKHNSNQELVAQGIANVVTPLFGGIPATGAIARTMTNINNGGRTPVAGVIHAVVLLLIFLFLMPLAQYIPMACLAGVLVVVSYNMSEWRTFRALMKNPRSDVAVLLVTFLLTVIIDLTVAIEVGLVLACLLFMRRVMETTDISVIRNEIDPGKESDLESHEEHLIIPRGVEVYEIDGPYFFGIANKFEEQMVQLGDHAQVRIIRMRKVPFIDSTGIHNLTNLCRISQQENTRIILSGVNPKVHEVLHKAGFYSLLGEENICPNINAALRRAKELVVEPKEK",
      "product": ""
     },
     {
      "start": 18234,
      "end": 18644,
      "strand": -1,
      "locus_tag": "ctg13_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,234 - 18,644,\n (total: 411 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAACTGTTTTTTGCCAGCCTGTGGGTTTTGGCTTGTTTGACCGCAGCCTGTTCCGATGAAAAAGACGAACCGAACGGCGAGTCCGGATCGGTCGTCGGAGAATGGGTGTTTCAGAAGAACGAGTATTATCGGAATGGAAAAATGATCGACAGTTTTACGGCTGTGGAGGACGAGGATAAGATGATCGCTGTATTTCGGGAAGACGGGACTTTTCGTTATTACGATTTCCCGCCCGAAGAGTATTATGACGGGACTTATTCTTATGATGAAGCGTCGGGAGTGTTGGTGACGGACGACGGGATCGAAAAACAGAGCTGCCGGGCCGAAATAACCGTTTCGGAGATGAAATGGATTTATGATGAAGGCAATGATGAGATGCTTGTCGAATATTATACGCGCAAGTAA",
      "translation": "MKKLFFASLWVLACLTAACSDEKDEPNGESGSVVGEWVFQKNEYYRNGKMIDSFTAVEDEDKMIAVFREDGTFRYYDFPPEEYYDGTYSYDEASGVLVTDDGIEKQSCRAEITVSEMKWIYDEGNDEMLVEYYTRK",
      "product": ""
     },
     {
      "start": 18834,
      "end": 19403,
      "strand": -1,
      "locus_tag": "ctg13_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,834 - 19,403,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTTCCAACTTTAAGAATACGCTCGAATTGACTCAACGGCGCGAATTGGAAGAGCTGAAACGACGCGAATCGCAACCGATCGTTGTCGAACCTTACCTGTGTAAATTCGAACTCGATCGTTGGGATCAAGTTATATTCACTTTCAAAGCCGACCTCCGGAATGTGTCGCAAAGCACATTTATCGACGCTGAATTTTATGAAGAATATATCGCAGGAGAAGATTGGGTTGGGGAACCTTACATCCGCGACCGATTGGCTGCATGGGTTTCCTTTTACTTTAATAAAGAGTACGTTTTGAGAAGAGACGAGGGGATGTTTTCCAGATACGAATGTATGTTTCCTAATGTTTCTTTCGATAATCCGTGGAAACCGCAAGAAACGAAGTCCTTTGAGGTTGTCATGTCGATTTATGACGACGATGCCGTAACCAAAGGTTTTACTGCATTCGATGTCAAAAGTTGTATCCTTCATTTCAATTTGACGGTCGAAGACCCTGACGGGCGGAAAATTCCGATGAAAATGAAATTCGATCTGGCGGATGTTTGGAAGGATTTTATTGACAAGTAG",
      "translation": "MISNFKNTLELTQRRELEELKRRESQPIVVEPYLCKFELDRWDQVIFTFKADLRNVSQSTFIDAEFYEEYIAGEDWVGEPYIRDRLAAWVSFYFNKEYVLRRDEGMFSRYECMFPNVSFDNPWKPQETKSFEVVMSIYDDDAVTKGFTAFDVKSCILHFNLTVEDPDGRKIPMKMKFDLADVWKDFIDK",
      "product": ""
     },
     {
      "start": 19842,
      "end": 20093,
      "strand": -1,
      "locus_tag": "ctg13_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,842 - 20,093,\n (total: 252 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATAGAAGATCGCTGGAAGTGTCAAAACTGCGGAAATTCCGTGCCGGACGGATTGACTGTATGTCCGAAATGCGGGCTGGTTAAAGGTGGATTCGACGAGTTGCCGAAACATACGGCAGACGGTTTGGAGATAGCTCGGGTCGAACAGAAAGTCAAAGTAGAAATTCCGTTTATTTTGTATCTGGGGACTGTCTGTTCTATTATTTTATTGGCCATTGTAGTTTATATTTATGTGGCAATAAAATTATGA",
      "translation": "MIEDRWKCQNCGNSVPDGLTVCPKCGLVKGGFDELPKHTADGLEIARVEQKVKVEIPFILYLGTVCSIILLAIVVYIYVAIKL",
      "product": ""
     },
     {
      "start": 20603,
      "end": 20914,
      "strand": -1,
      "locus_tag": "ctg13_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,603 - 20,914,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAAATGATTTTGTGCTGCCTCGTGGCAGTATTGGGATGCGGGGTGTTCGCCGTGGAAGCGAAGACGCCGCAGAAGAAGGGCGAGATCGTTACTACGGTGTTCACGGTCGATATCGATTGCGAAAGCTGTGCGGCCCGCATTATGAACAACGTGCCGGTAATCGGCAAGGGGATCAAGGATATTCAGGTCGATGTTCCCTCGAAAGAGGTGACCGTGACCTATGACAGTGCCAAGACCTCGCCCGAGGAGCTGATCAAAGGATTCGGAAAGATCCGGGTCAAGGCGGAAGAAAAACCTGTCAAATAG",
      "translation": "MKKMILCCLVAVLGCGVFAVEAKTPQKKGEIVTTVFTVDIDCESCAARIMNNVPVIGKGIKDIQVDVPSKEVTVTYDSAKTSPEELIKGFGKIRVKAEEKPVK",
      "product": ""
     },
     {
      "start": 20947,
      "end": 23376,
      "strand": -1,
      "locus_tag": "ctg13_18",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,947 - 23,376,\n (total: 2430 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 67.3; E-value: 2.3e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKFKYLAVLVFFVASAFGAARAQNVKGVVYGADTDEPLIGASVYWAGTTVGTGADAEGNYTIHRVKGYDMLVAGFVGYTSDTIRVESGVERVDFRLSNDGVELEEVVVNSTLGGNYVKRDGILKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGISSVTAGHEAITGQINLEHRKPTDDERLFINFYLDDELRPELNLSTALPVTKDKKLSTILLLHGSLDTHLLGDMDDNGDGFMDLPKTRLGAVANRWLYTADNGAQVRWGFKYLAENRLSGQKHYKASMREEMDTDWDKGAMYGSQIKNRELNAYFKFGMPVGPGVYDEDQQDELRSNIAFVADYDRFRERAYFGLNDYDGTDNMVSLNMMYNHYFSFRHSLIVGVQSHLQFLDESLLNPTPWLDAAGAWNLDRQENEVGAYAEYTYTIKDKLSVVAGIRGDYNGYYDKFYVTPRGHIKWNITPTTILRGSAGLGYRSTNVITDNIGVLATGRHITFERPTALSAGAAAVRGPLNPGSAYGGYTTWMVADGGAGNFKALNRMEKALTAGGSLTQIFTLVKEEDATLSFDYFRTQFYNSVIADQEYSPNDIYIYSSDKRSFTDTYQVDFSWTPVERFDIFATYRYTNSRMTIDRPDGSTALVERPLVSRYKALLNLQYSTRYNRWVFDVTAQLNGPSRLPTQTGDLADSEMSPTYPMFFAQVTRKVGKFDIYVGCENILDYKQKHPILNADDPFSAGFNSSVIWGPLMGRKFYAGLRINFY\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTCAAGTATTTAGCAGTATTAGTCTTTTTTGTTGCATCGGCATTCGGCGCGGCTCGGGCTCAGAATGTCAAAGGTGTCGTATATGGAGCCGACACGGACGAGCCGCTGATCGGTGCATCGGTGTACTGGGCCGGAACGACGGTGGGAACCGGTGCCGATGCCGAAGGAAATTATACCATACACCGGGTTAAGGGATACGATATGCTGGTCGCCGGCTTCGTCGGATATACCAGCGATACGATTCGCGTCGAGAGCGGCGTGGAGCGGGTCGATTTTCGTCTGTCGAACGACGGGGTGGAACTCGAGGAGGTCGTGGTGAACAGTACGCTGGGCGGTAACTACGTGAAGCGGGACGGCATTCTCAAAGGGGAGATGATCTCCTTCGCGGGCCTCTGCAAGATGGCTTGTTGCAACCTGGCCGAGAGTTTCGAGAACTCCGCTTCGGTGACAGTCGGTTACAGCGACGCCATTTCGGGTGCGCGTCAGATCAAGATGCTCGGTTTGGCCGGCACTTACACGCAAATATTGGACGAAAACCGTCCGATCATGCGCGGTTTGAGTGCTCCCTACGGCCTGAGCTATACGCCGGGCATGTGGCTCAATTCGATCCAGGTGTCGAAGGGTATTTCGTCCGTGACTGCCGGACATGAGGCCATCACCGGACAGATCAACCTCGAGCACCGCAAACCGACCGACGACGAGCGGCTGTTCATCAACTTCTACCTTGACGACGAACTGCGTCCCGAGCTGAACCTTTCGACGGCGCTTCCTGTAACCAAGGATAAGAAATTATCGACGATCCTCCTGTTGCACGGATCGTTGGATACTCATTTGCTGGGCGACATGGACGACAACGGCGACGGATTTATGGATCTGCCGAAAACCCGCCTGGGAGCGGTTGCAAACCGCTGGCTTTATACGGCTGACAACGGAGCGCAGGTGCGGTGGGGCTTCAAGTATCTGGCGGAAAATCGCTTGAGCGGTCAGAAGCACTACAAGGCTTCGATGCGTGAAGAGATGGATACCGACTGGGACAAGGGGGCCATGTACGGCTCGCAGATCAAGAACCGCGAGCTGAACGCCTACTTCAAATTCGGTATGCCGGTCGGTCCCGGTGTCTATGACGAGGACCAGCAGGACGAGCTTCGTTCGAACATCGCTTTCGTGGCCGATTACGACCGCTTCCGCGAACGGGCCTACTTCGGGCTCAACGATTACGACGGTACGGACAACATGGTTTCGCTGAACATGATGTACAACCACTATTTCTCCTTCCGTCATTCGCTGATCGTCGGCGTGCAGTCGCATCTGCAATTCCTTGACGAGTCGCTGCTCAACCCGACGCCGTGGCTGGATGCCGCCGGAGCCTGGAATCTCGACCGTCAGGAGAACGAGGTAGGCGCCTATGCCGAATATACCTACACGATCAAGGACAAGCTCTCCGTAGTTGCGGGCATACGCGGGGACTACAACGGTTATTACGATAAGTTCTACGTTACTCCGCGCGGTCATATCAAGTGGAACATCACCCCGACGACGATCCTGCGCGGTTCGGCCGGGCTGGGTTATCGTTCGACCAACGTCATCACCGATAATATCGGCGTTTTGGCTACGGGACGGCATATTACGTTCGAAAGACCGACGGCTCTTTCGGCGGGAGCCGCCGCTGTGCGCGGACCTCTCAATCCCGGCTCTGCTTACGGGGGATATACGACCTGGATGGTCGCAGACGGCGGTGCGGGCAATTTCAAAGCGCTCAACCGGATGGAGAAAGCCCTCACCGCAGGCGGTAGCCTGACGCAGATTTTCACGCTCGTGAAAGAGGAGGACGCGACGTTGAGTTTCGACTACTTCCGCACGCAATTTTATAATTCGGTGATTGCCGATCAGGAGTATTCGCCGAACGACATTTATATTTACAGCTCGGACAAACGCTCCTTTACCGATACTTATCAGGTCGATTTTTCGTGGACTCCGGTGGAGCGGTTCGATATTTTCGCTACGTACCGCTATACGAACAGCCGTATGACGATCGATCGTCCGGACGGCAGTACGGCGCTCGTGGAGCGTCCGCTGGTAAGCCGTTACAAGGCGCTGCTCAACTTGCAGTATTCGACCCGCTACAACCGCTGGGTGTTCGATGTGACGGCTCAGCTCAACGGTCCTTCGCGCCTGCCGACCCAGACGGGCGACCTGGCCGATTCCGAGATGTCGCCGACGTATCCGATGTTCTTCGCGCAGGTGACCCGCAAAGTCGGCAAGTTCGATATTTACGTGGGCTGCGAGAACATTCTCGATTATAAGCAGAAGCACCCGATTCTGAATGCGGACGATCCTTTCTCGGCGGGTTTCAACTCGTCGGTGATCTGGGGACCTCTGATGGGGCGCAAGTTTTATGCGGGATTGCGTATCAATTTTTATTGA",
      "translation": "MKFKYLAVLVFFVASAFGAARAQNVKGVVYGADTDEPLIGASVYWAGTTVGTGADAEGNYTIHRVKGYDMLVAGFVGYTSDTIRVESGVERVDFRLSNDGVELEEVVVNSTLGGNYVKRDGILKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGISSVTAGHEAITGQINLEHRKPTDDERLFINFYLDDELRPELNLSTALPVTKDKKLSTILLLHGSLDTHLLGDMDDNGDGFMDLPKTRLGAVANRWLYTADNGAQVRWGFKYLAENRLSGQKHYKASMREEMDTDWDKGAMYGSQIKNRELNAYFKFGMPVGPGVYDEDQQDELRSNIAFVADYDRFRERAYFGLNDYDGTDNMVSLNMMYNHYFSFRHSLIVGVQSHLQFLDESLLNPTPWLDAAGAWNLDRQENEVGAYAEYTYTIKDKLSVVAGIRGDYNGYYDKFYVTPRGHIKWNITPTTILRGSAGLGYRSTNVITDNIGVLATGRHITFERPTALSAGAAAVRGPLNPGSAYGGYTTWMVADGGAGNFKALNRMEKALTAGGSLTQIFTLVKEEDATLSFDYFRTQFYNSVIADQEYSPNDIYIYSSDKRSFTDTYQVDFSWTPVERFDIFATYRYTNSRMTIDRPDGSTALVERPLVSRYKALLNLQYSTRYNRWVFDVTAQLNGPSRLPTQTGDLADSEMSPTYPMFFAQVTRKVGKFDIYVGCENILDYKQKHPILNADDPFSAGFNSSVIWGPLMGRKFYAGLRINFY",
      "product": ""
     },
     {
      "start": 23510,
      "end": 23941,
      "strand": -1,
      "locus_tag": "ctg13_19",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,510 - 23,941,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGTAAAGCTGCGCAGATATATGTCCGTGTGGATGCTGCTGGTCGCCTACTGTTTCTCGGTAGGAGCAGCGGCATACGCCGTACTTTCGTGCCACTGTATGGGGCAGGAGAAAGGCGAGGTGCATATATGCTGCCGGGGTTGCGACATCCATACCGAATGCGATTCGCATTCGGCCGGTTTTAAGGCCGTTTGCTGCGGAGTGGATCACTCCAAGGTGTCGGAGCTATATACTTCCGTATCGTCTTCCCAATGGGAGCGTGATACGAAGGTCATGATCGTCGATCTTCCTGCCATATTGGCAGCGGAGATGACGGCGATTCCGTTCGATTCCGTTCATTGGGCGACGGTTTCTGAACGTCTCTGTCTGGCCCATAGCACGGTCCATCTTCTCTCTTCCGGACTGCGTGCTCCTCCCGTTTTCGTGTAA",
      "translation": "MSVKLRRYMSVWMLLVAYCFSVGAAAYAVLSCHCMGQEKGEVHICCRGCDIHTECDSHSAGFKAVCCGVDHSKVSELYTSVSSSQWERDTKVMIVDLPAILAAEMTAIPFDSVHWATVSERLCLAHSTVHLLSSGLRAPPVFV",
      "product": ""
     },
     {
      "start": 23938,
      "end": 24207,
      "strand": -1,
      "locus_tag": "ctg13_20",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,938 - 24,207,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGAATCAAAGAGGAATATAAGGTCCGTGAAATGGCAGGCGAGCATATCGTGGTGATGCAGGGCCGTTACGGAGTGGATATGACCAAAGTGATTGCATTGAACGAAACCTCGCTCTGGTTGTGGAACCGGTTGCAGGGACGTGAGTTCGGTACCGACGATGTCCGCGATTTGCTCCTCGGCGAGTACGACGTGGATGCGGAAACCGCCGAGCGCGACGCCCAGGCGTGGGTCGCCCGGCTCAAAACGTGTAATTTAGTCGAAGAATGA",
      "translation": "MRIKEEYKVREMAGEHIVVMQGRYGVDMTKVIALNETSLWLWNRLQGREFGTDDVRDLLLGEYDVDAETAERDAQAWVARLKTCNLVEE",
      "product": ""
     },
     {
      "start": 24319,
      "end": 26250,
      "strand": 1,
      "locus_tag": "ctg13_21",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,319 - 26,250,\n (total: 1932 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 295.7; E-value: 1.1e-89)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTATATGGAATCGACAGCACCGAACAGACGGCAACAGATCGCAGCGCTGCTCAAGCGCTACTGGGGGTTCGACACGTTCCGCCCCGTGCAGGAACAGGTCATCCTCTCGGTGCTCGCCGGACGCGATACGCTGGCCCTGATGCCCACGGGCGGCGGCAAGTCGCTCACCTATCAAATTCCGGGACTGGCTTCGGAGGGCGTATGCATCGTGGTCACCCCGCTGATCGCCCTGATGAAAGACCAGGTCGATCGGCTCCGCAAGCTGGGCATCCGTGCTCTGGCGATCCATTCGGGCCTGTCGGCCCGGCAGATCGACATCGACCTGGACAACTGCGTCTATGGCGACGTGAAATTCCTCTACGTCGCTCCCGAACGGCTCGCATCCGAGGCCTTCCGCCTGCGGGTGCAGCGAATGAACGTATCGCTTCTCGCCGTCGATGAGGCCCACTGCATCTCCCAATGGGGCTACGATTTCCGGCCCTCCTACCTGCGGATCGCCGAGCTGCGCGAGCGGATTCCCGGCGTCCCCGTGCTGGCTCTCACGGCCTCGGCCACACCGCGCGTCGCGGACGACATCATGGAAAAGCTGCGCTTCGCGGAACCCCATCTGCTGCGCAGCGATTTTTCGCGTCCCAACCTCTCTTATGCCGTGCGCCATACCGACGACAAAAACGAACAGCTCCTGCGGATCATCCGCAACGTCGGCGGTTCCGGCATCGTCTATGTCCGCACCCGCGAAGGAGCCGAACAGGTCGCGGCTTTCCTGCGCGACGAAGGTATCTCCGCAGAATATTATCACGGCGGGCTGGGACACGCCGAGCGCTCGATGCGGCAGGAAGCCTGGATTTCGGGGCGTACCCCCGTCATGGTCGCTACCAATGCCTTCGGGATGGGGATCGACAAGCCCGACGTCCGCTACGTGGTACATTATACGATGTGCGACTCGCTCGAAAGCTACTATCAGGAGGCCGGACGTGCCGGACGCGACGGGCGGCGCAGCTATGCCGTATTGCTGATTTCTTCCGACGATGCGGGACGCATCGCCAAACGCTTCGAAGCAGACTACCCGCCGCTCGAAAAGATCCGTTCGATCTACGAAAAAATCTGCAGCTACCTCCAGATCGCCATCGGCGACGGAGCGCAAAGTTCCTTTCTATTCAACCTGCGCGATTTCTGCACCCGGGAACACCTCTATACGGGTCTGGTACAGAACGCCCTGAAGATCCTGAGTCAGAACGGCTACATGACCCTCCTGGACGAAGCGGCCAACCCCGCGCGCATCCTCTTCTGCGTCAGCCGCGACGATCTCTACCGCCTGCGGGTGATCCGCGACGATCTGGACCACATCATCCGTGTTCTGCTGCGTCTGTACGAAGGGGTTTTCACCGACTTCCGCCCCATCGACGAAACGGAAATAGCGACCTGGAGCGGCTATACGCCCGAAAAGGTGCACGACCTGCTGAAACGGCTCTGGCAACTGCGCGTGATCCGCTACATCCCCTCGAACCGCTCGCCGCTCCTCTACATGGACGAAGAACGGCTCCCCACCGCCGATCTCTACATCTCCCCCGAATCGTACCAGCAGCGCCGGAAACAGACCCGCGAACGATTCGAGCGGATGCTCGCCTACGCCACGGCGGAAACCGGCTGCCGCAGCTCCTTCCTGGAAGCCTATTTCGGAGTGCCGGAGCCCCGGGAGTGCGGCATCTGCGACCTCTGCCTCGCCCGCAAACGCGCCGCCCGCGCTCCGCAGGCGGAAGCCTCGAAAAAGACCGTTCTGGAGCTGCTCCGCAACGACGCTCTCGATCCCCGGGAAATCGTCGCTGCACTCCGATCCGATCCGGCACAAATCGCCGAGCTCCTGCGCAAATTGAGCGGCGAAGGCAAAATTTCCATACTCCCGGATGGAAAAGTCACGATTAATCGGTAA",
      "translation": "MYMESTAPNRRQQIAALLKRYWGFDTFRPVQEQVILSVLAGRDTLALMPTGGGKSLTYQIPGLASEGVCIVVTPLIALMKDQVDRLRKLGIRALAIHSGLSARQIDIDLDNCVYGDVKFLYVAPERLASEAFRLRVQRMNVSLLAVDEAHCISQWGYDFRPSYLRIAELRERIPGVPVLALTASATPRVADDIMEKLRFAEPHLLRSDFSRPNLSYAVRHTDDKNEQLLRIIRNVGGSGIVYVRTREGAEQVAAFLRDEGISAEYYHGGLGHAERSMRQEAWISGRTPVMVATNAFGMGIDKPDVRYVVHYTMCDSLESYYQEAGRAGRDGRRSYAVLLISSDDAGRIAKRFEADYPPLEKIRSIYEKICSYLQIAIGDGAQSSFLFNLRDFCTREHLYTGLVQNALKILSQNGYMTLLDEAANPARILFCVSRDDLYRLRVIRDDLDHIIRVLLRLYEGVFTDFRPIDETEIATWSGYTPEKVHDLLKRLWQLRVIRYIPSNRSPLLYMDEERLPTADLYISPESYQQRRKQTRERFERMLAYATAETGCRSSFLEAYFGVPEPRECGICDLCLARKRAARAPQAEASKKTVLELLRNDALDPREIVAALRSDPAQIAELLRKLSGEGKISILPDGKVTINR",
      "product": ""
     },
     {
      "start": 26265,
      "end": 26876,
      "strand": 1,
      "locus_tag": "ctg13_22",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,265 - 26,876,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAAACCGATCACATTTCAAAATAGCATCAGCAACGAGGAGGCCGCTCTGCTTCCGGCCATCGAATTCCGGGGCCCGATCGTCGTCGTGGACTCGGAACCGAGGCTCAGGGAGGCCTGCCGCTACCTGGCGGCACAGCCCGTCATCGGGTTCGACACCGAAACCCGGCCTTCGTTCCGGGCGGGCGTCGTCAATCGGGTCGCACTGCTGCAACTCTCCTCGCCGGAACAGAGCTTCCTGTTCCGGCTCTGCAAGATTCCTCTCGACAAAGCCATCGTCAAAATCCTCGAAAACAAGGAGATCCTGAAAATCGGCGCCGATGTAAAGGGCGACCTGCGGGCACTGCACAACATCCGGCACTTTCAGGAAGCGGGCTTCGTGGATCTTCAGGAGCTCGCCGGAGAGTGGGGCATCGAAGAGAAAAGCCTGCGCAAACTTTCGGCGATCGTACTCGGCCAGCGGGTATCCAAAGCCCAGCGCCTGAGCAACTGGGAAGCCGCACAACTCACCGACAAGCAGCAGTTCTACGCCGCAACGGACGCCTGGGTCTGCACGCGTATCTACGACCGGCTGCTGCACACACCCAAACCAAAGAAAACGAAGAAATGA",
      "translation": "MNKPITFQNSISNEEAALLPAIEFRGPIVVVDSEPRLREACRYLAAQPVIGFDTETRPSFRAGVVNRVALLQLSSPEQSFLFRLCKIPLDKAIVKILENKEILKIGADVKGDLRALHNIRHFQEAGFVDLQELAGEWGIEEKSLRKLSAIVLGQRVSKAQRLSNWEAAQLTDKQQFYAATDAWVCTRIYDRLLHTPKPKKTKK",
      "product": ""
     },
     {
      "start": 26873,
      "end": 28069,
      "strand": 1,
      "locus_tag": "ctg13_23",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,873 - 28,069,\n (total: 1197 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCCGCAAATACACCTCCGACGCGGCAAGGAAGAGTCGTTGCTGCGCCGCCATCCCTGGATTTTCTCGGGCGCGATCGAATCCGTCCGTTACGACGGAAACGAAATCCCCGAAGGTGCCCTCGTCGATGTCTATACCCGTTCGGGCGACTTCATCGCCCGGGGACATTACCAGATCGGTTCGATCGCCGTGCGGGTGCTCACCTTCGAACAGGAACCGATCGACACGGCCTGGTGGCAGCGGATGATCTCCACCGCACTCGACGTGCGCCGCACGCTCGGGCTCACGGATGCCCCCGACACCACCTGCTACCGTCTGGTTCACGGCGAGGGGGACTCCCTGCCGGGACTCGTCGTCGATATTTACGACACGACCGCCGTGATTCAATGTCACTCGGTGGGCATGTACCACGCCCGCCTGACAATCGCCGATGCGATCCGAACGGTTTACGGCGACCGGATTACCGCCATCTACGACAAAAGTTCCCAAACCGTACCGTTCAAGGCCGGCCTGAATCCCGTGGACGGGTACCTTTACGGCAAAACGGGAGGAATGCCCCGCACCGTGCTCGAAAACGGCGAAAAATTCCTGGTCAATTGGGAAGAGGGGCAGAAAACGGGCTTCTTTATCGACCAGCGCTTCAACCGCGAACTGGTACGCCGCTACGCCCGAGGACGCACGGTCCTCAATACCTTCTGCTACACGGGCGGATTTTCGGTATATGCTCTTGCGGGCGGGGCACGCGAAGTATGCTCGATCGACTCCTCGGAGCGGGCCGTCGCCCTGGCCGACGCCAACGTTCGGCTCAACTTCGGAGAAGAGGCTCCCCACACTTCGCTGGCCGTCGATGCCGTCGAATACCTCAAGGACATCGGCGACCGGTACGACATGATCATCCTCGACCCGCCGGCCTTCGCCAAGCACCACAAAGTGCTGGGCAATGCCATGCAGGGCTACAAGCGGCTCAATGCCCGGGCGCTGGCGCAGATCAAAAGCGGAGGGCTCCTCTTCACTTTCTCCTGTTCGCAGGCGGTCAGCAAGGAGTTGTTCCGCACCACGGTCTTCTCGGCCGCAGCCATCGCCGGACGCAAGGTCCGCATCCTGCACCAACTGACCCAGCCCGCCGACCATCCGATCAACATCTATCATCCCGAAGGCGAATACCTCAAGGGATTGGTACTTTACGTCGAATAA",
      "translation": "MIPQIHLRRGKEESLLRRHPWIFSGAIESVRYDGNEIPEGALVDVYTRSGDFIARGHYQIGSIAVRVLTFEQEPIDTAWWQRMISTALDVRRTLGLTDAPDTTCYRLVHGEGDSLPGLVVDIYDTTAVIQCHSVGMYHARLTIADAIRTVYGDRITAIYDKSSQTVPFKAGLNPVDGYLYGKTGGMPRTVLENGEKFLVNWEEGQKTGFFIDQRFNRELVRRYARGRTVLNTFCYTGGFSVYALAGGAREVCSIDSSERAVALADANVRLNFGEEAPHTSLAVDAVEYLKDIGDRYDMIILDPPAFAKHHKVLGNAMQGYKRLNARALAQIKSGGLLFTFSCSQAVSKELFRTTVFSAAAIAGRKVRILHQLTQPADHPINIYHPEGEYLKGLVLYVE",
      "product": ""
     },
     {
      "start": 28102,
      "end": 28596,
      "strand": 1,
      "locus_tag": "ctg13_24",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,102 - 28,596,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAACGCGAAACGATCGTCCGGGAATTTCTCGACAGACACAAAATCCGGTACGACATCTATCACCACCCGGCTTCCCCGACCATCGAAGAGGCCAAGGCACATTGGCGCGAGGACGGGTCGAAACATTGCAAAAACCTCTTCTTCCGCAACCACAAGGGCGACCGTCATTATTTGGTCTGTTTCGACTGCGACCGCTCGCTGGCGATTCACGATCTGGAACACCGACTGCGGCAGGGCAAACTCACCTTCGCCTCGCCGCAGCGCATGGAACGCTACCTAGGGCTCGAACCGGGTTCCGTGTCGCCGTTCGGCCTTATCAACGATGCGGAACACCACGTACATCTCTTTTTAGACCGTCATCTGCAAACGTGCGACAGTTTGAGTTTCCACCCCAACGATTGCCGAGCCACGGTGGTCATTTCCCGCCCCGAATTCGAACGCTACCTCTCCCTGGTCGGAAATACGTACGAATACCTCGACCTCTACGACTGA",
      "translation": "MERETIVREFLDRHKIRYDIYHHPASPTIEEAKAHWREDGSKHCKNLFFRNHKGDRHYLVCFDCDRSLAIHDLEHRLRQGKLTFASPQRMERYLGLEPGSVSPFGLINDAEHHVHLFLDRHLQTCDSLSFHPNDCRATVVISRPEFERYLSLVGNTYEYLDLYD",
      "product": ""
     },
     {
      "start": 28737,
      "end": 30734,
      "strand": -1,
      "locus_tag": "ctg13_25",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,737 - 30,734,\n (total: 1998 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGCTTCGGGGTATCCTCAAAGAATTTAGATTACGCATGGATAAAAAATCAATCGCCGGAATTGTCATCGTGGCCCTGATCTTCCTGGGTTTCACGTTCTATAATTCGCATCAACAGAAAAAGTATCAGGAACAGCTCATGGCGTACAACGCCGAACAGGCGCGTATCCAAGCCGAGCAGGATTCGCTCTTGGCGCTCAACGCTCCGCTGCCGACTGCGGATTCCGCAGCTATTGCGGCTGCGGGAGAGCGGTTGTCCGGGGACAGCCTGCAGGCGCAGCGTCGGATCATGCAGTTCGGAGAGCTGCTGGCTGCGGCGCAGCAGGCCGAAGCCGAGGAGTTCACCGTGGAGAACGAGGTATTGAAGATCGATTTCTCGACGCGTGGCGGCCAGGTCAAGGATGTTACGCTGAAGGATTACACCAAGTATGCACCTCGTGACGAGCGGAATCAGCCGGTGCGGCTTTTCGATCCGGCAACGGCCAATTTCGCCCTGACGTTCTATGTGAAGAATGGTCATAACAACGTGTTGGTCAATACGGCGGATTACACCTTCAATCTGGTGTCGATGGAGAAGGATGCCGACGGTGCGCAGCGCATCACGATGGATCTGCCGGTGGCGCGTGACGCCGTGTTACGGTACGAGTATGTCGTTTATAACATACAGTCGCCGGCGCGGGATTATCTGGTCGATCTGAATGTCTATCTGAAAAATATGGCGCCGCAGATGGCCAGCCAGACGACTATCGGCATCGACTGGAGCAACCGGTCCTATCAGAATGAGAAAGGGTTTCAGAACGAGAATACCTATACGACCATCTATTACCGGGCTCCCGGCGAGTCGTCGGCCGACGACCTGGGGATAAGCGACGGGGAGAAGCAGAAGACGGTTTCGTCGTCGCTCAACTGGGTGGCTTTCAAGCAGCAGTTCTTCTCGTCGGTGATGATCGCCCCGGAGAACTTCTCCTACGCTGATATGAAGTTTACGACGGCGGAAAAAGGTTCGGGTTACATAAAGGATTTTTCGGCTAAATTGACGGTTCCCTATACGGCGCAAACTGACCATTACAACTTCGCCTTCTATTTCGGTCCGAACAAATACGCCATTCTCAAGCATGTGGCGACGACCGAGGGGGACGACGAACTGCATCTGGAGCGGTTGATTCCGCTCGGCTGGGGTATTTTCGGCTGGGTGAACCGCTGGTTCGTGATTCCGGTGTTCGATTTCCTGCGTCAGTTTATCCCGAGTTTCGGCCTGATTATCCTGATCTTGGCCGTGCTGGTGAAGGTCATCATCTCGCCGCTGACCTATAAGAGTTACATATCGACGGCCAAGATGCGCGTCATCAAGCCCGAGGTTGATGAGCTGGCCAAGAAATATCCGCGCCAGGAGGATGCCATGAAGCGCCAGCAGGCGACGATGGAGCTCTACAAGAAGGCCGGTATCAACCCGATGGGCGGTTGTATCCCGCTGTTGATCCAGATGCCGATCATCATTGCGATGTTCCGCTTCTTCCCCGCTTCGATCGAGCTGCGCGGCCAGCATTTCCTTTGGGCCGACGACCTTTCGTCGTACGACAGCGTGTTGTCGCTGCCGTTCAACATTCCCTTCTACGGAGATCACGTGAGCCTGTTCGCCCTGTTGATGACCGTTGCGCTGTTCGCCTTCTCGTATATCAATTACCAGCAGACGGCTTCGTCGCAGCCCCAGATGGCCGGCATGAAGTTTATGATGGTTTATCTGATGCCGGTGATGATGCTCCTGTGGTTCAACAGTTATTCGAGCGGTCTGACTTACTACTACTTCCTGGCCAACATTCTCACGATCGGACAGACGCTCGTGATCCGCCGGATGATCGACGACGAGAAAATTCATGCCGTGATGCAGGCCAATGCCGCGAAAAACAAGAACAGGAAGAAATCCAAGTTCCAGTTGCGTTACGAAGAGTTGCTGCGTCAGCAGGAGGAGGCGCAAAGGAACGCTTCCCGACGGAAATAA",
      "translation": "MLRGILKEFRLRMDKKSIAGIVIVALIFLGFTFYNSHQQKKYQEQLMAYNAEQARIQAEQDSLLALNAPLPTADSAAIAAAGERLSGDSLQAQRRIMQFGELLAAAQQAEAEEFTVENEVLKIDFSTRGGQVKDVTLKDYTKYAPRDERNQPVRLFDPATANFALTFYVKNGHNNVLVNTADYTFNLVSMEKDADGAQRITMDLPVARDAVLRYEYVVYNIQSPARDYLVDLNVYLKNMAPQMASQTTIGIDWSNRSYQNEKGFQNENTYTTIYYRAPGESSADDLGISDGEKQKTVSSSLNWVAFKQQFFSSVMIAPENFSYADMKFTTAEKGSGYIKDFSAKLTVPYTAQTDHYNFAFYFGPNKYAILKHVATTEGDDELHLERLIPLGWGIFGWVNRWFVIPVFDFLRQFIPSFGLIILILAVLVKVIISPLTYKSYISTAKMRVIKPEVDELAKKYPRQEDAMKRQQATMELYKKAGINPMGGCIPLLIQMPIIIAMFRFFPASIELRGQHFLWADDLSSYDSVLSLPFNIPFYGDHVSLFALLMTVALFAFSYINYQQTASSQPQMAGMKFMMVYLMPVMMLLWFNSYSSGLTYYYFLANILTIGQTLVIRRMIDDEKIHAVMQANAAKNKNRKKSKFQLRYEELLRQQEEAQRNASRRK",
      "product": ""
     },
     {
      "start": 30744,
      "end": 32372,
      "strand": -1,
      "locus_tag": "ctg13_26",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,744 - 32,372,\n (total: 1629 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACTCAGCAAACCCAAGTACATTTTCGTGACGGGCGGCGTGGCTTCGTCGCTCGGTAAAGGCATTATTTCGGCGTCGATCGCCCGCTTGCTGCAGGCACGCGGCTATTCGGTGACGATTCAGAAACTGGATCCCTATATCAATATCGACCCCGGAACCCTGAATCCTTACGAGCACGGAGAGTGTTACGTGACCGAAGACGGTGCGGAAACCGACCTCGACCTGGGCCATTACGAGCGTTTCACTTCGATTACGACCAGCCATGCCAACAACGTGACCACCGGTAAGATTTATCAGTGCGTGATTGACAAGGAGCGCAAGGGCGAGTACCTGGGCAAGACCGTGCAGGTCATTCCTCATATCACGGACGAAATCAAGCGCCGCATTCAACTGTTGGCGCAGCGCAAGGAGTACGACGTAATCATCACCGAGATCGGCGGTACGGTGGGCGACATCGAGTCGCTGCCCTTCATCGAATCGGTGCGTCAGTTGCGTTACCAGCTTGGAGCCCGCAATACGGCGCTGGTTCATCTGACGCTCATTCCTTACCTGGCCGCTTCCGGCGAGTTGAAGACCAAGCCGACCCAACATTCGGTCAAGACCTTGCTCGAGAACGGTTTGCAGCCCGATATTCTGGTGCTGCGCACCGAGCATCCGCTCTCTGCGGAGCTCAGGCGCAAGGTGGCGCTCTTCTGCAACGTGGATGCCAACGCGGTGATGGAGTCGATCGACGTACCGACGATCTACGAAGTGCCGCTGGTGATGCACCGTCAGCATCTGGACGAGGTGGTGCTCAGCAAGCTCGACCTTCCGTCGGAGCAGGAACCCGACTTGAGTTCGTTGCAGGCTTTCGTCGATAAGGTGAAGAATCCCAAGCGGACGATCGACATCGCCCTGGTGGGTAAATATACGGAACTTCCCGATGCTTACAAGTCGATCTGCGAGTCCTTTATTCAAGCCGGTGCGGTGAACGACTGCAAGGTGAAGTTGCATTACGTGAATTCGGAGAAGATAGACGCTTCGAACGTCGGGGAGAAGCTCGGCAAAATGGCCGGTATTCTCGTGGCTCCGGGGTTCGGCAACCGGGGAATCGAGGGGAAGATCGAAGCGGTGCACTTTGCGCGGACTCACCGTATTCCGTTCCTGGGAATCTGTCTGGGTATGCAGTGCGCCGTGATCGAATTCGCTCGCAACGTACTGGGCTTCAAGGATGCCACCTCGACAGAAATGGACCCGGCGACGAAGCATCCGGTCATCGACCTGATGGAGGAACAGAAGGGCATTACCGCCAAAGGCGGCACGATGCGTCTGGGAGCTTACCCCTGCTCGCTGGTGCCGGGATCGAAAGCTGCGCAGGCTTACGGTACGACTCAGATTCAGGAGCGTCATCGCCACCGCTACGAATTCAACAGCGAATACCTGAAGGATTTCGAGAGCCACGGAATGAAAGCCGTCGGTGCGAACCCCGATACGGGGCTGGTCGAAGTGGTCGAAATTCCCGACCATCCCTGGTTCGTCGGTACGCAATACCATCCCGAATACAAGAGCACCGTACAGCGGCCTCATCCGCTTTTCGTCGCGTTCGTAGCTGCGGCGCTGGCGGGAAAAGACGATAAGAAAAAATAG",
      "translation": "MKLSKPKYIFVTGGVASSLGKGIISASIARLLQARGYSVTIQKLDPYINIDPGTLNPYEHGECYVTEDGAETDLDLGHYERFTSITTSHANNVTTGKIYQCVIDKERKGEYLGKTVQVIPHITDEIKRRIQLLAQRKEYDVIITEIGGTVGDIESLPFIESVRQLRYQLGARNTALVHLTLIPYLAASGELKTKPTQHSVKTLLENGLQPDILVLRTEHPLSAELRRKVALFCNVDANAVMESIDVPTIYEVPLVMHRQHLDEVVLSKLDLPSEQEPDLSSLQAFVDKVKNPKRTIDIALVGKYTELPDAYKSICESFIQAGAVNDCKVKLHYVNSEKIDASNVGEKLGKMAGILVAPGFGNRGIEGKIEAVHFARTHRIPFLGICLGMQCAVIEFARNVLGFKDATSTEMDPATKHPVIDLMEEQKGITAKGGTMRLGAYPCSLVPGSKAAQAYGTTQIQERHRHRYEFNSEYLKDFESHGMKAVGANPDTGLVEVVEIPDHPWFVGTQYHPEYKSTVQRPHPLFVAFVAAALAGKDDKKK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 23937,
      "end": 24207,
      "tool": "rule-based-clusters",
      "neighbouring_start": 13937,
      "neighbouring_end": 34207,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r13c1"
   }
  ]
 },
 {
  "length": 57165,
  "seq_id": "NZ_JAXXHX010000014.1",
  "regions": []
 },
 {
  "length": 34796,
  "seq_id": "NZ_JAXXHX010000015.1",
  "regions": []
 },
 {
  "length": 130388,
  "seq_id": "NZ_JAXXHX010000016.1",
  "regions": []
 },
 {
  "length": 17291,
  "seq_id": "NZ_JAXXHX010000017.1",
  "regions": []
 },
 {
  "length": 133538,
  "seq_id": "NZ_JAXXHX010000018.1",
  "regions": []
 },
 {
  "length": 50540,
  "seq_id": "NZ_JAXXHX010000019.1",
  "regions": []
 },
 {
  "length": 26502,
  "seq_id": "NZ_JAXXHX010000020.1",
  "regions": []
 },
 {
  "length": 7803,
  "seq_id": "NZ_JAXXHX010000021.1",
  "regions": []
 },
 {
  "length": 41331,
  "seq_id": "NZ_JAXXHX010000022.1",
  "regions": []
 },
 {
  "length": 62566,
  "seq_id": "NZ_JAXXHX010000023.1",
  "regions": []
 },
 {
  "length": 74985,
  "seq_id": "NZ_JAXXHX010000024.1",
  "regions": []
 },
 {
  "length": 67484,
  "seq_id": "NZ_JAXXHX010000025.1",
  "regions": []
 },
 {
  "length": 113249,
  "seq_id": "NZ_JAXXHX010000026.1",
  "regions": []
 },
 {
  "length": 118897,
  "seq_id": "NZ_JAXXHX010000027.1",
  "regions": []
 },
 {
  "length": 35035,
  "seq_id": "NZ_JAXXHX010000028.1",
  "regions": []
 },
 {
  "length": 8753,
  "seq_id": "NZ_JAXXHX010000029.1",
  "regions": []
 },
 {
  "length": 115058,
  "seq_id": "NZ_JAXXHX010000030.1",
  "regions": []
 },
 {
  "length": 26121,
  "seq_id": "NZ_JAXXHX010000031.1",
  "regions": []
 },
 {
  "length": 24161,
  "seq_id": "NZ_JAXXHX010000032.1",
  "regions": []
 },
 {
  "length": 33555,
  "seq_id": "NZ_JAXXHX010000033.1",
  "regions": []
 },
 {
  "length": 24173,
  "seq_id": "NZ_JAXXHX010000034.1",
  "regions": []
 },
 {
  "length": 22632,
  "seq_id": "NZ_JAXXHX010000035.1",
  "regions": []
 },
 {
  "length": 20648,
  "seq_id": "NZ_JAXXHX010000036.1",
  "regions": []
 },
 {
  "length": 10179,
  "seq_id": "NZ_JAXXHX010000037.1",
  "regions": []
 },
 {
  "length": 34830,
  "seq_id": "NZ_JAXXHX010000038.1",
  "regions": []
 },
 {
  "length": 17989,
  "seq_id": "NZ_JAXXHX010000039.1",
  "regions": []
 },
 {
  "length": 16614,
  "seq_id": "NZ_JAXXHX010000040.1",
  "regions": []
 },
 {
  "length": 10917,
  "seq_id": "NZ_JAXXHX010000041.1",
  "regions": []
 },
 {
  "length": 12736,
  "seq_id": "NZ_JAXXHX010000042.1",
  "regions": []
 },
 {
  "length": 42662,
  "seq_id": "NZ_JAXXHX010000043.1",
  "regions": []
 },
 {
  "length": 121482,
  "seq_id": "NZ_JAXXHX010000044.1",
  "regions": []
 },
 {
  "length": 3815,
  "seq_id": "NZ_JAXXHX010000045.1",
  "regions": []
 },
 {
  "length": 11521,
  "seq_id": "NZ_JAXXHX010000046.1",
  "regions": []
 },
 {
  "length": 30020,
  "seq_id": "NZ_JAXXHX010000047.1",
  "regions": []
 },
 {
  "length": 8885,
  "seq_id": "NZ_JAXXHX010000048.1",
  "regions": []
 },
 {
  "length": 3974,
  "seq_id": "NZ_JAXXHX010000049.1",
  "regions": []
 },
 {
  "length": 3539,
  "seq_id": "NZ_JAXXHX010000050.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r13c1"
 ],
 "r13c1": {
  "start": 13938,
  "end": 34207,
  "idx": 1,
  "orfs": [
   {
    "start": 14750,
    "end": 15847,
    "strand": 1,
    "locus_tag": "ctg13_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,750 - 15,847,\n (total: 1098 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAACATTGAAAATCGGCGATCTGCTGGCCCGTCTTCCCATCATTCAGGGCGGTATGGGCGTAGGCATCTCCCTCTCGGGACTCGCATCGGCCGTAGCCAACCAAGGCGGTGTGGGAGTGATCTCCTCGGCCGGACTGGGCGTCATCTACCGGGAACACTCCAAAGACTACAATACGGCAAGCATCTGGGGCCTGCGCGAAGAGCTGCGCAAAGCCCGTGAAAAGACCAAAGGTATCATCGGCGTCAATGTCATGGTGGCCATGTCCAACTTCGCAGACATGGTCAGAACGGCCATCGCAGAGAAGGCCGACATCATCTTCTCGGGGGCCGGTATGCCCCTCAACCTGCCGTCGTTCCTGACCAAAGGCAGCAAGACGAAGTTGGCTCCGATCGTTTCGTCGGCCCGAGCCGCCAAGCTCATCTGCGAGAAATGGCTCGCCAACTACAAATACGTTCCCGACGCGATCGTGGTCGAGGGACCCAAGGCCGGCGGACACCTGGGCTACAAGCCGGAACAGATCACCGACGAACACTTCTCGCTGGAGCGGCTGCTGCCCGAAATCGTTTCGGAAGTCCGTCGTTTCGGCACGGCGCACGACACGCACATCCCGGTCATCGCAGCAGGCGGCATCTACACGGGCGAAGACATTTATCGCATCATGGAGCTGGGCGCCGACGGTGTCCAGATGGGCACGCGCTTCGTCACCACGGAGGAGTGCGACGCCTCGACGGAGTTCAAGCGGAGTTACATCGAAGCCTCTCAACAGGACATAGAGATCATCCAAAGTCCGGTGGGTATGCCGGGGCGGGCCATCCACAACTCTTTCCTGGAACGGGTGAAACAAGGGTTGAAACAGCCCAAAAGCTGTCCGTTCAACTGTATCAAGACCTGCGACGTAACCCACAGCCCCTACTGCATCATCATGGCCCTCTACAACGCCTTCAAAGGCAACCTGTCGGCAGGATACGCTTTCGCCGGCGTCAATGCCTGGCGAGCCGAAAAGATCGAGAGCGTGAAAGAGCTGATGACGAACCTTATCGACGAATTCGACCGTTTCAGCCTGAAAAAACAGTTGGCGAAACTGAAAAAATAA",
    "translation": "MKTLKIGDLLARLPIIQGGMGVGISLSGLASAVANQGGVGVISSAGLGVIYREHSKDYNTASIWGLREELRKAREKTKGIIGVNVMVAMSNFADMVRTAIAEKADIIFSGAGMPLNLPSFLTKGSKTKLAPIVSSARAAKLICEKWLANYKYVPDAIVVEGPKAGGHLGYKPEQITDEHFSLERLLPEIVSEVRRFGTAHDTHIPVIAAGGIYTGEDIYRIMELGADGVQMGTRFVTTEECDASTEFKRSYIEASQQDIEIIQSPVGMPGRAIHNSFLERVKQGLKQPKSCPFNCIKTCDVTHSPYCIIMALYNAFKGNLSAGYAFAGVNAWRAEKIESVKELMTNLIDEFDRFSLKKQLAKLKK",
    "product": ""
   },
   {
    "start": 16364,
    "end": 18046,
    "strand": 1,
    "locus_tag": "ctg13_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,364 - 18,046,\n (total: 1683 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGAATTCAGACCCGCACTTCTCACATCCCTGAAGCACTACTCCCGGGAGAAATTCACCGCCGACCTCATGGCCGGCATCATCGTCGGCATCGTGGCCCTGCCGCTGGCGATCGCCTTCGGCATCGCATCGGGCGTTTCACCGGAAAAAGGCATCATCACGGCCATCATCGCCGGCTTCCTCACATCGGCGCTCGGCGGCAGTCGCGTACAGATCGGCGGCCCCACAGGTGCATTCATCGTGATCGTCTATGGCATCATCCAACAGTACGGCATCGAGGGACTGACCGTCGCCACGATCATGGCGGGCGTATTCCTGATCCTGCTGGGACTCTTCCGCCTGGGGACGATCATCAAATTCATTCCCTACCCGATCGTCGTCGGTTTCACCAGCGGTATCGCCGTGACGATCTTCACCACGCAGATCAAGGATCTGTTCGGCCTCACGACCCCCGAAATGCCGGGCGACTTCGCCGGGAAGTGGATGGTCTACTTCCAGAATTTCGGGACGATCGACCTCTGGGCAACGGCCGTAGGCGTTATCAGCGTCGCCATCATCGCCCTCACGCCCCGCTTCTCGAAAAAGATACCCGGTTCGCTGATCGCTATCGTCGTTATGACGCTGGCCGTCTATCTGCTGAAACGCTACGCCGGAATCGACTCCGTCGAAACCATCGGCGACCGATTCACGATCAACTCCCAACTGCCCGACGCGGTCATCCCCGCCCTCTCATGGGAAGGGATGAAAGGACTGCTGCCCGCAGCTATCACCATCGCCGTACTGGGCGCCATCGAATCGCTGCTGTCGGCAACGGTCGCCGACGGCGTGACGGGGGACAAGCACAACTCCAACCAGGAACTCGTGGCCCAAGGTATCGCCAACGTGGTGACGCCTCTGTTCGGCGGCATTCCCGCCACCGGAGCCATCGCCCGCACGATGACCAATATCAACAACGGCGGCCGCACGCCGGTCGCAGGCGTCATCCATGCCGTCGTACTGCTGCTGATCTTCCTGTTCCTGATGCCGCTGGCGCAATATATCCCAATGGCCTGCCTGGCAGGCGTGCTGGTAGTGGTATCGTACAACATGAGCGAATGGCGCACGTTCCGGGCTCTGATGAAGAATCCCCGCTCGGATGTCGCGGTGCTGTTGGTCACCTTCCTGCTGACGGTCATCATCGACCTGACGGTGGCCATCGAAGTCGGACTGGTACTCGCCTGCCTGCTCTTCATGCGGCGCGTGATGGAAACTACCGACATCTCGGTCATCCGCAACGAAATAGACCCCGGTAAGGAGTCGGACCTCGAGTCGCACGAAGAGCACCTCATCATCCCCCGAGGCGTCGAAGTATATGAAATCGACGGTCCCTACTTCTTCGGCATCGCCAACAAATTCGAGGAACAGATGGTGCAGCTCGGCGACCACGCACAGGTGCGGATCATCCGTATGCGAAAGGTCCCCTTCATCGACTCGACGGGCATCCATAACCTCACGAACCTCTGCCGCATATCGCAACAGGAAAATACCCGCATCATCCTTTCGGGCGTCAATCCCAAAGTACACGAAGTCCTGCACAAAGCGGGATTCTACTCCCTGCTGGGCGAGGAAAACATCTGCCCGAATATCAATGCGGCGCTCCGACGGGCCAAAGAACTGGTTGTCGAACCGAAAGAGAAATAG",
    "translation": "MIEFRPALLTSLKHYSREKFTADLMAGIIVGIVALPLAIAFGIASGVSPEKGIITAIIAGFLTSALGGSRVQIGGPTGAFIVIVYGIIQQYGIEGLTVATIMAGVFLILLGLFRLGTIIKFIPYPIVVGFTSGIAVTIFTTQIKDLFGLTTPEMPGDFAGKWMVYFQNFGTIDLWATAVGVISVAIIALTPRFSKKIPGSLIAIVVMTLAVYLLKRYAGIDSVETIGDRFTINSQLPDAVIPALSWEGMKGLLPAAITIAVLGAIESLLSATVADGVTGDKHNSNQELVAQGIANVVTPLFGGIPATGAIARTMTNINNGGRTPVAGVIHAVVLLLIFLFLMPLAQYIPMACLAGVLVVVSYNMSEWRTFRALMKNPRSDVAVLLVTFLLTVIIDLTVAIEVGLVLACLLFMRRVMETTDISVIRNEIDPGKESDLESHEEHLIIPRGVEVYEIDGPYFFGIANKFEEQMVQLGDHAQVRIIRMRKVPFIDSTGIHNLTNLCRISQQENTRIILSGVNPKVHEVLHKAGFYSLLGEENICPNINAALRRAKELVVEPKEK",
    "product": ""
   },
   {
    "start": 18234,
    "end": 18644,
    "strand": -1,
    "locus_tag": "ctg13_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,234 - 18,644,\n (total: 411 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAACTGTTTTTTGCCAGCCTGTGGGTTTTGGCTTGTTTGACCGCAGCCTGTTCCGATGAAAAAGACGAACCGAACGGCGAGTCCGGATCGGTCGTCGGAGAATGGGTGTTTCAGAAGAACGAGTATTATCGGAATGGAAAAATGATCGACAGTTTTACGGCTGTGGAGGACGAGGATAAGATGATCGCTGTATTTCGGGAAGACGGGACTTTTCGTTATTACGATTTCCCGCCCGAAGAGTATTATGACGGGACTTATTCTTATGATGAAGCGTCGGGAGTGTTGGTGACGGACGACGGGATCGAAAAACAGAGCTGCCGGGCCGAAATAACCGTTTCGGAGATGAAATGGATTTATGATGAAGGCAATGATGAGATGCTTGTCGAATATTATACGCGCAAGTAA",
    "translation": "MKKLFFASLWVLACLTAACSDEKDEPNGESGSVVGEWVFQKNEYYRNGKMIDSFTAVEDEDKMIAVFREDGTFRYYDFPPEEYYDGTYSYDEASGVLVTDDGIEKQSCRAEITVSEMKWIYDEGNDEMLVEYYTRK",
    "product": ""
   },
   {
    "start": 18834,
    "end": 19403,
    "strand": -1,
    "locus_tag": "ctg13_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,834 - 19,403,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTTCCAACTTTAAGAATACGCTCGAATTGACTCAACGGCGCGAATTGGAAGAGCTGAAACGACGCGAATCGCAACCGATCGTTGTCGAACCTTACCTGTGTAAATTCGAACTCGATCGTTGGGATCAAGTTATATTCACTTTCAAAGCCGACCTCCGGAATGTGTCGCAAAGCACATTTATCGACGCTGAATTTTATGAAGAATATATCGCAGGAGAAGATTGGGTTGGGGAACCTTACATCCGCGACCGATTGGCTGCATGGGTTTCCTTTTACTTTAATAAAGAGTACGTTTTGAGAAGAGACGAGGGGATGTTTTCCAGATACGAATGTATGTTTCCTAATGTTTCTTTCGATAATCCGTGGAAACCGCAAGAAACGAAGTCCTTTGAGGTTGTCATGTCGATTTATGACGACGATGCCGTAACCAAAGGTTTTACTGCATTCGATGTCAAAAGTTGTATCCTTCATTTCAATTTGACGGTCGAAGACCCTGACGGGCGGAAAATTCCGATGAAAATGAAATTCGATCTGGCGGATGTTTGGAAGGATTTTATTGACAAGTAG",
    "translation": "MISNFKNTLELTQRRELEELKRRESQPIVVEPYLCKFELDRWDQVIFTFKADLRNVSQSTFIDAEFYEEYIAGEDWVGEPYIRDRLAAWVSFYFNKEYVLRRDEGMFSRYECMFPNVSFDNPWKPQETKSFEVVMSIYDDDAVTKGFTAFDVKSCILHFNLTVEDPDGRKIPMKMKFDLADVWKDFIDK",
    "product": ""
   },
   {
    "start": 19842,
    "end": 20093,
    "strand": -1,
    "locus_tag": "ctg13_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,842 - 20,093,\n (total: 252 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATAGAAGATCGCTGGAAGTGTCAAAACTGCGGAAATTCCGTGCCGGACGGATTGACTGTATGTCCGAAATGCGGGCTGGTTAAAGGTGGATTCGACGAGTTGCCGAAACATACGGCAGACGGTTTGGAGATAGCTCGGGTCGAACAGAAAGTCAAAGTAGAAATTCCGTTTATTTTGTATCTGGGGACTGTCTGTTCTATTATTTTATTGGCCATTGTAGTTTATATTTATGTGGCAATAAAATTATGA",
    "translation": "MIEDRWKCQNCGNSVPDGLTVCPKCGLVKGGFDELPKHTADGLEIARVEQKVKVEIPFILYLGTVCSIILLAIVVYIYVAIKL",
    "product": ""
   },
   {
    "start": 20603,
    "end": 20914,
    "strand": -1,
    "locus_tag": "ctg13_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,603 - 20,914,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAAATGATTTTGTGCTGCCTCGTGGCAGTATTGGGATGCGGGGTGTTCGCCGTGGAAGCGAAGACGCCGCAGAAGAAGGGCGAGATCGTTACTACGGTGTTCACGGTCGATATCGATTGCGAAAGCTGTGCGGCCCGCATTATGAACAACGTGCCGGTAATCGGCAAGGGGATCAAGGATATTCAGGTCGATGTTCCCTCGAAAGAGGTGACCGTGACCTATGACAGTGCCAAGACCTCGCCCGAGGAGCTGATCAAAGGATTCGGAAAGATCCGGGTCAAGGCGGAAGAAAAACCTGTCAAATAG",
    "translation": "MKKMILCCLVAVLGCGVFAVEAKTPQKKGEIVTTVFTVDIDCESCAARIMNNVPVIGKGIKDIQVDVPSKEVTVTYDSAKTSPEELIKGFGKIRVKAEEKPVK",
    "product": ""
   },
   {
    "start": 20947,
    "end": 23376,
    "strand": -1,
    "locus_tag": "ctg13_18",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,947 - 23,376,\n (total: 2430 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 67.3; E-value: 2.3e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKFKYLAVLVFFVASAFGAARAQNVKGVVYGADTDEPLIGASVYWAGTTVGTGADAEGNYTIHRVKGYDMLVAGFVGYTSDTIRVESGVERVDFRLSNDGVELEEVVVNSTLGGNYVKRDGILKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGISSVTAGHEAITGQINLEHRKPTDDERLFINFYLDDELRPELNLSTALPVTKDKKLSTILLLHGSLDTHLLGDMDDNGDGFMDLPKTRLGAVANRWLYTADNGAQVRWGFKYLAENRLSGQKHYKASMREEMDTDWDKGAMYGSQIKNRELNAYFKFGMPVGPGVYDEDQQDELRSNIAFVADYDRFRERAYFGLNDYDGTDNMVSLNMMYNHYFSFRHSLIVGVQSHLQFLDESLLNPTPWLDAAGAWNLDRQENEVGAYAEYTYTIKDKLSVVAGIRGDYNGYYDKFYVTPRGHIKWNITPTTILRGSAGLGYRSTNVITDNIGVLATGRHITFERPTALSAGAAAVRGPLNPGSAYGGYTTWMVADGGAGNFKALNRMEKALTAGGSLTQIFTLVKEEDATLSFDYFRTQFYNSVIADQEYSPNDIYIYSSDKRSFTDTYQVDFSWTPVERFDIFATYRYTNSRMTIDRPDGSTALVERPLVSRYKALLNLQYSTRYNRWVFDVTAQLNGPSRLPTQTGDLADSEMSPTYPMFFAQVTRKVGKFDIYVGCENILDYKQKHPILNADDPFSAGFNSSVIWGPLMGRKFYAGLRINFY\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTCAAGTATTTAGCAGTATTAGTCTTTTTTGTTGCATCGGCATTCGGCGCGGCTCGGGCTCAGAATGTCAAAGGTGTCGTATATGGAGCCGACACGGACGAGCCGCTGATCGGTGCATCGGTGTACTGGGCCGGAACGACGGTGGGAACCGGTGCCGATGCCGAAGGAAATTATACCATACACCGGGTTAAGGGATACGATATGCTGGTCGCCGGCTTCGTCGGATATACCAGCGATACGATTCGCGTCGAGAGCGGCGTGGAGCGGGTCGATTTTCGTCTGTCGAACGACGGGGTGGAACTCGAGGAGGTCGTGGTGAACAGTACGCTGGGCGGTAACTACGTGAAGCGGGACGGCATTCTCAAAGGGGAGATGATCTCCTTCGCGGGCCTCTGCAAGATGGCTTGTTGCAACCTGGCCGAGAGTTTCGAGAACTCCGCTTCGGTGACAGTCGGTTACAGCGACGCCATTTCGGGTGCGCGTCAGATCAAGATGCTCGGTTTGGCCGGCACTTACACGCAAATATTGGACGAAAACCGTCCGATCATGCGCGGTTTGAGTGCTCCCTACGGCCTGAGCTATACGCCGGGCATGTGGCTCAATTCGATCCAGGTGTCGAAGGGTATTTCGTCCGTGACTGCCGGACATGAGGCCATCACCGGACAGATCAACCTCGAGCACCGCAAACCGACCGACGACGAGCGGCTGTTCATCAACTTCTACCTTGACGACGAACTGCGTCCCGAGCTGAACCTTTCGACGGCGCTTCCTGTAACCAAGGATAAGAAATTATCGACGATCCTCCTGTTGCACGGATCGTTGGATACTCATTTGCTGGGCGACATGGACGACAACGGCGACGGATTTATGGATCTGCCGAAAACCCGCCTGGGAGCGGTTGCAAACCGCTGGCTTTATACGGCTGACAACGGAGCGCAGGTGCGGTGGGGCTTCAAGTATCTGGCGGAAAATCGCTTGAGCGGTCAGAAGCACTACAAGGCTTCGATGCGTGAAGAGATGGATACCGACTGGGACAAGGGGGCCATGTACGGCTCGCAGATCAAGAACCGCGAGCTGAACGCCTACTTCAAATTCGGTATGCCGGTCGGTCCCGGTGTCTATGACGAGGACCAGCAGGACGAGCTTCGTTCGAACATCGCTTTCGTGGCCGATTACGACCGCTTCCGCGAACGGGCCTACTTCGGGCTCAACGATTACGACGGTACGGACAACATGGTTTCGCTGAACATGATGTACAACCACTATTTCTCCTTCCGTCATTCGCTGATCGTCGGCGTGCAGTCGCATCTGCAATTCCTTGACGAGTCGCTGCTCAACCCGACGCCGTGGCTGGATGCCGCCGGAGCCTGGAATCTCGACCGTCAGGAGAACGAGGTAGGCGCCTATGCCGAATATACCTACACGATCAAGGACAAGCTCTCCGTAGTTGCGGGCATACGCGGGGACTACAACGGTTATTACGATAAGTTCTACGTTACTCCGCGCGGTCATATCAAGTGGAACATCACCCCGACGACGATCCTGCGCGGTTCGGCCGGGCTGGGTTATCGTTCGACCAACGTCATCACCGATAATATCGGCGTTTTGGCTACGGGACGGCATATTACGTTCGAAAGACCGACGGCTCTTTCGGCGGGAGCCGCCGCTGTGCGCGGACCTCTCAATCCCGGCTCTGCTTACGGGGGATATACGACCTGGATGGTCGCAGACGGCGGTGCGGGCAATTTCAAAGCGCTCAACCGGATGGAGAAAGCCCTCACCGCAGGCGGTAGCCTGACGCAGATTTTCACGCTCGTGAAAGAGGAGGACGCGACGTTGAGTTTCGACTACTTCCGCACGCAATTTTATAATTCGGTGATTGCCGATCAGGAGTATTCGCCGAACGACATTTATATTTACAGCTCGGACAAACGCTCCTTTACCGATACTTATCAGGTCGATTTTTCGTGGACTCCGGTGGAGCGGTTCGATATTTTCGCTACGTACCGCTATACGAACAGCCGTATGACGATCGATCGTCCGGACGGCAGTACGGCGCTCGTGGAGCGTCCGCTGGTAAGCCGTTACAAGGCGCTGCTCAACTTGCAGTATTCGACCCGCTACAACCGCTGGGTGTTCGATGTGACGGCTCAGCTCAACGGTCCTTCGCGCCTGCCGACCCAGACGGGCGACCTGGCCGATTCCGAGATGTCGCCGACGTATCCGATGTTCTTCGCGCAGGTGACCCGCAAAGTCGGCAAGTTCGATATTTACGTGGGCTGCGAGAACATTCTCGATTATAAGCAGAAGCACCCGATTCTGAATGCGGACGATCCTTTCTCGGCGGGTTTCAACTCGTCGGTGATCTGGGGACCTCTGATGGGGCGCAAGTTTTATGCGGGATTGCGTATCAATTTTTATTGA",
    "translation": "MKFKYLAVLVFFVASAFGAARAQNVKGVVYGADTDEPLIGASVYWAGTTVGTGADAEGNYTIHRVKGYDMLVAGFVGYTSDTIRVESGVERVDFRLSNDGVELEEVVVNSTLGGNYVKRDGILKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGISSVTAGHEAITGQINLEHRKPTDDERLFINFYLDDELRPELNLSTALPVTKDKKLSTILLLHGSLDTHLLGDMDDNGDGFMDLPKTRLGAVANRWLYTADNGAQVRWGFKYLAENRLSGQKHYKASMREEMDTDWDKGAMYGSQIKNRELNAYFKFGMPVGPGVYDEDQQDELRSNIAFVADYDRFRERAYFGLNDYDGTDNMVSLNMMYNHYFSFRHSLIVGVQSHLQFLDESLLNPTPWLDAAGAWNLDRQENEVGAYAEYTYTIKDKLSVVAGIRGDYNGYYDKFYVTPRGHIKWNITPTTILRGSAGLGYRSTNVITDNIGVLATGRHITFERPTALSAGAAAVRGPLNPGSAYGGYTTWMVADGGAGNFKALNRMEKALTAGGSLTQIFTLVKEEDATLSFDYFRTQFYNSVIADQEYSPNDIYIYSSDKRSFTDTYQVDFSWTPVERFDIFATYRYTNSRMTIDRPDGSTALVERPLVSRYKALLNLQYSTRYNRWVFDVTAQLNGPSRLPTQTGDLADSEMSPTYPMFFAQVTRKVGKFDIYVGCENILDYKQKHPILNADDPFSAGFNSSVIWGPLMGRKFYAGLRINFY",
    "product": ""
   },
   {
    "start": 23510,
    "end": 23941,
    "strand": -1,
    "locus_tag": "ctg13_19",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,510 - 23,941,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGTAAAGCTGCGCAGATATATGTCCGTGTGGATGCTGCTGGTCGCCTACTGTTTCTCGGTAGGAGCAGCGGCATACGCCGTACTTTCGTGCCACTGTATGGGGCAGGAGAAAGGCGAGGTGCATATATGCTGCCGGGGTTGCGACATCCATACCGAATGCGATTCGCATTCGGCCGGTTTTAAGGCCGTTTGCTGCGGAGTGGATCACTCCAAGGTGTCGGAGCTATATACTTCCGTATCGTCTTCCCAATGGGAGCGTGATACGAAGGTCATGATCGTCGATCTTCCTGCCATATTGGCAGCGGAGATGACGGCGATTCCGTTCGATTCCGTTCATTGGGCGACGGTTTCTGAACGTCTCTGTCTGGCCCATAGCACGGTCCATCTTCTCTCTTCCGGACTGCGTGCTCCTCCCGTTTTCGTGTAA",
    "translation": "MSVKLRRYMSVWMLLVAYCFSVGAAAYAVLSCHCMGQEKGEVHICCRGCDIHTECDSHSAGFKAVCCGVDHSKVSELYTSVSSSQWERDTKVMIVDLPAILAAEMTAIPFDSVHWATVSERLCLAHSTVHLLSSGLRAPPVFV",
    "product": ""
   },
   {
    "start": 23938,
    "end": 24207,
    "strand": -1,
    "locus_tag": "ctg13_20",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,938 - 24,207,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGAATCAAAGAGGAATATAAGGTCCGTGAAATGGCAGGCGAGCATATCGTGGTGATGCAGGGCCGTTACGGAGTGGATATGACCAAAGTGATTGCATTGAACGAAACCTCGCTCTGGTTGTGGAACCGGTTGCAGGGACGTGAGTTCGGTACCGACGATGTCCGCGATTTGCTCCTCGGCGAGTACGACGTGGATGCGGAAACCGCCGAGCGCGACGCCCAGGCGTGGGTCGCCCGGCTCAAAACGTGTAATTTAGTCGAAGAATGA",
    "translation": "MRIKEEYKVREMAGEHIVVMQGRYGVDMTKVIALNETSLWLWNRLQGREFGTDDVRDLLLGEYDVDAETAERDAQAWVARLKTCNLVEE",
    "product": ""
   },
   {
    "start": 24319,
    "end": 26250,
    "strand": 1,
    "locus_tag": "ctg13_21",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,319 - 26,250,\n (total: 1932 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 295.7; E-value: 1.1e-89)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTATATGGAATCGACAGCACCGAACAGACGGCAACAGATCGCAGCGCTGCTCAAGCGCTACTGGGGGTTCGACACGTTCCGCCCCGTGCAGGAACAGGTCATCCTCTCGGTGCTCGCCGGACGCGATACGCTGGCCCTGATGCCCACGGGCGGCGGCAAGTCGCTCACCTATCAAATTCCGGGACTGGCTTCGGAGGGCGTATGCATCGTGGTCACCCCGCTGATCGCCCTGATGAAAGACCAGGTCGATCGGCTCCGCAAGCTGGGCATCCGTGCTCTGGCGATCCATTCGGGCCTGTCGGCCCGGCAGATCGACATCGACCTGGACAACTGCGTCTATGGCGACGTGAAATTCCTCTACGTCGCTCCCGAACGGCTCGCATCCGAGGCCTTCCGCCTGCGGGTGCAGCGAATGAACGTATCGCTTCTCGCCGTCGATGAGGCCCACTGCATCTCCCAATGGGGCTACGATTTCCGGCCCTCCTACCTGCGGATCGCCGAGCTGCGCGAGCGGATTCCCGGCGTCCCCGTGCTGGCTCTCACGGCCTCGGCCACACCGCGCGTCGCGGACGACATCATGGAAAAGCTGCGCTTCGCGGAACCCCATCTGCTGCGCAGCGATTTTTCGCGTCCCAACCTCTCTTATGCCGTGCGCCATACCGACGACAAAAACGAACAGCTCCTGCGGATCATCCGCAACGTCGGCGGTTCCGGCATCGTCTATGTCCGCACCCGCGAAGGAGCCGAACAGGTCGCGGCTTTCCTGCGCGACGAAGGTATCTCCGCAGAATATTATCACGGCGGGCTGGGACACGCCGAGCGCTCGATGCGGCAGGAAGCCTGGATTTCGGGGCGTACCCCCGTCATGGTCGCTACCAATGCCTTCGGGATGGGGATCGACAAGCCCGACGTCCGCTACGTGGTACATTATACGATGTGCGACTCGCTCGAAAGCTACTATCAGGAGGCCGGACGTGCCGGACGCGACGGGCGGCGCAGCTATGCCGTATTGCTGATTTCTTCCGACGATGCGGGACGCATCGCCAAACGCTTCGAAGCAGACTACCCGCCGCTCGAAAAGATCCGTTCGATCTACGAAAAAATCTGCAGCTACCTCCAGATCGCCATCGGCGACGGAGCGCAAAGTTCCTTTCTATTCAACCTGCGCGATTTCTGCACCCGGGAACACCTCTATACGGGTCTGGTACAGAACGCCCTGAAGATCCTGAGTCAGAACGGCTACATGACCCTCCTGGACGAAGCGGCCAACCCCGCGCGCATCCTCTTCTGCGTCAGCCGCGACGATCTCTACCGCCTGCGGGTGATCCGCGACGATCTGGACCACATCATCCGTGTTCTGCTGCGTCTGTACGAAGGGGTTTTCACCGACTTCCGCCCCATCGACGAAACGGAAATAGCGACCTGGAGCGGCTATACGCCCGAAAAGGTGCACGACCTGCTGAAACGGCTCTGGCAACTGCGCGTGATCCGCTACATCCCCTCGAACCGCTCGCCGCTCCTCTACATGGACGAAGAACGGCTCCCCACCGCCGATCTCTACATCTCCCCCGAATCGTACCAGCAGCGCCGGAAACAGACCCGCGAACGATTCGAGCGGATGCTCGCCTACGCCACGGCGGAAACCGGCTGCCGCAGCTCCTTCCTGGAAGCCTATTTCGGAGTGCCGGAGCCCCGGGAGTGCGGCATCTGCGACCTCTGCCTCGCCCGCAAACGCGCCGCCCGCGCTCCGCAGGCGGAAGCCTCGAAAAAGACCGTTCTGGAGCTGCTCCGCAACGACGCTCTCGATCCCCGGGAAATCGTCGCTGCACTCCGATCCGATCCGGCACAAATCGCCGAGCTCCTGCGCAAATTGAGCGGCGAAGGCAAAATTTCCATACTCCCGGATGGAAAAGTCACGATTAATCGGTAA",
    "translation": "MYMESTAPNRRQQIAALLKRYWGFDTFRPVQEQVILSVLAGRDTLALMPTGGGKSLTYQIPGLASEGVCIVVTPLIALMKDQVDRLRKLGIRALAIHSGLSARQIDIDLDNCVYGDVKFLYVAPERLASEAFRLRVQRMNVSLLAVDEAHCISQWGYDFRPSYLRIAELRERIPGVPVLALTASATPRVADDIMEKLRFAEPHLLRSDFSRPNLSYAVRHTDDKNEQLLRIIRNVGGSGIVYVRTREGAEQVAAFLRDEGISAEYYHGGLGHAERSMRQEAWISGRTPVMVATNAFGMGIDKPDVRYVVHYTMCDSLESYYQEAGRAGRDGRRSYAVLLISSDDAGRIAKRFEADYPPLEKIRSIYEKICSYLQIAIGDGAQSSFLFNLRDFCTREHLYTGLVQNALKILSQNGYMTLLDEAANPARILFCVSRDDLYRLRVIRDDLDHIIRVLLRLYEGVFTDFRPIDETEIATWSGYTPEKVHDLLKRLWQLRVIRYIPSNRSPLLYMDEERLPTADLYISPESYQQRRKQTRERFERMLAYATAETGCRSSFLEAYFGVPEPRECGICDLCLARKRAARAPQAEASKKTVLELLRNDALDPREIVAALRSDPAQIAELLRKLSGEGKISILPDGKVTINR",
    "product": ""
   },
   {
    "start": 26265,
    "end": 26876,
    "strand": 1,
    "locus_tag": "ctg13_22",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,265 - 26,876,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAAACCGATCACATTTCAAAATAGCATCAGCAACGAGGAGGCCGCTCTGCTTCCGGCCATCGAATTCCGGGGCCCGATCGTCGTCGTGGACTCGGAACCGAGGCTCAGGGAGGCCTGCCGCTACCTGGCGGCACAGCCCGTCATCGGGTTCGACACCGAAACCCGGCCTTCGTTCCGGGCGGGCGTCGTCAATCGGGTCGCACTGCTGCAACTCTCCTCGCCGGAACAGAGCTTCCTGTTCCGGCTCTGCAAGATTCCTCTCGACAAAGCCATCGTCAAAATCCTCGAAAACAAGGAGATCCTGAAAATCGGCGCCGATGTAAAGGGCGACCTGCGGGCACTGCACAACATCCGGCACTTTCAGGAAGCGGGCTTCGTGGATCTTCAGGAGCTCGCCGGAGAGTGGGGCATCGAAGAGAAAAGCCTGCGCAAACTTTCGGCGATCGTACTCGGCCAGCGGGTATCCAAAGCCCAGCGCCTGAGCAACTGGGAAGCCGCACAACTCACCGACAAGCAGCAGTTCTACGCCGCAACGGACGCCTGGGTCTGCACGCGTATCTACGACCGGCTGCTGCACACACCCAAACCAAAGAAAACGAAGAAATGA",
    "translation": "MNKPITFQNSISNEEAALLPAIEFRGPIVVVDSEPRLREACRYLAAQPVIGFDTETRPSFRAGVVNRVALLQLSSPEQSFLFRLCKIPLDKAIVKILENKEILKIGADVKGDLRALHNIRHFQEAGFVDLQELAGEWGIEEKSLRKLSAIVLGQRVSKAQRLSNWEAAQLTDKQQFYAATDAWVCTRIYDRLLHTPKPKKTKK",
    "product": ""
   },
   {
    "start": 26873,
    "end": 28069,
    "strand": 1,
    "locus_tag": "ctg13_23",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,873 - 28,069,\n (total: 1197 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCCGCAAATACACCTCCGACGCGGCAAGGAAGAGTCGTTGCTGCGCCGCCATCCCTGGATTTTCTCGGGCGCGATCGAATCCGTCCGTTACGACGGAAACGAAATCCCCGAAGGTGCCCTCGTCGATGTCTATACCCGTTCGGGCGACTTCATCGCCCGGGGACATTACCAGATCGGTTCGATCGCCGTGCGGGTGCTCACCTTCGAACAGGAACCGATCGACACGGCCTGGTGGCAGCGGATGATCTCCACCGCACTCGACGTGCGCCGCACGCTCGGGCTCACGGATGCCCCCGACACCACCTGCTACCGTCTGGTTCACGGCGAGGGGGACTCCCTGCCGGGACTCGTCGTCGATATTTACGACACGACCGCCGTGATTCAATGTCACTCGGTGGGCATGTACCACGCCCGCCTGACAATCGCCGATGCGATCCGAACGGTTTACGGCGACCGGATTACCGCCATCTACGACAAAAGTTCCCAAACCGTACCGTTCAAGGCCGGCCTGAATCCCGTGGACGGGTACCTTTACGGCAAAACGGGAGGAATGCCCCGCACCGTGCTCGAAAACGGCGAAAAATTCCTGGTCAATTGGGAAGAGGGGCAGAAAACGGGCTTCTTTATCGACCAGCGCTTCAACCGCGAACTGGTACGCCGCTACGCCCGAGGACGCACGGTCCTCAATACCTTCTGCTACACGGGCGGATTTTCGGTATATGCTCTTGCGGGCGGGGCACGCGAAGTATGCTCGATCGACTCCTCGGAGCGGGCCGTCGCCCTGGCCGACGCCAACGTTCGGCTCAACTTCGGAGAAGAGGCTCCCCACACTTCGCTGGCCGTCGATGCCGTCGAATACCTCAAGGACATCGGCGACCGGTACGACATGATCATCCTCGACCCGCCGGCCTTCGCCAAGCACCACAAAGTGCTGGGCAATGCCATGCAGGGCTACAAGCGGCTCAATGCCCGGGCGCTGGCGCAGATCAAAAGCGGAGGGCTCCTCTTCACTTTCTCCTGTTCGCAGGCGGTCAGCAAGGAGTTGTTCCGCACCACGGTCTTCTCGGCCGCAGCCATCGCCGGACGCAAGGTCCGCATCCTGCACCAACTGACCCAGCCCGCCGACCATCCGATCAACATCTATCATCCCGAAGGCGAATACCTCAAGGGATTGGTACTTTACGTCGAATAA",
    "translation": "MIPQIHLRRGKEESLLRRHPWIFSGAIESVRYDGNEIPEGALVDVYTRSGDFIARGHYQIGSIAVRVLTFEQEPIDTAWWQRMISTALDVRRTLGLTDAPDTTCYRLVHGEGDSLPGLVVDIYDTTAVIQCHSVGMYHARLTIADAIRTVYGDRITAIYDKSSQTVPFKAGLNPVDGYLYGKTGGMPRTVLENGEKFLVNWEEGQKTGFFIDQRFNRELVRRYARGRTVLNTFCYTGGFSVYALAGGAREVCSIDSSERAVALADANVRLNFGEEAPHTSLAVDAVEYLKDIGDRYDMIILDPPAFAKHHKVLGNAMQGYKRLNARALAQIKSGGLLFTFSCSQAVSKELFRTTVFSAAAIAGRKVRILHQLTQPADHPINIYHPEGEYLKGLVLYVE",
    "product": ""
   },
   {
    "start": 28102,
    "end": 28596,
    "strand": 1,
    "locus_tag": "ctg13_24",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,102 - 28,596,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAACGCGAAACGATCGTCCGGGAATTTCTCGACAGACACAAAATCCGGTACGACATCTATCACCACCCGGCTTCCCCGACCATCGAAGAGGCCAAGGCACATTGGCGCGAGGACGGGTCGAAACATTGCAAAAACCTCTTCTTCCGCAACCACAAGGGCGACCGTCATTATTTGGTCTGTTTCGACTGCGACCGCTCGCTGGCGATTCACGATCTGGAACACCGACTGCGGCAGGGCAAACTCACCTTCGCCTCGCCGCAGCGCATGGAACGCTACCTAGGGCTCGAACCGGGTTCCGTGTCGCCGTTCGGCCTTATCAACGATGCGGAACACCACGTACATCTCTTTTTAGACCGTCATCTGCAAACGTGCGACAGTTTGAGTTTCCACCCCAACGATTGCCGAGCCACGGTGGTCATTTCCCGCCCCGAATTCGAACGCTACCTCTCCCTGGTCGGAAATACGTACGAATACCTCGACCTCTACGACTGA",
    "translation": "MERETIVREFLDRHKIRYDIYHHPASPTIEEAKAHWREDGSKHCKNLFFRNHKGDRHYLVCFDCDRSLAIHDLEHRLRQGKLTFASPQRMERYLGLEPGSVSPFGLINDAEHHVHLFLDRHLQTCDSLSFHPNDCRATVVISRPEFERYLSLVGNTYEYLDLYD",
    "product": ""
   },
   {
    "start": 28737,
    "end": 30734,
    "strand": -1,
    "locus_tag": "ctg13_25",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,737 - 30,734,\n (total: 1998 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGCTTCGGGGTATCCTCAAAGAATTTAGATTACGCATGGATAAAAAATCAATCGCCGGAATTGTCATCGTGGCCCTGATCTTCCTGGGTTTCACGTTCTATAATTCGCATCAACAGAAAAAGTATCAGGAACAGCTCATGGCGTACAACGCCGAACAGGCGCGTATCCAAGCCGAGCAGGATTCGCTCTTGGCGCTCAACGCTCCGCTGCCGACTGCGGATTCCGCAGCTATTGCGGCTGCGGGAGAGCGGTTGTCCGGGGACAGCCTGCAGGCGCAGCGTCGGATCATGCAGTTCGGAGAGCTGCTGGCTGCGGCGCAGCAGGCCGAAGCCGAGGAGTTCACCGTGGAGAACGAGGTATTGAAGATCGATTTCTCGACGCGTGGCGGCCAGGTCAAGGATGTTACGCTGAAGGATTACACCAAGTATGCACCTCGTGACGAGCGGAATCAGCCGGTGCGGCTTTTCGATCCGGCAACGGCCAATTTCGCCCTGACGTTCTATGTGAAGAATGGTCATAACAACGTGTTGGTCAATACGGCGGATTACACCTTCAATCTGGTGTCGATGGAGAAGGATGCCGACGGTGCGCAGCGCATCACGATGGATCTGCCGGTGGCGCGTGACGCCGTGTTACGGTACGAGTATGTCGTTTATAACATACAGTCGCCGGCGCGGGATTATCTGGTCGATCTGAATGTCTATCTGAAAAATATGGCGCCGCAGATGGCCAGCCAGACGACTATCGGCATCGACTGGAGCAACCGGTCCTATCAGAATGAGAAAGGGTTTCAGAACGAGAATACCTATACGACCATCTATTACCGGGCTCCCGGCGAGTCGTCGGCCGACGACCTGGGGATAAGCGACGGGGAGAAGCAGAAGACGGTTTCGTCGTCGCTCAACTGGGTGGCTTTCAAGCAGCAGTTCTTCTCGTCGGTGATGATCGCCCCGGAGAACTTCTCCTACGCTGATATGAAGTTTACGACGGCGGAAAAAGGTTCGGGTTACATAAAGGATTTTTCGGCTAAATTGACGGTTCCCTATACGGCGCAAACTGACCATTACAACTTCGCCTTCTATTTCGGTCCGAACAAATACGCCATTCTCAAGCATGTGGCGACGACCGAGGGGGACGACGAACTGCATCTGGAGCGGTTGATTCCGCTCGGCTGGGGTATTTTCGGCTGGGTGAACCGCTGGTTCGTGATTCCGGTGTTCGATTTCCTGCGTCAGTTTATCCCGAGTTTCGGCCTGATTATCCTGATCTTGGCCGTGCTGGTGAAGGTCATCATCTCGCCGCTGACCTATAAGAGTTACATATCGACGGCCAAGATGCGCGTCATCAAGCCCGAGGTTGATGAGCTGGCCAAGAAATATCCGCGCCAGGAGGATGCCATGAAGCGCCAGCAGGCGACGATGGAGCTCTACAAGAAGGCCGGTATCAACCCGATGGGCGGTTGTATCCCGCTGTTGATCCAGATGCCGATCATCATTGCGATGTTCCGCTTCTTCCCCGCTTCGATCGAGCTGCGCGGCCAGCATTTCCTTTGGGCCGACGACCTTTCGTCGTACGACAGCGTGTTGTCGCTGCCGTTCAACATTCCCTTCTACGGAGATCACGTGAGCCTGTTCGCCCTGTTGATGACCGTTGCGCTGTTCGCCTTCTCGTATATCAATTACCAGCAGACGGCTTCGTCGCAGCCCCAGATGGCCGGCATGAAGTTTATGATGGTTTATCTGATGCCGGTGATGATGCTCCTGTGGTTCAACAGTTATTCGAGCGGTCTGACTTACTACTACTTCCTGGCCAACATTCTCACGATCGGACAGACGCTCGTGATCCGCCGGATGATCGACGACGAGAAAATTCATGCCGTGATGCAGGCCAATGCCGCGAAAAACAAGAACAGGAAGAAATCCAAGTTCCAGTTGCGTTACGAAGAGTTGCTGCGTCAGCAGGAGGAGGCGCAAAGGAACGCTTCCCGACGGAAATAA",
    "translation": "MLRGILKEFRLRMDKKSIAGIVIVALIFLGFTFYNSHQQKKYQEQLMAYNAEQARIQAEQDSLLALNAPLPTADSAAIAAAGERLSGDSLQAQRRIMQFGELLAAAQQAEAEEFTVENEVLKIDFSTRGGQVKDVTLKDYTKYAPRDERNQPVRLFDPATANFALTFYVKNGHNNVLVNTADYTFNLVSMEKDADGAQRITMDLPVARDAVLRYEYVVYNIQSPARDYLVDLNVYLKNMAPQMASQTTIGIDWSNRSYQNEKGFQNENTYTTIYYRAPGESSADDLGISDGEKQKTVSSSLNWVAFKQQFFSSVMIAPENFSYADMKFTTAEKGSGYIKDFSAKLTVPYTAQTDHYNFAFYFGPNKYAILKHVATTEGDDELHLERLIPLGWGIFGWVNRWFVIPVFDFLRQFIPSFGLIILILAVLVKVIISPLTYKSYISTAKMRVIKPEVDELAKKYPRQEDAMKRQQATMELYKKAGINPMGGCIPLLIQMPIIIAMFRFFPASIELRGQHFLWADDLSSYDSVLSLPFNIPFYGDHVSLFALLMTVALFAFSYINYQQTASSQPQMAGMKFMMVYLMPVMMLLWFNSYSSGLTYYYFLANILTIGQTLVIRRMIDDEKIHAVMQANAAKNKNRKKSKFQLRYEELLRQQEEAQRNASRRK",
    "product": ""
   },
   {
    "start": 30744,
    "end": 32372,
    "strand": -1,
    "locus_tag": "ctg13_26",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg13_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg13_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,744 - 32,372,\n (total: 1629 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg13_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg13_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACTCAGCAAACCCAAGTACATTTTCGTGACGGGCGGCGTGGCTTCGTCGCTCGGTAAAGGCATTATTTCGGCGTCGATCGCCCGCTTGCTGCAGGCACGCGGCTATTCGGTGACGATTCAGAAACTGGATCCCTATATCAATATCGACCCCGGAACCCTGAATCCTTACGAGCACGGAGAGTGTTACGTGACCGAAGACGGTGCGGAAACCGACCTCGACCTGGGCCATTACGAGCGTTTCACTTCGATTACGACCAGCCATGCCAACAACGTGACCACCGGTAAGATTTATCAGTGCGTGATTGACAAGGAGCGCAAGGGCGAGTACCTGGGCAAGACCGTGCAGGTCATTCCTCATATCACGGACGAAATCAAGCGCCGCATTCAACTGTTGGCGCAGCGCAAGGAGTACGACGTAATCATCACCGAGATCGGCGGTACGGTGGGCGACATCGAGTCGCTGCCCTTCATCGAATCGGTGCGTCAGTTGCGTTACCAGCTTGGAGCCCGCAATACGGCGCTGGTTCATCTGACGCTCATTCCTTACCTGGCCGCTTCCGGCGAGTTGAAGACCAAGCCGACCCAACATTCGGTCAAGACCTTGCTCGAGAACGGTTTGCAGCCCGATATTCTGGTGCTGCGCACCGAGCATCCGCTCTCTGCGGAGCTCAGGCGCAAGGTGGCGCTCTTCTGCAACGTGGATGCCAACGCGGTGATGGAGTCGATCGACGTACCGACGATCTACGAAGTGCCGCTGGTGATGCACCGTCAGCATCTGGACGAGGTGGTGCTCAGCAAGCTCGACCTTCCGTCGGAGCAGGAACCCGACTTGAGTTCGTTGCAGGCTTTCGTCGATAAGGTGAAGAATCCCAAGCGGACGATCGACATCGCCCTGGTGGGTAAATATACGGAACTTCCCGATGCTTACAAGTCGATCTGCGAGTCCTTTATTCAAGCCGGTGCGGTGAACGACTGCAAGGTGAAGTTGCATTACGTGAATTCGGAGAAGATAGACGCTTCGAACGTCGGGGAGAAGCTCGGCAAAATGGCCGGTATTCTCGTGGCTCCGGGGTTCGGCAACCGGGGAATCGAGGGGAAGATCGAAGCGGTGCACTTTGCGCGGACTCACCGTATTCCGTTCCTGGGAATCTGTCTGGGTATGCAGTGCGCCGTGATCGAATTCGCTCGCAACGTACTGGGCTTCAAGGATGCCACCTCGACAGAAATGGACCCGGCGACGAAGCATCCGGTCATCGACCTGATGGAGGAACAGAAGGGCATTACCGCCAAAGGCGGCACGATGCGTCTGGGAGCTTACCCCTGCTCGCTGGTGCCGGGATCGAAAGCTGCGCAGGCTTACGGTACGACTCAGATTCAGGAGCGTCATCGCCACCGCTACGAATTCAACAGCGAATACCTGAAGGATTTCGAGAGCCACGGAATGAAAGCCGTCGGTGCGAACCCCGATACGGGGCTGGTCGAAGTGGTCGAAATTCCCGACCATCCCTGGTTCGTCGGTACGCAATACCATCCCGAATACAAGAGCACCGTACAGCGGCCTCATCCGCTTTTCGTCGCGTTCGTAGCTGCGGCGCTGGCGGGAAAAGACGATAAGAAAAAATAG",
    "translation": "MKLSKPKYIFVTGGVASSLGKGIISASIARLLQARGYSVTIQKLDPYINIDPGTLNPYEHGECYVTEDGAETDLDLGHYERFTSITTSHANNVTTGKIYQCVIDKERKGEYLGKTVQVIPHITDEIKRRIQLLAQRKEYDVIITEIGGTVGDIESLPFIESVRQLRYQLGARNTALVHLTLIPYLAASGELKTKPTQHSVKTLLENGLQPDILVLRTEHPLSAELRRKVALFCNVDANAVMESIDVPTIYEVPLVMHRQHLDEVVLSKLDLPSEQEPDLSSLQAFVDKVKNPKRTIDIALVGKYTELPDAYKSICESFIQAGAVNDCKVKLHYVNSEKIDASNVGEKLGKMAGILVAPGFGNRGIEGKIEAVHFARTHRIPFLGICLGMQCAVIEFARNVLGFKDATSTEMDPATKHPVIDLMEEQKGITAKGGTMRLGAYPCSLVPGSKAAQAYGTTQIQERHRHRYEFNSEYLKDFESHGMKAVGANPDTGLVEVVEIPDHPWFVGTQYHPEYKSTVQRPHPLFVAFVAAALAGKDDKKK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 23937,
    "end": 24207,
    "tool": "rule-based-clusters",
    "neighbouring_start": 13937,
    "neighbouring_end": 34207,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r13c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {
 "r13c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg13_12": {
     "functions": []
    },
    "ctg13_13": {
     "functions": []
    },
    "ctg13_14": {
     "functions": []
    },
    "ctg13_15": {
     "functions": []
    },
    "ctg13_16": {
     "functions": []
    },
    "ctg13_17": {
     "functions": []
    },
    "ctg13_18": {
     "functions": [
      {
       "description": "SMCOG1082:TonB-dependent siderophore receptor family ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg13_19": {
     "functions": []
    },
    "ctg13_20": {
     "functions": [
      {
       "description": "Stand_Alone_Lasso_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF05402",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg13_21": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg13_22": {
     "functions": []
    },
    "ctg13_23": {
     "functions": []
    },
    "ctg13_24": {
     "functions": []
    },
    "ctg13_25": {
     "functions": []
    },
    "ctg13_26": {
     "functions": []
    }
   }
  }
 }
};
