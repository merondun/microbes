var recordData = [
 {
  "length": 1672,
  "seq_id": "NZ_JAYAFN010000001.1",
  "regions": []
 },
 {
  "length": 1787,
  "seq_id": "NZ_JAYAFN010000002.1",
  "regions": []
 },
 {
  "length": 2300,
  "seq_id": "NZ_JAYAFN010000003.1",
  "regions": []
 },
 {
  "length": 3165,
  "seq_id": "NZ_JAYAFN010000004.1",
  "regions": []
 },
 {
  "length": 3217,
  "seq_id": "NZ_JAYAFN010000005.1",
  "regions": []
 },
 {
  "length": 3773,
  "seq_id": "NZ_JAYAFN010000006.1",
  "regions": []
 },
 {
  "length": 3821,
  "seq_id": "NZ_JAYAFN010000007.1",
  "regions": []
 },
 {
  "length": 3950,
  "seq_id": "NZ_JAYAFN010000008.1",
  "regions": []
 },
 {
  "length": 4217,
  "seq_id": "NZ_JAYAFN010000009.1",
  "regions": []
 },
 {
  "length": 3700,
  "seq_id": "NZ_JAYAFN010000010.1",
  "regions": []
 },
 {
  "length": 4380,
  "seq_id": "NZ_JAYAFN010000011.1",
  "regions": []
 },
 {
  "length": 3699,
  "seq_id": "NZ_JAYAFN010000012.1",
  "regions": []
 },
 {
  "length": 4448,
  "seq_id": "NZ_JAYAFN010000013.1",
  "regions": []
 },
 {
  "length": 4016,
  "seq_id": "NZ_JAYAFN010000014.1",
  "regions": []
 },
 {
  "length": 4462,
  "seq_id": "NZ_JAYAFN010000015.1",
  "regions": []
 },
 {
  "length": 4473,
  "seq_id": "NZ_JAYAFN010000016.1",
  "regions": []
 },
 {
  "length": 4992,
  "seq_id": "NZ_JAYAFN010000017.1",
  "regions": []
 },
 {
  "length": 5070,
  "seq_id": "NZ_JAYAFN010000018.1",
  "regions": []
 },
 {
  "length": 5229,
  "seq_id": "NZ_JAYAFN010000019.1",
  "regions": []
 },
 {
  "length": 5283,
  "seq_id": "NZ_JAYAFN010000020.1",
  "regions": []
 },
 {
  "length": 5294,
  "seq_id": "NZ_JAYAFN010000021.1",
  "regions": []
 },
 {
  "length": 5233,
  "seq_id": "NZ_JAYAFN010000022.1",
  "regions": []
 },
 {
  "length": 5585,
  "seq_id": "NZ_JAYAFN010000023.1",
  "regions": []
 },
 {
  "length": 5595,
  "seq_id": "NZ_JAYAFN010000024.1",
  "regions": []
 },
 {
  "length": 5727,
  "seq_id": "NZ_JAYAFN010000025.1",
  "regions": []
 },
 {
  "length": 5813,
  "seq_id": "NZ_JAYAFN010000026.1",
  "regions": []
 },
 {
  "length": 2205,
  "seq_id": "NZ_JAYAFN010000027.1",
  "regions": []
 },
 {
  "length": 5884,
  "seq_id": "NZ_JAYAFN010000028.1",
  "regions": []
 },
 {
  "length": 5989,
  "seq_id": "NZ_JAYAFN010000029.1",
  "regions": []
 },
 {
  "length": 6043,
  "seq_id": "NZ_JAYAFN010000030.1",
  "regions": []
 },
 {
  "length": 6226,
  "seq_id": "NZ_JAYAFN010000031.1",
  "regions": []
 },
 {
  "length": 6201,
  "seq_id": "NZ_JAYAFN010000032.1",
  "regions": []
 },
 {
  "length": 2002,
  "seq_id": "NZ_JAYAFN010000033.1",
  "regions": []
 },
 {
  "length": 7129,
  "seq_id": "NZ_JAYAFN010000034.1",
  "regions": []
 },
 {
  "length": 7281,
  "seq_id": "NZ_JAYAFN010000035.1",
  "regions": []
 },
 {
  "length": 7350,
  "seq_id": "NZ_JAYAFN010000036.1",
  "regions": []
 },
 {
  "length": 7483,
  "seq_id": "NZ_JAYAFN010000037.1",
  "regions": []
 },
 {
  "length": 8228,
  "seq_id": "NZ_JAYAFN010000038.1",
  "regions": []
 },
 {
  "length": 8380,
  "seq_id": "NZ_JAYAFN010000039.1",
  "regions": []
 },
 {
  "length": 7330,
  "seq_id": "NZ_JAYAFN010000040.1",
  "regions": []
 },
 {
  "length": 8717,
  "seq_id": "NZ_JAYAFN010000041.1",
  "regions": []
 },
 {
  "length": 3129,
  "seq_id": "NZ_JAYAFN010000042.1",
  "regions": []
 },
 {
  "length": 8787,
  "seq_id": "NZ_JAYAFN010000043.1",
  "regions": []
 },
 {
  "length": 8831,
  "seq_id": "NZ_JAYAFN010000044.1",
  "regions": []
 },
 {
  "length": 9497,
  "seq_id": "NZ_JAYAFN010000045.1",
  "regions": []
 },
 {
  "length": 21665,
  "seq_id": "NZ_JAYAFN010000046.1",
  "regions": []
 },
 {
  "length": 16270,
  "seq_id": "NZ_JAYAFN010000047.1",
  "regions": []
 },
 {
  "length": 16728,
  "seq_id": "NZ_JAYAFN010000048.1",
  "regions": []
 },
 {
  "length": 7193,
  "seq_id": "NZ_JAYAFN010000049.1",
  "regions": []
 },
 {
  "length": 23666,
  "seq_id": "NZ_JAYAFN010000050.1",
  "regions": []
 },
 {
  "length": 26979,
  "seq_id": "NZ_JAYAFN010000051.1",
  "regions": []
 },
 {
  "length": 6002,
  "seq_id": "NZ_JAYAFN010000052.1",
  "regions": []
 },
 {
  "length": 26877,
  "seq_id": "NZ_JAYAFN010000053.1",
  "regions": []
 },
 {
  "length": 5493,
  "seq_id": "NZ_JAYAFN010000054.1",
  "regions": []
 },
 {
  "length": 11739,
  "seq_id": "NZ_JAYAFN010000055.1",
  "regions": []
 },
 {
  "length": 4725,
  "seq_id": "NZ_JAYAFN010000056.1",
  "regions": []
 },
 {
  "length": 5858,
  "seq_id": "NZ_JAYAFN010000057.1",
  "regions": []
 },
 {
  "length": 33760,
  "seq_id": "NZ_JAYAFN010000058.1",
  "regions": []
 },
 {
  "length": 10453,
  "seq_id": "NZ_JAYAFN010000059.1",
  "regions": []
 },
 {
  "length": 40389,
  "seq_id": "NZ_JAYAFN010000060.1",
  "regions": []
 },
 {
  "length": 35953,
  "seq_id": "NZ_JAYAFN010000061.1",
  "regions": []
 },
 {
  "length": 22511,
  "seq_id": "NZ_JAYAFN010000062.1",
  "regions": []
 },
 {
  "length": 38097,
  "seq_id": "NZ_JAYAFN010000063.1",
  "regions": []
 },
 {
  "length": 20806,
  "seq_id": "NZ_JAYAFN010000064.1",
  "regions": []
 },
 {
  "length": 41388,
  "seq_id": "NZ_JAYAFN010000065.1",
  "regions": []
 },
 {
  "length": 59720,
  "seq_id": "NZ_JAYAFN010000066.1",
  "regions": []
 },
 {
  "length": 2404,
  "seq_id": "NZ_JAYAFN010000067.1",
  "regions": []
 },
 {
  "length": 16835,
  "seq_id": "NZ_JAYAFN010000068.1",
  "regions": [
   {
    "start": 1,
    "end": 16835,
    "idx": 1,
    "orfs": [
     {
      "start": 1,
      "end": 774,
      "strand": -1,
      "locus_tag": "ctg68_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 774,\n (total: 774 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGAAAAAATTTTTGTTTGTGGCGGCGGCGGTAGCGTCGATGGTTTTCACCGGGTGTATCAACGAGGACGACACCTATAAGAAGTTGCAACCGGTTCAGCAGGGGATCAACATCTACAACTGGACATCCAGCCAGTATTCCATGGCGACCGAGCAGGCCAACATAGGTATGCGTATGGCGATGCTCGTGGCCGAAGCCCACAAGCAGGGGGTGGATAACTTCGAGGATGTGAAAATCGAAGGCATCTCCATCAAGGGCAAGTTGCTCGGCACCTCTTCGAAGATCGAAAAGACGACCACTGGCTACAAAATCACTTTCAATCCTGCATATATGGACATGGACGGCTATTCGCGCGAGGGCGCCGTGCTGATCGACACGGGCGGGGCCCCGCTGCTCGAAGATGCCGTGGCCGGAAAGGTCTGGTCGGTGACGTTCGACGAAAAACTGGTGCTGGTTGCCACCAACGGCAATACGTCGGTAAAGGCTTCGCTGGTGGGCGGTTCCACGCAGCTCTACAACGATGAAAACGGAGCCTATGCGATCAGCATTGCGAATCAGGCCTGCTACCTCGATTCGGGCAGCAATTTTACCTCGAATTGGGGCGGCCGTATGACGTTGAAGCCCCATAACATGAATTTCACCTATTCGGATTGCATGGGCGAGAAGTTCGTCGTGAACACGACGGGTGCAATTTACGGCCCTTCGTTCTATACGATGGACAATGCAACGTCTCTGGAGCTGAGCATGACGCTGACGGATGTCGAGTATTAC",
      "translation": "MMKKFLFVAAAVASMVFTGCINEDDTYKKLQPVQQGINIYNWTSSQYSMATEQANIGMRMAMLVAEAHKQGVDNFEDVKIEGISIKGKLLGTSSKIEKTTTGYKITFNPAYMDMDGYSREGAVLIDTGGAPLLEDAVAGKVWSVTFDEKLVLVATNGNTSVKASLVGGSTQLYNDENGAYAISIANQACYLDSGSNFTSNWGGRMTLKPHNMNFTYSDCMGEKFVVNTTGAIYGPSFYTMDNATSLELSMTLTDVEYY",
      "product": ""
     },
     {
      "start": 838,
      "end": 1041,
      "strand": 1,
      "locus_tag": "ctg68_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 838 - 1,041,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAATGTGCGAATTATTCTATTTTCATCCTGCAAACCGGGCATCCGGCCCCAAATCATCGCCGCCAAAAGGTGCGCCAGGCCCGGCACAGAAAACTTCCCGGAAACCGTCCCCAACGTTTTCCCAGGTTCGATTGCGGCTCAAAGGTACGAATATTTCACTTTTTTTCACTATATTGGCGTTGTAATGTATAATATTTGA",
      "translation": "MKNVRIILFSSCKPGIRPQIIAAKRCARPGTENFPETVPNVFPGSIAAQRYEYFTFFHYIGVVMYNI",
      "product": ""
     },
     {
      "start": 1044,
      "end": 1787,
      "strand": 1,
      "locus_tag": "ctg68_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,044 - 1,787,\n (total: 744 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCAAAACTCTTGTTGCTTATGTCGATCCTATCGTTTTTCGGATGCGGAAAGAAAGCTCCCGAATACCCTGCCGACACGCTGACGACGCGCGACGGCATGCAAATCACGATCACCTTTTTCAAACACGCCTCGCTTTCGATCGAGGCCGGCGGAAAATACATCTACGTAGATCCCGTAAGCGGCTATGCCGACTACGCCGCCCTGCCCAAGGCCGACGTGGTACTTATCACCCACTCGCACTACGACCACCTGGACGTGGCGGCCGTCGAAGCGATCCAGACCCCGCAGACCGAGATACTCTGCGACCGCACATCGGCCGAGGCGTTCGAAATGAACTGCTACACGATGCGCCCGGGCAGTGTCGCTACGCCGCGCGATTACCTGAAAGTCGAGGCCGTGGCCGCTTACAACACGACCGACGGGCACCTGCAATTCCATCCCAAAGAGCGTGAGGACTGCGGCTACGTGCTCACGATAGGCGGCTCGCGCATCTACATCGCGGGCGATACCGAACCCACGCCCGAACTGAAGGCGCTGAAGAATATCGACATCGCCTTCCTGCCGGTCAACCAACCCTACACGATGACCGTCGACCAGGCCGTCGAGGCCGTCAAGGCGATCCGGCCGACGATCTTCTACCCCTACCACTACGGCGAAGTCGAGGAAAAGACCGACATCGACCGCCTCGTGCGGGAGTTGGAAGGCGTAACCGAGGTGCGCATCCGGCCGATGGAGTAA",
      "translation": "MNPKLLLLMSILSFFGCGKKAPEYPADTLTTRDGMQITITFFKHASLSIEAGGKYIYVDPVSGYADYAALPKADVVLITHSHYDHLDVAAVEAIQTPQTEILCDRTSAEAFEMNCYTMRPGSVATPRDYLKVEAVAAYNTTDGHLQFHPKEREDCGYVLTIGGSRIYIAGDTEPTPELKALKNIDIAFLPVNQPYTMTVDQAVEAVKAIRPTIFYPYHYGEVEEKTDIDRLVRELEGVTEVRIRPME",
      "product": ""
     },
     {
      "start": 1927,
      "end": 2340,
      "strand": -1,
      "locus_tag": "ctg68_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,927 - 2,340,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGGATTTTATTTTTGTTCCCCTGGTCGTAGGCGTGATTACGCTGGGAATCTACAAGTTCTTCGAATTGCTCGTGTGCCGTCGCGAGCGCCGCATGATCATTGATAAAATGGACGGCAATGCCCTGATCGACTACCTGAAATTCGTACCGATGGGTGTGAGGATCGGCGCTCCCGTATCGGTGCGGCCCGTGTCGGGCGGGGTGTCCGGAACCCTGAAGGCCGGTTGCCTTTTGCTGGGCATCGGTTTCGGGCTGCTCTTCGCCTTCATGTTGCTGAACTGGTGTGCTTATGATGCTTCGTACGAAATGCGCAGCATCGTCTACGGCGGGTCGGTTCTCTGCTTCGGCGGTGTCGGACTGATCGTTTCGTTCATCGTCGAGCGCAATATCGTCGGCAGGGAGTGTAAATAG",
      "translation": "MMDFIFVPLVVGVITLGIYKFFELLVCRRERRMIIDKMDGNALIDYLKFVPMGVRIGAPVSVRPVSGGVSGTLKAGCLLLGIGFGLLFAFMLLNWCAYDASYEMRSIVYGGSVLCFGGVGLIVSFIVERNIVGRECK",
      "product": ""
     },
     {
      "start": 2485,
      "end": 3051,
      "strand": 1,
      "locus_tag": "ctg68_5",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,485 - 3,051,\n (total: 567 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 117.7; E-value: 6.9e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAACAACAGGAGGAACTGGAGCTGATCCGACGGATCGTAAACGGAGAAACCGATCTGTATGCCATCCTTGCCCGGCGGTACGGGCGGGTGGTCTACACGCTGGTTTCCCGCATCGTCGGCTGCGCAGAGGATGCCGAGGAGCTGGCTCAGGACGTTTTCCTCAAGGCGTTCCGCAACCTGCACAGGTTCAACGGGCGCAGTTCGTTCCCGACCTGGCTCTTCCGGATCGCTTACAACACGGCGGTCTCCGAGACACGGCGCCGCAAACGCGAATGGGCCTGCATCGACCAGGCGCGGCTGGCGAACCTGCCCGACAGCGAAGCCGAGCGGATGGATGCCTGGGAGGGAAGGCAGGAATACCTCGACGCTCTGACCCGTGCCGTCGGTGAGTTGGAGCCCGAAGAGCGGGCACTCGTCACGCTCTTCTACTACGAAGAGTACTCCGTAAGCGAATGCGCCGGGATCACGCAGATGTCGGAGTCCAACATCAAAGTACGGCTCCACCGCATCCGCAAAAAACTGTATATACTGGTAAATACGCAACTGCATGGAAGCGAAAAATAA",
      "translation": "MQQQEELELIRRIVNGETDLYAILARRYGRVVYTLVSRIVGCAEDAEELAQDVFLKAFRNLHRFNGRSSFPTWLFRIAYNTAVSETRRRKREWACIDQARLANLPDSEAERMDAWEGRQEYLDALTRAVGELEPEERALVTLFYYEEYSVSECAGITQMSESNIKVRLHRIRKKLYILVNTQLHGSEK",
      "product": ""
     },
     {
      "start": 3035,
      "end": 3490,
      "strand": 1,
      "locus_tag": "ctg68_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,035 - 3,490,\n (total: 456 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAGCGAAAAATAACATAATCCGTCGCGCGCTGGAGCAAGCCCCGGGTACGCAACTGCCCGAAGGGTTCTGCGAGAGGCTCATGGAACGGCTGGAACGCGAATCGGCGCGGCGCGAACGGCGCGAAACATGGTTGCTGGGCACGGCGGGCGTACTCTGCCTGCTGGCGGTGATCGCCGGGCTCGCCTGGTATTTCTGGTACGAACCGGGCGTCGGGCTGCATCTGCCCGACATGCCTTCATTCCCCGACATGCCTTCATTCCCCGACATGCCCGCGTTCACAAGCCCGGGCTCCCTAAAATTTCCCGAACCGGATTTCCCGGCCGAAAGCAGGCGGCTGTCCCTGTTCTACGTCTTTATCGCCGCAACGTTCCTCGGCCTCGCAGGGCTCGACCTCTACCTGCGCAGGCGCAGGCACAATGCCATGAAAACAAACGGGCACCCGCACCGATAA",
      "translation": "MEAKNNIIRRALEQAPGTQLPEGFCERLMERLERESARRERRETWLLGTAGVLCLLAVIAGLAWYFWYEPGVGLHLPDMPSFPDMPSFPDMPAFTSPGSLKFPEPDFPAESRRLSLFYVFIAATFLGLAGLDLYLRRRRHNAMKTNGHPHR",
      "product": ""
     },
     {
      "start": 3731,
      "end": 4042,
      "strand": -1,
      "locus_tag": "ctg68_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,731 - 4,042,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAAAATTTTAATGCTGTGCCTTGCACTCGTGATGGGTGTGGGCATGTGTGCAGCGCAGAAGGCTGCCGACAAAAAGACGGTGACGACGGTTTTCACGACCGACATCGACTGTGAACACTGTGTCAAGAAGATCATGAATAATGTCCCCTCGCTCGGCAAGGGCGTCAAGGACGTGAAGGTCGACCTGCCCAAGAAGGAGGTGACCGTGGTCTACGATTCCACGAAAAACAGCGACGAGAATATCGTCAAGGGTTTTGCTTCGATCAAAGTCAAGGCCGAACCGAAAAAAGCCGACACGAAGAAATAA",
      "translation": "MKKILMLCLALVMGVGMCAAQKAADKKTVTTVFTTDIDCEHCVKKIMNNVPSLGKGVKDVKVDLPKKEVTVVYDSTKNSDENIVKGFASIKVKAEPKKADTKK",
      "product": ""
     },
     {
      "start": 4066,
      "end": 6402,
      "strand": -1,
      "locus_tag": "ctg68_8",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,066 - 6,402,\n (total: 2337 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 73.5; E-value: 3.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKINKIILSVSSLAVCGTLSAQDLRGVVRDADNQPLVGASVYWEGTTIGASTDAQGAFLLHRVKGYDNLVASYLGYVNDTLRVAGGAERIEFTLASEGVALEDVVVEGNLSGNFVKRDGIVKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGVASVTAGHEAITGQINLEHRKPTDDERLFVNLYLDDELRPEANISTAFPVTKDKKLSSVILLHGSMDTDVRKMDHNDDGFRDLPLSDQINVANKWLYAADNGTQIRWGWKFVQENRLGGMLDYKNSMRGEMEKNWNWKETGADMPLYGSKIRNRGANGYFKIGMPVGPSVYDADEQDEMRSNLAFVADFDHFNEYAYFGLNDYRGNENTLSLNLMYNHYFTYRSSLIVGAQGHLQYYRESFANNTPWIAAAPATLYDFDRNEQEVGAYAEYTYSIKDKFSVVAGIRGDYNAFYDKFFVTPRGHIRWNITPSTTLRGSAGLGYRSTNVITDNIGMLATGRQIVIPDFDGFNRLEKALTVGGSLTQTFGLVSPGDATLSFDYFRTQFYNSVIADQEYSADQIVLYNSDKRSYTDTYQIDFSWTPVERLDIFATFRYTDSEMTIDRPDGKTARVERPLVSQYKTLLNIQYATKFRRWVFDATAQLNGPARIPTQTGDLADDKYSPRYPMFFAQISRKVGKFDIYAGCENIADYRQHDPILNADNPYSTGFNSMNVWGPLMGRKFYIGLRFNLY\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAATCAACAAAATCATTTTATCTGTTTCTTCCCTTGCCGTGTGCGGAACCCTCAGCGCACAGGATTTGCGGGGTGTAGTCCGCGACGCCGACAACCAGCCGCTGGTGGGCGCTTCGGTTTACTGGGAGGGTACTACGATCGGTGCCAGCACCGATGCCCAGGGGGCGTTCCTGCTCCATCGGGTAAAAGGTTACGACAATCTGGTCGCCTCGTATCTGGGATATGTGAACGACACGCTGCGTGTGGCAGGCGGTGCGGAGCGTATCGAATTCACGCTCGCTTCCGAAGGCGTGGCGTTGGAGGACGTGGTGGTCGAGGGTAATCTGAGCGGCAACTTCGTCAAGCGTGACGGCATCGTCAAGGGCGAGATGATCTCGTTCGCGGGCCTCTGCAAGATGGCCTGCTGCAATCTGGCCGAGAGCTTCGAGAACTCGGCGTCGGTGACCGTCGGGTACAGCGACGCCATTTCGGGCGCACGGCAGATCAAGATGCTCGGCCTGGCAGGTACCTATACCCAGATCCTCGACGAAAACCGCCCGATCATGCGCGGGCTGAGCGCCCCCTACGGACTGAGCTACACGCCCGGCATGTGGCTCAATTCGATTCAGGTGTCGAAGGGCGTGGCGTCGGTGACGGCCGGGCATGAGGCCATCACGGGGCAGATCAACCTCGAGCACCGCAAGCCGACGGACGACGAGAGGCTGTTCGTGAACCTCTATCTGGACGACGAACTGCGCCCCGAGGCCAACATCTCGACGGCGTTCCCCGTCACGAAGGACAAGAAACTGTCGAGCGTCATCCTGCTCCACGGTTCGATGGATACCGACGTCCGTAAGATGGATCACAACGACGACGGATTCCGCGACCTGCCGCTCTCCGACCAGATCAATGTGGCCAACAAGTGGCTTTATGCGGCCGACAACGGTACGCAGATCCGCTGGGGATGGAAATTCGTACAGGAGAACCGCCTGGGCGGTATGCTCGACTACAAGAATTCGATGCGCGGCGAGATGGAGAAGAACTGGAACTGGAAGGAGACGGGCGCCGATATGCCCCTCTACGGTTCGAAGATCCGCAACCGCGGCGCGAACGGTTATTTTAAAATAGGTATGCCCGTCGGCCCGTCGGTCTACGATGCCGACGAGCAGGATGAGATGCGTTCGAACCTGGCTTTCGTGGCCGATTTCGACCACTTCAACGAGTACGCCTATTTCGGGCTGAACGACTACCGCGGCAATGAGAATACGCTCTCACTGAACCTCATGTACAACCACTATTTCACCTACCGGTCGTCGCTGATCGTCGGTGCACAGGGACATTTGCAGTACTACCGCGAGAGTTTTGCTAACAACACCCCGTGGATTGCGGCGGCTCCGGCTACGCTCTACGACTTCGACCGCAACGAGCAGGAAGTGGGTGCCTATGCCGAGTATACCTATTCGATCAAGGACAAGTTCTCGGTCGTGGCGGGTATCCGCGGCGATTACAATGCGTTTTATGACAAGTTCTTCGTGACGCCCCGCGGGCATATCCGCTGGAACATCACCCCCTCGACCACGCTGCGCGGCTCGGCCGGCCTGGGATACCGTTCGACCAATGTCATCACCGACAACATCGGTATGCTGGCGACCGGACGGCAGATCGTAATCCCCGATTTCGACGGTTTCAACCGGCTGGAGAAGGCACTTACGGTGGGCGGAAGCCTCACGCAGACCTTCGGGCTGGTCAGTCCCGGCGACGCAACGCTGAGTTTCGACTATTTCCGCACGCAGTTCTACAATTCGGTGATCGCCGACCAGGAGTACAGCGCCGACCAGATCGTGCTCTATAATTCGGACAAGCGTTCCTATACGGATACCTACCAGATCGACTTTTCGTGGACGCCTGTCGAACGGTTGGACATCTTCGCCACGTTCCGTTATACGGACAGCGAGATGACGATCGACCGCCCCGACGGAAAGACCGCCCGCGTGGAACGGCCGCTGGTGAGTCAGTACAAGACGCTGCTCAATATCCAGTACGCCACGAAATTCCGCCGCTGGGTGTTCGACGCGACGGCACAGCTGAACGGCCCTGCGCGCATCCCGACGCAGACGGGCGACCTGGCCGACGACAAGTATTCGCCGCGCTACCCGATGTTCTTCGCCCAGATAAGCCGCAAGGTCGGCAAGTTCGACATCTATGCCGGTTGCGAGAACATCGCCGACTACCGCCAGCACGACCCGATCCTCAATGCGGACAACCCCTATTCGACGGGTTTCAACTCGATGAACGTATGGGGGCCGCTGATGGGGCGCAAATTCTATATCGGCCTGCGGTTCAATTTGTATTGA",
      "translation": "MKINKIILSVSSLAVCGTLSAQDLRGVVRDADNQPLVGASVYWEGTTIGASTDAQGAFLLHRVKGYDNLVASYLGYVNDTLRVAGGAERIEFTLASEGVALEDVVVEGNLSGNFVKRDGIVKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGVASVTAGHEAITGQINLEHRKPTDDERLFVNLYLDDELRPEANISTAFPVTKDKKLSSVILLHGSMDTDVRKMDHNDDGFRDLPLSDQINVANKWLYAADNGTQIRWGWKFVQENRLGGMLDYKNSMRGEMEKNWNWKETGADMPLYGSKIRNRGANGYFKIGMPVGPSVYDADEQDEMRSNLAFVADFDHFNEYAYFGLNDYRGNENTLSLNLMYNHYFTYRSSLIVGAQGHLQYYRESFANNTPWIAAAPATLYDFDRNEQEVGAYAEYTYSIKDKFSVVAGIRGDYNAFYDKFFVTPRGHIRWNITPSTTLRGSAGLGYRSTNVITDNIGMLATGRQIVIPDFDGFNRLEKALTVGGSLTQTFGLVSPGDATLSFDYFRTQFYNSVIADQEYSADQIVLYNSDKRSYTDTYQIDFSWTPVERLDIFATFRYTDSEMTIDRPDGKTARVERPLVSQYKTLLNIQYATKFRRWVFDATAQLNGPARIPTQTGDLADDKYSPRYPMFFAQISRKVGKFDIYAGCENIADYRQHDPILNADNPYSTGFNSMNVWGPLMGRKFYIGLRFNLY",
      "product": ""
     },
     {
      "start": 6468,
      "end": 6881,
      "strand": -1,
      "locus_tag": "ctg68_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,468 - 6,881,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTGAAAAGACTCATATCGCTGTTGCTGCTCGCCATCTACCTGACGGCGTGGGGCGGCCCTGCGTATGTGTCGCTTTCGTGCAAGTGCGTCACGATGTCGTCGCATGTCTGCTGCCACCACTGCCAGCACAGCGCCGATGCCGCGGGTGCCGGCGAGTCGCTGAAGGCTCCCTGCTGCGGCAACCACCATTCGACCGAAATCGAACTCTATACGGGTTCTTCTTCCGATAACCACGAGAGATTCATCCGCTGCACGGTCACCGACCTGCCGCCCGCATTGGTTGCGGAGGCTCCGGTCGCGGCCGTCCTCAAGTTCTTCGGGGAGACGCTTCCCGAATGCGGCGATCCTTTCGTCATGCGGGGCCATGTGCGCTCCGCAGGCCTTCGTGCCCCTCCCGTATTGGCTTAA",
      "translation": "MKLKRLISLLLLAIYLTAWGGPAYVSLSCKCVTMSSHVCCHHCQHSADAAGAGESLKAPCCGNHHSTEIELYTGSSSDNHERFIRCTVTDLPPALVAEAPVAAVLKFFGETLPECGDPFVMRGHVRSAGLRAPPVLA",
      "product": ""
     },
     {
      "start": 6928,
      "end": 7194,
      "strand": -1,
      "locus_tag": "ctg68_10",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,928 - 7,194,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGATAAGCGAAAAATTCAAAGTGCGCGAGATGGCGGGGGAGCATGTGATTATCATGCCGGGCCGCTGCGGTGCCGACATGACCCGTATCCTGGCGCTCAACGATTCGTCGCTCTATCTTTGGGAGGCGCTCGGCGGCAAGGACTTTACCACCGGGGACGCAGCCGCCCTGTTGTTGGAGCGTTACGACGTGGACGAAGCCACCGCACAGCGCGATGCCGGGGCCTGGGCTGCGAAGCTCGCCGAATGCGGCGTGCTGGAGTAA",
      "translation": "MKISEKFKVREMAGEHVIIMPGRCGADMTRILALNDSSLYLWEALGGKDFTTGDAAALLLERYDVDEATAQRDAGAWAAKLAECGVLE",
      "product": ""
     },
     {
      "start": 7269,
      "end": 9203,
      "strand": 1,
      "locus_tag": "ctg68_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,269 - 9,203,\n (total: 1935 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 292.4; E-value: 1e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAAGGCCAGCGGACAAGATATACGACGTACTGAAACGCTACTGGGGCTTCACCGAATTCCGCCCCGTACAGGAGCGTATCATCCGTTCGGTGATGGACGGGCGCGACACCCTGGCCCTGATGCCCACGGGCGGCGGAAAGTCGCTTACCTACCAGATCCCCGGGCTTGCGCAGGAGGGGCTGTGCATCGTCGTGACGCCCCTGATCGCCCTGATGAAAGACCAGGTCGACCGCCTGCGGGCACGGCACATCCCGGCCGTGGCGATCCATTCGGGGCTCTCGCCGCGTGCAATCGACATCGCGCTGGACAACTGCGTCTACGGCGACGTCAAGTTCCTTTACGTCGCCCCCGAGCGGCTCGCAACGGAGGCCTTCCGCCTGCGCGTCGTGCGCATGAACGTATCGCTCGTGGCCGTCGACGAAGCCCACTGCATCTCGCAGTGGGGCTACGATTTCCGCCCCTCGTACCTGCGCATCGCCGAGCTGCGCGAAAAACTACCCGGCGTCCCGGTGCTGGCGCTCACGGCCTCGGCCACGAAACTCGTGGCCGAAGACATCATGCGCCACCTGCGGTTCGCCGAACCGCATATCCTGCGGAGCAGCTTCGCACGTCCCAACCTTTCGTACAGCGTCCGCCACACCGACGACAAGAACGGGCAGCTGCTGCGCCTGGTACGCAACGTCCCCGGCTCGGGCATCGTCTACGTCCGTACGCGCGAAGGCACCGAGCAGGTCGCCGACATGCTGCGCAGGGAGGGCATAACGGCCGCGGCCTACCATGGGGGCATGGGGCATGCCGAACGCTCGCTGCGGCAGGAGGAGTGGGTCTCGGGCAGGACGCGCGTGATGGTCGCCACCAACGCCTTCGGCATGGGCATCGACAAACCCGACGTGCGCTTCGTCGCCCATTACAGCATGTGCGACTCGCTCGAGAGCTACTACCAGGAGGCCGGCCGAGCGGGCCGCGACGGTATGCGGAGCTACGCCCTGCTGCTGGTCTCGTCGGACGACGGCGAACGCATCGTGCGGCGTTTCGAGCAAGAGTTCCCGCCGCTCGAAAAGATCAAGGACATCTACGAACGGGTCTGCTCCTACCTGCAGGTCGGCATCGGCGACGGCGCCCAGGCATCGTTCCTGTTCAACATCCACGACTTCTGCGCCCGCGAGCACCTCTACTCCGGCACGGTCGTAAGCGCCCTGAAGCTCCTGCAGCAAAACGGGTACATGACGCTGACCGACGCACAGGAGAACCCGGCGCGGATCATGTTCTGCGTGAGCCGCGACGACCTCTACAAACTCCGCGTGCAGCGCGACGAGCTGGATCACTTCATCCGCACGCTGCTGCGCCTCTACAACGGGGTCTTCACCGAATTCCGGCAGATCGACGAGGGCGAGATCGCCACCTGGAGCGGCTATACCGTACAGCGGGTCAAGGAGCTGCTCAAACGCCTCTGGCAGTTGCGCGTGATCCGCTACGTCCCCTCCAACCGCTCGCCGATCCTCTTCATGGACGAGGAGCGGCTGCCCCGCGCCGACCTCTACATCGCCCCCGAGACCTACAAACGGCGGCAGGAGCTGATGCGCGAACGCTTCGAACACATGCTCGCCTACGCCGCGAACGAGACCCGTTGCCGCAGCGCCGTTCTGGAAGGGTATTTCGGTGAAGGCGCCCCTGCGGCATGCGGCGTATGCGACATCTGCCTCGCACACAAACGTGCCGGGAAGCGGCAGGCACAGGGCTGCGCCACGCCGTCGGCCGACGGCGGGCTGCGCGAAAAACTGCGGCAAAGGCTATCCCGCGGGGCAGCCGACCCGCACGAACTGGCCGCGGAATTCCCCGGGGAGGCACAGCAGATAGGCCGGGCGCTGCGCGAATTGCTCGACGAAGGCATCGCCGGCACGGGCAGGGACGGGAAAATCGGGTTAAAATAG",
      "translation": "MERPADKIYDVLKRYWGFTEFRPVQERIIRSVMDGRDTLALMPTGGGKSLTYQIPGLAQEGLCIVVTPLIALMKDQVDRLRARHIPAVAIHSGLSPRAIDIALDNCVYGDVKFLYVAPERLATEAFRLRVVRMNVSLVAVDEAHCISQWGYDFRPSYLRIAELREKLPGVPVLALTASATKLVAEDIMRHLRFAEPHILRSSFARPNLSYSVRHTDDKNGQLLRLVRNVPGSGIVYVRTREGTEQVADMLRREGITAAAYHGGMGHAERSLRQEEWVSGRTRVMVATNAFGMGIDKPDVRFVAHYSMCDSLESYYQEAGRAGRDGMRSYALLLVSSDDGERIVRRFEQEFPPLEKIKDIYERVCSYLQVGIGDGAQASFLFNIHDFCAREHLYSGTVVSALKLLQQNGYMTLTDAQENPARIMFCVSRDDLYKLRVQRDELDHFIRTLLRLYNGVFTEFRQIDEGEIATWSGYTVQRVKELLKRLWQLRVIRYVPSNRSPILFMDEERLPRADLYIAPETYKRRQELMRERFEHMLAYAANETRCRSAVLEGYFGEGAPAACGVCDICLAHKRAGKRQAQGCATPSADGGLREKLRQRLSRGAADPHELAAEFPGEAQQIGRALRELLDEGIAGTGRDGKIGLK",
      "product": ""
     },
     {
      "start": 9281,
      "end": 9904,
      "strand": 1,
      "locus_tag": "ctg68_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,281 - 9,904,\n (total: 624 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCCACGGCATGACTACGACAAACAACTTTACGGATAAGATCAGCAACGAGGAGGCCGCAGCGCTTCCGGCCATCGAATTCAGGGGCGAAATACGCATCGTCGACAATGAGCGCGACATCGTCCCCGCCTGCAAATTCCTGATGAAACAACGCGTCATCGGTTTCGACACCGAGACCCGCCCGTCGTTCCGGCCCGGGGTGACGTTCCGCGTGTCGCTGCTGCAACTCTCCACGCCGCAGCTATGCTTCCTCTTCCGGCTGAACAAGATCCCGCTCGCCAAGCCGATCCTGCAGGTGCTCGAAAGCCAGGAGATCCTGAAAATCGGCGCCGACGTCGCGGGCGACCTGCGCTCGTTGCGCCAGATACGCCATTTCCGCGACGCAGGGTTCGTCGACCTGCAAACGATAGCCCCCCAATGGGGCATCGGGGAGAAGAGCCTGCGCAAACTCTCGGCCATCGTGCTGGGGCAGCGCGTATCGAAGGCTCAGCGGCTGAGTAACTGGGAGGCCGCGACATTCACCGACAAACAAAAACTCTACGCCGCGACCGATGCGTGGGTCTGCACGGCGATCTACGACCGACTGCTTCACACACCCAAAATCAAACATCCCGAATTATGA",
      "translation": "MFHGMTTTNNFTDKISNEEAAALPAIEFRGEIRIVDNERDIVPACKFLMKQRVIGFDTETRPSFRPGVTFRVSLLQLSTPQLCFLFRLNKIPLAKPILQVLESQEILKIGADVAGDLRSLRQIRHFRDAGFVDLQTIAPQWGIGEKSLRKLSAIVLGQRVSKAQRLSNWEAATFTDKQKLYAATDAWVCTAIYDRLLHTPKIKHPEL",
      "product": ""
     },
     {
      "start": 9901,
      "end": 11100,
      "strand": 1,
      "locus_tag": "ctg68_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,901 - 11,100,\n (total: 1200 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACACCTCAAGTATACCTGCGCAAAGGCAAGGAAGAATCGCTCATGCGCCGCCACCCGTGGATTTTCTCGGGCGCCATCGACCACATCAAGGCCGAAGACGAATCGGAAATCACGGAAGGCGCCCTGGTCGAAATATATACCCGCACGGGCGATTTCATCGCCCTGGGACACTACCAGATCGGCTCGATCGCCGTGCGTGTGCTTACATTCGACAAGGAACCGATCGACCAGGACTGGTGGAACCGGCGCATCGCCGTGGCCTACGACGTGCGGCGCACGCTCGGGCTCACGGACAACCCCGACACGGACTGTTACCGCCTCGTCCACGGCGAAGGCGACGGGCTCCCGGGACTGGTCGTGGATATCTACGGCACGGTGGCCGTCATCCAGTGCCACTCCGTCGGCATGTACCTCGCCCGCCAGGACATCGCGCGGGCGATCCTGGCCGCCTACGGCGACCGCATCACGGCCATCTACGACAAGAGTTCGCAAACCGTGCCCTTCAACGCCAAGCTGGGCGCTGTGGACGGCTACCTGTGGGGAAGTTCCGACCATTCGGCGCACGTGGTAACGGAGAACGGCGAGAAATTCCTCGTCAACTGGGAGCAGGGGCAGAAAACCGGGTTCTTCCTCGACCAGCGCGAAAACCGGGAGCTGGTCAAACGCTACTCGAAGGGGCGCACGGTGCTCAACACCTTCTGCTACACGGGGGGCTTCTCGGTCTATGCCATGGCCGGTGGCGCCGAGAAGGTCTGCTCGGTGGACTCTTCGGAACGCGCCGTCGTGCTGGCCACGGAAAACATGAAACTCAACTTCGGCCCGCAGGCCAACTTTACGGAAACAGCCGCCGATGCCGTGGAGTACCTCAAGGACATCGAAGACAAATACGACCTGATCATCCTCGACCCGCCGGCTTTCGCCAAGCACCACAAGGTGCTGGGTAATGCCATGCAGGGCTACAAGCGCCTCAACGCCCGCGCCATATCGCAGATACGCCCCGGCGGCATCCTCTTCACGTTCTCCTGCTCGCAGGCGGTGTCGAAGGAGCTGTTCCGCACGATGATTTTCTCGGCCGCGGCCATCGCGGGCCGCAACGTGCGCATCCTGCACCAGCTGACGCAGCCCGCCGACCACCCGGTGAGCATCTACCACCCCGAAGGCGAGTACCTCAAGGGACTGGTGTTGTATGTAGAATAG",
      "translation": "MTPQVYLRKGKEESLMRRHPWIFSGAIDHIKAEDESEITEGALVEIYTRTGDFIALGHYQIGSIAVRVLTFDKEPIDQDWWNRRIAVAYDVRRTLGLTDNPDTDCYRLVHGEGDGLPGLVVDIYGTVAVIQCHSVGMYLARQDIARAILAAYGDRITAIYDKSSQTVPFNAKLGAVDGYLWGSSDHSAHVVTENGEKFLVNWEQGQKTGFFLDQRENRELVKRYSKGRTVLNTFCYTGGFSVYAMAGGAEKVCSVDSSERAVVLATENMKLNFGPQANFTETAADAVEYLKDIEDKYDLIILDPPAFAKHHKVLGNAMQGYKRLNARAISQIRPGGILFTFSCSQAVSKELFRTMIFSAAAIAGRNVRILHQLTQPADHPVSIYHPEGEYLKGLVLYVE",
      "product": ""
     },
     {
      "start": 11122,
      "end": 11481,
      "strand": 1,
      "locus_tag": "ctg68_14",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,122 - 11,481,\n (total: 360 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1167:transcriptional regulator (Score: 119.3; E-value: 6.7e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAAAAACCGCACACCCGACCTACGCCCACTGCCCGATCCGCCATATCGTCGACCGCTTCGGGGACAAGTGGTCGCTGCTGGTACTCTACAACCTCCATACGAGCGGGTGCCTGCGTTTTTCGGAAATCCACCGCCGGACGGCCGACATCTCGCAGAAGATGCTCACATCGACACTCCGCAAGCTGGAACAGGACGGGCTGCTGTCGCGCAAGGTCTACCCCGAGGTACCGCCCCGCGTGGAATATGCGCTCACGCCCCGCGGCGAGTCGCTCATGCCCCACCTCACAGCGCTTATCGGGTGGGCAGAGGAAAATTTCGACGCCATCCTCGAAGACCGGGAGCGGGAAAAGATATAG",
      "translation": "MEKTAHPTYAHCPIRHIVDRFGDKWSLLVLYNLHTSGCLRFSEIHRRTADISQKMLTSTLRKLEQDGLLSRKVYPEVPPRVEYALTPRGESLMPHLTALIGWAEENFDAILEDREREKI",
      "product": ""
     },
     {
      "start": 11758,
      "end": 12612,
      "strand": -1,
      "locus_tag": "ctg68_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,758 - 12,612,\n (total: 855 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACGAACTTTTTTTGTATTGCTCCTGTTGGCGGCCGGAACCGCACTCCGGGCGCAGACACTGGGCGGGGAGTACCGCCTGTCGCGGGTTTTCCCGGTCGAAGGCCGGCAGGGGATCGCCGCTGACTCGAACTACTATTATGTTTCGGGCAGCACGGTGCTCTACAAGTACGACAAGCAGGGGCGGCTGGTCGCCCGTAACGGGCAGCCGTTCGAAGGGTTGCCGCTCGCCGCGAACCATATCGGCGATATCGACGTCTGGAACGGTGAGATTTATGCCGGCATCGAGACTTTCGAAGACGGTAAGGGTGAGAATATCCAGGTCGCCGTGTACGATGCCGACGACCTGACATGGAAGCGGTCGATCGATTGGGAACCGGCTTCGGGGCAGGTCGAGGTGTGCGGGCTGGCCGTAGACCGCGACCGGAATATGGTCTGGATGGCCGACTGGGTCGACGGGCGCTACCTGTACGGTTATGACCTGGCGACGGGTAAGTATGTGCGCAAAGTCCACCTGCGCCCGGTGCCGCAGTGGCAGCAGGGGATATATATGGCCGGCGGGCAGATGCTCATTTCGGCCGACGACGGCGATGCCGACCTGGACGAGCCGGACAACCTCTATATTGCCGACCTGCGCGACGGGAAAAGCTATGCTACGGTGTTGCCGTTCCGTATGATGTCCGATTTCCGGCGCGCGGGCGAGATCGAGGGGCTGACCGTCGACCCTGCGACGGATGAGCTGCTGGTACTTTCGAACCGGGGTTCGCGCATCGTGCTGGGAATGGTCAGGGGTTTCTACCCGGGGTACGACAGCGAACTGCACGAAGTGTATGTCTATGAAAAGGTAAAATAG",
      "translation": "MKRTFFVLLLLAAGTALRAQTLGGEYRLSRVFPVEGRQGIAADSNYYYVSGSTVLYKYDKQGRLVARNGQPFEGLPLAANHIGDIDVWNGEIYAGIETFEDGKGENIQVAVYDADDLTWKRSIDWEPASGQVEVCGLAVDRDRNMVWMADWVDGRYLYGYDLATGKYVRKVHLRPVPQWQQGIYMAGGQMLISADDGDADLDEPDNLYIADLRDGKSYATVLPFRMMSDFRRAGEIEGLTVDPATDELLVLSNRGSRIVLGMVRGFYPGYDSELHEVYVYEKVK",
      "product": ""
     },
     {
      "start": 13169,
      "end": 15115,
      "strand": -1,
      "locus_tag": "ctg68_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,169 - 15,115,\n (total: 1947 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATAAAAAAACAATTTTAGGTATTGTCGTCGTGGCGGCGCTTTTCCTGGGGTTCGCCTATTTCAATACCAAACAGCAGGAGAAATATCAGCAGGAAATGGCCGCGTATCAGGCCTACCAGGATTCGGTGGCGGCAGCGACGCGCCCCGTAGTCCCCGTAGCCGACAGTACGGCCGTGGCAGCTTCGAGTGCGGTTGTGCCCGAGGCTGAGGCAAATGCCGCTGATGCCGTACGCCGGCAGCAGGTCGCTGCGCTGGGCGAATACCTCGCCGGTGCGCGCGACGCGGAGGCGGAGGAGTTTACCGTCGAGAACGATGTGATGATCGTGACCTTTTCGACCCGCGGCGGCCGGATCACGGGCGTGACGCTCAAGGATTACACCAAGTATGCACCCCGCGGCAAGCGTGACCAGCTGATCGAGCTGATGGATCCCGCGAGTGCCAGGTTCGACCTTTCGTTCTACGTGAAGAACGGCTTGAACAACGTCAAGGTCAACACGATGGACTATGTCTTCCGGGCCCAGCCCGAACAGGTCGAAGGCGATGCCCGGAGGGTGGTGATGCGCCTGCCCGTGGCAGCGGATGCCTGGCTCGAATATGAGTACCTTATATATAATAAGCAGGTGCCCGAGCGCGACTACCTCGTGGACTTCAACGTGCGGCTGGTGAATATGGCGCCGCAGATGGCCAACCAGGCGTCGATCGGTATCGACTGGTCGAACAATTCCTACCAGAACGAAAAGGGATTCCAGAACGAGAACATGTACACGACGATTTCGTACCGGTTCCCGGGCGAGAGCTCGATCGAGGATCTGGGGATGAGCGAAAAATCCAAGTCGAAGAGCATCTCCACATCGGTCAACTGGGTGGCTTTTAAGCAGCAGTTCTTTTCGTCGGCGTTCATCGCCCCGCAAAATGTCACCAACGCCAACCTGGCGTTCGATACGGCGGCTCCCGGTTCGGAATTGCTGAAGAGTTTTTCGGCGCAGATGACCGTGCCCTATACGGTGCAGACCGAAGGGTATGACTTTGCATTCTATTTCGGCCCGAACAAATACGCCATCCTCAAGAAGGTCGCCGCTGCGGACGGTGAGGAACTGCACATGGAGCGCCTGATCCCGCTGGGATGGGGTATCTTCGGCTGGGTGAACCGCTGGTGCGTCATCCCGGTCTTCGACTTCCTGCGCAACTATATCGCCAGCTTCGGCATCATCATCCTGATCCTGGTGATCCTGGTGAAACTCGTCATCTCGCCCCTCACGTACAAGAGTTACGTTTCGATGGCAAAGATGCGCCTGATAAAACCGCAGGTGGACGAGCTCAACAAGAAATACCCCAAGAAGGAGGACGCCATGAAAAAACAGCAGGCGACGATGGAGCTCTACAAGAAAGCGGGCATCAACCCCATGGGCGGATGTATCCCCATGCTGATCCAGATGCCGATCCTGATCGCCATGTTCCGTTTCTTCCCGGCTTCGATCGAGCTGCGCGAACAACCGTTCCTCTGGGCCGACGACCTTTCGTCGTACGACAGCATCGTGAACCTGCCGTTCTCGATCCCGTTCTACGGCGACCATGTGAGCCTTTTCGCCTTGCTGATGGCCGTGTCGCTGTTCGGGTATTCGTATTTCAACTACCAGCAGACGGCTTCGTCCCAGCCCCAGATGGCAGGTATGAAGTTCATGATGGTCTACATGATGCCGATCATGATGCTGTTGTGGTTCAACAGCTATTCGAGCGGCCTTTGCTACTACTACCTGCTGTCGAACCTCTTTACCATCGGCCAGACGTTGCTGATCCGCCGCATGGTCGACGACGATAAGATCCATGCCGTCATGCAGGCCAATGCCGCCAAACGGAGCAAGGGCAAGAAGTCGAAGTTCCAGCAGCGCTACGAGGAGCTCCTCCGCCAGCAGGAGGCGCAGCAGCGTACCAAACGCAAGTAA",
      "translation": "MDKKTILGIVVVAALFLGFAYFNTKQQEKYQQEMAAYQAYQDSVAAATRPVVPVADSTAVAASSAVVPEAEANAADAVRRQQVAALGEYLAGARDAEAEEFTVENDVMIVTFSTRGGRITGVTLKDYTKYAPRGKRDQLIELMDPASARFDLSFYVKNGLNNVKVNTMDYVFRAQPEQVEGDARRVVMRLPVAADAWLEYEYLIYNKQVPERDYLVDFNVRLVNMAPQMANQASIGIDWSNNSYQNEKGFQNENMYTTISYRFPGESSIEDLGMSEKSKSKSISTSVNWVAFKQQFFSSAFIAPQNVTNANLAFDTAAPGSELLKSFSAQMTVPYTVQTEGYDFAFYFGPNKYAILKKVAAADGEELHMERLIPLGWGIFGWVNRWCVIPVFDFLRNYIASFGIIILILVILVKLVISPLTYKSYVSMAKMRLIKPQVDELNKKYPKKEDAMKKQQATMELYKKAGINPMGGCIPMLIQMPILIAMFRFFPASIELREQPFLWADDLSSYDSIVNLPFSIPFYGDHVSLFALLMAVSLFGYSYFNYQQTASSQPQMAGMKFMMVYMMPIMMLLWFNSYSSGLCYYYLLSNLFTIGQTLLIRRMVDDDKIHAVMQANAAKRSKGKKSKFQQRYEELLRQQEAQQRTKRK",
      "product": ""
     },
     {
      "start": 15156,
      "end": 16775,
      "strand": -1,
      "locus_tag": "ctg68_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,156 - 16,775,\n (total: 1620 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACTTTCCAAACCCAAGTACATATTTGTTACGGGCGGTGTCGCATCGTCGCTCGGCAAGGGTATTATTTCGGCCTCGATCGCCCGCCTGCTGCAGGCCCGAGGCTATTCGGTGACCATCCAGAAACTTGACCCCTACATCAACGTCGACCCCGGCACGCTGAACCCCTATGAACACGGCGAATGCTACGTGACCGAGGACGGCGCCGAGACCGACCTCGACCTGGGGCACTACGAGCGTTTCACGAACCAGCCCACGTCGAAGGCCAACAACGTCACGACGGGAAAGATCTACAAGAGCGTGATCGAGAAGGAGCGCAAGGGCGAGTACCTGGGCAAGACCGTGCAGGTCATCCCCCATATCACCGACGAGATCAAGCGCCGTATCCAGATGCTGGCGCAGAAGAAAGTTTACGACGTGATCATCACCGAGATCGGCGGTACGGTGGGCGACATCGAGTCGCTGCCGTTCATCGAATCGGTACGCCAGCTGCGCTATTCGCTGGGCTACAAGAGCACGGCCCTCGTGCACCTGACGCTGATCCCCTATATGGCCGCTTCGGGCGAACTGAAGACCAAGCCCACGCAGCATTCGGTCAAGGCCCTGCTCGAAAACGGGTTGCAGCCCGACATCCTCGTGCTGCGCACGGAGCATCCGCTGTCGACCAACCTGCGCCGCAAAGTGGCGTTATTCTGCAATGTCGACGCCAACGCCGTGATGGAGTCGATCGACGTGCCGACGATCTACGAAGTGCCGCTGAAGATGCACGAACAGCACCTCGACGAGGTGGTGCTCGACAAACTGAACCTGCCGGCCGAGAAGGAACCCGACATGGCGGCGTGGACGGCCTTCGTGGAGAAGGTGAAGCACCCGGCCAAGAAGATCGAGATCGCGCTGGTTGGCAAATATACCGAATTGCCCGACGCTTACAAGTCGATTTGCGAATCATTCATCCATGCAGGGGCCGTGAACGACTGCAAGGTCAAGTTGCGCTATGTCAATTCGGAAAAGGTTACAGCCGAGAATGTGGCCGAGAAGCTGGGCAGGATGTCCGGTATCCTCGTGGCCCCGGGCTTCGGCAACCGTGGCATCGAAGGTAAGATCGTCGCTGTGCGCTATGCACGTGAGAACAAGATCCCGTTCCTGGGAATCTGCCTCGGTATGCAGTGCGCCGTGATCGAATTCGCACGCAACGTGCTGGGTCTGGCCGATGCGAATTCGAGCGAAATGGAGTCTACGCCCCATCCGGTGATCGACCTGATGGAAGAGCAGAAGGGCGTGACGGCCAAGGGCGGCACGATGCGGCTGGGCGCTTATCCCTGTACGCTGAAGAAAGGTTCGAAAGTCGCGGCGGCCTACGGCAAGCTCCATATTTCGGAGCGTCACCGTCACCGTTACGAATTCAACAATGATTACCTGGCTGCGTTCGAAGGTGCCGGTATGCAGGCCGTGGGTATCAATCCCGACACGGGGCTGGTCGAGGTCGTCGAGGTCGAGGGGCATCCCTGGTTCGTCGGTACGCAGTACCATCCCGAATATAAGAGTACGGTGCTGAGCCCCTCGCCGCTGTTCGTGGCATTTGTGGGAGCGGCACTCGAATATGCCGGGAAGAAATAA",
      "translation": "MKLSKPKYIFVTGGVASSLGKGIISASIARLLQARGYSVTIQKLDPYINVDPGTLNPYEHGECYVTEDGAETDLDLGHYERFTNQPTSKANNVTTGKIYKSVIEKERKGEYLGKTVQVIPHITDEIKRRIQMLAQKKVYDVIITEIGGTVGDIESLPFIESVRQLRYSLGYKSTALVHLTLIPYMAASGELKTKPTQHSVKALLENGLQPDILVLRTEHPLSTNLRRKVALFCNVDANAVMESIDVPTIYEVPLKMHEQHLDEVVLDKLNLPAEKEPDMAAWTAFVEKVKHPAKKIEIALVGKYTELPDAYKSICESFIHAGAVNDCKVKLRYVNSEKVTAENVAEKLGRMSGILVAPGFGNRGIEGKIVAVRYARENKIPFLGICLGMQCAVIEFARNVLGLADANSSEMESTPHPVIDLMEEQKGVTAKGGTMRLGAYPCTLKKGSKVAAAYGKLHISERHRHRYEFNNDYLAAFEGAGMQAVGINPDTGLVEVVEVEGHPWFVGTQYHPEYKSTVLSPSPLFVAFVGAALEYAGKK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 6927,
      "end": 7194,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 16835,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r68c1"
   }
  ]
 },
 {
  "length": 6700,
  "seq_id": "NZ_JAYAFN010000069.1",
  "regions": []
 },
 {
  "length": 10566,
  "seq_id": "NZ_JAYAFN010000070.1",
  "regions": []
 },
 {
  "length": 29866,
  "seq_id": "NZ_JAYAFN010000071.1",
  "regions": []
 },
 {
  "length": 5261,
  "seq_id": "NZ_JAYAFN010000072.1",
  "regions": []
 },
 {
  "length": 51972,
  "seq_id": "NZ_JAYAFN010000073.1",
  "regions": []
 },
 {
  "length": 34468,
  "seq_id": "NZ_JAYAFN010000074.1",
  "regions": []
 },
 {
  "length": 2963,
  "seq_id": "NZ_JAYAFN010000075.1",
  "regions": []
 },
 {
  "length": 11373,
  "seq_id": "NZ_JAYAFN010000076.1",
  "regions": []
 },
 {
  "length": 67984,
  "seq_id": "NZ_JAYAFN010000077.1",
  "regions": [
   {
    "start": 1,
    "end": 30049,
    "idx": 1,
    "orfs": [
     {
      "start": 2,
      "end": 478,
      "strand": -1,
      "locus_tag": "ctg77_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 478,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGATAGCGTCACTTCTTTTCATCCCCGCCCTGCTCCTGTCGGGGCTGACGGCCCGGGCCGGGCTGCCCGCGTCGTTCAAAGAGCGGCTCGCCGAAGCCAGCCGCGAGAACAGGACTATCCAGTGCGACTTCACGCAGCGCAAACAGGTGCGCCGCATGAAGAACGAGATCGAGCTCAAAGGCCGCTTCTATTACGACAACAGCCTGGCCATGGCGCTCGACTACACCGTGCCCGAAGGCGACAAGGTGATTATCCGCAACGACCGCATCATCCTCAAAACGGCCGGGCAGGTGACCCAGACCGCGACGTCGGCCAACCCCATGCTGCAACAGGTGGCGCTGATGATCCGCGCCAGCATGACCGGCGACCTCTCGCAGTTCGGCCAAGGGTGGCAGATCGGCTACACCGAAAAGGAGGGTGTCGGGGAGGTGAAAATGGTTCCCGAGTCGAAGCGCGCCCGCAAGTACATCGAC",
      "translation": "MKIASLLFIPALLLSGLTARAGLPASFKERLAEASRENRTIQCDFTQRKQVRRMKNEIELKGRFYYDNSLAMALDYTVPEGDKVIIRNDRIILKTAGQVTQTATSANPMLQQVALMIRASMTGDLSQFGQGWQIGYTEKEGVGEVKMVPESKRARKYID",
      "product": ""
     },
     {
      "start": 475,
      "end": 1161,
      "strand": -1,
      "locus_tag": "ctg77_2",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 475 - 1,161,\n (total: 687 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1235:polysaccharide deacetylase (Score: 124.1; E-value: 1.1e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTATGTAATTATCGCCATAATCGCCGCGGGGTTCGCCCTTTTCTACTGCTCCTACCAGATCAGGCTGGGGGCGTATGTCCGCAGCCTGTGCCGCAACCGGGCGGCGGGGCGCGTCGTGGCGCTGACGTTCGACGACGGGCCCGACCCCGAGCAGACGCCGCGCGTATTGGACACGCTGCGGGCGCACGGCGTACGGGCGACCTTCTTCCTGATCGGCAGCAAGGCCGAACTGCACCCGGAGATCGTACGCCGTATGGCCGCCGAGGGGCATGCAATCGGCATTCACACGTGGAGCCACACGCCCGGCTTCCCGATGCTGCGAAGCGGGGCGATGGCGGCCGACATCCTGCGGTGCCGGGAGTCGCTGCGCGAGATAACCGGCGTGGAAACCGACCTTTTCCGGCCCCCCTACGGGGTCACGAACCCGATGGTGGCACGCGCCGTGAAACGGACGGGAAGCCGCTGCGTGGGCTGGAGCATCCGCTCGCTCGACACGCTCCGGCAGCGCAGCCGTGAGGCCGTGGCACGCCGCATCCGCCGACGGCTGGGCGACGGCAAGGTGATCCTGCTGCACGACGACCGCCCCGGTGCCGAACGGCTACTGGCGATGGTGCTGAACGACCTGCAACGCGGGGGCTACCGCACGGCGACCGTATGCGAACTGTTTAAAACCGAGAAACCATGA",
      "translation": "MYVIIAIIAAGFALFYCSYQIRLGAYVRSLCRNRAAGRVVALTFDDGPDPEQTPRVLDTLRAHGVRATFFLIGSKAELHPEIVRRMAAEGHAIGIHTWSHTPGFPMLRSGAMAADILRCRESLREITGVETDLFRPPYGVTNPMVARAVKRTGSRCVGWSIRSLDTLRQRSREAVARRIRRRLGDGKVILLHDDRPGAERLLAMVLNDLQRGGYRTATVCELFKTEKP",
      "product": ""
     },
     {
      "start": 1152,
      "end": 2198,
      "strand": -1,
      "locus_tag": "ctg77_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,152 - 2,198,\n (total: 1047 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACTCTACGTCAACTGCATCACATCGGGCGCCGGGCTGCGCCGCGACATCAAGGAGCTGATCCCCGAAATGAACCTCCGCCGGAGGATGAGCCGTGTGGTGAAGTCGGGCGTCGCGGCGGGCATCGAATCGCTGTTGGAATTCGGCGACCGGGCGGCGGTCGAGGCCGTCGTCACGGCCACGGGGCTAGGGTGCATCGCCGACAGCGAGAAATTCCTCGACTCGCTGATCGCCAACGAAGAGCGGATGCTCAACCCGACGCCGTTCATCCAGTCGACGTTCAACACGGTCGGGGCGCAGATCGCCCTGCTGCGCGGGCTGCACTGCTACAACACGACCTACGCCAACCGCTGGACGAGCTTCGAGAACGCCCTGACGGATGCCGCACTGCGCATCGGCGCGGGGCTGTCGCGGGCGGTGCTGGTCGGGGCGTTCGACGAGACGACGCCGTCGGTCGAAAAGGTACTGCAACGCCTCGGGATGGCACAGCAGGGCGGCTGGGGCGAATCGTCGGTATTCTTCGTGCTGACCGCCGAAGCGTTCGACACCTCGGTCGCGGCGATCACGGGGATCCGGTTCACGGACGGCACAGCCATCGGGGAAAGCGCCGGCAGTGAATTCCCGGACGGGGAAAGCGCCGGCACGGGAAGAATCCAGTCCCGGGAAGATGCCGGCACAAGGACATCGGCCGGGGGAAACGCCGGCCGTGAAATCCCGGCCGGGGGAAGTCCCGGCACGGGGGCGGCCGCCGGGAACGGGGAGGAACCAGGGAATGCGATGCATAGCGGCGAGTGCCGGACGGTACGTGCGTCGATGAGCGGCGTGACGCCCCATTTCACGGCCATCGCCGAGGTGTTCCGCCGTGTGGTCGCCGGGGAGGCCGGGAATACGGGTAAGGCCGGAAATATCGGGAACGCCGGGAGCATCGAGGACACCGGGAACACCGGGAACATCGGGAACGCGGGGAACGCCGAGCAGAGGATCGTGCTTTACAACGATTTCCCGGGCAGCACCGTATCCGCCATCGAATTGACATGTATGTAA",
      "translation": "MKLYVNCITSGAGLRRDIKELIPEMNLRRRMSRVVKSGVAAGIESLLEFGDRAAVEAVVTATGLGCIADSEKFLDSLIANEERMLNPTPFIQSTFNTVGAQIALLRGLHCYNTTYANRWTSFENALTDAALRIGAGLSRAVLVGAFDETTPSVEKVLQRLGMAQQGGWGESSVFFVLTAEAFDTSVAAITGIRFTDGTAIGESAGSEFPDGESAGTGRIQSREDAGTRTSAGGNAGREIPAGGSPGTGAAAGNGEEPGNAMHSGECRTVRASMSGVTPHFTAIAEVFRRVVAGEAGNTGKAGNIGNAGSIEDTGNTGNIGNAGNAEQRIVLYNDFPGSTVSAIELTCM",
      "product": ""
     },
     {
      "start": 2195,
      "end": 3358,
      "strand": -1,
      "locus_tag": "ctg77_4",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 3,358,\n (total: 1164 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 244.4; E-value: 3.6e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCATAGCCGTCTGCGGCATAGGGATCGTCTCGGCCATCGGCATCGGAGCCGGGGAGACGCTCGGGAACCTGCGCACCGGACGCAGCGGAATCGGGAAGCCGACGCTTCTCGGTTCGGCTGTCGACGTGCCCGTGGGCGAGGTGAAGCGGGACAACGCGGCGCTCGGGGAGCTGCTCGGCATCCCGGAGCGCGAGCACCCCTCCCGCACCGCCCTGCTGGGCATGGCGGCGGCCGCACAGGCCGTAGCGGATGCGGCGATCCCCGCCGGGGCGCGCGTAGCACTCGTTTCGGGCACCTCGGTAGGCGGCATGGATCTGACGGAGAATTTCTACCGCGACTTCCGCACGGACAAGGCGAAAGGGCGGCTGCGCGACGTGGCGGGGCACGACTGTGCCGACAGCACGCAACGGATCGCCCGCTACTGCGGCATCGGAGGTTACACGGCGACGGTCAGCACGGCCTGCTCGTCGGCCGCAAACGCCATCGTCACCGGCGCCCTGCTGCTCGGGAGCGGCATGGCCGACTATGTGGTGGCCGGGGGCACGGATGCCCTTTGCCGTTTCACGCTCAACGGCTTCAACTCGCTCTCGGTGCTCGACCGGGAACCCTGCCGCCCGTTCGACGCCACGCGCGCCGGGCTGAACCTGGGCGAAGGGGCGGGTTACCTCGTCCTCACGCACGAAAGGCCCGGCATGCGCACCTACTGCCGCCTGGCGGGATATGCCAATGCCAACGACGCCTATCACCAAACGGCCTCGTCGCAAACGGGCGAGGGGGCATACCGCGCCATGGCCGGGGCGCTGGCACAAAGCGGGCTGCGCTGCGTGGACTACATCAACGTCCACGGCACGGCGACCCCGAACAACGACCTCACGGAAGGTACCGCCCTGCGGCGACTGTTCGGCGGACAGGTGCCGCCGTTCAGTTCGACGAAAGGCTACACGGGGCATGCGCTCGCCGCGGCGGGAGGCATCGAGGCCGTATTGGCGGTGCTGGCTATCACACACGGGCTGCGCTACGGCAACCCCGGATTCGCGGAGCCGATCCCGGAGCTCGGGCTGCACCCCGTAGCACGGACGCAAGAGGCCGACGTACGTTCGGTGCTCTCAAATTCGTTCGGGTTCGGCGGCAACTGCTGTTCGTTAATCTTTGCCAAATGA",
      "translation": "MSIAVCGIGIVSAIGIGAGETLGNLRTGRSGIGKPTLLGSAVDVPVGEVKRDNAALGELLGIPEREHPSRTALLGMAAAAQAVADAAIPAGARVALVSGTSVGGMDLTENFYRDFRTDKAKGRLRDVAGHDCADSTQRIARYCGIGGYTATVSTACSSAANAIVTGALLLGSGMADYVVAGGTDALCRFTLNGFNSLSVLDREPCRPFDATRAGLNLGEGAGYLVLTHERPGMRTYCRLAGYANANDAYHQTASSQTGEGAYRAMAGALAQSGLRCVDYINVHGTATPNNDLTEGTALRRLFGGQVPPFSSTKGYTGHALAAAGGIEAVLAVLAITHGLRYGNPGFAEPIPELGLHPVARTQEADVRSVLSNSFGFGGNCCSLIFAK",
      "product": ""
     },
     {
      "start": 3355,
      "end": 5496,
      "strand": -1,
      "locus_tag": "ctg77_5",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,355 - 5,496,\n (total: 2142 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (rule-based-clusters) ketoacyl-synt<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 159.5; E-value: 2.1e-48)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGAGGTGAAATAACGGTCTGGTGGGGCCCCGACGACATGGTATCGGCGCTGGGCTTCGGCACGGAGGAGAACATGGCCGCCGTACGTGCCATGAAAAGCTCGCTGGCGTCGTGGCACGACGCCACACCCGTATGCCTGATCGACCGGAAGCGGCTCGGGGCGCTGGCGGCGGAGCAGGGACTCGCGGGATATACGCCCCTGGAACGGCTCGTGCTGGCGACGCTGGGCGGGGTGGTCGCCCGCTCGGGGGTCACACCCGCCGACAAGCGGGCGCTGATCGTCCTGGCGACGACCAAAGGGGAGATCGGGTCGCTGGGGAGCGCCCCGGAGCGATGCGACCTGAACAGAACCGCGGAGGTCGTGGGGCGTTATTTCGGCACCGCGCACCGGCCGCTGCTGATCTCGAACGCCTGCATCTCGGGGGTTTCGGCCATCGTCATCGCGGCACGGCTGATCCGCAGCGGCCGGTACGACCATGTCTTCGTGGCAGGATTCGACCTGCTGAGCGACTTCATCGTCAGCGGATTCAACGCCTTCAAGTCGGTGAGCCCGACGCTTTGCCGTCCCTACGATGCGGCACGCGACGGGCTGACGCTGGGCGAAGCGTGCGGCGCCGTCCTGCTGACACGCGACCGACGGCTCTCGGGCACGGGCGTGAGCGTGGCGGGAGGCGGAATTTCGAACGACGCCAACCACATATCGGCGCCTTCGCGCACAGGCGACGGGCTCTGGTACGCTATCCGCGCGGCACTCGCCGAGGCGGGAACCGGAGCCGGGGAGGTCGGGCTGGTAAACACCCACGGCACGGCGACCGCCTACAACGACGAGATGGAGAGCAAGGCGCTGCACCTGGCGGGATTGTGCGGCGTACCCTGCAACTCGCTGAAGCCCTATTTCGGACATACGCTGGGGGCTTCGGGCGTGATCGAGAGCATCGTCACGGTACGGGAGCTGTGCGAGGGCACCTGCTTCGGGGTGAAGGGCTACGCGGAGTGCGGGGTACCCTACCCGCCCGACGTGAGCGCCGCGCACCGCGAAATACGGACGGACACGGCGCTGAAAACCGCCTCGGGATTCGGGGGTTGCAACGCCGCGGTCGTATTCCGCCGCGCAGCGGGCTCCGACGCCGCGCCCGGAAATGAAACGGCGGAGGGACAAGGGTGTGGGCCAAACACAGGTGTGCAAGGCGGGAACGACTGCCTGGAGGCTGCCCGTGCCCGAAGCGGAACGGCTATGAGCGCGAATGACCGGGCGCGGGGCAAAAATGCGGTCGGGCACGGGAATCCGGACACCGGAGAAAAGGCCGACGGCCATGCGGAAACCGGCACAGGACGACACGGCAGCGGAATCCGCTGTCACGATACGGCTCACGTCGTCATTGCGCAACACCCTTCGCTGCCGTTCGACGCCTTCATCCGCGAAAGATACCGGGCGCTCGCAGACCCGAACATGAAGTTCTCGAAGATGGACGACCTGTGCAAGCTGGCCTACGTCGCCTCGTGCGAACTGCTTTCCGGACACAGGCCCGATTGCCCGGCGGAGCGCATCGGCGTGGTGATGGCCAACCGCAGCGCCTCGCTCGACAGCGACCGGCGCCACCAGGCGATTATCGACGCCGGGGACGGGTGCGGGGCTTCACCGGCGGTGTTCGTCTACACGCTGCCCAACATCATGCTGGGGCAGGTGGCGATCAAGCACGGGCTGAAGGGAGAGAGCACTTTTTTTGCGTTCCCGGACAAAAGCAGTAACTTTATCCGGGAATATGCCGCTTCGCTGATCGCCGAAGGGCGCATGGACGCCGTCCTGTGGGGCTGGTGCGAATTCGACGGCGGCAGCTACGACTGCGAACTGACATTAACCGAAAAAACGGGACAAGATACGATGGAAGATCTGGAACTGCAACTCAAACAACAAATTATCGAAGCGCTGAACCTCGAGGAGATCACCGCCGACGAGATAGCGACCGACGCGCCGCTGTTCGGCGACGGGCTGGGACTCGACTCGATCGACGCACTGGAAATCACCCTCCTGCTCGAAAAACACTACGGCATACGGCTGGCGAACCCGGCCGAAGCCAAACCGATATTCTATTCGGTAGCCACGCTGGCCGACTTTATCCGCAAGAACCGCCCGCAATGA",
      "translation": "MGGEITVWWGPDDMVSALGFGTEENMAAVRAMKSSLASWHDATPVCLIDRKRLGALAAEQGLAGYTPLERLVLATLGGVVARSGVTPADKRALIVLATTKGEIGSLGSAPERCDLNRTAEVVGRYFGTAHRPLLISNACISGVSAIVIAARLIRSGRYDHVFVAGFDLLSDFIVSGFNAFKSVSPTLCRPYDAARDGLTLGEACGAVLLTRDRRLSGTGVSVAGGGISNDANHISAPSRTGDGLWYAIRAALAEAGTGAGEVGLVNTHGTATAYNDEMESKALHLAGLCGVPCNSLKPYFGHTLGASGVIESIVTVRELCEGTCFGVKGYAECGVPYPPDVSAAHREIRTDTALKTASGFGGCNAAVVFRRAAGSDAAPGNETAEGQGCGPNTGVQGGNDCLEAARARSGTAMSANDRARGKNAVGHGNPDTGEKADGHAETGTGRHGSGIRCHDTAHVVIAQHPSLPFDAFIRERYRALADPNMKFSKMDDLCKLAYVASCELLSGHRPDCPAERIGVVMANRSASLDSDRRHQAIIDAGDGCGASPAVFVYTLPNIMLGQVAIKHGLKGESTFFAFPDKSSNFIREYAASLIAEGRMDAVLWGWCEFDGGSYDCELTLTEKTGQDTMEDLELQLKQQIIEALNLEEITADEIATDAPLFGDGLGLDSIDALEITLLLEKHYGIRLANPAEAKPIFYSVATLADFIRKNRPQ",
      "product": ""
     },
     {
      "start": 5481,
      "end": 5924,
      "strand": -1,
      "locus_tag": "ctg77_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,481 - 5,924,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTACGCAGGAAAAAGAGCGAGGCGAGCCTCGTGAACAAGACATCGCTGCGCGTGAGGTTCAGCGAAGTGGATTCGATGCAGATCGTGTGGCACGGCGAATACGTGCGTTATTTCGAGGACGGGCGCGAGGCGTTCGGCCGCGAATTCGCAGGGCTGGGTTACATGGACATCTATGCCAGCGGCTACACGGCGCCGATCGTCGAGTTGCACCTGCAATACAGGAAACCGCTGAAAGTGAATGACACGGCCGTGGTGGAAACCCGCTATATCGCCACCGAGGCGGCGAAGGTCTGTTTCGAGTACACGATTCGCAGCGCCACCGACGGCGAAGTGGTGGCCGAAGGCAGCTCGACACAGGTGTTTCTCGACAGCCGAGGCGAACTGCAACTGCTCGCGCCGGAGTTCTACCGCAAATGGAAAGAGCGATGGGAGGTGAAATAA",
      "translation": "MVRRKKSEASLVNKTSLRVRFSEVDSMQIVWHGEYVRYFEDGREAFGREFAGLGYMDIYASGYTAPIVELHLQYRKPLKVNDTAVVETRYIATEAAKVCFEYTIRSATDGEVVAEGSSTQVFLDSRGELQLLAPEFYRKWKERWEVK",
      "product": ""
     },
     {
      "start": 5924,
      "end": 6364,
      "strand": -1,
      "locus_tag": "ctg77_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,924 - 6,364,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGAGTACCTGAGAAAACCCTGATTACGGGGGAGGAGATACTGGAATACATCCCGCAGCGCCCGCCGGTCGTGATGGTCGACACCTTTTACGGCATCGACGAGCGGGGGTGCGCACGCAGCGGGCTGACCGTTACGGCGGACAACCTGCTCGTTGCGGACGGGGTGCTGGACGAGTGCGGCATCGTGGAGCACATCGCCCAGTCGGCCGCCCTGAGGGCGGGTTACATGAACCGCACGATGGGCCGAAGGGTGCAGCTGGGGTACATCGGCGCCGTGAACGACCTGAAGGTGCACTTCCTGCCGCCGGTGGGCAGCAGACTCGTCACACAGAACATGGTCGAGCAGACGGTGATGAACGTAACGCTTCTTTCGGCACGGACGGAATGCGACGGGAAACCCGTCGCCGAGTGCCGGATGAAAATATACCTGGAAGAGTGA",
      "translation": "MGVPEKTLITGEEILEYIPQRPPVVMVDTFYGIDERGCARSGLTVTADNLLVADGVLDECGIVEHIAQSAALRAGYMNRTMGRRVQLGYIGAVNDLKVHFLPPVGSRLVTQNMVEQTVMNVTLLSARTECDGKPVAECRMKIYLEE",
      "product": ""
     },
     {
      "start": 6340,
      "end": 7698,
      "strand": -1,
      "locus_tag": "ctg77_8",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,340 - 7,698,\n (total: 1359 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n  other (smcogs) SMCOG1277:Radical SAM domain protein (Score: 190.8; E-value: 6.5e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCGCATGCAGCATATTACTCGTATCGGCCAACCGGCACACCTCGCCCTACCCCGTTTATCCGCTCGGACTTTCGTACCTGAAAACCTATCTGGAGCGCACGATAAGCGGGATACGCGTCGATATGGCGGACTGCAACCTGCTCACGGACGGGCAGCTGGCGGAGCGTATCCGCATGCTGGCACCCCGTTACATCGGGCTGTCGCTGCGCAATGTCGACGGGGCCAACTCGCTCGACCGGCGGGGTTTCCTGCCCCAGTACAGGGCGCTGGCGGACGTCATACGCGCGGCAAGCGACGCCCCCCTGATCATCGGCGGCGCAGGGTTCTCGATCTACCCCGAGGCCTTCATGCGGGAGCTGGGCGCCGACTACGGCATCCACGGCGAAGGCGAAGGGCCGCTCGCGGAGCTGATCGGGGCGCTGGAGCGCGGCCGGACGGAGATCGACATCCCGTCGGTCTACACCCGCGACGGACGCCGCGGAAGCGGCCGCAGGAGCTACCTGCCGTCGATCGAGGTGCAGTTCGAGCCCGAGTTAACGGGCTATTACTGGAAGCGGAGCGGGATGCTCAACATACAGACCAAGCGGGGGTGCCCCTACGACTGCATCTATTGTTCGTACCCCTCGATCGACGGGCGGTGCGTGCGGACGATGGATCCGGAGGCGATCGCCGGAAACATCCTCCGCGCCAAGCGCGACTACGGGATCAGCTACCTGTTTTTCACCGATTCGGTGTTCAACATCAGCCCGGAATACAACGTCCGGCTGGCCGAGACGCTGATCCGCCGCCGCACGGATATCCGCTGGGGCGCCTACTTCTCGCCGCGGGGCATCGACGCAGAGCAGATGCGGCTGTTCCGGGCTTCGGGGCTTACGCACATCGAATTCGGCACCGAGTCGTTCTGCGACCGGACGCTGGAGGCTTACGGCAAGCATTTCACGTTCGGCGACGTCGTGCGGGCAAGCCGGCTCGCGCTGGACGAGGGCGTCTACTACGCCCACTTCCTGATCCTGGGCGGCTACGGCGACACGCGCGAAAACGTGCGCGAAACGATCGAAAACTCGCGGCGGATGGAGTACACCGTCATGTTCCCCTATGCGGGCATGCGCATCTACCCGCATACGCGGCTGGCGGAGCTGGCCGCGAAAGAGGGTGCCATCGGCCGGGACGACGACCTGATGGCGCCGAGCTACTATATCTCCCGGGATTTCGACCTGGAAGAGGTGCGGCGCGCGGCATTGGCCACGGGCAAGGCGTGGGTTTTCCCCGACGACCCGCAGAGCGCGCTGGCGGATACGCTGCGGTTGAAACGAAATAAAAAAGGGCCTTTATGGGAGTACCTGAGAAAACCCTGA",
      "translation": "MSACSILLVSANRHTSPYPVYPLGLSYLKTYLERTISGIRVDMADCNLLTDGQLAERIRMLAPRYIGLSLRNVDGANSLDRRGFLPQYRALADVIRAASDAPLIIGGAGFSIYPEAFMRELGADYGIHGEGEGPLAELIGALERGRTEIDIPSVYTRDGRRGSGRRSYLPSIEVQFEPELTGYYWKRSGMLNIQTKRGCPYDCIYCSYPSIDGRCVRTMDPEAIAGNILRAKRDYGISYLFFTDSVFNISPEYNVRLAETLIRRRTDIRWGAYFSPRGIDAEQMRLFRASGLTHIEFGTESFCDRTLEAYGKHFTFGDVVRASRLALDEGVYYAHFLILGGYGDTRENVRETIENSRRMEYTVMFPYAGMRIYPHTRLAELAAKEGAIGRDDDLMAPSYYISRDFDLEEVRRAALATGKAWVFPDDPQSALADTLRLKRNKKGPLWEYLRKP",
      "product": ""
     },
     {
      "start": 7695,
      "end": 8573,
      "strand": -1,
      "locus_tag": "ctg77_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,695 - 8,573,\n (total: 879 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGAAATAACGGCAAACAGTGGAGCGGACGCTCGCGCGGCGGCGGTTTCGGGTACAATTTCTTCATCCTGCTGATGAAGGTGGCCGGAATACGCAGCGCGTATGCCTTCCTCTCGCTGGTAGTCGTCTATTTCATCCCCTTCGCACCCCGCGCCACGCGGGCCGTATGGTTCTATAACCGCCGCATCCTGGGATACGGCAGGCTGCACTCGGCGGTGAAGCTCTACGCCCACTACTATGCGCTCGGGCAGACGATCATCGACCGGGTGGCTATCGGCAGCGGCATGGAGCGAAAATACAAATTCGAATTCGAAAACTACGACGCTTTCCTGCGCGTGCTCGACGGCGGGCGCGGGGCGGTGATCATCGGCGCACACGTCGGATGCTGGGGCACGGGGGCCGGGTTCTTCGGGGACTACGCCCGCAAGATGCACCTGGTGATGTACGACGCCGAATACCGGCAGATCAAAAGCGTCATGGAGAAACATTGCGGGCAGGAGGGCTACAAGGTGATCGCGGTGAACGAGGGCGGCATCGAGTCGATCCTCCGCATCAAGGAGGTGCTCGACCGCAAGGAGTACGTCTGCTTCCAGGGCGACCGCTTCGTCGAGGGCAGCCCGACGGTGACGCTACCTTTCATGGGGCACGAAGCGCCGTTCCCGGCGGGGCCGTTCGCCGTCGCCGGGAAATTCCGCGTCCCGGTGGTCTTCTACTATGCCATGCGCGAGCGCGGCAGGCGCTACCGGTTCATCTTCGACATCCCGGACGGGCAGCCCATGACCCGCGACGCCGTGCTGGGCAGCTACGTACGCTCGCTCGAAGCCGTGGTGAGACGCTACCCGCAGCAGTGGTTCAACTTCTATCGATTCTGGTCGTGA",
      "translation": "MGNNGKQWSGRSRGGGFGYNFFILLMKVAGIRSAYAFLSLVVVYFIPFAPRATRAVWFYNRRILGYGRLHSAVKLYAHYYALGQTIIDRVAIGSGMERKYKFEFENYDAFLRVLDGGRGAVIIGAHVGCWGTGAGFFGDYARKMHLVMYDAEYRQIKSVMEKHCGQEGYKVIAVNEGGIESILRIKEVLDRKEYVCFQGDRFVEGSPTVTLPFMGHEAPFPAGPFAVAGKFRVPVVFYYAMRERGRRYRFIFDIPDGQPMTRDAVLGSYVRSLEAVVRRYPQQWFNFYRFWS",
      "product": ""
     },
     {
      "start": 8563,
      "end": 8811,
      "strand": -1,
      "locus_tag": "ctg77_10",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,563 - 8,811,\n (total: 249 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAGAACAGGAACTCATAGAAAAGATCGATACCGTACTGGCCGATGAATTCGAAGTCGACCGGACGACCATCACGCCCGAAGCCCCGCTGCTGGAGACGCTCGACCTGGACAGCCTCGACCTGGTGGACGTCGTGGTGATCGTCGACAAGAACTTCGGCGTAACGCTCACGGGCCCCGATTTCAAGGAGCTGAAGACCTTCCGGGACTTCTACGACCTGATTATCAGCCGGACGAATGGGAAATAA",
      "translation": "MTEQELIEKIDTVLADEFEVDRTTITPEAPLLETLDLDSLDLVDVVVIVDKNFGVTLTGPDFKELKTFRDFYDLIISRTNGK",
      "product": ""
     },
     {
      "start": 8826,
      "end": 10049,
      "strand": -1,
      "locus_tag": "ctg77_11",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,826 - 10,049,\n (total: 1224 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 290.6; E-value: 3.5e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAGAGAGTAGTCATCACCGGAATGGGCATCTGGGCCTGCATCGGAAAAAATACGGAAGAAGTCACGCAATCGCTCCGCGAAGGACGCTCGGGCATCGGGCTCGACCCGGCGCGCAGGGAGCTGGGATACATCTCGTCGCTGACGGGGATCGTGGAACAACCGAACCTGAAAGGGGTGCTCGACCGCCGCAAGCGGCTGTGTCTGCCCCAGCAGGGCGAATATGCCTACATGGCCACCGCCGAGGCGATGCGCAACGCCGGAATGGACGAGGCCTACCTGGCGGCGAACGAGGTGGGAATCATCTACGGCAACGACAGCAGTGCGGCGCCGGTGATCGAGGGGATCGACATCATCCGCGCCAGGCGGAACACGGCGATGGTCGGCTCGGGCAATATTTTCCAGTCGATGAACTCGACCGTGACGATGAACCTCTCGGTGATCTTCAACCTGCGGGGCATCAACCTCACGCTCTCGGCGGCCTGCGCCAGCGGGTCGCACGCCATCGGCATGGGTTACCTGATGATCAGGCAGGGGTTGCAGGAGCGCGTGGTCTGCGGCGGCGCACAGGAGGTGAACCTCTACTCGGTGGGCAGCTTCGACGGGCTGGGGGCATTCTCGGCCCGCGAATCGGATCCCGCGGCGGCATCGCGCCCCTTCGACAAAGACCGCGACGGGCTGGTGCCGAGCGGAGGCGCGGCGACGGTGATCCTCGAAAGCCATGAATCGGCCGTCGCACGGGGCGCCGAAATCCTGGGCGAAGTGGTCGGGTACGGGTTCTCGTCGAACGGCGAGCATATCTCCGTGCCGAACGTTGACGGCCCGCGCCGTTCGCTGCTGCGGTGTCTGGAGGACGCCGGAATGCGGCCCGAAGAGATCCCCTACGTCAATGCGCACGCCACCTCGACGCCGCTGGGCGACTACAACGAGGCGGAGGCGATAGCCGGGGTATTCGCCGGGTGCAACCCCTACGTGGCGTCGACCAAGTCGATGACCGGCCACGAAATGTGGATGGCCGGGGCGAGCGAAGTGGTCTACTCGATGCTGATGATGCGGCACGGGTTCATCGCCCCGAACATCAACTTCACCGAGGGCGACGAGGCCACCTCGAAGCTCAACATCCCCGTCCGCAGGGTGGACACGGAGTTCGACTGCTTCCTCTCGAACTCGTTCGGCTTCGGCGGCACCAACTCGACCCTGATCGTTAAGAAATACAAATAA",
      "translation": "MEKRVVITGMGIWACIGKNTEEVTQSLREGRSGIGLDPARRELGYISSLTGIVEQPNLKGVLDRRKRLCLPQQGEYAYMATAEAMRNAGMDEAYLAANEVGIIYGNDSSAAPVIEGIDIIRARRNTAMVGSGNIFQSMNSTVTMNLSVIFNLRGINLTLSAACASGSHAIGMGYLMIRQGLQERVVCGGAQEVNLYSVGSFDGLGAFSARESDPAAASRPFDKDRDGLVPSGGAATVILESHESAVARGAEILGEVVGYGFSSNGEHISVPNVDGPRRSLLRCLEDAGMRPEEIPYVNAHATSTPLGDYNEAEAIAGVFAGCNPYVASTKSMTGHEMWMAGASEVVYSMLMMRHGFIAPNINFTEGDEATSKLNIPVRRVDTEFDCFLSNSFGFGGTNSTLIVKKYK",
      "product": ""
     },
     {
      "start": 10054,
      "end": 10794,
      "strand": -1,
      "locus_tag": "ctg77_12",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,054 - 10,794,\n (total: 741 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 207; E-value: 5.5e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAAAACGAATAAATACGCACTCGTGACCGGCGGCAGCCGGGGCATAGGCCGCGAAATCTGCCTCAAACTGGGCGGGTGCGGCTACCACGTGCTCGTCAACTACAAGTCGAACGCCGCCGAGGCCGAAAAGACCCTGTCGGGCATCCGCGCCGCAGGCGGCGACGGCGAGGCACTGCAATTCGACGTGGCCTCGGGCGAAGAGAGCACGGCGGCCATCGAGGCATGGCAGAAAGCGCACGAAGGCGCCTGCATCGAGGTGGTGGTGAACAACGCGGGCATCCGCGACGACGTGCTGATGATGTGGATGGAACCGCAGCAGTGGCACTCGGTGATCGGCACCAGCCTCGACGGGTTCTACAACGTCACGCGGCCGCTGCTCAAGGGGATGCTCGTGAACCGGTTCGGGCGCATCGTCAACATCGTCTCGCTCTCGGGCATCAAGGGGCTGCCCGGGCAGGCCAATTACGCCGCGGCCAAGGGCGGCGTGATCGCCGCGACCAAGGCGCTGGCGCAGGAGGTGGCCAAAAAGGGGGTGACGGTGAATGCCATCGCCCCGGGATTCGTGCGCACGGACATGACCGCCGACATCGACGAGGCGGAGCTCCGCAAACAGATACCTGCCGGACGCTTCTGCGAACCGGCCGAAGTCGCCGACCTGGCGATGTTCCTCATCTCGGAACAAGCCTCCTATATCACGGGAGAGGTCATTTCGATCAACGGGGGCTTATATACCTGA",
      "translation": "MAKTNKYALVTGGSRGIGREICLKLGGCGYHVLVNYKSNAAEAEKTLSGIRAAGGDGEALQFDVASGEESTAAIEAWQKAHEGACIEVVVNNAGIRDDVLMMWMEPQQWHSVIGTSLDGFYNVTRPLLKGMLVNRFGRIVNIVSLSGIKGLPGQANYAAAKGGVIAATKALAQEVAKKGVTVNAIAPGFVRTDMTADIDEAELRKQIPAGRFCEPAEVADLAMFLISEQASYITGEVISINGGLYT",
      "product": ""
     },
     {
      "start": 10804,
      "end": 10896,
      "strand": -1,
      "locus_tag": "ctg77_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,804 - 10,896,\n (total: 93 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAGCTCCTGACCACCCTGACCGCGACATTGTGCTGTCTTTCCGGCGCTTTCGCCGCTCGCTGGGCGAGGAGTTGCAGCAAGCTATAA",
      "translation": "MKKLLTTLTATLCCLSGAFAARWARSCSKL",
      "product": ""
     },
     {
      "start": 10893,
      "end": 12416,
      "strand": -1,
      "locus_tag": "ctg77_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,893 - 12,416,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTACGTTCGAACCTAAATACCATAAACGCCCGGATTTTCAACAAGACCGCAATACGGATCGACGACCAGGCGCTGCGCGAAGTGGAGGCGTGTTACCGTTTCCTGGAGAAATTCGAGCAGGGAAAGGTCATCTACGGCATCAACACGGGGTTCGGCCCCATGGCGCAGTACCGGATCGGCGACGCCGACCTGAACAGCCTCCAGTACAACATCATCCGTTCGCACAGCTGCGGCGCGGGCGAGGCACTGCCCGACATCTGCGTGCGGGCGGCGATGCTGGCGCGGCTGCAAACGTTCCTCAACGCCAAGTCGGGCGTACACCCCGACGTGGTGCGGATACTGGCCGATTTCCTCAACAACGAAATTTACCCGCTCGTGCCGCGCCACGGCAGCGTGGGCGCAAGCGGCGACCTGGTGCAGCTGGCGCATATCGCACTGGCGCTGATCGGCGAAGCGGAGGTCTCGTTCCGGGGCGAAACCGTCCCGGCAGCAGAGGCGATGGCGGCATGCGGCATAACGCCCCTCAGGCTTCGCATCCGCGACGGGCTGGCGCTCACGAACGGCACGGCCGTGATGACGGGCATCGGACTGGTGAACCTGGCCCAGGCGCGCCGCCTGCTGGGGTGGGCGGTGAAGGCATCGGTGATGCTCAACGAAATCGTAGAGTCGTACGACGACTTCATGGCCGGGGCGCTCAACGAATACAAACTCCACGCGGGGCAGATCGAGATCGCCCGGCAGATGCGCGCCATATGCGCCACGAGCCGCCGGCTGCGCAAGCGCGAAGCGGAACTTTACAGCGGCGACACGGGCGCGGCACCCACCTTCAGGCACAAGGTGCAGCCCTACTACTCGCTGCGGTGCATCCCCCAGATCCTGGGGCCGGTGCTCGAAACGATCTCCCAGGCCGAGAAAATCCTCGTCGAGGAGTTCAACGCGGTGGACGACAACCCGGTGGTAGACCCCGCGGCGGGGACGATCTACCACGGCGGGAATTTCCACGGCGACTACGTGTCGCTGGAGATGGACAAGCTCAAGATCGCCGTGACGAAGATGACGATGCTCGCCGAACGGCAGCTGAACTACCTTTTCCACGACCGGATCAACGAGACGCTGCCGCCGTTCGTAAACCTCGGCAAATTGGGGCTCAACTACGGGTTGCAGGCAGCGCAGTTCACGGCGACCTCGACCACGGCCGAGTCGCAAACGCTCTCCAACCCGATGTACGTCCACTCGATCCCCAACAACAACGACAACCAGGACATCGTGAGCATGGGAACCAACGCGGCGATGCTCACGCGGCAGGTCGTGGAGAACGGCTACCAGGTCGCCGCGATCGAGATGCTGGCGCTGGTGCAGGCCGCCGACTACCTGCAATGCGCCGGGGAGCTCTCCGACGCCACGCGGCAGTTGTATGCCGACATCCGGGGCATCGTGCCGCGCTTTGCCGACGACACGCCCAAGCACAGGGAGATCGCCGCCATCGAAAATTTCCTGAAAAACAATTCCGCTTCCCTATGA",
      "translation": "MLRSNLNTINARIFNKTAIRIDDQALREVEACYRFLEKFEQGKVIYGINTGFGPMAQYRIGDADLNSLQYNIIRSHSCGAGEALPDICVRAAMLARLQTFLNAKSGVHPDVVRILADFLNNEIYPLVPRHGSVGASGDLVQLAHIALALIGEAEVSFRGETVPAAEAMAACGITPLRLRIRDGLALTNGTAVMTGIGLVNLAQARRLLGWAVKASVMLNEIVESYDDFMAGALNEYKLHAGQIEIARQMRAICATSRRLRKREAELYSGDTGAAPTFRHKVQPYYSLRCIPQILGPVLETISQAEKILVEEFNAVDDNPVVDPAAGTIYHGGNFHGDYVSLEMDKLKIAVTKMTMLAERQLNYLFHDRINETLPPFVNLGKLGLNYGLQAAQFTATSTTAESQTLSNPMYVHSIPNNNDNQDIVSMGTNAAMLTRQVVENGYQVAAIEMLALVQAADYLQCAGELSDATRQLYADIRGIVPRFADDTPKHREIAAIENFLKNNSASL",
      "product": ""
     },
     {
      "start": 12603,
      "end": 13727,
      "strand": -1,
      "locus_tag": "ctg77_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,603 - 13,727,\n (total: 1125 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAATCGCTTATCCTACTCGGCATGTCGCTGCTGGCTGCGTGCGGCGTGCAGAAAACGGAACTCCCGCTGCTGCCCGAAGAGGCATTCCAGACCACCGTCGACGGCAAACCCGTCGCACTCTACACGCTCCATGCGGGCGACATCACCATGCAGGTCACCAATTACGGCGCCCGCGTCGTATCGCTCTGGACACCCGACCGCGAAGGCCGCTACGAGGACATCGTACTGGGCTACGAAAACATCGGCCGCTACATAGACAACACGGGCGAACGGTTCCTCGGCGCCGTGGTAGGCCCCTACGCCAACCGCATCGCAAAGGGGCACTTCACGCTCGACGGCGCGGAATACACCCTGCCGGTGAACAATAACGGGCAGACGCTGCACGGCGGGCTCCTGGGCGTAGACCGCGTGGTATGGGACGTGGTATCGGCCTCGGACGACAAACTCGTGCTGCATTACCTCCATCCCGACGGACAGGACGGGTTCCCGGGCAACCTGGATATCGAGATGACCTACTCGCTCACGCCCGACAACGAGTTCCGCATCGACTACAAGGCCACTACCGACAAACCGACCGTGGTGAACATGTCGAACCACCCGTTCTTCAACCTCAAGGGCGAAGGCAACGGCACGGTGCTCGACAACGTGATGACGATCAACGCCAGCCACACCACCCCGGTGGACTCGGTGCTGATCCCCACGGGCCAGATTGCCCCGGTAGAGGGTACGCCGTTCGACTTCCGTGAGCCGCACGCCATCGGCGAGCGCATCGGAGCGGACAACCAGCAGCTGCGCAACGGCGGCGGCTACGACCACAACTGGGTGATCGACCGCAAGACCGAAAGCGGCATCGAGCAGGTCGCCACGGTCTGGGAACCCGCCTCGGGACGTACCATCGAGGTGCTGAGCGACCAGCCCGGACTGCAGGTTTACAGCGGCAACTTCTTCGACGGCAAGAGCATCGGCAAATACGGCAAGCCGCAGCGCTACCGCGAGTCGCTGGCGCTCGAAACGCAGAAGTTCCCCGACAGCCCCAACCACGACAATTTCCCCTCGACGGTACTGCGCCCCGGGGAGACCTATACGCAGGTCTGCATCTACAAGTTCGGCGTGAAATAA",
      "translation": "MKKSLILLGMSLLAACGVQKTELPLLPEEAFQTTVDGKPVALYTLHAGDITMQVTNYGARVVSLWTPDREGRYEDIVLGYENIGRYIDNTGERFLGAVVGPYANRIAKGHFTLDGAEYTLPVNNNGQTLHGGLLGVDRVVWDVVSASDDKLVLHYLHPDGQDGFPGNLDIEMTYSLTPDNEFRIDYKATTDKPTVVNMSNHPFFNLKGEGNGTVLDNVMTINASHTTPVDSVLIPTGQIAPVEGTPFDFREPHAIGERIGADNQQLRNGGGYDHNWVIDRKTESGIEQVATVWEPASGRTIEVLSDQPGLQVYSGNFFDGKSIGKYGKPQRYRESLALETQKFPDSPNHDNFPSTVLRPGETYTQVCIYKFGVK",
      "product": ""
     },
     {
      "start": 13765,
      "end": 13890,
      "strand": -1,
      "locus_tag": "ctg77_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,765 - 13,890,\n (total: 126 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCCGGACAAAAATAGCAAAATCCCTCCAATATACGCCGCAAATGTCCGAAAGCGTGCCGAAACCGTACGGGCTCCGGCAAAAAACCGGGCCGCAGCGCACGTTTTTCGCCAGAATCGTATAA",
      "translation": "MSRTKIAKSLQYTPQMSESVPKPYGLRQKTGPQRTFFARIV",
      "product": ""
     },
     {
      "start": 13902,
      "end": 15164,
      "strand": 1,
      "locus_tag": "ctg77_17",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,902 - 15,164,\n (total: 1263 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) rSAM_pep_methan<br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) SPASM<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACAGAAGCAGATATTTACGTTCCGCGACGCGGAGAAACAGGTCGCCCCCGCGGCCTTTTCGATCATGCTCAAACCGGCGGGCTCGGCCTGCAACCTCGACTGCCACTACTGCTACTACCTCGACAAGGCGGTGCAGTACGGCGGCCGCCAGGCCGTGATGGACGACCAGCTGCTGGAGCTCTGCATAAAACAGTACATCCGGGCCAATGAGGTCGACACCGTGCAGTTCTGCTGGCACGGCGGCGAGCCGTTGCTGCTGGGACTGGATTTCTACCGCCGGGCGATGGAGCTGCAGCGCAGGTACGCCGACGGCAAACGGATCGAGAACACGTTGCAGACCAACGGTACGCTGGTCGACGAGGCGTGGTGCGACCTCTTCGCCGCCAACAATTTCCTGGTCGGCCTCTCGCTCGACGGGCCCGGGGATATCCATGACGCCTTCCGCCTGACCAGGGGCGGCAAACCGACCTTCGAGCGCGTGATGCGGACGGTCGGGATGTTCGGGCGCAGCGGCGTGGAATTCAATACGCTGAGCGTCGTGAACCGGTGCTGCGAGGGGCGCGGCGGGGAGATCTACCGCTTCTTCCGCGACGAGGTGCACAGCCGCTTCATGCAGTTCCTGCCCGCCGTCGAACACGTCGTCGGCAAACCGGGACACCACCGTCCGCTGATCGTCCCGCCCGGACATGAAGGAGCGCGGCTGGCCGGCTGGTCGGTCTCGGCCGAAGGCTACGGGCATTTCCTGTGCGATGTGTTCGATGAGTGGGTCGTAAGCGACGTGGGGCGCTGTTTCGTGCAGTTGTTCGACGCCTCGCTGGCGCAGTGGTGCGGTGTGCGGCCGGGCGTCTGCTCGATGGGTGAGACGTGCGGCGACGCGCTGGTCGTCGAGCACAACGGCGACGTCTACCCGTGCGACCATTTCGTCTACCCCGGGTACAGGCTGGGCAATATCCGTGAGACGCCCCTTGCCGAGCTCTACCGCTCGCAGAAACGCCGCGAATTCGGGCTGGATAAACGCAACACGCTGCCCGCCGAATGTCTGCGGTGCAACTACTATTTCGCCTGCCGGGGCGAATGTCCCAAGCACCGTTTCGCCCGCGGGGCCGACGGCAGCCCCAAGAATTCACTCTGCGAGGGGCTGAAACGTTATTTCCGCCACGTCGAACCCTATATGGAATACATGCGCGACCTGCTCGCGCGGCAACAGTCCCCGGCCTGGGTCATGCCTTTCGCCCGCAGGCGCATGGGGCTGATGTAG",
      "translation": "MKQKQIFTFRDAEKQVAPAAFSIMLKPAGSACNLDCHYCYYLDKAVQYGGRQAVMDDQLLELCIKQYIRANEVDTVQFCWHGGEPLLLGLDFYRRAMELQRRYADGKRIENTLQTNGTLVDEAWCDLFAANNFLVGLSLDGPGDIHDAFRLTRGGKPTFERVMRTVGMFGRSGVEFNTLSVVNRCCEGRGGEIYRFFRDEVHSRFMQFLPAVEHVVGKPGHHRPLIVPPGHEGARLAGWSVSAEGYGHFLCDVFDEWVVSDVGRCFVQLFDASLAQWCGVRPGVCSMGETCGDALVVEHNGDVYPCDHFVYPGYRLGNIRETPLAELYRSQKRREFGLDKRNTLPAECLRCNYYFACRGECPKHRFARGADGSPKNSLCEGLKRYFRHVEPYMEYMRDLLARQQSPAWVMPFARRRMGLM",
      "product": ""
     },
     {
      "start": 15331,
      "end": 16806,
      "strand": -1,
      "locus_tag": "ctg77_18",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,331 - 16,806,\n (total: 1476 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 371.3; E-value: 9e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMATLGEHIRQSNAYKWWILGMIMLGTFMAVLDVTVVNVGLPAIMSAFGIGISTAEWVITAYMITMTVMLPSAGWFADRFGNKRIYILGLALFTLGSWLCGKAPGDLFLIGARALQGVGSGIIQSLGLAIVTREFRPEQLGLALGLWAMAAAASISFGPLLGGYLVDAYSWHRIFDVNVPVGVFAILLSAFIQKEWKSPARHPFDWRGFVAIALFMPLAIYALARGNSPTNHDGWASPTVIGCFAVAAVALAYFVRTELRSPAPLLQLRLLGERNFGVSMAVLTLFSIGMLGGTYLLPLYMQRGLGYTALMAGSVFLPVGLIQGVLSAVSGYLTRYVKPLLLAAAGILLLATSFWLASRFTLHTTHRHILFVLYIRGLGMGLTFAPLNFFSLRNLTQHDMAAAAGISNSIKQLAGSVGIAILTAVYSARTAFHAAHETVSASQTYVEGVTDALGVVTWLTLAAGLPLLWVFRKKRKKTPAGNPGAAGEAGES\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGACCCTCGGCGAACATATCCGGCAAAGCAACGCTTACAAATGGTGGATCCTGGGCATGATCATGCTCGGGACGTTCATGGCCGTGCTGGACGTGACGGTAGTCAACGTCGGGCTGCCGGCCATCATGTCGGCTTTCGGCATCGGCATCTCGACGGCCGAATGGGTCATCACCGCCTACATGATCACCATGACCGTCATGCTCCCCTCGGCGGGTTGGTTCGCCGACCGCTTCGGGAACAAACGCATCTATATTCTGGGGCTGGCGCTCTTCACGCTCGGGTCGTGGCTCTGCGGCAAAGCCCCGGGCGACCTGTTTCTGATCGGGGCACGCGCCCTGCAAGGCGTCGGCAGCGGCATCATCCAGTCACTGGGACTGGCGATCGTGACCCGCGAATTCCGCCCCGAGCAGCTCGGCCTGGCGCTCGGCCTGTGGGCAATGGCCGCCGCCGCGTCGATCTCGTTCGGCCCCCTGCTGGGCGGCTACCTGGTCGACGCATACAGCTGGCACAGAATCTTCGACGTGAACGTCCCCGTGGGAGTGTTCGCCATCCTGCTCTCGGCCTTTATCCAGAAAGAATGGAAAAGCCCGGCGCGGCACCCGTTCGACTGGCGGGGATTCGTGGCCATCGCGCTCTTCATGCCGCTGGCGATCTATGCGCTGGCGCGGGGCAACTCGCCGACCAACCACGACGGCTGGGCCTCGCCCACGGTGATCGGCTGTTTCGCCGTGGCGGCCGTGGCGCTCGCCTACTTCGTCCGCACGGAGCTGCGCAGCCCGGCGCCGCTGCTGCAGCTGCGCCTGCTCGGGGAGCGCAACTTCGGGGTTTCGATGGCCGTGCTGACGCTCTTCTCGATCGGTATGCTGGGCGGCACCTACCTGCTGCCGCTCTACATGCAGCGCGGGCTGGGCTACACGGCGCTGATGGCCGGGAGCGTATTCCTGCCCGTGGGGCTCATACAAGGAGTGCTGTCGGCCGTATCGGGTTACCTCACGCGCTATGTCAAACCCCTGCTGCTCGCGGCGGCGGGCATCCTGCTGCTGGCGACGAGCTTTTGGCTGGCCAGCCGTTTCACGCTCCACACCACCCACCGGCACATCCTCTTCGTGCTCTACATCCGCGGGCTGGGCATGGGGCTCACGTTCGCCCCGCTGAACTTCTTTTCGCTGCGGAACCTCACGCAGCACGACATGGCCGCTGCGGCGGGTATCTCGAACAGCATCAAACAGTTGGCTGGAAGCGTCGGCATCGCCATCCTGACAGCCGTTTACTCGGCCCGGACGGCTTTCCATGCGGCGCACGAAACGGTATCGGCCTCCCAAACCTATGTCGAGGGGGTGACCGACGCGCTGGGCGTAGTGACATGGCTGACCCTCGCGGCCGGGCTGCCGCTGCTGTGGGTATTCCGCAAAAAACGAAAGAAAACGCCGGCAGGAAACCCGGGAGCAGCCGGGGAGGCCGGGGAAAGTTAA",
      "translation": "MATLGEHIRQSNAYKWWILGMIMLGTFMAVLDVTVVNVGLPAIMSAFGIGISTAEWVITAYMITMTVMLPSAGWFADRFGNKRIYILGLALFTLGSWLCGKAPGDLFLIGARALQGVGSGIIQSLGLAIVTREFRPEQLGLALGLWAMAAAASISFGPLLGGYLVDAYSWHRIFDVNVPVGVFAILLSAFIQKEWKSPARHPFDWRGFVAIALFMPLAIYALARGNSPTNHDGWASPTVIGCFAVAAVALAYFVRTELRSPAPLLQLRLLGERNFGVSMAVLTLFSIGMLGGTYLLPLYMQRGLGYTALMAGSVFLPVGLIQGVLSAVSGYLTRYVKPLLLAAAGILLLATSFWLASRFTLHTTHRHILFVLYIRGLGMGLTFAPLNFFSLRNLTQHDMAAAAGISNSIKQLAGSVGIAILTAVYSARTAFHAAHETVSASQTYVEGVTDALGVVTWLTLAAGLPLLWVFRKKRKKTPAGNPGAAGEAGES",
      "product": ""
     },
     {
      "start": 17747,
      "end": 18343,
      "strand": 1,
      "locus_tag": "ctg77_19",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,747 - 18,343,\n (total: 597 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 94.3; E-value: 1.1e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGATAACGCGCATACGATCGACATACACGACAACCGCACGGTTGTCGGATTGCTCCGTGCGGGGGATGAAAAATGTTTCGATGCGCTTTTCCGCCGCTATTACAAACCGCTCTGCACCTATGCCACGCGCTTCGTGCCGCCGGTACGCGCCGAGGAACTCGTCCAGGACACCCTGATGTGGGTGTGGGAAAACCGCACCTCGCTGATCCCCGAGATGCCGCTCAAATCGCTGCTGTTCACCATCGTAAAGAACAAGTCGCTAAACAGCGCCTTGCGCGACACGCTCAAGAACCGCATCATCCGCCAGCTGGCCGAACGCTACGAAGAGACGTTCGACGACCCCGATTTCTACCTCGAGGGCGAACTGGTGCAGCGGCTGACCGAAGCTCTGCGCAAAATGCCTCCTGAATTCCGGCAGACCTTCCGTATGCACCGCCTGGAAGGTATGACCCACAAAGAAATAGCCGTCCGCCTCAACGTCTCCCCGCAGACGGTCAATTACCGTATCGGGCAGACGGTTCGCCTGCTGCGCGAAGAGCTCAGCGATTACTGGCCGCTGCTCGTGCTGTTGCTGTGGCCTGACCTCTCCTGA",
      "translation": "MADNAHTIDIHDNRTVVGLLRAGDEKCFDALFRRYYKPLCTYATRFVPPVRAEELVQDTLMWVWENRTSLIPEMPLKSLLFTIVKNKSLNSALRDTLKNRIIRQLAERYEETFDDPDFYLEGELVQRLTEALRKMPPEFRQTFRMHRLEGMTHKEIAVRLNVSPQTVNYRIGQTVRLLREELSDYWPLLVLLLWPDLS",
      "product": ""
     },
     {
      "start": 18426,
      "end": 19427,
      "strand": 1,
      "locus_tag": "ctg77_20",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,426 - 19,427,\n (total: 1002 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAATTTCGAAATCGACGAAGAGGTATTGGTAGCCTTCCTCAAGGGCGAGCTGGACGCAGCGCAGGCGGCGGCCGTAGAGGCGTGGTACGACCGCTCGGCCGCAAACCGCAGGATGCTCGGCCAGGTCTATTATATATTATATGTCAGCGACCGTATCAACGACGCGGCCGGTATCGACGTCGAGCGTTCGCTCCGGCAGTTCAAGCGCCGCATGCACGCCGGACGCCGTATCTCCCTGCGCCGGAGCGCGGTGCGTATAGCCGCTGCGGCCGTGATCGCCGCGGTGCTCCTGGCCGGCGGGCTCACGACCGTGTTGCTTTCCAAGCGCCTGGCGCAGCCCGTGACCGTCGTCACCCAGCTGGGCGAGCGGTCGCAGGTGGTGCTGCCCGACGGGACGAAGGTGTGGCTCAATTCGTCGAGCAGCGTGGAGTACGTCGCCCCCTTCTTTTCGCGCCAGCGCCGCGTGAAGATGGAGGGTGAAGCCTATTTCGAGGTCGAGCACGACCGCCGGGCGCCGTTCGTCGTGTCGACCAACGGCCTGGACATCGAAGTCCTCGGCACACGTTTCAACATCCGCAACGACGACAATGACCACCGTGTCACCACCGTCCTGCTCGAAGGTGCCGTCAAGGCCTCTGCTTCGGGACACGGGCAGGCCTCGGTACGCCTGCACCCCGCGCAGCAACTGGTCTTCGACACCCGGACGCACGCCATGCGCCTGACCGACTGCCCCTCGGCCGAACGCTCGATCAACTGGATCGACGGCCGCTTCTGTTTCGAGCACGACACTTTCGGGGAGATCGTCGCCGAACTCAAGCGCTACTACAACGTCGACATCCGTTTCATGGACACCCGGCTCCGCGACATGCGCTTCTCGGGCAATTTCCGCGTCGAGGACGGCATCTACCACATCATGTCCGTATTGCAACTGACCTATAAATTCAATTACAGGATCGCCGGCAACGACATCGAGCTCTATGCAAACCCTGAACGATAA",
      "translation": "MANFEIDEEVLVAFLKGELDAAQAAAVEAWYDRSAANRRMLGQVYYILYVSDRINDAAGIDVERSLRQFKRRMHAGRRISLRRSAVRIAAAAVIAAVLLAGGLTTVLLSKRLAQPVTVVTQLGERSQVVLPDGTKVWLNSSSSVEYVAPFFSRQRRVKMEGEAYFEVEHDRRAPFVVSTNGLDIEVLGTRFNIRNDDNDHRVTTVLLEGAVKASASGHGQASVRLHPAQQLVFDTRTHAMRLTDCPSAERSINWIDGRFCFEHDTFGEIVAELKRYYNVDIRFMDTRLRDMRFSGNFRVEDGIYHIMSVLQLTYKFNYRIAGNDIELYANPER",
      "product": ""
     },
     {
      "start": 19630,
      "end": 22914,
      "strand": 1,
      "locus_tag": "ctg77_21",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,630 - 22,914,\n (total: 3285 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 72.7; E-value: 5.5e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLLLGCFGATSATAQTQQALSRVSLDAPDATVITVFQAIQQQTGCSFVYNTSDIDTDRKVSLSVHDEPLQAVLDKLFAGSDIAYTLRDKHIVLSKKAKNSPPHSAQGGVTGVIKDDKGMPLVGATVLIKGTTTGAAADIDGNFSLPQAKPGDTLEISLIGYTKQELPVSGSAPLSVVMHEDNEVLDAVVVTALGIKRSEKALTYNVQEVAGDIVNTVKDANFMNSLSGKVAGLQINASASGVGGSTRVVMRGVKSISGNNNALYVIDGIPMPDLRSSQTEGTYETPDGGDFEGISNLNPEDIESMTVLSGATAAALYGSQGANGVIVITTKKGEEGRVRVNYANNTTFSSPFVMPQFQNTYGTDATAPSMSWGTKLSTPTSYDPSDFFQTGFEETNAISVSGGTRVNQSYFSAASLNSRGVIPNNVYNRYNFTFRNTTQLIKDKLTLDLGASYMRQYKRNPLVQGLYHNPLIPIYLFPRGDDISKYEVYERYDATAGYMKQFWPLEFITGVENPWWITNRELFENTAHRYTFNATLKWDIADWITLTGRVRTDNMVMNYTRKIYASSDKLFASEYGNYQNNKIHHNNLYADALLSINKSFFDDKFSLSFNLGASILDDKNDGEGFEGHLATLANKFSVYNVDMSHSQTKPYADRYHDQTQAVYATAQLGYNGMVYLDVTARNEWASQLAFTPHMNIFYPSVGLSAVISSMADLSKAGISFLKVRASYAEVGNAPQRFITGVNTPLQTGGIVSSDSYAPAVNLTPERTKSFEVGLNAKFLGNKIWTDVTYYNTNTYNQLFSYDAPPSTGYKRAYINAGKVNNWGIEAVVGYKNKWRDFSWSTNVNFSMNRNEVKELVPEGTRDVAGNLVTVDEVNMDYGGYRMKVKKGGSIGDFYVTGLKTDDQGRIYVDPNTNTVTTDPNTWLYGGNTEARFRLGWNNRFSYKGVNLGVLFDARIGGQGVSATQALMDRWGASQDSADARENGGVWISEDQKVPDARVFYANNGNGLSMLSHYVYSMTNVRLRELTLGYDLPSRWFNDKIGMTVSLVGRNLWMIYNKAPFDPEITASTGTYYQGLDYFMQPSARTIGFSVRLQF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGCTCCTGGGATGCTTCGGCGCCACCTCTGCCACGGCACAGACGCAGCAAGCCCTCTCGCGTGTGAGCCTCGATGCCCCGGACGCGACGGTCATCACGGTTTTCCAGGCTATCCAGCAGCAGACGGGCTGTTCGTTCGTCTACAATACGTCGGACATCGACACCGACCGCAAAGTGAGCCTCTCGGTGCACGACGAACCGCTGCAGGCCGTGTTGGACAAGCTCTTCGCGGGCTCCGACATCGCTTATACCCTTCGGGACAAACACATCGTGCTCTCGAAGAAAGCTAAAAATTCCCCCCCCCACAGCGCTCAGGGCGGCGTTACCGGAGTCATAAAGGACGATAAGGGCATGCCCCTGGTCGGCGCCACCGTGCTTATAAAAGGTACGACGACCGGTGCCGCCGCCGACATCGACGGCAATTTCTCGCTTCCGCAGGCCAAACCGGGGGACACGCTCGAAATTTCGCTCATCGGCTATACCAAACAGGAGCTTCCCGTCTCGGGATCCGCCCCGTTGTCGGTGGTCATGCACGAGGACAACGAAGTGCTCGACGCCGTGGTGGTTACCGCCCTCGGCATCAAGAGGTCGGAGAAAGCGCTGACCTACAACGTGCAGGAGGTCGCGGGCGACATCGTCAACACGGTCAAGGACGCCAACTTCATGAACTCGCTTTCGGGCAAGGTCGCCGGCCTTCAGATCAACGCCAGCGCCTCGGGCGTGGGTGGTTCCACGCGCGTGGTGATGCGCGGCGTGAAGTCCATCAGCGGCAACAACAACGCCCTCTATGTGATCGACGGTATCCCGATGCCCGACCTGCGTTCCTCGCAGACCGAGGGCACCTACGAAACGCCCGACGGCGGCGATTTCGAGGGTATCTCGAACCTCAACCCCGAGGACATCGAATCCATGACGGTGCTTTCGGGTGCCACGGCGGCCGCGCTCTACGGTTCGCAGGGTGCCAACGGTGTGATCGTCATCACGACAAAAAAGGGCGAGGAGGGGCGCGTGCGCGTGAACTACGCCAACAATACCACCTTTTCGTCGCCGTTCGTCATGCCGCAGTTCCAGAACACCTACGGCACCGACGCTACGGCACCTTCCATGAGCTGGGGTACGAAGCTCTCGACCCCGACCTCGTACGACCCCTCGGATTTCTTCCAGACCGGCTTCGAGGAGACCAATGCGATCTCGGTTTCGGGCGGTACGCGCGTGAACCAGTCCTATTTCTCGGCAGCTTCGCTCAATTCGCGCGGCGTCATCCCCAACAACGTCTACAACCGGTACAACTTCACCTTCCGCAATACCACGCAGCTCATCAAGGACAAGCTGACGCTCGACCTGGGCGCTTCCTACATGCGCCAGTACAAGCGTAACCCGCTCGTGCAGGGCCTCTACCACAACCCGCTGATTCCCATTTACCTCTTCCCGCGCGGCGACGACATCTCCAAGTACGAGGTTTACGAGCGTTACGACGCCACGGCGGGCTATATGAAGCAGTTCTGGCCCCTGGAGTTCATCACCGGCGTCGAGAACCCCTGGTGGATCACCAACCGCGAGCTGTTCGAGAATACGGCGCACCGCTATACGTTCAACGCCACGCTCAAGTGGGACATTGCCGACTGGATCACCCTCACGGGGCGCGTGCGCACCGATAACATGGTGATGAACTATACGCGCAAGATCTATGCCTCGTCCGACAAGCTGTTCGCTTCCGAATACGGTAACTACCAGAACAACAAGATCCATCACAACAACCTCTACGCCGACGCCCTGCTGTCGATCAACAAGAGTTTCTTCGACGACAAGTTCTCCCTGTCGTTCAACCTGGGTGCGAGCATCCTCGACGACAAGAACGACGGCGAAGGCTTCGAGGGCCACCTGGCCACCCTCGCCAACAAGTTCTCGGTCTACAACGTGGATATGAGCCATTCGCAGACCAAACCCTACGCCGACCGCTACCACGACCAGACGCAGGCCGTCTACGCCACCGCCCAGCTGGGATATAACGGCATGGTCTACCTCGACGTGACGGCGCGCAACGAGTGGGCGTCGCAGCTGGCCTTCACGCCCCATATGAACATATTCTACCCGTCGGTGGGCCTTTCGGCCGTCATCTCGTCGATGGCCGACCTTTCCAAAGCCGGCATTTCGTTCCTCAAGGTGCGTGCCTCCTATGCCGAGGTGGGTAACGCCCCGCAGCGGTTTATTACCGGTGTCAATACGCCCTTGCAGACGGGCGGTATCGTTTCGTCGGACTCCTATGCCCCGGCTGTCAACCTTACGCCCGAGCGCACCAAGTCGTTCGAAGTGGGCCTGAACGCCAAGTTCCTCGGCAACAAGATCTGGACGGACGTGACCTATTACAATACCAACACCTACAACCAGCTTTTTAGCTATGATGCACCGCCCAGCACCGGCTACAAACGGGCATATATCAATGCCGGCAAGGTCAACAACTGGGGTATCGAAGCGGTCGTGGGTTACAAGAACAAGTGGCGCGACTTCTCGTGGTCGACCAATGTCAACTTCTCGATGAACCGCAACGAGGTGAAGGAGCTGGTTCCCGAAGGCACGCGCGACGTGGCCGGTAACCTGGTGACTGTCGACGAGGTGAACATGGACTACGGCGGCTACCGCATGAAGGTCAAAAAAGGCGGTTCGATCGGCGACTTCTACGTGACGGGGCTCAAGACCGACGACCAGGGACGCATCTATGTCGACCCCAATACCAATACCGTCACCACCGATCCCAATACGTGGCTTTACGGCGGCAATACCGAAGCCCGCTTCCGCCTGGGGTGGAACAACCGCTTCTCCTACAAGGGCGTGAACCTCGGCGTGCTGTTCGATGCCCGCATCGGCGGCCAGGGCGTTTCGGCGACGCAGGCCCTGATGGATCGCTGGGGTGCCTCGCAGGATTCGGCCGACGCCCGGGAAAACGGCGGTGTCTGGATCTCCGAGGATCAGAAAGTCCCCGATGCCAGGGTCTTCTACGCCAACAACGGCAACGGGCTTTCGATGCTTTCACACTACGTTTACAGCATGACCAACGTCCGCCTGCGTGAACTTACTCTGGGCTACGACCTGCCTTCCAGGTGGTTCAACGACAAGATCGGCATGACCGTGTCGCTCGTCGGCCGCAACCTGTGGATGATCTACAACAAGGCGCCGTTCGATCCCGAGATCACCGCGTCCACGGGTACCTATTACCAGGGGCTCGACTATTTCATGCAGCCCAGCGCCCGTACCATCGGTTTCAGCGTAAGACTCCAATTCTAA",
      "translation": "MLLLGCFGATSATAQTQQALSRVSLDAPDATVITVFQAIQQQTGCSFVYNTSDIDTDRKVSLSVHDEPLQAVLDKLFAGSDIAYTLRDKHIVLSKKAKNSPPHSAQGGVTGVIKDDKGMPLVGATVLIKGTTTGAAADIDGNFSLPQAKPGDTLEISLIGYTKQELPVSGSAPLSVVMHEDNEVLDAVVVTALGIKRSEKALTYNVQEVAGDIVNTVKDANFMNSLSGKVAGLQINASASGVGGSTRVVMRGVKSISGNNNALYVIDGIPMPDLRSSQTEGTYETPDGGDFEGISNLNPEDIESMTVLSGATAAALYGSQGANGVIVITTKKGEEGRVRVNYANNTTFSSPFVMPQFQNTYGTDATAPSMSWGTKLSTPTSYDPSDFFQTGFEETNAISVSGGTRVNQSYFSAASLNSRGVIPNNVYNRYNFTFRNTTQLIKDKLTLDLGASYMRQYKRNPLVQGLYHNPLIPIYLFPRGDDISKYEVYERYDATAGYMKQFWPLEFITGVENPWWITNRELFENTAHRYTFNATLKWDIADWITLTGRVRTDNMVMNYTRKIYASSDKLFASEYGNYQNNKIHHNNLYADALLSINKSFFDDKFSLSFNLGASILDDKNDGEGFEGHLATLANKFSVYNVDMSHSQTKPYADRYHDQTQAVYATAQLGYNGMVYLDVTARNEWASQLAFTPHMNIFYPSVGLSAVISSMADLSKAGISFLKVRASYAEVGNAPQRFITGVNTPLQTGGIVSSDSYAPAVNLTPERTKSFEVGLNAKFLGNKIWTDVTYYNTNTYNQLFSYDAPPSTGYKRAYINAGKVNNWGIEAVVGYKNKWRDFSWSTNVNFSMNRNEVKELVPEGTRDVAGNLVTVDEVNMDYGGYRMKVKKGGSIGDFYVTGLKTDDQGRIYVDPNTNTVTTDPNTWLYGGNTEARFRLGWNNRFSYKGVNLGVLFDARIGGQGVSATQALMDRWGASQDSADARENGGVWISEDQKVPDARVFYANNGNGLSMLSHYVYSMTNVRLRELTLGYDLPSRWFNDKIGMTVSLVGRNLWMIYNKAPFDPEITASTGTYYQGLDYFMQPSARTIGFSVRLQF",
      "product": ""
     },
     {
      "start": 22927,
      "end": 24483,
      "strand": 1,
      "locus_tag": "ctg77_22",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,927 - 24,483,\n (total: 1557 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACGATTCAATCATACAATAGGATTTTTCGCCGCTGCGGCGCTTGCCGCCTGTACCGGTGACTTCGAATCCTTCAACACCAATCCCGATGCGGTGCAGTCGGTCGACAAGAAGACCTACATCACCACCATGCAAATGGATGCCGTGATCCCGTGCAGCGACGTGGGGGCCAACGAGTTCCAGCGCGCCTGCAACCTGATGGGCGACGCCTTCGGCGGCTATCTCTCCCCGATCCAGGCCTTCAACGGCGGCAGCTATACCTGTACCTACGACCTCGACGGTACGGACTATAACAACGTGCCCTTCTCGGTGGCTTTCACCAATGTGATGCCTGCATGGCTCAACCTCAAGTACGCCTACCAGAACGGGCAGGTTACCGACGACGTCTTTGCCGTTGCCGAGGTCATCAAGGTGATGGCCCTCCAGCGTACCACCGACATCTACGGCCCGATCCCCGTTTCGAATTTCGGCCAGACCGAAAACTCCTACGAATCGCAGGAGACCGTCTACAAAAACCTTCTCACGGATCTGAATGCCGCCATCGTGGTGCTCAAGGAGTATGCGGCCAATGCCGCCGACGCCAGGCCGTTGCAGAAGGTCGACGCCGTTTACCAGGGCGACTATGCGAAATGGCTCAAGCTGGCCAACTCGGTCAAGCTCCGCATGGCCATGCGCATCCGTTTTGTCGAACCCGGGCTTGCCCGGATCTATGCCGAGGAAGCCGTCAGGGACGGGGTGATGACCGCTTCGGACGACGGTGCGTGGCTCAAGAGTTCCGGTTCGGTACAGGTATACAATCCGCTCGAAGAGGTGTGGAACGCCTATAACGATACCCGCATGGGTGCGACCATCGACGCTTATATGAACGGTTACGCCGATCCGCGCCTACCGGCCTATTTCAAAACCTGCGAGGATGGCAAGTACCACGGTGTCCGCAGCGGTCTCAGCTCGATGCTGAAGGCGGACTATACCGGACTTTCGGTGCCCAACGTCGCCAAGGATACGCCCGTCGTGTGGTTCCTCGCTTCCGAGGCCGCTTTCCTGAGGGCCGAAGGCGCCATGCTCGGCTGGGAGATGGGCGGTGACGATGAATCGTTCTACAAGACGGGTATCGAACTGTCGTTCCTCGAACGCGGTCTTACCGCGGCCGCCGCGGCCACCTATGCCGAGAGTGCGAGCGAACCCCAGGCATTCGAGGACGCTTCGGCCGCCTCGACGAAATACAACGCTTCGAAACCTTCGTCCGTCTCCCCGAAATGGAATGCCGGCGCCGGGGACGAGGAGAAACTCGAACGGATCATCACGCAGAAGTGGATCGCCATGTTCCCCAACGGGCAGGAAGCCTGGTCGGAATTCCGCCGCACAGGTTACCCCAAGGTGATCCCGATCGTCAACAACCTCAGCGGCGGCAAGGTCGATACCAACGTCCAGGTGCGCCGTATGACCTTCCCGCGTTCGGAGTACTCGAACAATGCCGCCGGCGTGGCGGCTGCCACCGCACTGCTCGGCGGAGCCGATACCGGCGGTACGAAACTCTGGTGGGATAAGAAATAA",
      "translation": "MKRFNHTIGFFAAAALAACTGDFESFNTNPDAVQSVDKKTYITTMQMDAVIPCSDVGANEFQRACNLMGDAFGGYLSPIQAFNGGSYTCTYDLDGTDYNNVPFSVAFTNVMPAWLNLKYAYQNGQVTDDVFAVAEVIKVMALQRTTDIYGPIPVSNFGQTENSYESQETVYKNLLTDLNAAIVVLKEYAANAADARPLQKVDAVYQGDYAKWLKLANSVKLRMAMRIRFVEPGLARIYAEEAVRDGVMTASDDGAWLKSSGSVQVYNPLEEVWNAYNDTRMGATIDAYMNGYADPRLPAYFKTCEDGKYHGVRSGLSSMLKADYTGLSVPNVAKDTPVVWFLASEAAFLRAEGAMLGWEMGGDDESFYKTGIELSFLERGLTAAAAATYAESASEPQAFEDASAASTKYNASKPSSVSPKWNAGAGDEEKLERIITQKWIAMFPNGQEAWSEFRRTGYPKVIPIVNNLSGGKVDTNVQVRRMTFPRSEYSNNAAGVAAATALLGGADTGGTKLWWDKK",
      "product": ""
     },
     {
      "start": 24507,
      "end": 26414,
      "strand": 1,
      "locus_tag": "ctg77_23",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,507 - 26,414,\n (total: 1908 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAATTTCTTGAAATACGTCGCGGCCCTTGCGATCGTGGGTGCCTTTTTCGTCGCTTGTTCGGATTGGACGGATCCCGAGCGCGAAATTACGCAGCATCCCGACCAGCAGTCGCCCATCCTGCGCGATAATGCCTACTACCAGGCCCTGCGCGAATACAAAAAGACCAAGCACAAGATCGCTTTCGGCTGGTACGGTTCGTGGACGGCCGTCGGCGCATCCTACCAGACCCGCCTGCAGAGTGCTCCCGACTCGATGGATATCATCTCCATCTGGAGCCAGTGGCATTCGCTGACCCCCGAGCAGATCGCCGACAAGGAGTTCGTGCAGAAGATCAAGGGCACGAAGGTGACCTTCACGATCTTCTCGGACAAGATGCCCGAGCCGTTCCTCACCGAGATCGGCGGCGGCGAATATACCGACGAGGCCATCGAGGCCTACGCCAAAGCCTACTGCAAGGACTCGATGGACAAGTACAGCTACGACGGCATCGACGTCGACTACGAACCCGGCTACGGCGCTTCGGGGCCGTTCGTGGGACATGACAACGAGCTGTTCAGGAAGCTGATCCTGGCCATGAGCAAATACGTCGGCCCCAAGTCGGGGACGGGACGCCTGCTTATGATCGACGGCGTGCCCTATGCCGTGCATGCCGATGTGGCCGACTGCTTCGACTACGGCATCGTGCAGGCTTATAATTCTTACGGCTATACCGATTTGCAGGATCGCTTTGACGAAGCCGATAAGAAAGGCTGGAAGCCCGAGCAGTATATCTTCGCCGAGAACTTCGAGTCCCTCTGGAAAACCGGCGGCGTGTCGCATGAATGCCGCGACGGCCAGAGGGTCAACTCGCTGCTGGGCATGGCGCGCTTCAACCCCACGCAGGGTTTCGGTGCCGGTTTCGGTGCCTACCACATGGAGTATGAGTACGCCAATTCGTCGATGCCTTACAAGTATATGCGCGAGGCGATCCAGGATGTGAACCCCGCCGGCGGCGACCTGATCGTCGGTCTGACCTCGACCGGCTTGTCCAAATACCTGTTCCTGGTCGGGGACGACGGTACCATCACGGGCGAGGTGGACGAAAAAATCCGGGTCGAGCTGGCTCGTCCTGCCCCGGCCGACGTTTCGTTCCCGCTGGCTATCGACAATTCGCTGGTCGATGCCTACAACGAAAAGCACGGCACCTCCTACGAGCCGATCGACCCCGCGCGTGTTTCACTCGGCACGCTCGGCGTGGCAGCCGGTGCGTTCTTGTCCGACGAGGTGTCCGTTACCGTAAGTTCTGCCGGGATCGAGAAGGGTTACTACCTGATCCCCATCGTCGTGGAACTTCCCGCGGAAGATATTTATACCTCGAAGGAGCCATTGGTACGCTACCTGCTGTTGACGGTGTCGGCGATGGAGATCGACGTCGATGCGACGGCGCTTACGGGCGTGAAGATCGAACCTGCCTCCGGGTGGACGATCGTCTGCTACCAGGGCACCGCTTCGAGCGGCGCCAACGGCGTCTGGAACCTCGATTCCGATGCGCAGAAGGCCTGCATGTTCGACGGCAAGCTCGACTCCAACTGCTGGTATGCCGCGAATGCGTCCTATTCGTGGGGGAACGGCGGCAACTTCATCATCACGCTGGACAAGGCCTACGACATCAACGGCTTCCGCTGGCATATCTACTACGAGGACTCCAACCCCGAATGTACCGATTTCCAGTACAGCGAGGACGGCACCAACTGGTATAGCCTCACCAATGAAATTTCGTTCGTGCCCAAACTCTCGGCCGACAACTGGAAGATATTCCAGTTCAAGAAGACCGTCAAAGCCCGCTATCTCCGGGTATACGTCGGCCGGGTAACCGATTTCACCAGTATGAACGAGGCCGAGATTTTCGCCCCTGCAAACTAA",
      "translation": "MKNFLKYVAALAIVGAFFVACSDWTDPEREITQHPDQQSPILRDNAYYQALREYKKTKHKIAFGWYGSWTAVGASYQTRLQSAPDSMDIISIWSQWHSLTPEQIADKEFVQKIKGTKVTFTIFSDKMPEPFLTEIGGGEYTDEAIEAYAKAYCKDSMDKYSYDGIDVDYEPGYGASGPFVGHDNELFRKLILAMSKYVGPKSGTGRLLMIDGVPYAVHADVADCFDYGIVQAYNSYGYTDLQDRFDEADKKGWKPEQYIFAENFESLWKTGGVSHECRDGQRVNSLLGMARFNPTQGFGAGFGAYHMEYEYANSSMPYKYMREAIQDVNPAGGDLIVGLTSTGLSKYLFLVGDDGTITGEVDEKIRVELARPAPADVSFPLAIDNSLVDAYNEKHGTSYEPIDPARVSLGTLGVAAGAFLSDEVSVTVSSAGIEKGYYLIPIVVELPAEDIYTSKEPLVRYLLLTVSAMEIDVDATALTGVKIEPASGWTIVCYQGTASSGANGVWNLDSDAQKACMFDGKLDSNCWYAANASYSWGNGGNFIITLDKAYDINGFRWHIYYEDSNPECTDFQYSEDGTNWYSLTNEISFVPKLSADNWKIFQFKKTVKARYLRVYVGRVTDFTSMNEAEIFAPAN",
      "product": ""
     },
     {
      "start": 26433,
      "end": 27590,
      "strand": 1,
      "locus_tag": "ctg77_24",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,433 - 27,590,\n (total: 1158 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACTGAAATATTTGGTCGCTCCGCTGTTGTTCGCCGCCGCTGCGGCGACGGGCTGTCAGGAGTCCGCGGAGACCTATCCTGCGATCTACATGACCGATGCGCAGAACAATCCCGACAAATCAATGACCATCGACGAACCCCCTGCCGAGACCTCGATCACCGTATCCTCCTCGGTGGTTATGGAGCACGACGTGCGGATCCAGTTGGAAGTGCGGCCCGAACTGCTGGCTGCCTATAACGACAAGTACGGCAAAAACTACCAGATTCCGCCCGAGGAAAGCTACGCCCTGAGTTCGACCGAAACGACCATCCTGGCCGGCTACAACACCTCTTCGGCGATCGACTTCACGGTGTCGTCCGTCTCGGAGTTCGCCGAGGGCGTGACCTATTGCGTCCCCGTGGGCATCAAGACCGTATCCGGCGGAATAAGCGTGCTCGAACCGAGCCGCACGCTCTTCATCGTGCTGAAGACCCCGGTGATCAGCAAGGCGATCTACCTGGGATCGAGCAACATCTACAAGGTGACTTCGTTCCAGGAGAATTCCGACCTGGCAGCCCTTCCGCAGCTCACGCTCGAAGCCCGCGTATACATGCTCGGCTTCCAGACCCGCGATCCTTATATCAGTTCCATCATGGGTATCGAGGGCATCTGCGGCGTACGTTTCGGCGACGTGAAGGTCGATCCCGACTGCATCCAGATCTGTCACGACTCCTACCAGCCCGCAGCTACCGACAAGCCGTTCGACAAGGAGAAGTGGTACCACGTCGCCGCAGTCTGGACGGGCTCTTCGTGGGACATCTATATCAACGGGCAGTATGCCACGGGCGTGGAAACGCAGGGCGAGACCATCGACCTGACGAGCGACAATTCGGGCGGTTTCTACCTGGGAGCCTCCTATGGCGGCGGCCGTACGCTGAACGGCTATGTCGCCGAGTGCCGCGTATGGACACGCGCCCTCTCGCAATCCGAGATCGCCAACAACATGAACTATGTCGACCCCACGTCCGACGGGCTGCTCGCTTACTGGCGCATGAACGCCTGGGAGCCCAACGACAGCGGTTCCGGCAATATCGTGCGCGACCTCACGGGCCATGGTTACGATGCCGTCGGCGGCAGCTCCAACCCGACGATGATGGACACCAAGTGGAATTAG",
      "translation": "MKLKYLVAPLLFAAAAATGCQESAETYPAIYMTDAQNNPDKSMTIDEPPAETSITVSSSVVMEHDVRIQLEVRPELLAAYNDKYGKNYQIPPEESYALSSTETTILAGYNTSSAIDFTVSSVSEFAEGVTYCVPVGIKTVSGGISVLEPSRTLFIVLKTPVISKAIYLGSSNIYKVTSFQENSDLAALPQLTLEARVYMLGFQTRDPYISSIMGIEGICGVRFGDVKVDPDCIQICHDSYQPAATDKPFDKEKWYHVAAVWTGSSWDIYINGQYATGVETQGETIDLTSDNSGGFYLGASYGGGRTLNGYVAECRVWTRALSQSEIANNMNYVDPTSDGLLAYWRMNAWEPNDSGSGNIVRDLTGHGYDAVGGSSNPTMMDTKWN",
      "product": ""
     },
     {
      "start": 27909,
      "end": 29969,
      "strand": 1,
      "locus_tag": "ctg77_25",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,909 - 29,969,\n (total: 2061 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAAATCACGCTTATCTCTTTTTGCCTTGCCGCTTTCGCCTTTGCTTCGTGCGCCGGCGGCGGGTGCCCGGCCACGGGCATCATCCCGGCCCCGCAGCAGGTGACGTGGGGCGAAGGTGCCTTCCGTATGCCTGCCAAGCTGCTCTACACGACCGACCTCGACGGGCAGGACAAGGCCGACCTCGCGGCGTGGATGCAGCGTGCCGCGGACGGATTCTTCCCCGCCTCCTTTGCCGAGGCCTCCGACGGCGACATGCCCGCACTCGAACTGCTTCGTACGGGCGACGGCGCCCCCGAAAGCTACCGTCTCGACGTCTCCCGCACAAAGATCACGCTCACGGCCCCCGATGCCGCAGGGTTGTTCTACGGACTCCAGTCGCTCGCACAACTGGCCGGGCACCACGGCCGCCGCATTCCGGCCGTCACGATCGTGGACGCCCCGCGCTTCGGTTACCGGGGCTTCATGCTCGACGTCTCGCGCCATTTCCGCGACAAGGAGTTCGTCGAACGTCAGCTCGACCTCATGGCGCGCTACAAGCTCAACCGCTTCCACTGGCACCTGACCGACGGAGCCGGATGGCGCATCGAAATCAAAAAATACCCCGCCCTGACCGACATCGCCGCCTGGCGTCCCTATCCCGACTGGGAGGGATGGAACTTCGGCGGCAAACGCTACTGCCACCGCGACGACCCGGCGGCCGCCGGGGGCTATTACACGCAGGACGACATCCGCGAAGTGGTCGAATACGCCCGTGCCCTGCATATCGAGGTGATTCCCGAGATCGAGATGCCGGGGCACAGCGAGGAGGTGCTGGCCGTTTACCCCGAACTCTCGTGCAGCGGCAAACCCTACACGGACTCCGATTTCTGCATCGGCAACGAGCAGACGTTCGAATTCCTTGAGAGCGTGCTCTCCGAAGTGATCGGGCTCTTCCCTTCGGAATATATCCATATCGGCGGCGACGAGGCTTCGAAACAGGGGTGGCGCACCTGCCCCGAATGTGCCGCCCGGATGCGTCGGGAGGGACTGCAGGACGTCGATGAACTGCAAAGCTACCTGGTGCACCGCATCGGGACGTTCCTCGCCGCCAAGGGCCGCCGCCTGCTGGGCTGGGACGAGATTCTCCAGGGCGGGCTCGCGCCCGGCGCCACGGTCATGTCGTGGCGCGGCACCGAGGGCGGGATCGCCGCGGCCAGGGCCGGACACCGCGCCGTGATGGCTCCCTCGAACTACTGCTACCTCGATTTCTGCCAGGACGACCCCACCCGCGAGCCGGTCGCCGCCGCGGCGTTCCTCACCCTCGCGCAAGCCTACTCCTACGACCCTGCGCCCGATTCGCTGGGTGCGGATGTCGTGCCGATGATCCTCGGCGTGCAGGGCAACCTGTGGTGCGAGCACGTGCCCACAGCCGAACATGCCGAACACATGATCTGGCCGCGCCTGCTGGCGATTGCCGAAGTGGGGTGGAGCGCCCCCGAACGGAAGGACTACGACGACTTCCACGCCCGCGTGCTCGACGCCGTGGCGTGGATGCAGCAGCGCGGATACCACCCCTTCGACCAGAAAAATGCCGTCGGCCCCCGCCCCGAATCGCTCGATACCCTGCATTGCCTTTCGACCGGCAGGCAGGTGGTTTACCGTACGCCTTACAGCCCGAAATACCCGGCTGCGGGCGACGCTTCGCTGACCGACGGGCTGTGCGGCGGGTGGAACTACGGCGACCGCCGCTGGCAGGGGTGGCTCGATACGGATGTCGAACTGGTCGTCGACCTCGGGGAACGCCAGCCTGTGAAACGTATCGCGGCCTGTTTCATGCAGGGTTTCTATGCCGACATCTGGATGCCCCGTGCGGTCGAAATCTCGGTTTCGGACGACGACAGGCACTATACGCCCCTTGCCGCGGTCGAAAACGACATCCCGTTCGAATACAAGCAGGATTGCTACCGCGAGTTCGGCTGGTCGGGCCAAACCGCGGCGCGTTACGTGCGGCTGAAAGCCCGGCACAACGGCCATCCCGGCGGCTGGATTTTCACCGACGAGATTATTGTGGAGTAA",
      "translation": "MKKITLISFCLAAFAFASCAGGGCPATGIIPAPQQVTWGEGAFRMPAKLLYTTDLDGQDKADLAAWMQRAADGFFPASFAEASDGDMPALELLRTGDGAPESYRLDVSRTKITLTAPDAAGLFYGLQSLAQLAGHHGRRIPAVTIVDAPRFGYRGFMLDVSRHFRDKEFVERQLDLMARYKLNRFHWHLTDGAGWRIEIKKYPALTDIAAWRPYPDWEGWNFGGKRYCHRDDPAAAGGYYTQDDIREVVEYARALHIEVIPEIEMPGHSEEVLAVYPELSCSGKPYTDSDFCIGNEQTFEFLESVLSEVIGLFPSEYIHIGGDEASKQGWRTCPECAARMRREGLQDVDELQSYLVHRIGTFLAAKGRRLLGWDEILQGGLAPGATVMSWRGTEGGIAAARAGHRAVMAPSNYCYLDFCQDDPTREPVAAAAFLTLAQAYSYDPAPDSLGADVVPMILGVQGNLWCEHVPTAEHAEHMIWPRLLAIAEVGWSAPERKDYDDFHARVLDAVAWMQQRGYHPFDQKNAVGPRPESLDTLHCLSTGRQVVYRTPYSPKYPAAGDASLTDGLCGGWNYGDRRWQGWLDTDVELVVDLGERQPVKRIAACFMQGFYADIWMPRAVEISVSDDDRHYTPLAAVENDIPFEYKQDCYREFGWSGQTAARYVRLKARHNGHPGGWIFTDEIIVE",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 2194,
      "end": 10049,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 30049,
      "product": "arylpolyene",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "arylpolyene",
    "products": [
     "arylpolyene"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS arylpolyene",
    "anchor": "r77c1"
   }
  ]
 },
 {
  "length": 28552,
  "seq_id": "NZ_JAYAFN010000078.1",
  "regions": []
 },
 {
  "length": 21261,
  "seq_id": "NZ_JAYAFN010000079.1",
  "regions": []
 },
 {
  "length": 4419,
  "seq_id": "NZ_JAYAFN010000080.1",
  "regions": []
 },
 {
  "length": 72098,
  "seq_id": "NZ_JAYAFN010000081.1",
  "regions": []
 },
 {
  "length": 15105,
  "seq_id": "NZ_JAYAFN010000082.1",
  "regions": []
 },
 {
  "length": 62848,
  "seq_id": "NZ_JAYAFN010000083.1",
  "regions": []
 },
 {
  "length": 24427,
  "seq_id": "NZ_JAYAFN010000084.1",
  "regions": []
 },
 {
  "length": 17547,
  "seq_id": "NZ_JAYAFN010000085.1",
  "regions": []
 },
 {
  "length": 38539,
  "seq_id": "NZ_JAYAFN010000086.1",
  "regions": []
 },
 {
  "length": 21454,
  "seq_id": "NZ_JAYAFN010000087.1",
  "regions": []
 },
 {
  "length": 49579,
  "seq_id": "NZ_JAYAFN010000088.1",
  "regions": []
 },
 {
  "length": 4033,
  "seq_id": "NZ_JAYAFN010000089.1",
  "regions": []
 },
 {
  "length": 17446,
  "seq_id": "NZ_JAYAFN010000090.1",
  "regions": []
 },
 {
  "length": 14922,
  "seq_id": "NZ_JAYAFN010000091.1",
  "regions": []
 },
 {
  "length": 97546,
  "seq_id": "NZ_JAYAFN010000092.1",
  "regions": []
 },
 {
  "length": 10485,
  "seq_id": "NZ_JAYAFN010000093.1",
  "regions": []
 },
 {
  "length": 43526,
  "seq_id": "NZ_JAYAFN010000094.1",
  "regions": []
 },
 {
  "length": 7738,
  "seq_id": "NZ_JAYAFN010000095.1",
  "regions": []
 },
 {
  "length": 31741,
  "seq_id": "NZ_JAYAFN010000096.1",
  "regions": []
 },
 {
  "length": 3846,
  "seq_id": "NZ_JAYAFN010000097.1",
  "regions": []
 },
 {
  "length": 36973,
  "seq_id": "NZ_JAYAFN010000098.1",
  "regions": []
 },
 {
  "length": 39278,
  "seq_id": "NZ_JAYAFN010000099.1",
  "regions": []
 },
 {
  "length": 15473,
  "seq_id": "NZ_JAYAFN010000100.1",
  "regions": []
 },
 {
  "length": 48574,
  "seq_id": "NZ_JAYAFN010000101.1",
  "regions": []
 },
 {
  "length": 79846,
  "seq_id": "NZ_JAYAFN010000102.1",
  "regions": []
 },
 {
  "length": 5982,
  "seq_id": "NZ_JAYAFN010000103.1",
  "regions": []
 },
 {
  "length": 38322,
  "seq_id": "NZ_JAYAFN010000104.1",
  "regions": []
 },
 {
  "length": 8967,
  "seq_id": "NZ_JAYAFN010000105.1",
  "regions": []
 },
 {
  "length": 39608,
  "seq_id": "NZ_JAYAFN010000106.1",
  "regions": []
 },
 {
  "length": 22480,
  "seq_id": "NZ_JAYAFN010000107.1",
  "regions": []
 },
 {
  "length": 9197,
  "seq_id": "NZ_JAYAFN010000108.1",
  "regions": []
 },
 {
  "length": 18168,
  "seq_id": "NZ_JAYAFN010000109.1",
  "regions": []
 },
 {
  "length": 25892,
  "seq_id": "NZ_JAYAFN010000110.1",
  "regions": []
 },
 {
  "length": 30500,
  "seq_id": "NZ_JAYAFN010000111.1",
  "regions": []
 },
 {
  "length": 35548,
  "seq_id": "NZ_JAYAFN010000112.1",
  "regions": []
 },
 {
  "length": 6494,
  "seq_id": "NZ_JAYAFN010000113.1",
  "regions": []
 },
 {
  "length": 21056,
  "seq_id": "NZ_JAYAFN010000114.1",
  "regions": []
 },
 {
  "length": 6379,
  "seq_id": "NZ_JAYAFN010000115.1",
  "regions": []
 },
 {
  "length": 19851,
  "seq_id": "NZ_JAYAFN010000116.1",
  "regions": []
 },
 {
  "length": 19718,
  "seq_id": "NZ_JAYAFN010000117.1",
  "regions": []
 },
 {
  "length": 17031,
  "seq_id": "NZ_JAYAFN010000118.1",
  "regions": []
 },
 {
  "length": 7446,
  "seq_id": "NZ_JAYAFN010000119.1",
  "regions": []
 },
 {
  "length": 16796,
  "seq_id": "NZ_JAYAFN010000120.1",
  "regions": []
 },
 {
  "length": 14521,
  "seq_id": "NZ_JAYAFN010000121.1",
  "regions": []
 },
 {
  "length": 16257,
  "seq_id": "NZ_JAYAFN010000122.1",
  "regions": []
 },
 {
  "length": 7363,
  "seq_id": "NZ_JAYAFN010000123.1",
  "regions": []
 },
 {
  "length": 8772,
  "seq_id": "NZ_JAYAFN010000124.1",
  "regions": []
 },
 {
  "length": 10803,
  "seq_id": "NZ_JAYAFN010000125.1",
  "regions": []
 },
 {
  "length": 15950,
  "seq_id": "NZ_JAYAFN010000126.1",
  "regions": []
 },
 {
  "length": 34560,
  "seq_id": "NZ_JAYAFN010000127.1",
  "regions": []
 },
 {
  "length": 13866,
  "seq_id": "NZ_JAYAFN010000128.1",
  "regions": []
 },
 {
  "length": 24064,
  "seq_id": "NZ_JAYAFN010000129.1",
  "regions": []
 },
 {
  "length": 15722,
  "seq_id": "NZ_JAYAFN010000130.1",
  "regions": []
 },
 {
  "length": 15258,
  "seq_id": "NZ_JAYAFN010000131.1",
  "regions": []
 },
 {
  "length": 9754,
  "seq_id": "NZ_JAYAFN010000132.1",
  "regions": []
 },
 {
  "length": 13735,
  "seq_id": "NZ_JAYAFN010000133.1",
  "regions": []
 },
 {
  "length": 4893,
  "seq_id": "NZ_JAYAFN010000134.1",
  "regions": []
 },
 {
  "length": 48224,
  "seq_id": "NZ_JAYAFN010000135.1",
  "regions": []
 },
 {
  "length": 13518,
  "seq_id": "NZ_JAYAFN010000136.1",
  "regions": []
 },
 {
  "length": 65032,
  "seq_id": "NZ_JAYAFN010000137.1",
  "regions": []
 },
 {
  "length": 38098,
  "seq_id": "NZ_JAYAFN010000138.1",
  "regions": []
 },
 {
  "length": 12350,
  "seq_id": "NZ_JAYAFN010000139.1",
  "regions": []
 },
 {
  "length": 13440,
  "seq_id": "NZ_JAYAFN010000140.1",
  "regions": []
 },
 {
  "length": 13368,
  "seq_id": "NZ_JAYAFN010000141.1",
  "regions": []
 },
 {
  "length": 13032,
  "seq_id": "NZ_JAYAFN010000142.1",
  "regions": []
 },
 {
  "length": 4246,
  "seq_id": "NZ_JAYAFN010000143.1",
  "regions": []
 },
 {
  "length": 9104,
  "seq_id": "NZ_JAYAFN010000144.1",
  "regions": []
 },
 {
  "length": 43459,
  "seq_id": "NZ_JAYAFN010000145.1",
  "regions": []
 },
 {
  "length": 18037,
  "seq_id": "NZ_JAYAFN010000146.1",
  "regions": []
 },
 {
  "length": 13021,
  "seq_id": "NZ_JAYAFN010000147.1",
  "regions": []
 },
 {
  "length": 12992,
  "seq_id": "NZ_JAYAFN010000148.1",
  "regions": []
 },
 {
  "length": 3312,
  "seq_id": "NZ_JAYAFN010000149.1",
  "regions": []
 },
 {
  "length": 12777,
  "seq_id": "NZ_JAYAFN010000150.1",
  "regions": []
 },
 {
  "length": 38407,
  "seq_id": "NZ_JAYAFN010000151.1",
  "regions": []
 },
 {
  "length": 12475,
  "seq_id": "NZ_JAYAFN010000152.1",
  "regions": []
 },
 {
  "length": 11785,
  "seq_id": "NZ_JAYAFN010000153.1",
  "regions": []
 },
 {
  "length": 11705,
  "seq_id": "NZ_JAYAFN010000154.1",
  "regions": []
 },
 {
  "length": 5169,
  "seq_id": "NZ_JAYAFN010000155.1",
  "regions": []
 },
 {
  "length": 32556,
  "seq_id": "NZ_JAYAFN010000156.1",
  "regions": []
 },
 {
  "length": 48142,
  "seq_id": "NZ_JAYAFN010000157.1",
  "regions": []
 },
 {
  "length": 11641,
  "seq_id": "NZ_JAYAFN010000158.1",
  "regions": []
 },
 {
  "length": 11620,
  "seq_id": "NZ_JAYAFN010000159.1",
  "regions": []
 },
 {
  "length": 11325,
  "seq_id": "NZ_JAYAFN010000160.1",
  "regions": []
 },
 {
  "length": 4590,
  "seq_id": "NZ_JAYAFN010000161.1",
  "regions": []
 },
 {
  "length": 9740,
  "seq_id": "NZ_JAYAFN010000162.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r68c1",
  "r77c1"
 ],
 "r68c1": {
  "start": 1,
  "end": 16835,
  "idx": 1,
  "orfs": [
   {
    "start": 1,
    "end": 774,
    "strand": -1,
    "locus_tag": "ctg68_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 774,\n (total: 774 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGAAAAAATTTTTGTTTGTGGCGGCGGCGGTAGCGTCGATGGTTTTCACCGGGTGTATCAACGAGGACGACACCTATAAGAAGTTGCAACCGGTTCAGCAGGGGATCAACATCTACAACTGGACATCCAGCCAGTATTCCATGGCGACCGAGCAGGCCAACATAGGTATGCGTATGGCGATGCTCGTGGCCGAAGCCCACAAGCAGGGGGTGGATAACTTCGAGGATGTGAAAATCGAAGGCATCTCCATCAAGGGCAAGTTGCTCGGCACCTCTTCGAAGATCGAAAAGACGACCACTGGCTACAAAATCACTTTCAATCCTGCATATATGGACATGGACGGCTATTCGCGCGAGGGCGCCGTGCTGATCGACACGGGCGGGGCCCCGCTGCTCGAAGATGCCGTGGCCGGAAAGGTCTGGTCGGTGACGTTCGACGAAAAACTGGTGCTGGTTGCCACCAACGGCAATACGTCGGTAAAGGCTTCGCTGGTGGGCGGTTCCACGCAGCTCTACAACGATGAAAACGGAGCCTATGCGATCAGCATTGCGAATCAGGCCTGCTACCTCGATTCGGGCAGCAATTTTACCTCGAATTGGGGCGGCCGTATGACGTTGAAGCCCCATAACATGAATTTCACCTATTCGGATTGCATGGGCGAGAAGTTCGTCGTGAACACGACGGGTGCAATTTACGGCCCTTCGTTCTATACGATGGACAATGCAACGTCTCTGGAGCTGAGCATGACGCTGACGGATGTCGAGTATTAC",
    "translation": "MMKKFLFVAAAVASMVFTGCINEDDTYKKLQPVQQGINIYNWTSSQYSMATEQANIGMRMAMLVAEAHKQGVDNFEDVKIEGISIKGKLLGTSSKIEKTTTGYKITFNPAYMDMDGYSREGAVLIDTGGAPLLEDAVAGKVWSVTFDEKLVLVATNGNTSVKASLVGGSTQLYNDENGAYAISIANQACYLDSGSNFTSNWGGRMTLKPHNMNFTYSDCMGEKFVVNTTGAIYGPSFYTMDNATSLELSMTLTDVEYY",
    "product": ""
   },
   {
    "start": 838,
    "end": 1041,
    "strand": 1,
    "locus_tag": "ctg68_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 838 - 1,041,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAATGTGCGAATTATTCTATTTTCATCCTGCAAACCGGGCATCCGGCCCCAAATCATCGCCGCCAAAAGGTGCGCCAGGCCCGGCACAGAAAACTTCCCGGAAACCGTCCCCAACGTTTTCCCAGGTTCGATTGCGGCTCAAAGGTACGAATATTTCACTTTTTTTCACTATATTGGCGTTGTAATGTATAATATTTGA",
    "translation": "MKNVRIILFSSCKPGIRPQIIAAKRCARPGTENFPETVPNVFPGSIAAQRYEYFTFFHYIGVVMYNI",
    "product": ""
   },
   {
    "start": 1044,
    "end": 1787,
    "strand": 1,
    "locus_tag": "ctg68_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,044 - 1,787,\n (total: 744 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCAAAACTCTTGTTGCTTATGTCGATCCTATCGTTTTTCGGATGCGGAAAGAAAGCTCCCGAATACCCTGCCGACACGCTGACGACGCGCGACGGCATGCAAATCACGATCACCTTTTTCAAACACGCCTCGCTTTCGATCGAGGCCGGCGGAAAATACATCTACGTAGATCCCGTAAGCGGCTATGCCGACTACGCCGCCCTGCCCAAGGCCGACGTGGTACTTATCACCCACTCGCACTACGACCACCTGGACGTGGCGGCCGTCGAAGCGATCCAGACCCCGCAGACCGAGATACTCTGCGACCGCACATCGGCCGAGGCGTTCGAAATGAACTGCTACACGATGCGCCCGGGCAGTGTCGCTACGCCGCGCGATTACCTGAAAGTCGAGGCCGTGGCCGCTTACAACACGACCGACGGGCACCTGCAATTCCATCCCAAAGAGCGTGAGGACTGCGGCTACGTGCTCACGATAGGCGGCTCGCGCATCTACATCGCGGGCGATACCGAACCCACGCCCGAACTGAAGGCGCTGAAGAATATCGACATCGCCTTCCTGCCGGTCAACCAACCCTACACGATGACCGTCGACCAGGCCGTCGAGGCCGTCAAGGCGATCCGGCCGACGATCTTCTACCCCTACCACTACGGCGAAGTCGAGGAAAAGACCGACATCGACCGCCTCGTGCGGGAGTTGGAAGGCGTAACCGAGGTGCGCATCCGGCCGATGGAGTAA",
    "translation": "MNPKLLLLMSILSFFGCGKKAPEYPADTLTTRDGMQITITFFKHASLSIEAGGKYIYVDPVSGYADYAALPKADVVLITHSHYDHLDVAAVEAIQTPQTEILCDRTSAEAFEMNCYTMRPGSVATPRDYLKVEAVAAYNTTDGHLQFHPKEREDCGYVLTIGGSRIYIAGDTEPTPELKALKNIDIAFLPVNQPYTMTVDQAVEAVKAIRPTIFYPYHYGEVEEKTDIDRLVRELEGVTEVRIRPME",
    "product": ""
   },
   {
    "start": 1927,
    "end": 2340,
    "strand": -1,
    "locus_tag": "ctg68_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,927 - 2,340,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGGATTTTATTTTTGTTCCCCTGGTCGTAGGCGTGATTACGCTGGGAATCTACAAGTTCTTCGAATTGCTCGTGTGCCGTCGCGAGCGCCGCATGATCATTGATAAAATGGACGGCAATGCCCTGATCGACTACCTGAAATTCGTACCGATGGGTGTGAGGATCGGCGCTCCCGTATCGGTGCGGCCCGTGTCGGGCGGGGTGTCCGGAACCCTGAAGGCCGGTTGCCTTTTGCTGGGCATCGGTTTCGGGCTGCTCTTCGCCTTCATGTTGCTGAACTGGTGTGCTTATGATGCTTCGTACGAAATGCGCAGCATCGTCTACGGCGGGTCGGTTCTCTGCTTCGGCGGTGTCGGACTGATCGTTTCGTTCATCGTCGAGCGCAATATCGTCGGCAGGGAGTGTAAATAG",
    "translation": "MMDFIFVPLVVGVITLGIYKFFELLVCRRERRMIIDKMDGNALIDYLKFVPMGVRIGAPVSVRPVSGGVSGTLKAGCLLLGIGFGLLFAFMLLNWCAYDASYEMRSIVYGGSVLCFGGVGLIVSFIVERNIVGRECK",
    "product": ""
   },
   {
    "start": 2485,
    "end": 3051,
    "strand": 1,
    "locus_tag": "ctg68_5",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,485 - 3,051,\n (total: 567 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 117.7; E-value: 6.9e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAACAACAGGAGGAACTGGAGCTGATCCGACGGATCGTAAACGGAGAAACCGATCTGTATGCCATCCTTGCCCGGCGGTACGGGCGGGTGGTCTACACGCTGGTTTCCCGCATCGTCGGCTGCGCAGAGGATGCCGAGGAGCTGGCTCAGGACGTTTTCCTCAAGGCGTTCCGCAACCTGCACAGGTTCAACGGGCGCAGTTCGTTCCCGACCTGGCTCTTCCGGATCGCTTACAACACGGCGGTCTCCGAGACACGGCGCCGCAAACGCGAATGGGCCTGCATCGACCAGGCGCGGCTGGCGAACCTGCCCGACAGCGAAGCCGAGCGGATGGATGCCTGGGAGGGAAGGCAGGAATACCTCGACGCTCTGACCCGTGCCGTCGGTGAGTTGGAGCCCGAAGAGCGGGCACTCGTCACGCTCTTCTACTACGAAGAGTACTCCGTAAGCGAATGCGCCGGGATCACGCAGATGTCGGAGTCCAACATCAAAGTACGGCTCCACCGCATCCGCAAAAAACTGTATATACTGGTAAATACGCAACTGCATGGAAGCGAAAAATAA",
    "translation": "MQQQEELELIRRIVNGETDLYAILARRYGRVVYTLVSRIVGCAEDAEELAQDVFLKAFRNLHRFNGRSSFPTWLFRIAYNTAVSETRRRKREWACIDQARLANLPDSEAERMDAWEGRQEYLDALTRAVGELEPEERALVTLFYYEEYSVSECAGITQMSESNIKVRLHRIRKKLYILVNTQLHGSEK",
    "product": ""
   },
   {
    "start": 3035,
    "end": 3490,
    "strand": 1,
    "locus_tag": "ctg68_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,035 - 3,490,\n (total: 456 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAGCGAAAAATAACATAATCCGTCGCGCGCTGGAGCAAGCCCCGGGTACGCAACTGCCCGAAGGGTTCTGCGAGAGGCTCATGGAACGGCTGGAACGCGAATCGGCGCGGCGCGAACGGCGCGAAACATGGTTGCTGGGCACGGCGGGCGTACTCTGCCTGCTGGCGGTGATCGCCGGGCTCGCCTGGTATTTCTGGTACGAACCGGGCGTCGGGCTGCATCTGCCCGACATGCCTTCATTCCCCGACATGCCTTCATTCCCCGACATGCCCGCGTTCACAAGCCCGGGCTCCCTAAAATTTCCCGAACCGGATTTCCCGGCCGAAAGCAGGCGGCTGTCCCTGTTCTACGTCTTTATCGCCGCAACGTTCCTCGGCCTCGCAGGGCTCGACCTCTACCTGCGCAGGCGCAGGCACAATGCCATGAAAACAAACGGGCACCCGCACCGATAA",
    "translation": "MEAKNNIIRRALEQAPGTQLPEGFCERLMERLERESARRERRETWLLGTAGVLCLLAVIAGLAWYFWYEPGVGLHLPDMPSFPDMPSFPDMPAFTSPGSLKFPEPDFPAESRRLSLFYVFIAATFLGLAGLDLYLRRRRHNAMKTNGHPHR",
    "product": ""
   },
   {
    "start": 3731,
    "end": 4042,
    "strand": -1,
    "locus_tag": "ctg68_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,731 - 4,042,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAAAATTTTAATGCTGTGCCTTGCACTCGTGATGGGTGTGGGCATGTGTGCAGCGCAGAAGGCTGCCGACAAAAAGACGGTGACGACGGTTTTCACGACCGACATCGACTGTGAACACTGTGTCAAGAAGATCATGAATAATGTCCCCTCGCTCGGCAAGGGCGTCAAGGACGTGAAGGTCGACCTGCCCAAGAAGGAGGTGACCGTGGTCTACGATTCCACGAAAAACAGCGACGAGAATATCGTCAAGGGTTTTGCTTCGATCAAAGTCAAGGCCGAACCGAAAAAAGCCGACACGAAGAAATAA",
    "translation": "MKKILMLCLALVMGVGMCAAQKAADKKTVTTVFTTDIDCEHCVKKIMNNVPSLGKGVKDVKVDLPKKEVTVVYDSTKNSDENIVKGFASIKVKAEPKKADTKK",
    "product": ""
   },
   {
    "start": 4066,
    "end": 6402,
    "strand": -1,
    "locus_tag": "ctg68_8",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,066 - 6,402,\n (total: 2337 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 73.5; E-value: 3.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKINKIILSVSSLAVCGTLSAQDLRGVVRDADNQPLVGASVYWEGTTIGASTDAQGAFLLHRVKGYDNLVASYLGYVNDTLRVAGGAERIEFTLASEGVALEDVVVEGNLSGNFVKRDGIVKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGVASVTAGHEAITGQINLEHRKPTDDERLFVNLYLDDELRPEANISTAFPVTKDKKLSSVILLHGSMDTDVRKMDHNDDGFRDLPLSDQINVANKWLYAADNGTQIRWGWKFVQENRLGGMLDYKNSMRGEMEKNWNWKETGADMPLYGSKIRNRGANGYFKIGMPVGPSVYDADEQDEMRSNLAFVADFDHFNEYAYFGLNDYRGNENTLSLNLMYNHYFTYRSSLIVGAQGHLQYYRESFANNTPWIAAAPATLYDFDRNEQEVGAYAEYTYSIKDKFSVVAGIRGDYNAFYDKFFVTPRGHIRWNITPSTTLRGSAGLGYRSTNVITDNIGMLATGRQIVIPDFDGFNRLEKALTVGGSLTQTFGLVSPGDATLSFDYFRTQFYNSVIADQEYSADQIVLYNSDKRSYTDTYQIDFSWTPVERLDIFATFRYTDSEMTIDRPDGKTARVERPLVSQYKTLLNIQYATKFRRWVFDATAQLNGPARIPTQTGDLADDKYSPRYPMFFAQISRKVGKFDIYAGCENIADYRQHDPILNADNPYSTGFNSMNVWGPLMGRKFYIGLRFNLY\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAATCAACAAAATCATTTTATCTGTTTCTTCCCTTGCCGTGTGCGGAACCCTCAGCGCACAGGATTTGCGGGGTGTAGTCCGCGACGCCGACAACCAGCCGCTGGTGGGCGCTTCGGTTTACTGGGAGGGTACTACGATCGGTGCCAGCACCGATGCCCAGGGGGCGTTCCTGCTCCATCGGGTAAAAGGTTACGACAATCTGGTCGCCTCGTATCTGGGATATGTGAACGACACGCTGCGTGTGGCAGGCGGTGCGGAGCGTATCGAATTCACGCTCGCTTCCGAAGGCGTGGCGTTGGAGGACGTGGTGGTCGAGGGTAATCTGAGCGGCAACTTCGTCAAGCGTGACGGCATCGTCAAGGGCGAGATGATCTCGTTCGCGGGCCTCTGCAAGATGGCCTGCTGCAATCTGGCCGAGAGCTTCGAGAACTCGGCGTCGGTGACCGTCGGGTACAGCGACGCCATTTCGGGCGCACGGCAGATCAAGATGCTCGGCCTGGCAGGTACCTATACCCAGATCCTCGACGAAAACCGCCCGATCATGCGCGGGCTGAGCGCCCCCTACGGACTGAGCTACACGCCCGGCATGTGGCTCAATTCGATTCAGGTGTCGAAGGGCGTGGCGTCGGTGACGGCCGGGCATGAGGCCATCACGGGGCAGATCAACCTCGAGCACCGCAAGCCGACGGACGACGAGAGGCTGTTCGTGAACCTCTATCTGGACGACGAACTGCGCCCCGAGGCCAACATCTCGACGGCGTTCCCCGTCACGAAGGACAAGAAACTGTCGAGCGTCATCCTGCTCCACGGTTCGATGGATACCGACGTCCGTAAGATGGATCACAACGACGACGGATTCCGCGACCTGCCGCTCTCCGACCAGATCAATGTGGCCAACAAGTGGCTTTATGCGGCCGACAACGGTACGCAGATCCGCTGGGGATGGAAATTCGTACAGGAGAACCGCCTGGGCGGTATGCTCGACTACAAGAATTCGATGCGCGGCGAGATGGAGAAGAACTGGAACTGGAAGGAGACGGGCGCCGATATGCCCCTCTACGGTTCGAAGATCCGCAACCGCGGCGCGAACGGTTATTTTAAAATAGGTATGCCCGTCGGCCCGTCGGTCTACGATGCCGACGAGCAGGATGAGATGCGTTCGAACCTGGCTTTCGTGGCCGATTTCGACCACTTCAACGAGTACGCCTATTTCGGGCTGAACGACTACCGCGGCAATGAGAATACGCTCTCACTGAACCTCATGTACAACCACTATTTCACCTACCGGTCGTCGCTGATCGTCGGTGCACAGGGACATTTGCAGTACTACCGCGAGAGTTTTGCTAACAACACCCCGTGGATTGCGGCGGCTCCGGCTACGCTCTACGACTTCGACCGCAACGAGCAGGAAGTGGGTGCCTATGCCGAGTATACCTATTCGATCAAGGACAAGTTCTCGGTCGTGGCGGGTATCCGCGGCGATTACAATGCGTTTTATGACAAGTTCTTCGTGACGCCCCGCGGGCATATCCGCTGGAACATCACCCCCTCGACCACGCTGCGCGGCTCGGCCGGCCTGGGATACCGTTCGACCAATGTCATCACCGACAACATCGGTATGCTGGCGACCGGACGGCAGATCGTAATCCCCGATTTCGACGGTTTCAACCGGCTGGAGAAGGCACTTACGGTGGGCGGAAGCCTCACGCAGACCTTCGGGCTGGTCAGTCCCGGCGACGCAACGCTGAGTTTCGACTATTTCCGCACGCAGTTCTACAATTCGGTGATCGCCGACCAGGAGTACAGCGCCGACCAGATCGTGCTCTATAATTCGGACAAGCGTTCCTATACGGATACCTACCAGATCGACTTTTCGTGGACGCCTGTCGAACGGTTGGACATCTTCGCCACGTTCCGTTATACGGACAGCGAGATGACGATCGACCGCCCCGACGGAAAGACCGCCCGCGTGGAACGGCCGCTGGTGAGTCAGTACAAGACGCTGCTCAATATCCAGTACGCCACGAAATTCCGCCGCTGGGTGTTCGACGCGACGGCACAGCTGAACGGCCCTGCGCGCATCCCGACGCAGACGGGCGACCTGGCCGACGACAAGTATTCGCCGCGCTACCCGATGTTCTTCGCCCAGATAAGCCGCAAGGTCGGCAAGTTCGACATCTATGCCGGTTGCGAGAACATCGCCGACTACCGCCAGCACGACCCGATCCTCAATGCGGACAACCCCTATTCGACGGGTTTCAACTCGATGAACGTATGGGGGCCGCTGATGGGGCGCAAATTCTATATCGGCCTGCGGTTCAATTTGTATTGA",
    "translation": "MKINKIILSVSSLAVCGTLSAQDLRGVVRDADNQPLVGASVYWEGTTIGASTDAQGAFLLHRVKGYDNLVASYLGYVNDTLRVAGGAERIEFTLASEGVALEDVVVEGNLSGNFVKRDGIVKGEMISFAGLCKMACCNLAESFENSASVTVGYSDAISGARQIKMLGLAGTYTQILDENRPIMRGLSAPYGLSYTPGMWLNSIQVSKGVASVTAGHEAITGQINLEHRKPTDDERLFVNLYLDDELRPEANISTAFPVTKDKKLSSVILLHGSMDTDVRKMDHNDDGFRDLPLSDQINVANKWLYAADNGTQIRWGWKFVQENRLGGMLDYKNSMRGEMEKNWNWKETGADMPLYGSKIRNRGANGYFKIGMPVGPSVYDADEQDEMRSNLAFVADFDHFNEYAYFGLNDYRGNENTLSLNLMYNHYFTYRSSLIVGAQGHLQYYRESFANNTPWIAAAPATLYDFDRNEQEVGAYAEYTYSIKDKFSVVAGIRGDYNAFYDKFFVTPRGHIRWNITPSTTLRGSAGLGYRSTNVITDNIGMLATGRQIVIPDFDGFNRLEKALTVGGSLTQTFGLVSPGDATLSFDYFRTQFYNSVIADQEYSADQIVLYNSDKRSYTDTYQIDFSWTPVERLDIFATFRYTDSEMTIDRPDGKTARVERPLVSQYKTLLNIQYATKFRRWVFDATAQLNGPARIPTQTGDLADDKYSPRYPMFFAQISRKVGKFDIYAGCENIADYRQHDPILNADNPYSTGFNSMNVWGPLMGRKFYIGLRFNLY",
    "product": ""
   },
   {
    "start": 6468,
    "end": 6881,
    "strand": -1,
    "locus_tag": "ctg68_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,468 - 6,881,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTGAAAAGACTCATATCGCTGTTGCTGCTCGCCATCTACCTGACGGCGTGGGGCGGCCCTGCGTATGTGTCGCTTTCGTGCAAGTGCGTCACGATGTCGTCGCATGTCTGCTGCCACCACTGCCAGCACAGCGCCGATGCCGCGGGTGCCGGCGAGTCGCTGAAGGCTCCCTGCTGCGGCAACCACCATTCGACCGAAATCGAACTCTATACGGGTTCTTCTTCCGATAACCACGAGAGATTCATCCGCTGCACGGTCACCGACCTGCCGCCCGCATTGGTTGCGGAGGCTCCGGTCGCGGCCGTCCTCAAGTTCTTCGGGGAGACGCTTCCCGAATGCGGCGATCCTTTCGTCATGCGGGGCCATGTGCGCTCCGCAGGCCTTCGTGCCCCTCCCGTATTGGCTTAA",
    "translation": "MKLKRLISLLLLAIYLTAWGGPAYVSLSCKCVTMSSHVCCHHCQHSADAAGAGESLKAPCCGNHHSTEIELYTGSSSDNHERFIRCTVTDLPPALVAEAPVAAVLKFFGETLPECGDPFVMRGHVRSAGLRAPPVLA",
    "product": ""
   },
   {
    "start": 6928,
    "end": 7194,
    "strand": -1,
    "locus_tag": "ctg68_10",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,928 - 7,194,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGATAAGCGAAAAATTCAAAGTGCGCGAGATGGCGGGGGAGCATGTGATTATCATGCCGGGCCGCTGCGGTGCCGACATGACCCGTATCCTGGCGCTCAACGATTCGTCGCTCTATCTTTGGGAGGCGCTCGGCGGCAAGGACTTTACCACCGGGGACGCAGCCGCCCTGTTGTTGGAGCGTTACGACGTGGACGAAGCCACCGCACAGCGCGATGCCGGGGCCTGGGCTGCGAAGCTCGCCGAATGCGGCGTGCTGGAGTAA",
    "translation": "MKISEKFKVREMAGEHVIIMPGRCGADMTRILALNDSSLYLWEALGGKDFTTGDAAALLLERYDVDEATAQRDAGAWAAKLAECGVLE",
    "product": ""
   },
   {
    "start": 7269,
    "end": 9203,
    "strand": 1,
    "locus_tag": "ctg68_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,269 - 9,203,\n (total: 1935 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 292.4; E-value: 1e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAAGGCCAGCGGACAAGATATACGACGTACTGAAACGCTACTGGGGCTTCACCGAATTCCGCCCCGTACAGGAGCGTATCATCCGTTCGGTGATGGACGGGCGCGACACCCTGGCCCTGATGCCCACGGGCGGCGGAAAGTCGCTTACCTACCAGATCCCCGGGCTTGCGCAGGAGGGGCTGTGCATCGTCGTGACGCCCCTGATCGCCCTGATGAAAGACCAGGTCGACCGCCTGCGGGCACGGCACATCCCGGCCGTGGCGATCCATTCGGGGCTCTCGCCGCGTGCAATCGACATCGCGCTGGACAACTGCGTCTACGGCGACGTCAAGTTCCTTTACGTCGCCCCCGAGCGGCTCGCAACGGAGGCCTTCCGCCTGCGCGTCGTGCGCATGAACGTATCGCTCGTGGCCGTCGACGAAGCCCACTGCATCTCGCAGTGGGGCTACGATTTCCGCCCCTCGTACCTGCGCATCGCCGAGCTGCGCGAAAAACTACCCGGCGTCCCGGTGCTGGCGCTCACGGCCTCGGCCACGAAACTCGTGGCCGAAGACATCATGCGCCACCTGCGGTTCGCCGAACCGCATATCCTGCGGAGCAGCTTCGCACGTCCCAACCTTTCGTACAGCGTCCGCCACACCGACGACAAGAACGGGCAGCTGCTGCGCCTGGTACGCAACGTCCCCGGCTCGGGCATCGTCTACGTCCGTACGCGCGAAGGCACCGAGCAGGTCGCCGACATGCTGCGCAGGGAGGGCATAACGGCCGCGGCCTACCATGGGGGCATGGGGCATGCCGAACGCTCGCTGCGGCAGGAGGAGTGGGTCTCGGGCAGGACGCGCGTGATGGTCGCCACCAACGCCTTCGGCATGGGCATCGACAAACCCGACGTGCGCTTCGTCGCCCATTACAGCATGTGCGACTCGCTCGAGAGCTACTACCAGGAGGCCGGCCGAGCGGGCCGCGACGGTATGCGGAGCTACGCCCTGCTGCTGGTCTCGTCGGACGACGGCGAACGCATCGTGCGGCGTTTCGAGCAAGAGTTCCCGCCGCTCGAAAAGATCAAGGACATCTACGAACGGGTCTGCTCCTACCTGCAGGTCGGCATCGGCGACGGCGCCCAGGCATCGTTCCTGTTCAACATCCACGACTTCTGCGCCCGCGAGCACCTCTACTCCGGCACGGTCGTAAGCGCCCTGAAGCTCCTGCAGCAAAACGGGTACATGACGCTGACCGACGCACAGGAGAACCCGGCGCGGATCATGTTCTGCGTGAGCCGCGACGACCTCTACAAACTCCGCGTGCAGCGCGACGAGCTGGATCACTTCATCCGCACGCTGCTGCGCCTCTACAACGGGGTCTTCACCGAATTCCGGCAGATCGACGAGGGCGAGATCGCCACCTGGAGCGGCTATACCGTACAGCGGGTCAAGGAGCTGCTCAAACGCCTCTGGCAGTTGCGCGTGATCCGCTACGTCCCCTCCAACCGCTCGCCGATCCTCTTCATGGACGAGGAGCGGCTGCCCCGCGCCGACCTCTACATCGCCCCCGAGACCTACAAACGGCGGCAGGAGCTGATGCGCGAACGCTTCGAACACATGCTCGCCTACGCCGCGAACGAGACCCGTTGCCGCAGCGCCGTTCTGGAAGGGTATTTCGGTGAAGGCGCCCCTGCGGCATGCGGCGTATGCGACATCTGCCTCGCACACAAACGTGCCGGGAAGCGGCAGGCACAGGGCTGCGCCACGCCGTCGGCCGACGGCGGGCTGCGCGAAAAACTGCGGCAAAGGCTATCCCGCGGGGCAGCCGACCCGCACGAACTGGCCGCGGAATTCCCCGGGGAGGCACAGCAGATAGGCCGGGCGCTGCGCGAATTGCTCGACGAAGGCATCGCCGGCACGGGCAGGGACGGGAAAATCGGGTTAAAATAG",
    "translation": "MERPADKIYDVLKRYWGFTEFRPVQERIIRSVMDGRDTLALMPTGGGKSLTYQIPGLAQEGLCIVVTPLIALMKDQVDRLRARHIPAVAIHSGLSPRAIDIALDNCVYGDVKFLYVAPERLATEAFRLRVVRMNVSLVAVDEAHCISQWGYDFRPSYLRIAELREKLPGVPVLALTASATKLVAEDIMRHLRFAEPHILRSSFARPNLSYSVRHTDDKNGQLLRLVRNVPGSGIVYVRTREGTEQVADMLRREGITAAAYHGGMGHAERSLRQEEWVSGRTRVMVATNAFGMGIDKPDVRFVAHYSMCDSLESYYQEAGRAGRDGMRSYALLLVSSDDGERIVRRFEQEFPPLEKIKDIYERVCSYLQVGIGDGAQASFLFNIHDFCAREHLYSGTVVSALKLLQQNGYMTLTDAQENPARIMFCVSRDDLYKLRVQRDELDHFIRTLLRLYNGVFTEFRQIDEGEIATWSGYTVQRVKELLKRLWQLRVIRYVPSNRSPILFMDEERLPRADLYIAPETYKRRQELMRERFEHMLAYAANETRCRSAVLEGYFGEGAPAACGVCDICLAHKRAGKRQAQGCATPSADGGLREKLRQRLSRGAADPHELAAEFPGEAQQIGRALRELLDEGIAGTGRDGKIGLK",
    "product": ""
   },
   {
    "start": 9281,
    "end": 9904,
    "strand": 1,
    "locus_tag": "ctg68_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,281 - 9,904,\n (total: 624 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCCACGGCATGACTACGACAAACAACTTTACGGATAAGATCAGCAACGAGGAGGCCGCAGCGCTTCCGGCCATCGAATTCAGGGGCGAAATACGCATCGTCGACAATGAGCGCGACATCGTCCCCGCCTGCAAATTCCTGATGAAACAACGCGTCATCGGTTTCGACACCGAGACCCGCCCGTCGTTCCGGCCCGGGGTGACGTTCCGCGTGTCGCTGCTGCAACTCTCCACGCCGCAGCTATGCTTCCTCTTCCGGCTGAACAAGATCCCGCTCGCCAAGCCGATCCTGCAGGTGCTCGAAAGCCAGGAGATCCTGAAAATCGGCGCCGACGTCGCGGGCGACCTGCGCTCGTTGCGCCAGATACGCCATTTCCGCGACGCAGGGTTCGTCGACCTGCAAACGATAGCCCCCCAATGGGGCATCGGGGAGAAGAGCCTGCGCAAACTCTCGGCCATCGTGCTGGGGCAGCGCGTATCGAAGGCTCAGCGGCTGAGTAACTGGGAGGCCGCGACATTCACCGACAAACAAAAACTCTACGCCGCGACCGATGCGTGGGTCTGCACGGCGATCTACGACCGACTGCTTCACACACCCAAAATCAAACATCCCGAATTATGA",
    "translation": "MFHGMTTTNNFTDKISNEEAAALPAIEFRGEIRIVDNERDIVPACKFLMKQRVIGFDTETRPSFRPGVTFRVSLLQLSTPQLCFLFRLNKIPLAKPILQVLESQEILKIGADVAGDLRSLRQIRHFRDAGFVDLQTIAPQWGIGEKSLRKLSAIVLGQRVSKAQRLSNWEAATFTDKQKLYAATDAWVCTAIYDRLLHTPKIKHPEL",
    "product": ""
   },
   {
    "start": 9901,
    "end": 11100,
    "strand": 1,
    "locus_tag": "ctg68_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,901 - 11,100,\n (total: 1200 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACACCTCAAGTATACCTGCGCAAAGGCAAGGAAGAATCGCTCATGCGCCGCCACCCGTGGATTTTCTCGGGCGCCATCGACCACATCAAGGCCGAAGACGAATCGGAAATCACGGAAGGCGCCCTGGTCGAAATATATACCCGCACGGGCGATTTCATCGCCCTGGGACACTACCAGATCGGCTCGATCGCCGTGCGTGTGCTTACATTCGACAAGGAACCGATCGACCAGGACTGGTGGAACCGGCGCATCGCCGTGGCCTACGACGTGCGGCGCACGCTCGGGCTCACGGACAACCCCGACACGGACTGTTACCGCCTCGTCCACGGCGAAGGCGACGGGCTCCCGGGACTGGTCGTGGATATCTACGGCACGGTGGCCGTCATCCAGTGCCACTCCGTCGGCATGTACCTCGCCCGCCAGGACATCGCGCGGGCGATCCTGGCCGCCTACGGCGACCGCATCACGGCCATCTACGACAAGAGTTCGCAAACCGTGCCCTTCAACGCCAAGCTGGGCGCTGTGGACGGCTACCTGTGGGGAAGTTCCGACCATTCGGCGCACGTGGTAACGGAGAACGGCGAGAAATTCCTCGTCAACTGGGAGCAGGGGCAGAAAACCGGGTTCTTCCTCGACCAGCGCGAAAACCGGGAGCTGGTCAAACGCTACTCGAAGGGGCGCACGGTGCTCAACACCTTCTGCTACACGGGGGGCTTCTCGGTCTATGCCATGGCCGGTGGCGCCGAGAAGGTCTGCTCGGTGGACTCTTCGGAACGCGCCGTCGTGCTGGCCACGGAAAACATGAAACTCAACTTCGGCCCGCAGGCCAACTTTACGGAAACAGCCGCCGATGCCGTGGAGTACCTCAAGGACATCGAAGACAAATACGACCTGATCATCCTCGACCCGCCGGCTTTCGCCAAGCACCACAAGGTGCTGGGTAATGCCATGCAGGGCTACAAGCGCCTCAACGCCCGCGCCATATCGCAGATACGCCCCGGCGGCATCCTCTTCACGTTCTCCTGCTCGCAGGCGGTGTCGAAGGAGCTGTTCCGCACGATGATTTTCTCGGCCGCGGCCATCGCGGGCCGCAACGTGCGCATCCTGCACCAGCTGACGCAGCCCGCCGACCACCCGGTGAGCATCTACCACCCCGAAGGCGAGTACCTCAAGGGACTGGTGTTGTATGTAGAATAG",
    "translation": "MTPQVYLRKGKEESLMRRHPWIFSGAIDHIKAEDESEITEGALVEIYTRTGDFIALGHYQIGSIAVRVLTFDKEPIDQDWWNRRIAVAYDVRRTLGLTDNPDTDCYRLVHGEGDGLPGLVVDIYGTVAVIQCHSVGMYLARQDIARAILAAYGDRITAIYDKSSQTVPFNAKLGAVDGYLWGSSDHSAHVVTENGEKFLVNWEQGQKTGFFLDQRENRELVKRYSKGRTVLNTFCYTGGFSVYAMAGGAEKVCSVDSSERAVVLATENMKLNFGPQANFTETAADAVEYLKDIEDKYDLIILDPPAFAKHHKVLGNAMQGYKRLNARAISQIRPGGILFTFSCSQAVSKELFRTMIFSAAAIAGRNVRILHQLTQPADHPVSIYHPEGEYLKGLVLYVE",
    "product": ""
   },
   {
    "start": 11122,
    "end": 11481,
    "strand": 1,
    "locus_tag": "ctg68_14",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,122 - 11,481,\n (total: 360 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1167:transcriptional regulator (Score: 119.3; E-value: 6.7e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAAAAACCGCACACCCGACCTACGCCCACTGCCCGATCCGCCATATCGTCGACCGCTTCGGGGACAAGTGGTCGCTGCTGGTACTCTACAACCTCCATACGAGCGGGTGCCTGCGTTTTTCGGAAATCCACCGCCGGACGGCCGACATCTCGCAGAAGATGCTCACATCGACACTCCGCAAGCTGGAACAGGACGGGCTGCTGTCGCGCAAGGTCTACCCCGAGGTACCGCCCCGCGTGGAATATGCGCTCACGCCCCGCGGCGAGTCGCTCATGCCCCACCTCACAGCGCTTATCGGGTGGGCAGAGGAAAATTTCGACGCCATCCTCGAAGACCGGGAGCGGGAAAAGATATAG",
    "translation": "MEKTAHPTYAHCPIRHIVDRFGDKWSLLVLYNLHTSGCLRFSEIHRRTADISQKMLTSTLRKLEQDGLLSRKVYPEVPPRVEYALTPRGESLMPHLTALIGWAEENFDAILEDREREKI",
    "product": ""
   },
   {
    "start": 11758,
    "end": 12612,
    "strand": -1,
    "locus_tag": "ctg68_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,758 - 12,612,\n (total: 855 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACGAACTTTTTTTGTATTGCTCCTGTTGGCGGCCGGAACCGCACTCCGGGCGCAGACACTGGGCGGGGAGTACCGCCTGTCGCGGGTTTTCCCGGTCGAAGGCCGGCAGGGGATCGCCGCTGACTCGAACTACTATTATGTTTCGGGCAGCACGGTGCTCTACAAGTACGACAAGCAGGGGCGGCTGGTCGCCCGTAACGGGCAGCCGTTCGAAGGGTTGCCGCTCGCCGCGAACCATATCGGCGATATCGACGTCTGGAACGGTGAGATTTATGCCGGCATCGAGACTTTCGAAGACGGTAAGGGTGAGAATATCCAGGTCGCCGTGTACGATGCCGACGACCTGACATGGAAGCGGTCGATCGATTGGGAACCGGCTTCGGGGCAGGTCGAGGTGTGCGGGCTGGCCGTAGACCGCGACCGGAATATGGTCTGGATGGCCGACTGGGTCGACGGGCGCTACCTGTACGGTTATGACCTGGCGACGGGTAAGTATGTGCGCAAAGTCCACCTGCGCCCGGTGCCGCAGTGGCAGCAGGGGATATATATGGCCGGCGGGCAGATGCTCATTTCGGCCGACGACGGCGATGCCGACCTGGACGAGCCGGACAACCTCTATATTGCCGACCTGCGCGACGGGAAAAGCTATGCTACGGTGTTGCCGTTCCGTATGATGTCCGATTTCCGGCGCGCGGGCGAGATCGAGGGGCTGACCGTCGACCCTGCGACGGATGAGCTGCTGGTACTTTCGAACCGGGGTTCGCGCATCGTGCTGGGAATGGTCAGGGGTTTCTACCCGGGGTACGACAGCGAACTGCACGAAGTGTATGTCTATGAAAAGGTAAAATAG",
    "translation": "MKRTFFVLLLLAAGTALRAQTLGGEYRLSRVFPVEGRQGIAADSNYYYVSGSTVLYKYDKQGRLVARNGQPFEGLPLAANHIGDIDVWNGEIYAGIETFEDGKGENIQVAVYDADDLTWKRSIDWEPASGQVEVCGLAVDRDRNMVWMADWVDGRYLYGYDLATGKYVRKVHLRPVPQWQQGIYMAGGQMLISADDGDADLDEPDNLYIADLRDGKSYATVLPFRMMSDFRRAGEIEGLTVDPATDELLVLSNRGSRIVLGMVRGFYPGYDSELHEVYVYEKVK",
    "product": ""
   },
   {
    "start": 13169,
    "end": 15115,
    "strand": -1,
    "locus_tag": "ctg68_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,169 - 15,115,\n (total: 1947 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATAAAAAAACAATTTTAGGTATTGTCGTCGTGGCGGCGCTTTTCCTGGGGTTCGCCTATTTCAATACCAAACAGCAGGAGAAATATCAGCAGGAAATGGCCGCGTATCAGGCCTACCAGGATTCGGTGGCGGCAGCGACGCGCCCCGTAGTCCCCGTAGCCGACAGTACGGCCGTGGCAGCTTCGAGTGCGGTTGTGCCCGAGGCTGAGGCAAATGCCGCTGATGCCGTACGCCGGCAGCAGGTCGCTGCGCTGGGCGAATACCTCGCCGGTGCGCGCGACGCGGAGGCGGAGGAGTTTACCGTCGAGAACGATGTGATGATCGTGACCTTTTCGACCCGCGGCGGCCGGATCACGGGCGTGACGCTCAAGGATTACACCAAGTATGCACCCCGCGGCAAGCGTGACCAGCTGATCGAGCTGATGGATCCCGCGAGTGCCAGGTTCGACCTTTCGTTCTACGTGAAGAACGGCTTGAACAACGTCAAGGTCAACACGATGGACTATGTCTTCCGGGCCCAGCCCGAACAGGTCGAAGGCGATGCCCGGAGGGTGGTGATGCGCCTGCCCGTGGCAGCGGATGCCTGGCTCGAATATGAGTACCTTATATATAATAAGCAGGTGCCCGAGCGCGACTACCTCGTGGACTTCAACGTGCGGCTGGTGAATATGGCGCCGCAGATGGCCAACCAGGCGTCGATCGGTATCGACTGGTCGAACAATTCCTACCAGAACGAAAAGGGATTCCAGAACGAGAACATGTACACGACGATTTCGTACCGGTTCCCGGGCGAGAGCTCGATCGAGGATCTGGGGATGAGCGAAAAATCCAAGTCGAAGAGCATCTCCACATCGGTCAACTGGGTGGCTTTTAAGCAGCAGTTCTTTTCGTCGGCGTTCATCGCCCCGCAAAATGTCACCAACGCCAACCTGGCGTTCGATACGGCGGCTCCCGGTTCGGAATTGCTGAAGAGTTTTTCGGCGCAGATGACCGTGCCCTATACGGTGCAGACCGAAGGGTATGACTTTGCATTCTATTTCGGCCCGAACAAATACGCCATCCTCAAGAAGGTCGCCGCTGCGGACGGTGAGGAACTGCACATGGAGCGCCTGATCCCGCTGGGATGGGGTATCTTCGGCTGGGTGAACCGCTGGTGCGTCATCCCGGTCTTCGACTTCCTGCGCAACTATATCGCCAGCTTCGGCATCATCATCCTGATCCTGGTGATCCTGGTGAAACTCGTCATCTCGCCCCTCACGTACAAGAGTTACGTTTCGATGGCAAAGATGCGCCTGATAAAACCGCAGGTGGACGAGCTCAACAAGAAATACCCCAAGAAGGAGGACGCCATGAAAAAACAGCAGGCGACGATGGAGCTCTACAAGAAAGCGGGCATCAACCCCATGGGCGGATGTATCCCCATGCTGATCCAGATGCCGATCCTGATCGCCATGTTCCGTTTCTTCCCGGCTTCGATCGAGCTGCGCGAACAACCGTTCCTCTGGGCCGACGACCTTTCGTCGTACGACAGCATCGTGAACCTGCCGTTCTCGATCCCGTTCTACGGCGACCATGTGAGCCTTTTCGCCTTGCTGATGGCCGTGTCGCTGTTCGGGTATTCGTATTTCAACTACCAGCAGACGGCTTCGTCCCAGCCCCAGATGGCAGGTATGAAGTTCATGATGGTCTACATGATGCCGATCATGATGCTGTTGTGGTTCAACAGCTATTCGAGCGGCCTTTGCTACTACTACCTGCTGTCGAACCTCTTTACCATCGGCCAGACGTTGCTGATCCGCCGCATGGTCGACGACGATAAGATCCATGCCGTCATGCAGGCCAATGCCGCCAAACGGAGCAAGGGCAAGAAGTCGAAGTTCCAGCAGCGCTACGAGGAGCTCCTCCGCCAGCAGGAGGCGCAGCAGCGTACCAAACGCAAGTAA",
    "translation": "MDKKTILGIVVVAALFLGFAYFNTKQQEKYQQEMAAYQAYQDSVAAATRPVVPVADSTAVAASSAVVPEAEANAADAVRRQQVAALGEYLAGARDAEAEEFTVENDVMIVTFSTRGGRITGVTLKDYTKYAPRGKRDQLIELMDPASARFDLSFYVKNGLNNVKVNTMDYVFRAQPEQVEGDARRVVMRLPVAADAWLEYEYLIYNKQVPERDYLVDFNVRLVNMAPQMANQASIGIDWSNNSYQNEKGFQNENMYTTISYRFPGESSIEDLGMSEKSKSKSISTSVNWVAFKQQFFSSAFIAPQNVTNANLAFDTAAPGSELLKSFSAQMTVPYTVQTEGYDFAFYFGPNKYAILKKVAAADGEELHMERLIPLGWGIFGWVNRWCVIPVFDFLRNYIASFGIIILILVILVKLVISPLTYKSYVSMAKMRLIKPQVDELNKKYPKKEDAMKKQQATMELYKKAGINPMGGCIPMLIQMPILIAMFRFFPASIELREQPFLWADDLSSYDSIVNLPFSIPFYGDHVSLFALLMAVSLFGYSYFNYQQTASSQPQMAGMKFMMVYMMPIMMLLWFNSYSSGLCYYYLLSNLFTIGQTLLIRRMVDDDKIHAVMQANAAKRSKGKKSKFQQRYEELLRQQEAQQRTKRK",
    "product": ""
   },
   {
    "start": 15156,
    "end": 16775,
    "strand": -1,
    "locus_tag": "ctg68_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg68_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg68_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,156 - 16,775,\n (total: 1620 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg68_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg68_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACTTTCCAAACCCAAGTACATATTTGTTACGGGCGGTGTCGCATCGTCGCTCGGCAAGGGTATTATTTCGGCCTCGATCGCCCGCCTGCTGCAGGCCCGAGGCTATTCGGTGACCATCCAGAAACTTGACCCCTACATCAACGTCGACCCCGGCACGCTGAACCCCTATGAACACGGCGAATGCTACGTGACCGAGGACGGCGCCGAGACCGACCTCGACCTGGGGCACTACGAGCGTTTCACGAACCAGCCCACGTCGAAGGCCAACAACGTCACGACGGGAAAGATCTACAAGAGCGTGATCGAGAAGGAGCGCAAGGGCGAGTACCTGGGCAAGACCGTGCAGGTCATCCCCCATATCACCGACGAGATCAAGCGCCGTATCCAGATGCTGGCGCAGAAGAAAGTTTACGACGTGATCATCACCGAGATCGGCGGTACGGTGGGCGACATCGAGTCGCTGCCGTTCATCGAATCGGTACGCCAGCTGCGCTATTCGCTGGGCTACAAGAGCACGGCCCTCGTGCACCTGACGCTGATCCCCTATATGGCCGCTTCGGGCGAACTGAAGACCAAGCCCACGCAGCATTCGGTCAAGGCCCTGCTCGAAAACGGGTTGCAGCCCGACATCCTCGTGCTGCGCACGGAGCATCCGCTGTCGACCAACCTGCGCCGCAAAGTGGCGTTATTCTGCAATGTCGACGCCAACGCCGTGATGGAGTCGATCGACGTGCCGACGATCTACGAAGTGCCGCTGAAGATGCACGAACAGCACCTCGACGAGGTGGTGCTCGACAAACTGAACCTGCCGGCCGAGAAGGAACCCGACATGGCGGCGTGGACGGCCTTCGTGGAGAAGGTGAAGCACCCGGCCAAGAAGATCGAGATCGCGCTGGTTGGCAAATATACCGAATTGCCCGACGCTTACAAGTCGATTTGCGAATCATTCATCCATGCAGGGGCCGTGAACGACTGCAAGGTCAAGTTGCGCTATGTCAATTCGGAAAAGGTTACAGCCGAGAATGTGGCCGAGAAGCTGGGCAGGATGTCCGGTATCCTCGTGGCCCCGGGCTTCGGCAACCGTGGCATCGAAGGTAAGATCGTCGCTGTGCGCTATGCACGTGAGAACAAGATCCCGTTCCTGGGAATCTGCCTCGGTATGCAGTGCGCCGTGATCGAATTCGCACGCAACGTGCTGGGTCTGGCCGATGCGAATTCGAGCGAAATGGAGTCTACGCCCCATCCGGTGATCGACCTGATGGAAGAGCAGAAGGGCGTGACGGCCAAGGGCGGCACGATGCGGCTGGGCGCTTATCCCTGTACGCTGAAGAAAGGTTCGAAAGTCGCGGCGGCCTACGGCAAGCTCCATATTTCGGAGCGTCACCGTCACCGTTACGAATTCAACAATGATTACCTGGCTGCGTTCGAAGGTGCCGGTATGCAGGCCGTGGGTATCAATCCCGACACGGGGCTGGTCGAGGTCGTCGAGGTCGAGGGGCATCCCTGGTTCGTCGGTACGCAGTACCATCCCGAATATAAGAGTACGGTGCTGAGCCCCTCGCCGCTGTTCGTGGCATTTGTGGGAGCGGCACTCGAATATGCCGGGAAGAAATAA",
    "translation": "MKLSKPKYIFVTGGVASSLGKGIISASIARLLQARGYSVTIQKLDPYINVDPGTLNPYEHGECYVTEDGAETDLDLGHYERFTNQPTSKANNVTTGKIYKSVIEKERKGEYLGKTVQVIPHITDEIKRRIQMLAQKKVYDVIITEIGGTVGDIESLPFIESVRQLRYSLGYKSTALVHLTLIPYMAASGELKTKPTQHSVKALLENGLQPDILVLRTEHPLSTNLRRKVALFCNVDANAVMESIDVPTIYEVPLKMHEQHLDEVVLDKLNLPAEKEPDMAAWTAFVEKVKHPAKKIEIALVGKYTELPDAYKSICESFIHAGAVNDCKVKLRYVNSEKVTAENVAEKLGRMSGILVAPGFGNRGIEGKIVAVRYARENKIPFLGICLGMQCAVIEFARNVLGLADANSSEMESTPHPVIDLMEEQKGVTAKGGTMRLGAYPCTLKKGSKVAAAYGKLHISERHRHRYEFNNDYLAAFEGAGMQAVGINPDTGLVEVVEVEGHPWFVGTQYHPEYKSTVLSPSPLFVAFVGAALEYAGKK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 6927,
    "end": 7194,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 16835,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r68c1"
 },
 "r77c1": {
  "start": 1,
  "end": 30049,
  "idx": 1,
  "orfs": [
   {
    "start": 2,
    "end": 478,
    "strand": -1,
    "locus_tag": "ctg77_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 478,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGATAGCGTCACTTCTTTTCATCCCCGCCCTGCTCCTGTCGGGGCTGACGGCCCGGGCCGGGCTGCCCGCGTCGTTCAAAGAGCGGCTCGCCGAAGCCAGCCGCGAGAACAGGACTATCCAGTGCGACTTCACGCAGCGCAAACAGGTGCGCCGCATGAAGAACGAGATCGAGCTCAAAGGCCGCTTCTATTACGACAACAGCCTGGCCATGGCGCTCGACTACACCGTGCCCGAAGGCGACAAGGTGATTATCCGCAACGACCGCATCATCCTCAAAACGGCCGGGCAGGTGACCCAGACCGCGACGTCGGCCAACCCCATGCTGCAACAGGTGGCGCTGATGATCCGCGCCAGCATGACCGGCGACCTCTCGCAGTTCGGCCAAGGGTGGCAGATCGGCTACACCGAAAAGGAGGGTGTCGGGGAGGTGAAAATGGTTCCCGAGTCGAAGCGCGCCCGCAAGTACATCGAC",
    "translation": "MKIASLLFIPALLLSGLTARAGLPASFKERLAEASRENRTIQCDFTQRKQVRRMKNEIELKGRFYYDNSLAMALDYTVPEGDKVIIRNDRIILKTAGQVTQTATSANPMLQQVALMIRASMTGDLSQFGQGWQIGYTEKEGVGEVKMVPESKRARKYID",
    "product": ""
   },
   {
    "start": 475,
    "end": 1161,
    "strand": -1,
    "locus_tag": "ctg77_2",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 475 - 1,161,\n (total: 687 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1235:polysaccharide deacetylase (Score: 124.1; E-value: 1.1e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTATGTAATTATCGCCATAATCGCCGCGGGGTTCGCCCTTTTCTACTGCTCCTACCAGATCAGGCTGGGGGCGTATGTCCGCAGCCTGTGCCGCAACCGGGCGGCGGGGCGCGTCGTGGCGCTGACGTTCGACGACGGGCCCGACCCCGAGCAGACGCCGCGCGTATTGGACACGCTGCGGGCGCACGGCGTACGGGCGACCTTCTTCCTGATCGGCAGCAAGGCCGAACTGCACCCGGAGATCGTACGCCGTATGGCCGCCGAGGGGCATGCAATCGGCATTCACACGTGGAGCCACACGCCCGGCTTCCCGATGCTGCGAAGCGGGGCGATGGCGGCCGACATCCTGCGGTGCCGGGAGTCGCTGCGCGAGATAACCGGCGTGGAAACCGACCTTTTCCGGCCCCCCTACGGGGTCACGAACCCGATGGTGGCACGCGCCGTGAAACGGACGGGAAGCCGCTGCGTGGGCTGGAGCATCCGCTCGCTCGACACGCTCCGGCAGCGCAGCCGTGAGGCCGTGGCACGCCGCATCCGCCGACGGCTGGGCGACGGCAAGGTGATCCTGCTGCACGACGACCGCCCCGGTGCCGAACGGCTACTGGCGATGGTGCTGAACGACCTGCAACGCGGGGGCTACCGCACGGCGACCGTATGCGAACTGTTTAAAACCGAGAAACCATGA",
    "translation": "MYVIIAIIAAGFALFYCSYQIRLGAYVRSLCRNRAAGRVVALTFDDGPDPEQTPRVLDTLRAHGVRATFFLIGSKAELHPEIVRRMAAEGHAIGIHTWSHTPGFPMLRSGAMAADILRCRESLREITGVETDLFRPPYGVTNPMVARAVKRTGSRCVGWSIRSLDTLRQRSREAVARRIRRRLGDGKVILLHDDRPGAERLLAMVLNDLQRGGYRTATVCELFKTEKP",
    "product": ""
   },
   {
    "start": 1152,
    "end": 2198,
    "strand": -1,
    "locus_tag": "ctg77_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,152 - 2,198,\n (total: 1047 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACTCTACGTCAACTGCATCACATCGGGCGCCGGGCTGCGCCGCGACATCAAGGAGCTGATCCCCGAAATGAACCTCCGCCGGAGGATGAGCCGTGTGGTGAAGTCGGGCGTCGCGGCGGGCATCGAATCGCTGTTGGAATTCGGCGACCGGGCGGCGGTCGAGGCCGTCGTCACGGCCACGGGGCTAGGGTGCATCGCCGACAGCGAGAAATTCCTCGACTCGCTGATCGCCAACGAAGAGCGGATGCTCAACCCGACGCCGTTCATCCAGTCGACGTTCAACACGGTCGGGGCGCAGATCGCCCTGCTGCGCGGGCTGCACTGCTACAACACGACCTACGCCAACCGCTGGACGAGCTTCGAGAACGCCCTGACGGATGCCGCACTGCGCATCGGCGCGGGGCTGTCGCGGGCGGTGCTGGTCGGGGCGTTCGACGAGACGACGCCGTCGGTCGAAAAGGTACTGCAACGCCTCGGGATGGCACAGCAGGGCGGCTGGGGCGAATCGTCGGTATTCTTCGTGCTGACCGCCGAAGCGTTCGACACCTCGGTCGCGGCGATCACGGGGATCCGGTTCACGGACGGCACAGCCATCGGGGAAAGCGCCGGCAGTGAATTCCCGGACGGGGAAAGCGCCGGCACGGGAAGAATCCAGTCCCGGGAAGATGCCGGCACAAGGACATCGGCCGGGGGAAACGCCGGCCGTGAAATCCCGGCCGGGGGAAGTCCCGGCACGGGGGCGGCCGCCGGGAACGGGGAGGAACCAGGGAATGCGATGCATAGCGGCGAGTGCCGGACGGTACGTGCGTCGATGAGCGGCGTGACGCCCCATTTCACGGCCATCGCCGAGGTGTTCCGCCGTGTGGTCGCCGGGGAGGCCGGGAATACGGGTAAGGCCGGAAATATCGGGAACGCCGGGAGCATCGAGGACACCGGGAACACCGGGAACATCGGGAACGCGGGGAACGCCGAGCAGAGGATCGTGCTTTACAACGATTTCCCGGGCAGCACCGTATCCGCCATCGAATTGACATGTATGTAA",
    "translation": "MKLYVNCITSGAGLRRDIKELIPEMNLRRRMSRVVKSGVAAGIESLLEFGDRAAVEAVVTATGLGCIADSEKFLDSLIANEERMLNPTPFIQSTFNTVGAQIALLRGLHCYNTTYANRWTSFENALTDAALRIGAGLSRAVLVGAFDETTPSVEKVLQRLGMAQQGGWGESSVFFVLTAEAFDTSVAAITGIRFTDGTAIGESAGSEFPDGESAGTGRIQSREDAGTRTSAGGNAGREIPAGGSPGTGAAAGNGEEPGNAMHSGECRTVRASMSGVTPHFTAIAEVFRRVVAGEAGNTGKAGNIGNAGSIEDTGNTGNIGNAGNAEQRIVLYNDFPGSTVSAIELTCM",
    "product": ""
   },
   {
    "start": 2195,
    "end": 3358,
    "strand": -1,
    "locus_tag": "ctg77_4",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,195 - 3,358,\n (total: 1164 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 244.4; E-value: 3.6e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCATAGCCGTCTGCGGCATAGGGATCGTCTCGGCCATCGGCATCGGAGCCGGGGAGACGCTCGGGAACCTGCGCACCGGACGCAGCGGAATCGGGAAGCCGACGCTTCTCGGTTCGGCTGTCGACGTGCCCGTGGGCGAGGTGAAGCGGGACAACGCGGCGCTCGGGGAGCTGCTCGGCATCCCGGAGCGCGAGCACCCCTCCCGCACCGCCCTGCTGGGCATGGCGGCGGCCGCACAGGCCGTAGCGGATGCGGCGATCCCCGCCGGGGCGCGCGTAGCACTCGTTTCGGGCACCTCGGTAGGCGGCATGGATCTGACGGAGAATTTCTACCGCGACTTCCGCACGGACAAGGCGAAAGGGCGGCTGCGCGACGTGGCGGGGCACGACTGTGCCGACAGCACGCAACGGATCGCCCGCTACTGCGGCATCGGAGGTTACACGGCGACGGTCAGCACGGCCTGCTCGTCGGCCGCAAACGCCATCGTCACCGGCGCCCTGCTGCTCGGGAGCGGCATGGCCGACTATGTGGTGGCCGGGGGCACGGATGCCCTTTGCCGTTTCACGCTCAACGGCTTCAACTCGCTCTCGGTGCTCGACCGGGAACCCTGCCGCCCGTTCGACGCCACGCGCGCCGGGCTGAACCTGGGCGAAGGGGCGGGTTACCTCGTCCTCACGCACGAAAGGCCCGGCATGCGCACCTACTGCCGCCTGGCGGGATATGCCAATGCCAACGACGCCTATCACCAAACGGCCTCGTCGCAAACGGGCGAGGGGGCATACCGCGCCATGGCCGGGGCGCTGGCACAAAGCGGGCTGCGCTGCGTGGACTACATCAACGTCCACGGCACGGCGACCCCGAACAACGACCTCACGGAAGGTACCGCCCTGCGGCGACTGTTCGGCGGACAGGTGCCGCCGTTCAGTTCGACGAAAGGCTACACGGGGCATGCGCTCGCCGCGGCGGGAGGCATCGAGGCCGTATTGGCGGTGCTGGCTATCACACACGGGCTGCGCTACGGCAACCCCGGATTCGCGGAGCCGATCCCGGAGCTCGGGCTGCACCCCGTAGCACGGACGCAAGAGGCCGACGTACGTTCGGTGCTCTCAAATTCGTTCGGGTTCGGCGGCAACTGCTGTTCGTTAATCTTTGCCAAATGA",
    "translation": "MSIAVCGIGIVSAIGIGAGETLGNLRTGRSGIGKPTLLGSAVDVPVGEVKRDNAALGELLGIPEREHPSRTALLGMAAAAQAVADAAIPAGARVALVSGTSVGGMDLTENFYRDFRTDKAKGRLRDVAGHDCADSTQRIARYCGIGGYTATVSTACSSAANAIVTGALLLGSGMADYVVAGGTDALCRFTLNGFNSLSVLDREPCRPFDATRAGLNLGEGAGYLVLTHERPGMRTYCRLAGYANANDAYHQTASSQTGEGAYRAMAGALAQSGLRCVDYINVHGTATPNNDLTEGTALRRLFGGQVPPFSSTKGYTGHALAAAGGIEAVLAVLAITHGLRYGNPGFAEPIPELGLHPVARTQEADVRSVLSNSFGFGGNCCSLIFAK",
    "product": ""
   },
   {
    "start": 3355,
    "end": 5496,
    "strand": -1,
    "locus_tag": "ctg77_5",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,355 - 5,496,\n (total: 2142 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (rule-based-clusters) ketoacyl-synt<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 159.5; E-value: 2.1e-48)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGAGGTGAAATAACGGTCTGGTGGGGCCCCGACGACATGGTATCGGCGCTGGGCTTCGGCACGGAGGAGAACATGGCCGCCGTACGTGCCATGAAAAGCTCGCTGGCGTCGTGGCACGACGCCACACCCGTATGCCTGATCGACCGGAAGCGGCTCGGGGCGCTGGCGGCGGAGCAGGGACTCGCGGGATATACGCCCCTGGAACGGCTCGTGCTGGCGACGCTGGGCGGGGTGGTCGCCCGCTCGGGGGTCACACCCGCCGACAAGCGGGCGCTGATCGTCCTGGCGACGACCAAAGGGGAGATCGGGTCGCTGGGGAGCGCCCCGGAGCGATGCGACCTGAACAGAACCGCGGAGGTCGTGGGGCGTTATTTCGGCACCGCGCACCGGCCGCTGCTGATCTCGAACGCCTGCATCTCGGGGGTTTCGGCCATCGTCATCGCGGCACGGCTGATCCGCAGCGGCCGGTACGACCATGTCTTCGTGGCAGGATTCGACCTGCTGAGCGACTTCATCGTCAGCGGATTCAACGCCTTCAAGTCGGTGAGCCCGACGCTTTGCCGTCCCTACGATGCGGCACGCGACGGGCTGACGCTGGGCGAAGCGTGCGGCGCCGTCCTGCTGACACGCGACCGACGGCTCTCGGGCACGGGCGTGAGCGTGGCGGGAGGCGGAATTTCGAACGACGCCAACCACATATCGGCGCCTTCGCGCACAGGCGACGGGCTCTGGTACGCTATCCGCGCGGCACTCGCCGAGGCGGGAACCGGAGCCGGGGAGGTCGGGCTGGTAAACACCCACGGCACGGCGACCGCCTACAACGACGAGATGGAGAGCAAGGCGCTGCACCTGGCGGGATTGTGCGGCGTACCCTGCAACTCGCTGAAGCCCTATTTCGGACATACGCTGGGGGCTTCGGGCGTGATCGAGAGCATCGTCACGGTACGGGAGCTGTGCGAGGGCACCTGCTTCGGGGTGAAGGGCTACGCGGAGTGCGGGGTACCCTACCCGCCCGACGTGAGCGCCGCGCACCGCGAAATACGGACGGACACGGCGCTGAAAACCGCCTCGGGATTCGGGGGTTGCAACGCCGCGGTCGTATTCCGCCGCGCAGCGGGCTCCGACGCCGCGCCCGGAAATGAAACGGCGGAGGGACAAGGGTGTGGGCCAAACACAGGTGTGCAAGGCGGGAACGACTGCCTGGAGGCTGCCCGTGCCCGAAGCGGAACGGCTATGAGCGCGAATGACCGGGCGCGGGGCAAAAATGCGGTCGGGCACGGGAATCCGGACACCGGAGAAAAGGCCGACGGCCATGCGGAAACCGGCACAGGACGACACGGCAGCGGAATCCGCTGTCACGATACGGCTCACGTCGTCATTGCGCAACACCCTTCGCTGCCGTTCGACGCCTTCATCCGCGAAAGATACCGGGCGCTCGCAGACCCGAACATGAAGTTCTCGAAGATGGACGACCTGTGCAAGCTGGCCTACGTCGCCTCGTGCGAACTGCTTTCCGGACACAGGCCCGATTGCCCGGCGGAGCGCATCGGCGTGGTGATGGCCAACCGCAGCGCCTCGCTCGACAGCGACCGGCGCCACCAGGCGATTATCGACGCCGGGGACGGGTGCGGGGCTTCACCGGCGGTGTTCGTCTACACGCTGCCCAACATCATGCTGGGGCAGGTGGCGATCAAGCACGGGCTGAAGGGAGAGAGCACTTTTTTTGCGTTCCCGGACAAAAGCAGTAACTTTATCCGGGAATATGCCGCTTCGCTGATCGCCGAAGGGCGCATGGACGCCGTCCTGTGGGGCTGGTGCGAATTCGACGGCGGCAGCTACGACTGCGAACTGACATTAACCGAAAAAACGGGACAAGATACGATGGAAGATCTGGAACTGCAACTCAAACAACAAATTATCGAAGCGCTGAACCTCGAGGAGATCACCGCCGACGAGATAGCGACCGACGCGCCGCTGTTCGGCGACGGGCTGGGACTCGACTCGATCGACGCACTGGAAATCACCCTCCTGCTCGAAAAACACTACGGCATACGGCTGGCGAACCCGGCCGAAGCCAAACCGATATTCTATTCGGTAGCCACGCTGGCCGACTTTATCCGCAAGAACCGCCCGCAATGA",
    "translation": "MGGEITVWWGPDDMVSALGFGTEENMAAVRAMKSSLASWHDATPVCLIDRKRLGALAAEQGLAGYTPLERLVLATLGGVVARSGVTPADKRALIVLATTKGEIGSLGSAPERCDLNRTAEVVGRYFGTAHRPLLISNACISGVSAIVIAARLIRSGRYDHVFVAGFDLLSDFIVSGFNAFKSVSPTLCRPYDAARDGLTLGEACGAVLLTRDRRLSGTGVSVAGGGISNDANHISAPSRTGDGLWYAIRAALAEAGTGAGEVGLVNTHGTATAYNDEMESKALHLAGLCGVPCNSLKPYFGHTLGASGVIESIVTVRELCEGTCFGVKGYAECGVPYPPDVSAAHREIRTDTALKTASGFGGCNAAVVFRRAAGSDAAPGNETAEGQGCGPNTGVQGGNDCLEAARARSGTAMSANDRARGKNAVGHGNPDTGEKADGHAETGTGRHGSGIRCHDTAHVVIAQHPSLPFDAFIRERYRALADPNMKFSKMDDLCKLAYVASCELLSGHRPDCPAERIGVVMANRSASLDSDRRHQAIIDAGDGCGASPAVFVYTLPNIMLGQVAIKHGLKGESTFFAFPDKSSNFIREYAASLIAEGRMDAVLWGWCEFDGGSYDCELTLTEKTGQDTMEDLELQLKQQIIEALNLEEITADEIATDAPLFGDGLGLDSIDALEITLLLEKHYGIRLANPAEAKPIFYSVATLADFIRKNRPQ",
    "product": ""
   },
   {
    "start": 5481,
    "end": 5924,
    "strand": -1,
    "locus_tag": "ctg77_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,481 - 5,924,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTACGCAGGAAAAAGAGCGAGGCGAGCCTCGTGAACAAGACATCGCTGCGCGTGAGGTTCAGCGAAGTGGATTCGATGCAGATCGTGTGGCACGGCGAATACGTGCGTTATTTCGAGGACGGGCGCGAGGCGTTCGGCCGCGAATTCGCAGGGCTGGGTTACATGGACATCTATGCCAGCGGCTACACGGCGCCGATCGTCGAGTTGCACCTGCAATACAGGAAACCGCTGAAAGTGAATGACACGGCCGTGGTGGAAACCCGCTATATCGCCACCGAGGCGGCGAAGGTCTGTTTCGAGTACACGATTCGCAGCGCCACCGACGGCGAAGTGGTGGCCGAAGGCAGCTCGACACAGGTGTTTCTCGACAGCCGAGGCGAACTGCAACTGCTCGCGCCGGAGTTCTACCGCAAATGGAAAGAGCGATGGGAGGTGAAATAA",
    "translation": "MVRRKKSEASLVNKTSLRVRFSEVDSMQIVWHGEYVRYFEDGREAFGREFAGLGYMDIYASGYTAPIVELHLQYRKPLKVNDTAVVETRYIATEAAKVCFEYTIRSATDGEVVAEGSSTQVFLDSRGELQLLAPEFYRKWKERWEVK",
    "product": ""
   },
   {
    "start": 5924,
    "end": 6364,
    "strand": -1,
    "locus_tag": "ctg77_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,924 - 6,364,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGAGTACCTGAGAAAACCCTGATTACGGGGGAGGAGATACTGGAATACATCCCGCAGCGCCCGCCGGTCGTGATGGTCGACACCTTTTACGGCATCGACGAGCGGGGGTGCGCACGCAGCGGGCTGACCGTTACGGCGGACAACCTGCTCGTTGCGGACGGGGTGCTGGACGAGTGCGGCATCGTGGAGCACATCGCCCAGTCGGCCGCCCTGAGGGCGGGTTACATGAACCGCACGATGGGCCGAAGGGTGCAGCTGGGGTACATCGGCGCCGTGAACGACCTGAAGGTGCACTTCCTGCCGCCGGTGGGCAGCAGACTCGTCACACAGAACATGGTCGAGCAGACGGTGATGAACGTAACGCTTCTTTCGGCACGGACGGAATGCGACGGGAAACCCGTCGCCGAGTGCCGGATGAAAATATACCTGGAAGAGTGA",
    "translation": "MGVPEKTLITGEEILEYIPQRPPVVMVDTFYGIDERGCARSGLTVTADNLLVADGVLDECGIVEHIAQSAALRAGYMNRTMGRRVQLGYIGAVNDLKVHFLPPVGSRLVTQNMVEQTVMNVTLLSARTECDGKPVAECRMKIYLEE",
    "product": ""
   },
   {
    "start": 6340,
    "end": 7698,
    "strand": -1,
    "locus_tag": "ctg77_8",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,340 - 7,698,\n (total: 1359 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n  other (smcogs) SMCOG1277:Radical SAM domain protein (Score: 190.8; E-value: 6.5e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCGCATGCAGCATATTACTCGTATCGGCCAACCGGCACACCTCGCCCTACCCCGTTTATCCGCTCGGACTTTCGTACCTGAAAACCTATCTGGAGCGCACGATAAGCGGGATACGCGTCGATATGGCGGACTGCAACCTGCTCACGGACGGGCAGCTGGCGGAGCGTATCCGCATGCTGGCACCCCGTTACATCGGGCTGTCGCTGCGCAATGTCGACGGGGCCAACTCGCTCGACCGGCGGGGTTTCCTGCCCCAGTACAGGGCGCTGGCGGACGTCATACGCGCGGCAAGCGACGCCCCCCTGATCATCGGCGGCGCAGGGTTCTCGATCTACCCCGAGGCCTTCATGCGGGAGCTGGGCGCCGACTACGGCATCCACGGCGAAGGCGAAGGGCCGCTCGCGGAGCTGATCGGGGCGCTGGAGCGCGGCCGGACGGAGATCGACATCCCGTCGGTCTACACCCGCGACGGACGCCGCGGAAGCGGCCGCAGGAGCTACCTGCCGTCGATCGAGGTGCAGTTCGAGCCCGAGTTAACGGGCTATTACTGGAAGCGGAGCGGGATGCTCAACATACAGACCAAGCGGGGGTGCCCCTACGACTGCATCTATTGTTCGTACCCCTCGATCGACGGGCGGTGCGTGCGGACGATGGATCCGGAGGCGATCGCCGGAAACATCCTCCGCGCCAAGCGCGACTACGGGATCAGCTACCTGTTTTTCACCGATTCGGTGTTCAACATCAGCCCGGAATACAACGTCCGGCTGGCCGAGACGCTGATCCGCCGCCGCACGGATATCCGCTGGGGCGCCTACTTCTCGCCGCGGGGCATCGACGCAGAGCAGATGCGGCTGTTCCGGGCTTCGGGGCTTACGCACATCGAATTCGGCACCGAGTCGTTCTGCGACCGGACGCTGGAGGCTTACGGCAAGCATTTCACGTTCGGCGACGTCGTGCGGGCAAGCCGGCTCGCGCTGGACGAGGGCGTCTACTACGCCCACTTCCTGATCCTGGGCGGCTACGGCGACACGCGCGAAAACGTGCGCGAAACGATCGAAAACTCGCGGCGGATGGAGTACACCGTCATGTTCCCCTATGCGGGCATGCGCATCTACCCGCATACGCGGCTGGCGGAGCTGGCCGCGAAAGAGGGTGCCATCGGCCGGGACGACGACCTGATGGCGCCGAGCTACTATATCTCCCGGGATTTCGACCTGGAAGAGGTGCGGCGCGCGGCATTGGCCACGGGCAAGGCGTGGGTTTTCCCCGACGACCCGCAGAGCGCGCTGGCGGATACGCTGCGGTTGAAACGAAATAAAAAAGGGCCTTTATGGGAGTACCTGAGAAAACCCTGA",
    "translation": "MSACSILLVSANRHTSPYPVYPLGLSYLKTYLERTISGIRVDMADCNLLTDGQLAERIRMLAPRYIGLSLRNVDGANSLDRRGFLPQYRALADVIRAASDAPLIIGGAGFSIYPEAFMRELGADYGIHGEGEGPLAELIGALERGRTEIDIPSVYTRDGRRGSGRRSYLPSIEVQFEPELTGYYWKRSGMLNIQTKRGCPYDCIYCSYPSIDGRCVRTMDPEAIAGNILRAKRDYGISYLFFTDSVFNISPEYNVRLAETLIRRRTDIRWGAYFSPRGIDAEQMRLFRASGLTHIEFGTESFCDRTLEAYGKHFTFGDVVRASRLALDEGVYYAHFLILGGYGDTRENVRETIENSRRMEYTVMFPYAGMRIYPHTRLAELAAKEGAIGRDDDLMAPSYYISRDFDLEEVRRAALATGKAWVFPDDPQSALADTLRLKRNKKGPLWEYLRKP",
    "product": ""
   },
   {
    "start": 7695,
    "end": 8573,
    "strand": -1,
    "locus_tag": "ctg77_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,695 - 8,573,\n (total: 879 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGAAATAACGGCAAACAGTGGAGCGGACGCTCGCGCGGCGGCGGTTTCGGGTACAATTTCTTCATCCTGCTGATGAAGGTGGCCGGAATACGCAGCGCGTATGCCTTCCTCTCGCTGGTAGTCGTCTATTTCATCCCCTTCGCACCCCGCGCCACGCGGGCCGTATGGTTCTATAACCGCCGCATCCTGGGATACGGCAGGCTGCACTCGGCGGTGAAGCTCTACGCCCACTACTATGCGCTCGGGCAGACGATCATCGACCGGGTGGCTATCGGCAGCGGCATGGAGCGAAAATACAAATTCGAATTCGAAAACTACGACGCTTTCCTGCGCGTGCTCGACGGCGGGCGCGGGGCGGTGATCATCGGCGCACACGTCGGATGCTGGGGCACGGGGGCCGGGTTCTTCGGGGACTACGCCCGCAAGATGCACCTGGTGATGTACGACGCCGAATACCGGCAGATCAAAAGCGTCATGGAGAAACATTGCGGGCAGGAGGGCTACAAGGTGATCGCGGTGAACGAGGGCGGCATCGAGTCGATCCTCCGCATCAAGGAGGTGCTCGACCGCAAGGAGTACGTCTGCTTCCAGGGCGACCGCTTCGTCGAGGGCAGCCCGACGGTGACGCTACCTTTCATGGGGCACGAAGCGCCGTTCCCGGCGGGGCCGTTCGCCGTCGCCGGGAAATTCCGCGTCCCGGTGGTCTTCTACTATGCCATGCGCGAGCGCGGCAGGCGCTACCGGTTCATCTTCGACATCCCGGACGGGCAGCCCATGACCCGCGACGCCGTGCTGGGCAGCTACGTACGCTCGCTCGAAGCCGTGGTGAGACGCTACCCGCAGCAGTGGTTCAACTTCTATCGATTCTGGTCGTGA",
    "translation": "MGNNGKQWSGRSRGGGFGYNFFILLMKVAGIRSAYAFLSLVVVYFIPFAPRATRAVWFYNRRILGYGRLHSAVKLYAHYYALGQTIIDRVAIGSGMERKYKFEFENYDAFLRVLDGGRGAVIIGAHVGCWGTGAGFFGDYARKMHLVMYDAEYRQIKSVMEKHCGQEGYKVIAVNEGGIESILRIKEVLDRKEYVCFQGDRFVEGSPTVTLPFMGHEAPFPAGPFAVAGKFRVPVVFYYAMRERGRRYRFIFDIPDGQPMTRDAVLGSYVRSLEAVVRRYPQQWFNFYRFWS",
    "product": ""
   },
   {
    "start": 8563,
    "end": 8811,
    "strand": -1,
    "locus_tag": "ctg77_10",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,563 - 8,811,\n (total: 249 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAGAACAGGAACTCATAGAAAAGATCGATACCGTACTGGCCGATGAATTCGAAGTCGACCGGACGACCATCACGCCCGAAGCCCCGCTGCTGGAGACGCTCGACCTGGACAGCCTCGACCTGGTGGACGTCGTGGTGATCGTCGACAAGAACTTCGGCGTAACGCTCACGGGCCCCGATTTCAAGGAGCTGAAGACCTTCCGGGACTTCTACGACCTGATTATCAGCCGGACGAATGGGAAATAA",
    "translation": "MTEQELIEKIDTVLADEFEVDRTTITPEAPLLETLDLDSLDLVDVVVIVDKNFGVTLTGPDFKELKTFRDFYDLIISRTNGK",
    "product": ""
   },
   {
    "start": 8826,
    "end": 10049,
    "strand": -1,
    "locus_tag": "ctg77_11",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,826 - 10,049,\n (total: 1224 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 290.6; E-value: 3.5e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAGAGAGTAGTCATCACCGGAATGGGCATCTGGGCCTGCATCGGAAAAAATACGGAAGAAGTCACGCAATCGCTCCGCGAAGGACGCTCGGGCATCGGGCTCGACCCGGCGCGCAGGGAGCTGGGATACATCTCGTCGCTGACGGGGATCGTGGAACAACCGAACCTGAAAGGGGTGCTCGACCGCCGCAAGCGGCTGTGTCTGCCCCAGCAGGGCGAATATGCCTACATGGCCACCGCCGAGGCGATGCGCAACGCCGGAATGGACGAGGCCTACCTGGCGGCGAACGAGGTGGGAATCATCTACGGCAACGACAGCAGTGCGGCGCCGGTGATCGAGGGGATCGACATCATCCGCGCCAGGCGGAACACGGCGATGGTCGGCTCGGGCAATATTTTCCAGTCGATGAACTCGACCGTGACGATGAACCTCTCGGTGATCTTCAACCTGCGGGGCATCAACCTCACGCTCTCGGCGGCCTGCGCCAGCGGGTCGCACGCCATCGGCATGGGTTACCTGATGATCAGGCAGGGGTTGCAGGAGCGCGTGGTCTGCGGCGGCGCACAGGAGGTGAACCTCTACTCGGTGGGCAGCTTCGACGGGCTGGGGGCATTCTCGGCCCGCGAATCGGATCCCGCGGCGGCATCGCGCCCCTTCGACAAAGACCGCGACGGGCTGGTGCCGAGCGGAGGCGCGGCGACGGTGATCCTCGAAAGCCATGAATCGGCCGTCGCACGGGGCGCCGAAATCCTGGGCGAAGTGGTCGGGTACGGGTTCTCGTCGAACGGCGAGCATATCTCCGTGCCGAACGTTGACGGCCCGCGCCGTTCGCTGCTGCGGTGTCTGGAGGACGCCGGAATGCGGCCCGAAGAGATCCCCTACGTCAATGCGCACGCCACCTCGACGCCGCTGGGCGACTACAACGAGGCGGAGGCGATAGCCGGGGTATTCGCCGGGTGCAACCCCTACGTGGCGTCGACCAAGTCGATGACCGGCCACGAAATGTGGATGGCCGGGGCGAGCGAAGTGGTCTACTCGATGCTGATGATGCGGCACGGGTTCATCGCCCCGAACATCAACTTCACCGAGGGCGACGAGGCCACCTCGAAGCTCAACATCCCCGTCCGCAGGGTGGACACGGAGTTCGACTGCTTCCTCTCGAACTCGTTCGGCTTCGGCGGCACCAACTCGACCCTGATCGTTAAGAAATACAAATAA",
    "translation": "MEKRVVITGMGIWACIGKNTEEVTQSLREGRSGIGLDPARRELGYISSLTGIVEQPNLKGVLDRRKRLCLPQQGEYAYMATAEAMRNAGMDEAYLAANEVGIIYGNDSSAAPVIEGIDIIRARRNTAMVGSGNIFQSMNSTVTMNLSVIFNLRGINLTLSAACASGSHAIGMGYLMIRQGLQERVVCGGAQEVNLYSVGSFDGLGAFSARESDPAAASRPFDKDRDGLVPSGGAATVILESHESAVARGAEILGEVVGYGFSSNGEHISVPNVDGPRRSLLRCLEDAGMRPEEIPYVNAHATSTPLGDYNEAEAIAGVFAGCNPYVASTKSMTGHEMWMAGASEVVYSMLMMRHGFIAPNINFTEGDEATSKLNIPVRRVDTEFDCFLSNSFGFGGTNSTLIVKKYK",
    "product": ""
   },
   {
    "start": 10054,
    "end": 10794,
    "strand": -1,
    "locus_tag": "ctg77_12",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,054 - 10,794,\n (total: 741 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 207; E-value: 5.5e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAAAACGAATAAATACGCACTCGTGACCGGCGGCAGCCGGGGCATAGGCCGCGAAATCTGCCTCAAACTGGGCGGGTGCGGCTACCACGTGCTCGTCAACTACAAGTCGAACGCCGCCGAGGCCGAAAAGACCCTGTCGGGCATCCGCGCCGCAGGCGGCGACGGCGAGGCACTGCAATTCGACGTGGCCTCGGGCGAAGAGAGCACGGCGGCCATCGAGGCATGGCAGAAAGCGCACGAAGGCGCCTGCATCGAGGTGGTGGTGAACAACGCGGGCATCCGCGACGACGTGCTGATGATGTGGATGGAACCGCAGCAGTGGCACTCGGTGATCGGCACCAGCCTCGACGGGTTCTACAACGTCACGCGGCCGCTGCTCAAGGGGATGCTCGTGAACCGGTTCGGGCGCATCGTCAACATCGTCTCGCTCTCGGGCATCAAGGGGCTGCCCGGGCAGGCCAATTACGCCGCGGCCAAGGGCGGCGTGATCGCCGCGACCAAGGCGCTGGCGCAGGAGGTGGCCAAAAAGGGGGTGACGGTGAATGCCATCGCCCCGGGATTCGTGCGCACGGACATGACCGCCGACATCGACGAGGCGGAGCTCCGCAAACAGATACCTGCCGGACGCTTCTGCGAACCGGCCGAAGTCGCCGACCTGGCGATGTTCCTCATCTCGGAACAAGCCTCCTATATCACGGGAGAGGTCATTTCGATCAACGGGGGCTTATATACCTGA",
    "translation": "MAKTNKYALVTGGSRGIGREICLKLGGCGYHVLVNYKSNAAEAEKTLSGIRAAGGDGEALQFDVASGEESTAAIEAWQKAHEGACIEVVVNNAGIRDDVLMMWMEPQQWHSVIGTSLDGFYNVTRPLLKGMLVNRFGRIVNIVSLSGIKGLPGQANYAAAKGGVIAATKALAQEVAKKGVTVNAIAPGFVRTDMTADIDEAELRKQIPAGRFCEPAEVADLAMFLISEQASYITGEVISINGGLYT",
    "product": ""
   },
   {
    "start": 10804,
    "end": 10896,
    "strand": -1,
    "locus_tag": "ctg77_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,804 - 10,896,\n (total: 93 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAGCTCCTGACCACCCTGACCGCGACATTGTGCTGTCTTTCCGGCGCTTTCGCCGCTCGCTGGGCGAGGAGTTGCAGCAAGCTATAA",
    "translation": "MKKLLTTLTATLCCLSGAFAARWARSCSKL",
    "product": ""
   },
   {
    "start": 10893,
    "end": 12416,
    "strand": -1,
    "locus_tag": "ctg77_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,893 - 12,416,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTACGTTCGAACCTAAATACCATAAACGCCCGGATTTTCAACAAGACCGCAATACGGATCGACGACCAGGCGCTGCGCGAAGTGGAGGCGTGTTACCGTTTCCTGGAGAAATTCGAGCAGGGAAAGGTCATCTACGGCATCAACACGGGGTTCGGCCCCATGGCGCAGTACCGGATCGGCGACGCCGACCTGAACAGCCTCCAGTACAACATCATCCGTTCGCACAGCTGCGGCGCGGGCGAGGCACTGCCCGACATCTGCGTGCGGGCGGCGATGCTGGCGCGGCTGCAAACGTTCCTCAACGCCAAGTCGGGCGTACACCCCGACGTGGTGCGGATACTGGCCGATTTCCTCAACAACGAAATTTACCCGCTCGTGCCGCGCCACGGCAGCGTGGGCGCAAGCGGCGACCTGGTGCAGCTGGCGCATATCGCACTGGCGCTGATCGGCGAAGCGGAGGTCTCGTTCCGGGGCGAAACCGTCCCGGCAGCAGAGGCGATGGCGGCATGCGGCATAACGCCCCTCAGGCTTCGCATCCGCGACGGGCTGGCGCTCACGAACGGCACGGCCGTGATGACGGGCATCGGACTGGTGAACCTGGCCCAGGCGCGCCGCCTGCTGGGGTGGGCGGTGAAGGCATCGGTGATGCTCAACGAAATCGTAGAGTCGTACGACGACTTCATGGCCGGGGCGCTCAACGAATACAAACTCCACGCGGGGCAGATCGAGATCGCCCGGCAGATGCGCGCCATATGCGCCACGAGCCGCCGGCTGCGCAAGCGCGAAGCGGAACTTTACAGCGGCGACACGGGCGCGGCACCCACCTTCAGGCACAAGGTGCAGCCCTACTACTCGCTGCGGTGCATCCCCCAGATCCTGGGGCCGGTGCTCGAAACGATCTCCCAGGCCGAGAAAATCCTCGTCGAGGAGTTCAACGCGGTGGACGACAACCCGGTGGTAGACCCCGCGGCGGGGACGATCTACCACGGCGGGAATTTCCACGGCGACTACGTGTCGCTGGAGATGGACAAGCTCAAGATCGCCGTGACGAAGATGACGATGCTCGCCGAACGGCAGCTGAACTACCTTTTCCACGACCGGATCAACGAGACGCTGCCGCCGTTCGTAAACCTCGGCAAATTGGGGCTCAACTACGGGTTGCAGGCAGCGCAGTTCACGGCGACCTCGACCACGGCCGAGTCGCAAACGCTCTCCAACCCGATGTACGTCCACTCGATCCCCAACAACAACGACAACCAGGACATCGTGAGCATGGGAACCAACGCGGCGATGCTCACGCGGCAGGTCGTGGAGAACGGCTACCAGGTCGCCGCGATCGAGATGCTGGCGCTGGTGCAGGCCGCCGACTACCTGCAATGCGCCGGGGAGCTCTCCGACGCCACGCGGCAGTTGTATGCCGACATCCGGGGCATCGTGCCGCGCTTTGCCGACGACACGCCCAAGCACAGGGAGATCGCCGCCATCGAAAATTTCCTGAAAAACAATTCCGCTTCCCTATGA",
    "translation": "MLRSNLNTINARIFNKTAIRIDDQALREVEACYRFLEKFEQGKVIYGINTGFGPMAQYRIGDADLNSLQYNIIRSHSCGAGEALPDICVRAAMLARLQTFLNAKSGVHPDVVRILADFLNNEIYPLVPRHGSVGASGDLVQLAHIALALIGEAEVSFRGETVPAAEAMAACGITPLRLRIRDGLALTNGTAVMTGIGLVNLAQARRLLGWAVKASVMLNEIVESYDDFMAGALNEYKLHAGQIEIARQMRAICATSRRLRKREAELYSGDTGAAPTFRHKVQPYYSLRCIPQILGPVLETISQAEKILVEEFNAVDDNPVVDPAAGTIYHGGNFHGDYVSLEMDKLKIAVTKMTMLAERQLNYLFHDRINETLPPFVNLGKLGLNYGLQAAQFTATSTTAESQTLSNPMYVHSIPNNNDNQDIVSMGTNAAMLTRQVVENGYQVAAIEMLALVQAADYLQCAGELSDATRQLYADIRGIVPRFADDTPKHREIAAIENFLKNNSASL",
    "product": ""
   },
   {
    "start": 12603,
    "end": 13727,
    "strand": -1,
    "locus_tag": "ctg77_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,603 - 13,727,\n (total: 1125 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAATCGCTTATCCTACTCGGCATGTCGCTGCTGGCTGCGTGCGGCGTGCAGAAAACGGAACTCCCGCTGCTGCCCGAAGAGGCATTCCAGACCACCGTCGACGGCAAACCCGTCGCACTCTACACGCTCCATGCGGGCGACATCACCATGCAGGTCACCAATTACGGCGCCCGCGTCGTATCGCTCTGGACACCCGACCGCGAAGGCCGCTACGAGGACATCGTACTGGGCTACGAAAACATCGGCCGCTACATAGACAACACGGGCGAACGGTTCCTCGGCGCCGTGGTAGGCCCCTACGCCAACCGCATCGCAAAGGGGCACTTCACGCTCGACGGCGCGGAATACACCCTGCCGGTGAACAATAACGGGCAGACGCTGCACGGCGGGCTCCTGGGCGTAGACCGCGTGGTATGGGACGTGGTATCGGCCTCGGACGACAAACTCGTGCTGCATTACCTCCATCCCGACGGACAGGACGGGTTCCCGGGCAACCTGGATATCGAGATGACCTACTCGCTCACGCCCGACAACGAGTTCCGCATCGACTACAAGGCCACTACCGACAAACCGACCGTGGTGAACATGTCGAACCACCCGTTCTTCAACCTCAAGGGCGAAGGCAACGGCACGGTGCTCGACAACGTGATGACGATCAACGCCAGCCACACCACCCCGGTGGACTCGGTGCTGATCCCCACGGGCCAGATTGCCCCGGTAGAGGGTACGCCGTTCGACTTCCGTGAGCCGCACGCCATCGGCGAGCGCATCGGAGCGGACAACCAGCAGCTGCGCAACGGCGGCGGCTACGACCACAACTGGGTGATCGACCGCAAGACCGAAAGCGGCATCGAGCAGGTCGCCACGGTCTGGGAACCCGCCTCGGGACGTACCATCGAGGTGCTGAGCGACCAGCCCGGACTGCAGGTTTACAGCGGCAACTTCTTCGACGGCAAGAGCATCGGCAAATACGGCAAGCCGCAGCGCTACCGCGAGTCGCTGGCGCTCGAAACGCAGAAGTTCCCCGACAGCCCCAACCACGACAATTTCCCCTCGACGGTACTGCGCCCCGGGGAGACCTATACGCAGGTCTGCATCTACAAGTTCGGCGTGAAATAA",
    "translation": "MKKSLILLGMSLLAACGVQKTELPLLPEEAFQTTVDGKPVALYTLHAGDITMQVTNYGARVVSLWTPDREGRYEDIVLGYENIGRYIDNTGERFLGAVVGPYANRIAKGHFTLDGAEYTLPVNNNGQTLHGGLLGVDRVVWDVVSASDDKLVLHYLHPDGQDGFPGNLDIEMTYSLTPDNEFRIDYKATTDKPTVVNMSNHPFFNLKGEGNGTVLDNVMTINASHTTPVDSVLIPTGQIAPVEGTPFDFREPHAIGERIGADNQQLRNGGGYDHNWVIDRKTESGIEQVATVWEPASGRTIEVLSDQPGLQVYSGNFFDGKSIGKYGKPQRYRESLALETQKFPDSPNHDNFPSTVLRPGETYTQVCIYKFGVK",
    "product": ""
   },
   {
    "start": 13765,
    "end": 13890,
    "strand": -1,
    "locus_tag": "ctg77_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,765 - 13,890,\n (total: 126 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCCGGACAAAAATAGCAAAATCCCTCCAATATACGCCGCAAATGTCCGAAAGCGTGCCGAAACCGTACGGGCTCCGGCAAAAAACCGGGCCGCAGCGCACGTTTTTCGCCAGAATCGTATAA",
    "translation": "MSRTKIAKSLQYTPQMSESVPKPYGLRQKTGPQRTFFARIV",
    "product": ""
   },
   {
    "start": 13902,
    "end": 15164,
    "strand": 1,
    "locus_tag": "ctg77_17",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,902 - 15,164,\n (total: 1263 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) rSAM_pep_methan<br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) SPASM<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACAGAAGCAGATATTTACGTTCCGCGACGCGGAGAAACAGGTCGCCCCCGCGGCCTTTTCGATCATGCTCAAACCGGCGGGCTCGGCCTGCAACCTCGACTGCCACTACTGCTACTACCTCGACAAGGCGGTGCAGTACGGCGGCCGCCAGGCCGTGATGGACGACCAGCTGCTGGAGCTCTGCATAAAACAGTACATCCGGGCCAATGAGGTCGACACCGTGCAGTTCTGCTGGCACGGCGGCGAGCCGTTGCTGCTGGGACTGGATTTCTACCGCCGGGCGATGGAGCTGCAGCGCAGGTACGCCGACGGCAAACGGATCGAGAACACGTTGCAGACCAACGGTACGCTGGTCGACGAGGCGTGGTGCGACCTCTTCGCCGCCAACAATTTCCTGGTCGGCCTCTCGCTCGACGGGCCCGGGGATATCCATGACGCCTTCCGCCTGACCAGGGGCGGCAAACCGACCTTCGAGCGCGTGATGCGGACGGTCGGGATGTTCGGGCGCAGCGGCGTGGAATTCAATACGCTGAGCGTCGTGAACCGGTGCTGCGAGGGGCGCGGCGGGGAGATCTACCGCTTCTTCCGCGACGAGGTGCACAGCCGCTTCATGCAGTTCCTGCCCGCCGTCGAACACGTCGTCGGCAAACCGGGACACCACCGTCCGCTGATCGTCCCGCCCGGACATGAAGGAGCGCGGCTGGCCGGCTGGTCGGTCTCGGCCGAAGGCTACGGGCATTTCCTGTGCGATGTGTTCGATGAGTGGGTCGTAAGCGACGTGGGGCGCTGTTTCGTGCAGTTGTTCGACGCCTCGCTGGCGCAGTGGTGCGGTGTGCGGCCGGGCGTCTGCTCGATGGGTGAGACGTGCGGCGACGCGCTGGTCGTCGAGCACAACGGCGACGTCTACCCGTGCGACCATTTCGTCTACCCCGGGTACAGGCTGGGCAATATCCGTGAGACGCCCCTTGCCGAGCTCTACCGCTCGCAGAAACGCCGCGAATTCGGGCTGGATAAACGCAACACGCTGCCCGCCGAATGTCTGCGGTGCAACTACTATTTCGCCTGCCGGGGCGAATGTCCCAAGCACCGTTTCGCCCGCGGGGCCGACGGCAGCCCCAAGAATTCACTCTGCGAGGGGCTGAAACGTTATTTCCGCCACGTCGAACCCTATATGGAATACATGCGCGACCTGCTCGCGCGGCAACAGTCCCCGGCCTGGGTCATGCCTTTCGCCCGCAGGCGCATGGGGCTGATGTAG",
    "translation": "MKQKQIFTFRDAEKQVAPAAFSIMLKPAGSACNLDCHYCYYLDKAVQYGGRQAVMDDQLLELCIKQYIRANEVDTVQFCWHGGEPLLLGLDFYRRAMELQRRYADGKRIENTLQTNGTLVDEAWCDLFAANNFLVGLSLDGPGDIHDAFRLTRGGKPTFERVMRTVGMFGRSGVEFNTLSVVNRCCEGRGGEIYRFFRDEVHSRFMQFLPAVEHVVGKPGHHRPLIVPPGHEGARLAGWSVSAEGYGHFLCDVFDEWVVSDVGRCFVQLFDASLAQWCGVRPGVCSMGETCGDALVVEHNGDVYPCDHFVYPGYRLGNIRETPLAELYRSQKRREFGLDKRNTLPAECLRCNYYFACRGECPKHRFARGADGSPKNSLCEGLKRYFRHVEPYMEYMRDLLARQQSPAWVMPFARRRMGLM",
    "product": ""
   },
   {
    "start": 15331,
    "end": 16806,
    "strand": -1,
    "locus_tag": "ctg77_18",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,331 - 16,806,\n (total: 1476 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 371.3; E-value: 9e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMATLGEHIRQSNAYKWWILGMIMLGTFMAVLDVTVVNVGLPAIMSAFGIGISTAEWVITAYMITMTVMLPSAGWFADRFGNKRIYILGLALFTLGSWLCGKAPGDLFLIGARALQGVGSGIIQSLGLAIVTREFRPEQLGLALGLWAMAAAASISFGPLLGGYLVDAYSWHRIFDVNVPVGVFAILLSAFIQKEWKSPARHPFDWRGFVAIALFMPLAIYALARGNSPTNHDGWASPTVIGCFAVAAVALAYFVRTELRSPAPLLQLRLLGERNFGVSMAVLTLFSIGMLGGTYLLPLYMQRGLGYTALMAGSVFLPVGLIQGVLSAVSGYLTRYVKPLLLAAAGILLLATSFWLASRFTLHTTHRHILFVLYIRGLGMGLTFAPLNFFSLRNLTQHDMAAAAGISNSIKQLAGSVGIAILTAVYSARTAFHAAHETVSASQTYVEGVTDALGVVTWLTLAAGLPLLWVFRKKRKKTPAGNPGAAGEAGES\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGACCCTCGGCGAACATATCCGGCAAAGCAACGCTTACAAATGGTGGATCCTGGGCATGATCATGCTCGGGACGTTCATGGCCGTGCTGGACGTGACGGTAGTCAACGTCGGGCTGCCGGCCATCATGTCGGCTTTCGGCATCGGCATCTCGACGGCCGAATGGGTCATCACCGCCTACATGATCACCATGACCGTCATGCTCCCCTCGGCGGGTTGGTTCGCCGACCGCTTCGGGAACAAACGCATCTATATTCTGGGGCTGGCGCTCTTCACGCTCGGGTCGTGGCTCTGCGGCAAAGCCCCGGGCGACCTGTTTCTGATCGGGGCACGCGCCCTGCAAGGCGTCGGCAGCGGCATCATCCAGTCACTGGGACTGGCGATCGTGACCCGCGAATTCCGCCCCGAGCAGCTCGGCCTGGCGCTCGGCCTGTGGGCAATGGCCGCCGCCGCGTCGATCTCGTTCGGCCCCCTGCTGGGCGGCTACCTGGTCGACGCATACAGCTGGCACAGAATCTTCGACGTGAACGTCCCCGTGGGAGTGTTCGCCATCCTGCTCTCGGCCTTTATCCAGAAAGAATGGAAAAGCCCGGCGCGGCACCCGTTCGACTGGCGGGGATTCGTGGCCATCGCGCTCTTCATGCCGCTGGCGATCTATGCGCTGGCGCGGGGCAACTCGCCGACCAACCACGACGGCTGGGCCTCGCCCACGGTGATCGGCTGTTTCGCCGTGGCGGCCGTGGCGCTCGCCTACTTCGTCCGCACGGAGCTGCGCAGCCCGGCGCCGCTGCTGCAGCTGCGCCTGCTCGGGGAGCGCAACTTCGGGGTTTCGATGGCCGTGCTGACGCTCTTCTCGATCGGTATGCTGGGCGGCACCTACCTGCTGCCGCTCTACATGCAGCGCGGGCTGGGCTACACGGCGCTGATGGCCGGGAGCGTATTCCTGCCCGTGGGGCTCATACAAGGAGTGCTGTCGGCCGTATCGGGTTACCTCACGCGCTATGTCAAACCCCTGCTGCTCGCGGCGGCGGGCATCCTGCTGCTGGCGACGAGCTTTTGGCTGGCCAGCCGTTTCACGCTCCACACCACCCACCGGCACATCCTCTTCGTGCTCTACATCCGCGGGCTGGGCATGGGGCTCACGTTCGCCCCGCTGAACTTCTTTTCGCTGCGGAACCTCACGCAGCACGACATGGCCGCTGCGGCGGGTATCTCGAACAGCATCAAACAGTTGGCTGGAAGCGTCGGCATCGCCATCCTGACAGCCGTTTACTCGGCCCGGACGGCTTTCCATGCGGCGCACGAAACGGTATCGGCCTCCCAAACCTATGTCGAGGGGGTGACCGACGCGCTGGGCGTAGTGACATGGCTGACCCTCGCGGCCGGGCTGCCGCTGCTGTGGGTATTCCGCAAAAAACGAAAGAAAACGCCGGCAGGAAACCCGGGAGCAGCCGGGGAGGCCGGGGAAAGTTAA",
    "translation": "MATLGEHIRQSNAYKWWILGMIMLGTFMAVLDVTVVNVGLPAIMSAFGIGISTAEWVITAYMITMTVMLPSAGWFADRFGNKRIYILGLALFTLGSWLCGKAPGDLFLIGARALQGVGSGIIQSLGLAIVTREFRPEQLGLALGLWAMAAAASISFGPLLGGYLVDAYSWHRIFDVNVPVGVFAILLSAFIQKEWKSPARHPFDWRGFVAIALFMPLAIYALARGNSPTNHDGWASPTVIGCFAVAAVALAYFVRTELRSPAPLLQLRLLGERNFGVSMAVLTLFSIGMLGGTYLLPLYMQRGLGYTALMAGSVFLPVGLIQGVLSAVSGYLTRYVKPLLLAAAGILLLATSFWLASRFTLHTTHRHILFVLYIRGLGMGLTFAPLNFFSLRNLTQHDMAAAAGISNSIKQLAGSVGIAILTAVYSARTAFHAAHETVSASQTYVEGVTDALGVVTWLTLAAGLPLLWVFRKKRKKTPAGNPGAAGEAGES",
    "product": ""
   },
   {
    "start": 17747,
    "end": 18343,
    "strand": 1,
    "locus_tag": "ctg77_19",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,747 - 18,343,\n (total: 597 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 94.3; E-value: 1.1e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGATAACGCGCATACGATCGACATACACGACAACCGCACGGTTGTCGGATTGCTCCGTGCGGGGGATGAAAAATGTTTCGATGCGCTTTTCCGCCGCTATTACAAACCGCTCTGCACCTATGCCACGCGCTTCGTGCCGCCGGTACGCGCCGAGGAACTCGTCCAGGACACCCTGATGTGGGTGTGGGAAAACCGCACCTCGCTGATCCCCGAGATGCCGCTCAAATCGCTGCTGTTCACCATCGTAAAGAACAAGTCGCTAAACAGCGCCTTGCGCGACACGCTCAAGAACCGCATCATCCGCCAGCTGGCCGAACGCTACGAAGAGACGTTCGACGACCCCGATTTCTACCTCGAGGGCGAACTGGTGCAGCGGCTGACCGAAGCTCTGCGCAAAATGCCTCCTGAATTCCGGCAGACCTTCCGTATGCACCGCCTGGAAGGTATGACCCACAAAGAAATAGCCGTCCGCCTCAACGTCTCCCCGCAGACGGTCAATTACCGTATCGGGCAGACGGTTCGCCTGCTGCGCGAAGAGCTCAGCGATTACTGGCCGCTGCTCGTGCTGTTGCTGTGGCCTGACCTCTCCTGA",
    "translation": "MADNAHTIDIHDNRTVVGLLRAGDEKCFDALFRRYYKPLCTYATRFVPPVRAEELVQDTLMWVWENRTSLIPEMPLKSLLFTIVKNKSLNSALRDTLKNRIIRQLAERYEETFDDPDFYLEGELVQRLTEALRKMPPEFRQTFRMHRLEGMTHKEIAVRLNVSPQTVNYRIGQTVRLLREELSDYWPLLVLLLWPDLS",
    "product": ""
   },
   {
    "start": 18426,
    "end": 19427,
    "strand": 1,
    "locus_tag": "ctg77_20",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,426 - 19,427,\n (total: 1002 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAATTTCGAAATCGACGAAGAGGTATTGGTAGCCTTCCTCAAGGGCGAGCTGGACGCAGCGCAGGCGGCGGCCGTAGAGGCGTGGTACGACCGCTCGGCCGCAAACCGCAGGATGCTCGGCCAGGTCTATTATATATTATATGTCAGCGACCGTATCAACGACGCGGCCGGTATCGACGTCGAGCGTTCGCTCCGGCAGTTCAAGCGCCGCATGCACGCCGGACGCCGTATCTCCCTGCGCCGGAGCGCGGTGCGTATAGCCGCTGCGGCCGTGATCGCCGCGGTGCTCCTGGCCGGCGGGCTCACGACCGTGTTGCTTTCCAAGCGCCTGGCGCAGCCCGTGACCGTCGTCACCCAGCTGGGCGAGCGGTCGCAGGTGGTGCTGCCCGACGGGACGAAGGTGTGGCTCAATTCGTCGAGCAGCGTGGAGTACGTCGCCCCCTTCTTTTCGCGCCAGCGCCGCGTGAAGATGGAGGGTGAAGCCTATTTCGAGGTCGAGCACGACCGCCGGGCGCCGTTCGTCGTGTCGACCAACGGCCTGGACATCGAAGTCCTCGGCACACGTTTCAACATCCGCAACGACGACAATGACCACCGTGTCACCACCGTCCTGCTCGAAGGTGCCGTCAAGGCCTCTGCTTCGGGACACGGGCAGGCCTCGGTACGCCTGCACCCCGCGCAGCAACTGGTCTTCGACACCCGGACGCACGCCATGCGCCTGACCGACTGCCCCTCGGCCGAACGCTCGATCAACTGGATCGACGGCCGCTTCTGTTTCGAGCACGACACTTTCGGGGAGATCGTCGCCGAACTCAAGCGCTACTACAACGTCGACATCCGTTTCATGGACACCCGGCTCCGCGACATGCGCTTCTCGGGCAATTTCCGCGTCGAGGACGGCATCTACCACATCATGTCCGTATTGCAACTGACCTATAAATTCAATTACAGGATCGCCGGCAACGACATCGAGCTCTATGCAAACCCTGAACGATAA",
    "translation": "MANFEIDEEVLVAFLKGELDAAQAAAVEAWYDRSAANRRMLGQVYYILYVSDRINDAAGIDVERSLRQFKRRMHAGRRISLRRSAVRIAAAAVIAAVLLAGGLTTVLLSKRLAQPVTVVTQLGERSQVVLPDGTKVWLNSSSSVEYVAPFFSRQRRVKMEGEAYFEVEHDRRAPFVVSTNGLDIEVLGTRFNIRNDDNDHRVTTVLLEGAVKASASGHGQASVRLHPAQQLVFDTRTHAMRLTDCPSAERSINWIDGRFCFEHDTFGEIVAELKRYYNVDIRFMDTRLRDMRFSGNFRVEDGIYHIMSVLQLTYKFNYRIAGNDIELYANPER",
    "product": ""
   },
   {
    "start": 19630,
    "end": 22914,
    "strand": 1,
    "locus_tag": "ctg77_21",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,630 - 22,914,\n (total: 3285 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 72.7; E-value: 5.5e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLLLGCFGATSATAQTQQALSRVSLDAPDATVITVFQAIQQQTGCSFVYNTSDIDTDRKVSLSVHDEPLQAVLDKLFAGSDIAYTLRDKHIVLSKKAKNSPPHSAQGGVTGVIKDDKGMPLVGATVLIKGTTTGAAADIDGNFSLPQAKPGDTLEISLIGYTKQELPVSGSAPLSVVMHEDNEVLDAVVVTALGIKRSEKALTYNVQEVAGDIVNTVKDANFMNSLSGKVAGLQINASASGVGGSTRVVMRGVKSISGNNNALYVIDGIPMPDLRSSQTEGTYETPDGGDFEGISNLNPEDIESMTVLSGATAAALYGSQGANGVIVITTKKGEEGRVRVNYANNTTFSSPFVMPQFQNTYGTDATAPSMSWGTKLSTPTSYDPSDFFQTGFEETNAISVSGGTRVNQSYFSAASLNSRGVIPNNVYNRYNFTFRNTTQLIKDKLTLDLGASYMRQYKRNPLVQGLYHNPLIPIYLFPRGDDISKYEVYERYDATAGYMKQFWPLEFITGVENPWWITNRELFENTAHRYTFNATLKWDIADWITLTGRVRTDNMVMNYTRKIYASSDKLFASEYGNYQNNKIHHNNLYADALLSINKSFFDDKFSLSFNLGASILDDKNDGEGFEGHLATLANKFSVYNVDMSHSQTKPYADRYHDQTQAVYATAQLGYNGMVYLDVTARNEWASQLAFTPHMNIFYPSVGLSAVISSMADLSKAGISFLKVRASYAEVGNAPQRFITGVNTPLQTGGIVSSDSYAPAVNLTPERTKSFEVGLNAKFLGNKIWTDVTYYNTNTYNQLFSYDAPPSTGYKRAYINAGKVNNWGIEAVVGYKNKWRDFSWSTNVNFSMNRNEVKELVPEGTRDVAGNLVTVDEVNMDYGGYRMKVKKGGSIGDFYVTGLKTDDQGRIYVDPNTNTVTTDPNTWLYGGNTEARFRLGWNNRFSYKGVNLGVLFDARIGGQGVSATQALMDRWGASQDSADARENGGVWISEDQKVPDARVFYANNGNGLSMLSHYVYSMTNVRLRELTLGYDLPSRWFNDKIGMTVSLVGRNLWMIYNKAPFDPEITASTGTYYQGLDYFMQPSARTIGFSVRLQF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGCTCCTGGGATGCTTCGGCGCCACCTCTGCCACGGCACAGACGCAGCAAGCCCTCTCGCGTGTGAGCCTCGATGCCCCGGACGCGACGGTCATCACGGTTTTCCAGGCTATCCAGCAGCAGACGGGCTGTTCGTTCGTCTACAATACGTCGGACATCGACACCGACCGCAAAGTGAGCCTCTCGGTGCACGACGAACCGCTGCAGGCCGTGTTGGACAAGCTCTTCGCGGGCTCCGACATCGCTTATACCCTTCGGGACAAACACATCGTGCTCTCGAAGAAAGCTAAAAATTCCCCCCCCCACAGCGCTCAGGGCGGCGTTACCGGAGTCATAAAGGACGATAAGGGCATGCCCCTGGTCGGCGCCACCGTGCTTATAAAAGGTACGACGACCGGTGCCGCCGCCGACATCGACGGCAATTTCTCGCTTCCGCAGGCCAAACCGGGGGACACGCTCGAAATTTCGCTCATCGGCTATACCAAACAGGAGCTTCCCGTCTCGGGATCCGCCCCGTTGTCGGTGGTCATGCACGAGGACAACGAAGTGCTCGACGCCGTGGTGGTTACCGCCCTCGGCATCAAGAGGTCGGAGAAAGCGCTGACCTACAACGTGCAGGAGGTCGCGGGCGACATCGTCAACACGGTCAAGGACGCCAACTTCATGAACTCGCTTTCGGGCAAGGTCGCCGGCCTTCAGATCAACGCCAGCGCCTCGGGCGTGGGTGGTTCCACGCGCGTGGTGATGCGCGGCGTGAAGTCCATCAGCGGCAACAACAACGCCCTCTATGTGATCGACGGTATCCCGATGCCCGACCTGCGTTCCTCGCAGACCGAGGGCACCTACGAAACGCCCGACGGCGGCGATTTCGAGGGTATCTCGAACCTCAACCCCGAGGACATCGAATCCATGACGGTGCTTTCGGGTGCCACGGCGGCCGCGCTCTACGGTTCGCAGGGTGCCAACGGTGTGATCGTCATCACGACAAAAAAGGGCGAGGAGGGGCGCGTGCGCGTGAACTACGCCAACAATACCACCTTTTCGTCGCCGTTCGTCATGCCGCAGTTCCAGAACACCTACGGCACCGACGCTACGGCACCTTCCATGAGCTGGGGTACGAAGCTCTCGACCCCGACCTCGTACGACCCCTCGGATTTCTTCCAGACCGGCTTCGAGGAGACCAATGCGATCTCGGTTTCGGGCGGTACGCGCGTGAACCAGTCCTATTTCTCGGCAGCTTCGCTCAATTCGCGCGGCGTCATCCCCAACAACGTCTACAACCGGTACAACTTCACCTTCCGCAATACCACGCAGCTCATCAAGGACAAGCTGACGCTCGACCTGGGCGCTTCCTACATGCGCCAGTACAAGCGTAACCCGCTCGTGCAGGGCCTCTACCACAACCCGCTGATTCCCATTTACCTCTTCCCGCGCGGCGACGACATCTCCAAGTACGAGGTTTACGAGCGTTACGACGCCACGGCGGGCTATATGAAGCAGTTCTGGCCCCTGGAGTTCATCACCGGCGTCGAGAACCCCTGGTGGATCACCAACCGCGAGCTGTTCGAGAATACGGCGCACCGCTATACGTTCAACGCCACGCTCAAGTGGGACATTGCCGACTGGATCACCCTCACGGGGCGCGTGCGCACCGATAACATGGTGATGAACTATACGCGCAAGATCTATGCCTCGTCCGACAAGCTGTTCGCTTCCGAATACGGTAACTACCAGAACAACAAGATCCATCACAACAACCTCTACGCCGACGCCCTGCTGTCGATCAACAAGAGTTTCTTCGACGACAAGTTCTCCCTGTCGTTCAACCTGGGTGCGAGCATCCTCGACGACAAGAACGACGGCGAAGGCTTCGAGGGCCACCTGGCCACCCTCGCCAACAAGTTCTCGGTCTACAACGTGGATATGAGCCATTCGCAGACCAAACCCTACGCCGACCGCTACCACGACCAGACGCAGGCCGTCTACGCCACCGCCCAGCTGGGATATAACGGCATGGTCTACCTCGACGTGACGGCGCGCAACGAGTGGGCGTCGCAGCTGGCCTTCACGCCCCATATGAACATATTCTACCCGTCGGTGGGCCTTTCGGCCGTCATCTCGTCGATGGCCGACCTTTCCAAAGCCGGCATTTCGTTCCTCAAGGTGCGTGCCTCCTATGCCGAGGTGGGTAACGCCCCGCAGCGGTTTATTACCGGTGTCAATACGCCCTTGCAGACGGGCGGTATCGTTTCGTCGGACTCCTATGCCCCGGCTGTCAACCTTACGCCCGAGCGCACCAAGTCGTTCGAAGTGGGCCTGAACGCCAAGTTCCTCGGCAACAAGATCTGGACGGACGTGACCTATTACAATACCAACACCTACAACCAGCTTTTTAGCTATGATGCACCGCCCAGCACCGGCTACAAACGGGCATATATCAATGCCGGCAAGGTCAACAACTGGGGTATCGAAGCGGTCGTGGGTTACAAGAACAAGTGGCGCGACTTCTCGTGGTCGACCAATGTCAACTTCTCGATGAACCGCAACGAGGTGAAGGAGCTGGTTCCCGAAGGCACGCGCGACGTGGCCGGTAACCTGGTGACTGTCGACGAGGTGAACATGGACTACGGCGGCTACCGCATGAAGGTCAAAAAAGGCGGTTCGATCGGCGACTTCTACGTGACGGGGCTCAAGACCGACGACCAGGGACGCATCTATGTCGACCCCAATACCAATACCGTCACCACCGATCCCAATACGTGGCTTTACGGCGGCAATACCGAAGCCCGCTTCCGCCTGGGGTGGAACAACCGCTTCTCCTACAAGGGCGTGAACCTCGGCGTGCTGTTCGATGCCCGCATCGGCGGCCAGGGCGTTTCGGCGACGCAGGCCCTGATGGATCGCTGGGGTGCCTCGCAGGATTCGGCCGACGCCCGGGAAAACGGCGGTGTCTGGATCTCCGAGGATCAGAAAGTCCCCGATGCCAGGGTCTTCTACGCCAACAACGGCAACGGGCTTTCGATGCTTTCACACTACGTTTACAGCATGACCAACGTCCGCCTGCGTGAACTTACTCTGGGCTACGACCTGCCTTCCAGGTGGTTCAACGACAAGATCGGCATGACCGTGTCGCTCGTCGGCCGCAACCTGTGGATGATCTACAACAAGGCGCCGTTCGATCCCGAGATCACCGCGTCCACGGGTACCTATTACCAGGGGCTCGACTATTTCATGCAGCCCAGCGCCCGTACCATCGGTTTCAGCGTAAGACTCCAATTCTAA",
    "translation": "MLLLGCFGATSATAQTQQALSRVSLDAPDATVITVFQAIQQQTGCSFVYNTSDIDTDRKVSLSVHDEPLQAVLDKLFAGSDIAYTLRDKHIVLSKKAKNSPPHSAQGGVTGVIKDDKGMPLVGATVLIKGTTTGAAADIDGNFSLPQAKPGDTLEISLIGYTKQELPVSGSAPLSVVMHEDNEVLDAVVVTALGIKRSEKALTYNVQEVAGDIVNTVKDANFMNSLSGKVAGLQINASASGVGGSTRVVMRGVKSISGNNNALYVIDGIPMPDLRSSQTEGTYETPDGGDFEGISNLNPEDIESMTVLSGATAAALYGSQGANGVIVITTKKGEEGRVRVNYANNTTFSSPFVMPQFQNTYGTDATAPSMSWGTKLSTPTSYDPSDFFQTGFEETNAISVSGGTRVNQSYFSAASLNSRGVIPNNVYNRYNFTFRNTTQLIKDKLTLDLGASYMRQYKRNPLVQGLYHNPLIPIYLFPRGDDISKYEVYERYDATAGYMKQFWPLEFITGVENPWWITNRELFENTAHRYTFNATLKWDIADWITLTGRVRTDNMVMNYTRKIYASSDKLFASEYGNYQNNKIHHNNLYADALLSINKSFFDDKFSLSFNLGASILDDKNDGEGFEGHLATLANKFSVYNVDMSHSQTKPYADRYHDQTQAVYATAQLGYNGMVYLDVTARNEWASQLAFTPHMNIFYPSVGLSAVISSMADLSKAGISFLKVRASYAEVGNAPQRFITGVNTPLQTGGIVSSDSYAPAVNLTPERTKSFEVGLNAKFLGNKIWTDVTYYNTNTYNQLFSYDAPPSTGYKRAYINAGKVNNWGIEAVVGYKNKWRDFSWSTNVNFSMNRNEVKELVPEGTRDVAGNLVTVDEVNMDYGGYRMKVKKGGSIGDFYVTGLKTDDQGRIYVDPNTNTVTTDPNTWLYGGNTEARFRLGWNNRFSYKGVNLGVLFDARIGGQGVSATQALMDRWGASQDSADARENGGVWISEDQKVPDARVFYANNGNGLSMLSHYVYSMTNVRLRELTLGYDLPSRWFNDKIGMTVSLVGRNLWMIYNKAPFDPEITASTGTYYQGLDYFMQPSARTIGFSVRLQF",
    "product": ""
   },
   {
    "start": 22927,
    "end": 24483,
    "strand": 1,
    "locus_tag": "ctg77_22",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,927 - 24,483,\n (total: 1557 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACGATTCAATCATACAATAGGATTTTTCGCCGCTGCGGCGCTTGCCGCCTGTACCGGTGACTTCGAATCCTTCAACACCAATCCCGATGCGGTGCAGTCGGTCGACAAGAAGACCTACATCACCACCATGCAAATGGATGCCGTGATCCCGTGCAGCGACGTGGGGGCCAACGAGTTCCAGCGCGCCTGCAACCTGATGGGCGACGCCTTCGGCGGCTATCTCTCCCCGATCCAGGCCTTCAACGGCGGCAGCTATACCTGTACCTACGACCTCGACGGTACGGACTATAACAACGTGCCCTTCTCGGTGGCTTTCACCAATGTGATGCCTGCATGGCTCAACCTCAAGTACGCCTACCAGAACGGGCAGGTTACCGACGACGTCTTTGCCGTTGCCGAGGTCATCAAGGTGATGGCCCTCCAGCGTACCACCGACATCTACGGCCCGATCCCCGTTTCGAATTTCGGCCAGACCGAAAACTCCTACGAATCGCAGGAGACCGTCTACAAAAACCTTCTCACGGATCTGAATGCCGCCATCGTGGTGCTCAAGGAGTATGCGGCCAATGCCGCCGACGCCAGGCCGTTGCAGAAGGTCGACGCCGTTTACCAGGGCGACTATGCGAAATGGCTCAAGCTGGCCAACTCGGTCAAGCTCCGCATGGCCATGCGCATCCGTTTTGTCGAACCCGGGCTTGCCCGGATCTATGCCGAGGAAGCCGTCAGGGACGGGGTGATGACCGCTTCGGACGACGGTGCGTGGCTCAAGAGTTCCGGTTCGGTACAGGTATACAATCCGCTCGAAGAGGTGTGGAACGCCTATAACGATACCCGCATGGGTGCGACCATCGACGCTTATATGAACGGTTACGCCGATCCGCGCCTACCGGCCTATTTCAAAACCTGCGAGGATGGCAAGTACCACGGTGTCCGCAGCGGTCTCAGCTCGATGCTGAAGGCGGACTATACCGGACTTTCGGTGCCCAACGTCGCCAAGGATACGCCCGTCGTGTGGTTCCTCGCTTCCGAGGCCGCTTTCCTGAGGGCCGAAGGCGCCATGCTCGGCTGGGAGATGGGCGGTGACGATGAATCGTTCTACAAGACGGGTATCGAACTGTCGTTCCTCGAACGCGGTCTTACCGCGGCCGCCGCGGCCACCTATGCCGAGAGTGCGAGCGAACCCCAGGCATTCGAGGACGCTTCGGCCGCCTCGACGAAATACAACGCTTCGAAACCTTCGTCCGTCTCCCCGAAATGGAATGCCGGCGCCGGGGACGAGGAGAAACTCGAACGGATCATCACGCAGAAGTGGATCGCCATGTTCCCCAACGGGCAGGAAGCCTGGTCGGAATTCCGCCGCACAGGTTACCCCAAGGTGATCCCGATCGTCAACAACCTCAGCGGCGGCAAGGTCGATACCAACGTCCAGGTGCGCCGTATGACCTTCCCGCGTTCGGAGTACTCGAACAATGCCGCCGGCGTGGCGGCTGCCACCGCACTGCTCGGCGGAGCCGATACCGGCGGTACGAAACTCTGGTGGGATAAGAAATAA",
    "translation": "MKRFNHTIGFFAAAALAACTGDFESFNTNPDAVQSVDKKTYITTMQMDAVIPCSDVGANEFQRACNLMGDAFGGYLSPIQAFNGGSYTCTYDLDGTDYNNVPFSVAFTNVMPAWLNLKYAYQNGQVTDDVFAVAEVIKVMALQRTTDIYGPIPVSNFGQTENSYESQETVYKNLLTDLNAAIVVLKEYAANAADARPLQKVDAVYQGDYAKWLKLANSVKLRMAMRIRFVEPGLARIYAEEAVRDGVMTASDDGAWLKSSGSVQVYNPLEEVWNAYNDTRMGATIDAYMNGYADPRLPAYFKTCEDGKYHGVRSGLSSMLKADYTGLSVPNVAKDTPVVWFLASEAAFLRAEGAMLGWEMGGDDESFYKTGIELSFLERGLTAAAAATYAESASEPQAFEDASAASTKYNASKPSSVSPKWNAGAGDEEKLERIITQKWIAMFPNGQEAWSEFRRTGYPKVIPIVNNLSGGKVDTNVQVRRMTFPRSEYSNNAAGVAAATALLGGADTGGTKLWWDKK",
    "product": ""
   },
   {
    "start": 24507,
    "end": 26414,
    "strand": 1,
    "locus_tag": "ctg77_23",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,507 - 26,414,\n (total: 1908 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAATTTCTTGAAATACGTCGCGGCCCTTGCGATCGTGGGTGCCTTTTTCGTCGCTTGTTCGGATTGGACGGATCCCGAGCGCGAAATTACGCAGCATCCCGACCAGCAGTCGCCCATCCTGCGCGATAATGCCTACTACCAGGCCCTGCGCGAATACAAAAAGACCAAGCACAAGATCGCTTTCGGCTGGTACGGTTCGTGGACGGCCGTCGGCGCATCCTACCAGACCCGCCTGCAGAGTGCTCCCGACTCGATGGATATCATCTCCATCTGGAGCCAGTGGCATTCGCTGACCCCCGAGCAGATCGCCGACAAGGAGTTCGTGCAGAAGATCAAGGGCACGAAGGTGACCTTCACGATCTTCTCGGACAAGATGCCCGAGCCGTTCCTCACCGAGATCGGCGGCGGCGAATATACCGACGAGGCCATCGAGGCCTACGCCAAAGCCTACTGCAAGGACTCGATGGACAAGTACAGCTACGACGGCATCGACGTCGACTACGAACCCGGCTACGGCGCTTCGGGGCCGTTCGTGGGACATGACAACGAGCTGTTCAGGAAGCTGATCCTGGCCATGAGCAAATACGTCGGCCCCAAGTCGGGGACGGGACGCCTGCTTATGATCGACGGCGTGCCCTATGCCGTGCATGCCGATGTGGCCGACTGCTTCGACTACGGCATCGTGCAGGCTTATAATTCTTACGGCTATACCGATTTGCAGGATCGCTTTGACGAAGCCGATAAGAAAGGCTGGAAGCCCGAGCAGTATATCTTCGCCGAGAACTTCGAGTCCCTCTGGAAAACCGGCGGCGTGTCGCATGAATGCCGCGACGGCCAGAGGGTCAACTCGCTGCTGGGCATGGCGCGCTTCAACCCCACGCAGGGTTTCGGTGCCGGTTTCGGTGCCTACCACATGGAGTATGAGTACGCCAATTCGTCGATGCCTTACAAGTATATGCGCGAGGCGATCCAGGATGTGAACCCCGCCGGCGGCGACCTGATCGTCGGTCTGACCTCGACCGGCTTGTCCAAATACCTGTTCCTGGTCGGGGACGACGGTACCATCACGGGCGAGGTGGACGAAAAAATCCGGGTCGAGCTGGCTCGTCCTGCCCCGGCCGACGTTTCGTTCCCGCTGGCTATCGACAATTCGCTGGTCGATGCCTACAACGAAAAGCACGGCACCTCCTACGAGCCGATCGACCCCGCGCGTGTTTCACTCGGCACGCTCGGCGTGGCAGCCGGTGCGTTCTTGTCCGACGAGGTGTCCGTTACCGTAAGTTCTGCCGGGATCGAGAAGGGTTACTACCTGATCCCCATCGTCGTGGAACTTCCCGCGGAAGATATTTATACCTCGAAGGAGCCATTGGTACGCTACCTGCTGTTGACGGTGTCGGCGATGGAGATCGACGTCGATGCGACGGCGCTTACGGGCGTGAAGATCGAACCTGCCTCCGGGTGGACGATCGTCTGCTACCAGGGCACCGCTTCGAGCGGCGCCAACGGCGTCTGGAACCTCGATTCCGATGCGCAGAAGGCCTGCATGTTCGACGGCAAGCTCGACTCCAACTGCTGGTATGCCGCGAATGCGTCCTATTCGTGGGGGAACGGCGGCAACTTCATCATCACGCTGGACAAGGCCTACGACATCAACGGCTTCCGCTGGCATATCTACTACGAGGACTCCAACCCCGAATGTACCGATTTCCAGTACAGCGAGGACGGCACCAACTGGTATAGCCTCACCAATGAAATTTCGTTCGTGCCCAAACTCTCGGCCGACAACTGGAAGATATTCCAGTTCAAGAAGACCGTCAAAGCCCGCTATCTCCGGGTATACGTCGGCCGGGTAACCGATTTCACCAGTATGAACGAGGCCGAGATTTTCGCCCCTGCAAACTAA",
    "translation": "MKNFLKYVAALAIVGAFFVACSDWTDPEREITQHPDQQSPILRDNAYYQALREYKKTKHKIAFGWYGSWTAVGASYQTRLQSAPDSMDIISIWSQWHSLTPEQIADKEFVQKIKGTKVTFTIFSDKMPEPFLTEIGGGEYTDEAIEAYAKAYCKDSMDKYSYDGIDVDYEPGYGASGPFVGHDNELFRKLILAMSKYVGPKSGTGRLLMIDGVPYAVHADVADCFDYGIVQAYNSYGYTDLQDRFDEADKKGWKPEQYIFAENFESLWKTGGVSHECRDGQRVNSLLGMARFNPTQGFGAGFGAYHMEYEYANSSMPYKYMREAIQDVNPAGGDLIVGLTSTGLSKYLFLVGDDGTITGEVDEKIRVELARPAPADVSFPLAIDNSLVDAYNEKHGTSYEPIDPARVSLGTLGVAAGAFLSDEVSVTVSSAGIEKGYYLIPIVVELPAEDIYTSKEPLVRYLLLTVSAMEIDVDATALTGVKIEPASGWTIVCYQGTASSGANGVWNLDSDAQKACMFDGKLDSNCWYAANASYSWGNGGNFIITLDKAYDINGFRWHIYYEDSNPECTDFQYSEDGTNWYSLTNEISFVPKLSADNWKIFQFKKTVKARYLRVYVGRVTDFTSMNEAEIFAPAN",
    "product": ""
   },
   {
    "start": 26433,
    "end": 27590,
    "strand": 1,
    "locus_tag": "ctg77_24",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,433 - 27,590,\n (total: 1158 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACTGAAATATTTGGTCGCTCCGCTGTTGTTCGCCGCCGCTGCGGCGACGGGCTGTCAGGAGTCCGCGGAGACCTATCCTGCGATCTACATGACCGATGCGCAGAACAATCCCGACAAATCAATGACCATCGACGAACCCCCTGCCGAGACCTCGATCACCGTATCCTCCTCGGTGGTTATGGAGCACGACGTGCGGATCCAGTTGGAAGTGCGGCCCGAACTGCTGGCTGCCTATAACGACAAGTACGGCAAAAACTACCAGATTCCGCCCGAGGAAAGCTACGCCCTGAGTTCGACCGAAACGACCATCCTGGCCGGCTACAACACCTCTTCGGCGATCGACTTCACGGTGTCGTCCGTCTCGGAGTTCGCCGAGGGCGTGACCTATTGCGTCCCCGTGGGCATCAAGACCGTATCCGGCGGAATAAGCGTGCTCGAACCGAGCCGCACGCTCTTCATCGTGCTGAAGACCCCGGTGATCAGCAAGGCGATCTACCTGGGATCGAGCAACATCTACAAGGTGACTTCGTTCCAGGAGAATTCCGACCTGGCAGCCCTTCCGCAGCTCACGCTCGAAGCCCGCGTATACATGCTCGGCTTCCAGACCCGCGATCCTTATATCAGTTCCATCATGGGTATCGAGGGCATCTGCGGCGTACGTTTCGGCGACGTGAAGGTCGATCCCGACTGCATCCAGATCTGTCACGACTCCTACCAGCCCGCAGCTACCGACAAGCCGTTCGACAAGGAGAAGTGGTACCACGTCGCCGCAGTCTGGACGGGCTCTTCGTGGGACATCTATATCAACGGGCAGTATGCCACGGGCGTGGAAACGCAGGGCGAGACCATCGACCTGACGAGCGACAATTCGGGCGGTTTCTACCTGGGAGCCTCCTATGGCGGCGGCCGTACGCTGAACGGCTATGTCGCCGAGTGCCGCGTATGGACACGCGCCCTCTCGCAATCCGAGATCGCCAACAACATGAACTATGTCGACCCCACGTCCGACGGGCTGCTCGCTTACTGGCGCATGAACGCCTGGGAGCCCAACGACAGCGGTTCCGGCAATATCGTGCGCGACCTCACGGGCCATGGTTACGATGCCGTCGGCGGCAGCTCCAACCCGACGATGATGGACACCAAGTGGAATTAG",
    "translation": "MKLKYLVAPLLFAAAAATGCQESAETYPAIYMTDAQNNPDKSMTIDEPPAETSITVSSSVVMEHDVRIQLEVRPELLAAYNDKYGKNYQIPPEESYALSSTETTILAGYNTSSAIDFTVSSVSEFAEGVTYCVPVGIKTVSGGISVLEPSRTLFIVLKTPVISKAIYLGSSNIYKVTSFQENSDLAALPQLTLEARVYMLGFQTRDPYISSIMGIEGICGVRFGDVKVDPDCIQICHDSYQPAATDKPFDKEKWYHVAAVWTGSSWDIYINGQYATGVETQGETIDLTSDNSGGFYLGASYGGGRTLNGYVAECRVWTRALSQSEIANNMNYVDPTSDGLLAYWRMNAWEPNDSGSGNIVRDLTGHGYDAVGGSSNPTMMDTKWN",
    "product": ""
   },
   {
    "start": 27909,
    "end": 29969,
    "strand": 1,
    "locus_tag": "ctg77_25",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg77_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg77_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,909 - 29,969,\n (total: 2061 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg77_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg77_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAAATCACGCTTATCTCTTTTTGCCTTGCCGCTTTCGCCTTTGCTTCGTGCGCCGGCGGCGGGTGCCCGGCCACGGGCATCATCCCGGCCCCGCAGCAGGTGACGTGGGGCGAAGGTGCCTTCCGTATGCCTGCCAAGCTGCTCTACACGACCGACCTCGACGGGCAGGACAAGGCCGACCTCGCGGCGTGGATGCAGCGTGCCGCGGACGGATTCTTCCCCGCCTCCTTTGCCGAGGCCTCCGACGGCGACATGCCCGCACTCGAACTGCTTCGTACGGGCGACGGCGCCCCCGAAAGCTACCGTCTCGACGTCTCCCGCACAAAGATCACGCTCACGGCCCCCGATGCCGCAGGGTTGTTCTACGGACTCCAGTCGCTCGCACAACTGGCCGGGCACCACGGCCGCCGCATTCCGGCCGTCACGATCGTGGACGCCCCGCGCTTCGGTTACCGGGGCTTCATGCTCGACGTCTCGCGCCATTTCCGCGACAAGGAGTTCGTCGAACGTCAGCTCGACCTCATGGCGCGCTACAAGCTCAACCGCTTCCACTGGCACCTGACCGACGGAGCCGGATGGCGCATCGAAATCAAAAAATACCCCGCCCTGACCGACATCGCCGCCTGGCGTCCCTATCCCGACTGGGAGGGATGGAACTTCGGCGGCAAACGCTACTGCCACCGCGACGACCCGGCGGCCGCCGGGGGCTATTACACGCAGGACGACATCCGCGAAGTGGTCGAATACGCCCGTGCCCTGCATATCGAGGTGATTCCCGAGATCGAGATGCCGGGGCACAGCGAGGAGGTGCTGGCCGTTTACCCCGAACTCTCGTGCAGCGGCAAACCCTACACGGACTCCGATTTCTGCATCGGCAACGAGCAGACGTTCGAATTCCTTGAGAGCGTGCTCTCCGAAGTGATCGGGCTCTTCCCTTCGGAATATATCCATATCGGCGGCGACGAGGCTTCGAAACAGGGGTGGCGCACCTGCCCCGAATGTGCCGCCCGGATGCGTCGGGAGGGACTGCAGGACGTCGATGAACTGCAAAGCTACCTGGTGCACCGCATCGGGACGTTCCTCGCCGCCAAGGGCCGCCGCCTGCTGGGCTGGGACGAGATTCTCCAGGGCGGGCTCGCGCCCGGCGCCACGGTCATGTCGTGGCGCGGCACCGAGGGCGGGATCGCCGCGGCCAGGGCCGGACACCGCGCCGTGATGGCTCCCTCGAACTACTGCTACCTCGATTTCTGCCAGGACGACCCCACCCGCGAGCCGGTCGCCGCCGCGGCGTTCCTCACCCTCGCGCAAGCCTACTCCTACGACCCTGCGCCCGATTCGCTGGGTGCGGATGTCGTGCCGATGATCCTCGGCGTGCAGGGCAACCTGTGGTGCGAGCACGTGCCCACAGCCGAACATGCCGAACACATGATCTGGCCGCGCCTGCTGGCGATTGCCGAAGTGGGGTGGAGCGCCCCCGAACGGAAGGACTACGACGACTTCCACGCCCGCGTGCTCGACGCCGTGGCGTGGATGCAGCAGCGCGGATACCACCCCTTCGACCAGAAAAATGCCGTCGGCCCCCGCCCCGAATCGCTCGATACCCTGCATTGCCTTTCGACCGGCAGGCAGGTGGTTTACCGTACGCCTTACAGCCCGAAATACCCGGCTGCGGGCGACGCTTCGCTGACCGACGGGCTGTGCGGCGGGTGGAACTACGGCGACCGCCGCTGGCAGGGGTGGCTCGATACGGATGTCGAACTGGTCGTCGACCTCGGGGAACGCCAGCCTGTGAAACGTATCGCGGCCTGTTTCATGCAGGGTTTCTATGCCGACATCTGGATGCCCCGTGCGGTCGAAATCTCGGTTTCGGACGACGACAGGCACTATACGCCCCTTGCCGCGGTCGAAAACGACATCCCGTTCGAATACAAGCAGGATTGCTACCGCGAGTTCGGCTGGTCGGGCCAAACCGCGGCGCGTTACGTGCGGCTGAAAGCCCGGCACAACGGCCATCCCGGCGGCTGGATTTTCACCGACGAGATTATTGTGGAGTAA",
    "translation": "MKKITLISFCLAAFAFASCAGGGCPATGIIPAPQQVTWGEGAFRMPAKLLYTTDLDGQDKADLAAWMQRAADGFFPASFAEASDGDMPALELLRTGDGAPESYRLDVSRTKITLTAPDAAGLFYGLQSLAQLAGHHGRRIPAVTIVDAPRFGYRGFMLDVSRHFRDKEFVERQLDLMARYKLNRFHWHLTDGAGWRIEIKKYPALTDIAAWRPYPDWEGWNFGGKRYCHRDDPAAAGGYYTQDDIREVVEYARALHIEVIPEIEMPGHSEEVLAVYPELSCSGKPYTDSDFCIGNEQTFEFLESVLSEVIGLFPSEYIHIGGDEASKQGWRTCPECAARMRREGLQDVDELQSYLVHRIGTFLAAKGRRLLGWDEILQGGLAPGATVMSWRGTEGGIAAARAGHRAVMAPSNYCYLDFCQDDPTREPVAAAAFLTLAQAYSYDPAPDSLGADVVPMILGVQGNLWCEHVPTAEHAEHMIWPRLLAIAEVGWSAPERKDYDDFHARVLDAVAWMQQRGYHPFDQKNAVGPRPESLDTLHCLSTGRQVVYRTPYSPKYPAAGDASLTDGLCGGWNYGDRRWQGWLDTDVELVVDLGERQPVKRIAACFMQGFYADIWMPRAVEISVSDDDRHYTPLAAVENDIPFEYKQDCYREFGWSGQTAARYVRLKARHNGHPGGWIFTDEIIVE",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 2194,
    "end": 10049,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 30049,
    "product": "arylpolyene",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "arylpolyene",
  "products": [
   "arylpolyene"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS arylpolyene",
  "anchor": "r77c1"
 }
};
var details_data = {
 "nrpspks": {
  "r77c1": {
   "id": "r77c1",
   "orfs": [
    {
     "id": "ctg77_4",
     "sequence": "MSIAVCGIGIVSAIGIGAGETLGNLRTGRSGIGKPTLLGSAVDVPVGEVKRDNAALGELLGIPEREHPSRTALLGMAAAAQAVADAAIPAGARVALVSGTSVGGMDLTENFYRDFRTDKAKGRLRDVAGHDCADSTQRIARYCGIGGYTATVSTACSSAANAIVTGALLLGSGMADYVVAGGTDALCRFTLNGFNSLSVLDREPCRPFDATRAGLNLGEGAGYLVLTHERPGMRTYCRLAGYANANDAYHQTASSQTGEGAYRAMAGALAQSGLRCVDYINVHGTATPNNDLTEGTALRRLFGGQVPPFSSTKGYTGHALAAAGGIEAVLAVLAITHGLRYGNPGFAEPIPELGLHPVARTQEADVRSVLSNSFGFGGNCCSLIFAK",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 76,
       "end": 385,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "AAAAQAVADAAIPAGARVALVSGTSVGGMDLTENFYRDFRTDKAKGRLRDVAGHDCADSTQRIARYCGIGGYTATVSTACSSAANAIVTGALLLGSGMADYVVAGGTDALCRFTLNGFNSLSVLDREPCRPFDATRAGLNLGEGAGYLVLTHERPGMRTYCRLAGYANANDAYHQTASSQTGEGAYRAMAGALAQSGLRCVDYINVHGTATPNNDLTEGTALRRLFGGQVPPFSSTKGYTGHALAAAGGIEAVLAVLAITHGLRYGNPGFAEPIPELGLHPVARTQEADVRSVLSNSFGFGGNCCSLIF",
       "dna_sequence": "GCGGCGGCCGCACAGGCCGTAGCGGATGCGGCGATCCCCGCCGGGGCGCGCGTAGCACTCGTTTCGGGCACCTCGGTAGGCGGCATGGATCTGACGGAGAATTTCTACCGCGACTTCCGCACGGACAAGGCGAAAGGGCGGCTGCGCGACGTGGCGGGGCACGACTGTGCCGACAGCACGCAACGGATCGCCCGCTACTGCGGCATCGGAGGTTACACGGCGACGGTCAGCACGGCCTGCTCGTCGGCCGCAAACGCCATCGTCACCGGCGCCCTGCTGCTCGGGAGCGGCATGGCCGACTATGTGGTGGCCGGGGGCACGGATGCCCTTTGCCGTTTCACGCTCAACGGCTTCAACTCGCTCTCGGTGCTCGACCGGGAACCCTGCCGCCCGTTCGACGCCACGCGCGCCGGGCTGAACCTGGGCGAAGGGGCGGGTTACCTCGTCCTCACGCACGAAAGGCCCGGCATGCGCACCTACTGCCGCCTGGCGGGATATGCCAATGCCAACGACGCCTATCACCAAACGGCCTCGTCGCAAACGGGCGAGGGGGCATACCGCGCCATGGCCGGGGCGCTGGCACAAAGCGGGCTGCGCTGCGTGGACTACATCAACGTCCACGGCACGGCGACCCCGAACAACGACCTCACGGAAGGTACCGCCCTGCGGCGACTGTTCGGCGGACAGGTGCCGCCGTTCAGTTCGACGAAAGGCTACACGGGGCATGCGCTCGCCGCGGCGGGAGGCATCGAGGCCGTATTGGCGGTGCTGGCTATCACACACGGGCTGCGCTACGGCAACCCCGGATTCGCGGAGCCGATCCCGGAGCTCGGGCTGCACCCCGTAGCACGGACGCAAGAGGCCGACGTACGTTCGGTGCTCTCAAATTCGTTCGGGTTCGGCGGCAACTGCTGTTCGTTAATCTTT",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg77_5",
     "sequence": "MGGEITVWWGPDDMVSALGFGTEENMAAVRAMKSSLASWHDATPVCLIDRKRLGALAAEQGLAGYTPLERLVLATLGGVVARSGVTPADKRALIVLATTKGEIGSLGSAPERCDLNRTAEVVGRYFGTAHRPLLISNACISGVSAIVIAARLIRSGRYDHVFVAGFDLLSDFIVSGFNAFKSVSPTLCRPYDAARDGLTLGEACGAVLLTRDRRLSGTGVSVAGGGISNDANHISAPSRTGDGLWYAIRAALAEAGTGAGEVGLVNTHGTATAYNDEMESKALHLAGLCGVPCNSLKPYFGHTLGASGVIESIVTVRELCEGTCFGVKGYAECGVPYPPDVSAAHREIRTDTALKTASGFGGCNAAVVFRRAAGSDAAPGNETAEGQGCGPNTGVQGGNDCLEAARARSGTAMSANDRARGKNAVGHGNPDTGEKADGHAETGTGRHGSGIRCHDTAHVVIAQHPSLPFDAFIRERYRALADPNMKFSKMDDLCKLAYVASCELLSGHRPDCPAERIGVVMANRSASLDSDRRHQAIIDAGDGCGASPAVFVYTLPNIMLGQVAIKHGLKGESTFFAFPDKSSNFIREYAASLIAEGRMDAVLWGWCEFDGGSYDCELTLTEKTGQDTMEDLELQLKQQIIEALNLEEITADEIATDAPLFGDGLGLDSIDALEITLLLEKHYGIRLANPAEAKPIFYSVATLADFIRKNRPQ",
     "domains": [
      {
       "type": "PP-binding",
       "start": 641,
       "end": 707,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EALNLEEITADEIATDAPLFGDGLGLDSIDALEITLLLEKHYGIRLANPAEAKPIFYSVATLADFI",
       "dna_sequence": "GAAGCGCTGAACCTCGAGGAGATCACCGCCGACGAGATAGCGACCGACGCGCCGCTGTTCGGCGACGGGCTGGGACTCGACTCGATCGACGCACTGGAAATCACCCTCCTGCTCGAAAAACACTACGGCATACGGCTGGCGAACCCGGCCGAAGCCAAACCGATATTCTATTCGGTAGCCACGCTGGCCGACTTTATC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg77_10",
     "sequence": "MTEQELIEKIDTVLADEFEVDRTTITPEAPLLETLDLDSLDLVDVVVIVDKNFGVTLTGPDFKELKTFRDFYDLIISRTNGK",
     "domains": [
      {
       "type": "PP-binding",
       "start": 8,
       "end": 75,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "KIDTVLADEFEVDRTTITPEAPLLETLDLDSLDLVDVVVIVDKNFGVTLTGPDFKELKTFRDFYDLI",
       "dna_sequence": "AAGATCGATACCGTACTGGCCGATGAATTCGAAGTCGACCGGACGACCATCACGCCCGAAGCCCCGCTGCTGGAGACGCTCGACCTGGACAGCCTCGACCTGGTGGACGTCGTGGTGATCGTCGACAAGAACTTCGGCGTAACGCTCACGGGCCCCGATTTCAAGGAGCTGAAGACCTTCCGGGACTTCTACGACCTGATT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg77_11",
     "sequence": "MEKRVVITGMGIWACIGKNTEEVTQSLREGRSGIGLDPARRELGYISSLTGIVEQPNLKGVLDRRKRLCLPQQGEYAYMATAEAMRNAGMDEAYLAANEVGIIYGNDSSAAPVIEGIDIIRARRNTAMVGSGNIFQSMNSTVTMNLSVIFNLRGINLTLSAACASGSHAIGMGYLMIRQGLQERVVCGGAQEVNLYSVGSFDGLGAFSARESDPAAASRPFDKDRDGLVPSGGAATVILESHESAVARGAEILGEVVGYGFSSNGEHISVPNVDGPRRSLLRCLEDAGMRPEEIPYVNAHATSTPLGDYNEAEAIAGVFAGCNPYVASTKSMTGHEMWMAGASEVVYSMLMMRHGFIAPNINFTEGDEATSKLNIPVRRVDTEFDCFLSNSFGFGGTNSTLIVKKYK",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 77,
       "end": 406,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YMATAEAMRNAGMDEAYLAANEVGIIYGNDSSAAPVIEGIDIIRARRNTAMVGSGNIFQSMNSTVTMNLSVIFNLRGINLTLSAACASGSHAIGMGYLMIRQGLQERVVCGGAQEVNLYSVGSFDGLGAFSARESDPAAASRPFDKDRDGLVPSGGAATVILESHESAVARGAEILGEVVGYGFSSNGEHISVPNVDGPRRSLLRCLEDAGMRPEEIPYVNAHATSTPLGDYNEAEAIAGVFAGCNPYVASTKSMTGHEMWMAGASEVVYSMLMMRHGFIAPNINFTEGDEATSKLNIPVRRVDTEFDCFLSNSFGFGGTNSTLIVKKY",
       "dna_sequence": "TACATGGCCACCGCCGAGGCGATGCGCAACGCCGGAATGGACGAGGCCTACCTGGCGGCGAACGAGGTGGGAATCATCTACGGCAACGACAGCAGTGCGGCGCCGGTGATCGAGGGGATCGACATCATCCGCGCCAGGCGGAACACGGCGATGGTCGGCTCGGGCAATATTTTCCAGTCGATGAACTCGACCGTGACGATGAACCTCTCGGTGATCTTCAACCTGCGGGGCATCAACCTCACGCTCTCGGCGGCCTGCGCCAGCGGGTCGCACGCCATCGGCATGGGTTACCTGATGATCAGGCAGGGGTTGCAGGAGCGCGTGGTCTGCGGCGGCGCACAGGAGGTGAACCTCTACTCGGTGGGCAGCTTCGACGGGCTGGGGGCATTCTCGGCCCGCGAATCGGATCCCGCGGCGGCATCGCGCCCCTTCGACAAAGACCGCGACGGGCTGGTGCCGAGCGGAGGCGCGGCGACGGTGATCCTCGAAAGCCATGAATCGGCCGTCGCACGGGGCGCCGAAATCCTGGGCGAAGTGGTCGGGTACGGGTTCTCGTCGAACGGCGAGCATATCTCCGTGCCGAACGTTGACGGCCCGCGCCGTTCGCTGCTGCGGTGTCTGGAGGACGCCGGAATGCGGCCCGAAGAGATCCCCTACGTCAATGCGCACGCCACCTCGACGCCGCTGGGCGACTACAACGAGGCGGAGGCGATAGCCGGGGTATTCGCCGGGTGCAACCCCTACGTGGCGTCGACCAAGTCGATGACCGGCCACGAAATGTGGATGGCCGGGGCGAGCGAAGTGGTCTACTCGATGCTGATGATGCGGCACGGGTTCATCGCCCCGAACATCAACTTCACCGAGGGCGACGAGGCCACCTCGAAGCTCAACATCCCCGTCCGCAGGGTGGACACGGAGTTCGACTGCTTCCTCTCGAACTCGTTCGGCTTCGGCGGCACCAACTCGACCCTGATCGTTAAGAAATAC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg77_12",
     "sequence": "MAKTNKYALVTGGSRGIGREICLKLGGCGYHVLVNYKSNAAEAEKTLSGIRAAGGDGEALQFDVASGEESTAAIEAWQKAHEGACIEVVVNNAGIRDDVLMMWMEPQQWHSVIGTSLDGFYNVTRPLLKGMLVNRFGRIVNIVSLSGIKGLPGQANYAAAKGGVIAATKALAQEVAKKGVTVNAIAPGFVRTDMTADIDEAELRKQIPAGRFCEPAEVADLAMFLISEQASYITGEVISINGGLYT",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 7,
       "end": 177,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C2"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ALVTGGSRGIGREICLKLGGCGYHVLVNYKSNAAEAEKTLSGIRAAGGDGEALQFDVASGEESTAAIEAWQKAHEGACIEVVVNNAGIRDDVLMMWMEPQQWHSVIGTSLDGFYNVTRPLLKGMLVNRFGRIVNIVSLSGIKGLPGQANYAAAKGGVIAATKALAQEVAK",
       "dna_sequence": "GCACTCGTGACCGGCGGCAGCCGGGGCATAGGCCGCGAAATCTGCCTCAAACTGGGCGGGTGCGGCTACCACGTGCTCGTCAACTACAAGTCGAACGCCGCCGAGGCCGAAAAGACCCTGTCGGGCATCCGCGCCGCAGGCGGCGACGGCGAGGCACTGCAATTCGACGTGGCCTCGGGCGAAGAGAGCACGGCGGCCATCGAGGCATGGCAGAAAGCGCACGAAGGCGCCTGCATCGAGGTGGTGGTGAACAACGCGGGCATCCGCGACGACGTGCTGATGATGTGGATGGAACCGCAGCAGTGGCACTCGGTGATCGGCACCAGCCTCGACGGGTTCTACAACGTCACGCGGCCGCTGCTCAAGGGGATGCTCGTGAACCGGTTCGGGCGCATCGTCAACATCGTCTCGCTCTCGGGCATCAAGGGGCTGCCCGGGCAGGCCAATTACGCCGCGGCCAAGGGCGGCGTGATCGCCGCGACCAAGGCGCTGGCGCAGGAGGTGGCCAAA",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r68c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg68_1": {
     "functions": []
    },
    "ctg68_2": {
     "functions": []
    },
    "ctg68_3": {
     "functions": []
    },
    "ctg68_4": {
     "functions": []
    },
    "ctg68_5": {
     "functions": [
      {
       "description": "SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg68_6": {
     "functions": []
    },
    "ctg68_7": {
     "functions": []
    },
    "ctg68_8": {
     "functions": [
      {
       "description": "SMCOG1082:TonB-dependent siderophore receptor family ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg68_9": {
     "functions": []
    },
    "ctg68_10": {
     "functions": [
      {
       "description": "Stand_Alone_Lasso_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF05402",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg68_11": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg68_12": {
     "functions": []
    },
    "ctg68_13": {
     "functions": []
    },
    "ctg68_14": {
     "functions": [
      {
       "description": "SMCOG1167:transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg68_15": {
     "functions": []
    },
    "ctg68_16": {
     "functions": []
    },
    "ctg68_17": {
     "functions": []
    }
   }
  }
 },
 "r77c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg77_1": {
     "functions": []
    },
    "ctg77_2": {
     "functions": [
      {
       "description": "SMCOG1235:polysaccharide deacetylase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_3": {
     "functions": []
    },
    "ctg77_4": {
     "functions": [
      {
       "description": "APE_KS2",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_5": {
     "functions": [
      {
       "description": "APE_KS2",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ketoacyl-synt",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_6": {
     "functions": []
    },
    "ctg77_7": {
     "functions": []
    },
    "ctg77_8": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1277:Radical SAM domain protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_9": {
     "functions": []
    },
    "ctg77_10": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg77_11": {
     "functions": [
      {
       "description": "APE_KS1",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_12": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_13": {
     "functions": []
    },
    "ctg77_14": {
     "functions": []
    },
    "ctg77_15": {
     "functions": []
    },
    "ctg77_16": {
     "functions": []
    },
    "ctg77_17": {
     "functions": [
      {
       "description": "rSAM_pep_methan",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR04085",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SPASM",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg77_18": {
     "functions": [
      {
       "description": "SMCOG1005:Drug resistance transporter, EmrB/QacA ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_19": {
     "functions": [
      {
       "description": "SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_20": {
     "functions": []
    },
    "ctg77_21": {
     "functions": [
      {
       "description": "SMCOG1082:TonB-dependent siderophore receptor family ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg77_22": {
     "functions": []
    },
    "ctg77_23": {
     "functions": []
    },
    "ctg77_24": {
     "functions": []
    },
    "ctg77_25": {
     "functions": []
    }
   }
  }
 }
};
