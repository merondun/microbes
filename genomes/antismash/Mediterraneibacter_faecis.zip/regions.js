var recordData = [
 {
  "length": 262824,
  "seq_id": "NZ_JANGDO010000001.1",
  "regions": []
 },
 {
  "length": 112980,
  "seq_id": "NZ_JANGDO010000010.1",
  "regions": []
 },
 {
  "length": 112911,
  "seq_id": "NZ_JANGDO010000011.1",
  "regions": []
 },
 {
  "length": 109205,
  "seq_id": "NZ_JANGDO010000012.1",
  "regions": []
 },
 {
  "length": 105335,
  "seq_id": "NZ_JANGDO010000013.1",
  "regions": []
 },
 {
  "length": 97330,
  "seq_id": "NZ_JANGDO010000014.1",
  "regions": []
 },
 {
  "length": 87446,
  "seq_id": "NZ_JANGDO010000015.1",
  "regions": []
 },
 {
  "length": 86368,
  "seq_id": "NZ_JANGDO010000016.1",
  "regions": []
 },
 {
  "length": 77399,
  "seq_id": "NZ_JANGDO010000017.1",
  "regions": []
 },
 {
  "length": 73533,
  "seq_id": "NZ_JANGDO010000018.1",
  "regions": []
 },
 {
  "length": 65259,
  "seq_id": "NZ_JANGDO010000019.1",
  "regions": []
 },
 {
  "length": 208981,
  "seq_id": "NZ_JANGDO010000002.1",
  "regions": []
 },
 {
  "length": 63643,
  "seq_id": "NZ_JANGDO010000020.1",
  "regions": []
 },
 {
  "length": 60399,
  "seq_id": "NZ_JANGDO010000021.1",
  "regions": []
 },
 {
  "length": 54746,
  "seq_id": "NZ_JANGDO010000022.1",
  "regions": []
 },
 {
  "length": 47885,
  "seq_id": "NZ_JANGDO010000023.1",
  "regions": []
 },
 {
  "length": 45135,
  "seq_id": "NZ_JANGDO010000024.1",
  "regions": []
 },
 {
  "length": 43915,
  "seq_id": "NZ_JANGDO010000025.1",
  "regions": []
 },
 {
  "length": 43356,
  "seq_id": "NZ_JANGDO010000026.1",
  "regions": []
 },
 {
  "length": 41114,
  "seq_id": "NZ_JANGDO010000027.1",
  "regions": []
 },
 {
  "length": 37428,
  "seq_id": "NZ_JANGDO010000028.1",
  "regions": [
   {
    "start": 1,
    "end": 12929,
    "idx": 1,
    "orfs": [
     {
      "start": 194,
      "end": 607,
      "strand": 1,
      "locus_tag": "ctg21_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 194 - 607,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATTTTAAAGAAATATTCTCCAATCGGTGAATTAGGAACACTGGCAGGGATTTATGCAGATAGTCTTTCGAAGACACTTGATTGTACAGTCTGTATCACTGATACAGATCAGGTGATCGCGGCAGCAGGAAACGGGAAGAAAGAACTTCAGGAAATGCTGTTGAGTGCAGAGCTGGCAGAAGTGTTTCAAGAAAGAAAGACCGTGTTGAAAAAGAGTAGTGACGCTGAGTTTGTAGCAATTACAAAAGACAGGAGTGAATACAGCGAGGAAATAATCAGTGTGATTCTCAGTGAAGGTGATATTGCAGGTGGAGTGATCTTTCTGCAGAAAAATGAGAAAAAGCATTTCGGAGAAATGGAAAAGAAGTTTGCGGCAGGCGCAGCAGATCTGCTTGGGAGGCAGTTAAGTTAA",
      "translation": "MILKKYSPIGELGTLAGIYADSLSKTLDCTVCITDTDQVIAAAGNGKKELQEMLLSAELAEVFQERKTVLKKSSDAEFVAITKDRSEYSEEIISVILSEGDIAGGVIFLQKNEKKHFGEMEKKFAAGAADLLGRQLS",
      "product": ""
     },
     {
      "start": 684,
      "end": 1064,
      "strand": 1,
      "locus_tag": "ctg21_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 684 - 1,064,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGAGAAAATCATGGGAAAAAAGGGATAATATACGCAGAAAATTTAGTGAAGGCATTACTTTGCGCCTATCTGGTCACAGGAATGTTTCTGTTAATTCTTGCACTTCTCCTTTATAAAGCAGGATTGAGTGAAGAAAATGTAAATCTGGGAATTATTCTCATTTATGTAATAGGAACTTTTTCCGGTGGTTTTGTGATGGGAAAACTGGAAGGTCAAAAGAAGTTCCTCTGGGGGCTTGGAACCGGTGTGGTTTATTTTGTTTTATTACTGATCATCTCATTTGGAATGTACCGTGAGGTTTCGTCGGGGACAGGAGATTTGTTTCTGACATTTGTACTTTGTACCGGAGGTGGAATGCTCGGTGGGATGGTCGCATGA",
      "translation": "MRENHGKKGIIYAENLVKALLCAYLVTGMFLLILALLLYKAGLSEENVNLGIILIYVIGTFSGGFVMGKLEGQKKFLWGLGTGVVYFVLLLIISFGMYREVSSGTGDLFLTFVLCTGGGMLGGMVA",
      "product": ""
     },
     {
      "start": 1048,
      "end": 1305,
      "strand": 1,
      "locus_tag": "ctg21_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,048 - 1,305,\n (total: 258 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGGATGGTCGCATGAAGAAAAACCAGACGGATGTGTGAAAAAATACTTTAAAAACCTGACTGTGTGTGCTATAATAGCGAAAGCAATATGTGCGAAGTTAGGAGGAGTAAAAATGAAACACATTAAAACACTGAATACACAGACACTGAACAACACAGTTAAAAAAGGTGGATGCGGAGAGTGCCAGACATCTTGCCAGTCTGCATGTAAGACATCCTGTACAGTAGGAAACCAGACTTGCGAAAACGCAAAATAA",
      "translation": "MGWSHEEKPDGCVKKYFKNLTVCAIIAKAICAKLGGVKMKHIKTLNTQTLNNTVKKGGCGECQTSCQSACKTSCTVGNQTCENAK",
      "product": ""
     },
     {
      "start": 1529,
      "end": 2929,
      "strand": 1,
      "locus_tag": "ctg21_4",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,529 - 2,929,\n (total: 1401 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATACATCAGTACCAGAACAATGGATATAATATCGTCCTCGACGTGAACAGCGGAGCTGTACATGTTGTGGATCAGGAAGCGTATGATGTCATCGAAGTGCTTAATCGCATGAATGAAGATCATACAGTGGAGACATTGAAATCTCCGGAAACAGCAGAAGCATTGAAAAAAGAGCTTGGAGAAAAATATTCCGAGAAAGATCTGCTGGATATTTTAGAGGCAGTAACAGAACTGACGGAACAGGGACGTCTGTTTACAAAAGACATTTATGAGAGCTTTATCGACGTTGTAAAGCAGCGTAAGACAGTTGTTAAGGCTTTATGTCTTCATATTGCACATGACTGTAACCTTGCCTGTAAGTACTGCTTTGCGGAAGAGGGAGAATATCACGGCCGCAGGGCTCTGATGTCTTACGAGGTTGGTAAGAAAGCACTTGATTTCCTGATCGCGAATTCAGGAACAAGAAGAAACCTTGAGGTTGACTTCTTCGGTGGTGAGCCGCTGATGAACTGGCAGGTTGTTAAAGACCTGGTTGCTTACGGAAGAGAGCAGGAGAAACTTCATGACAAGCATTTCCGTTTCACACTTACAACAAACGGAGTTCTTTTGAACGATGAAGTTCAGGAGTTCGTGAACAAAGAGATGGACAACGTTGTCATCAGTCTTGACGGAAGAAAAGAAGTGAATGACCAGATGCGCCCGTTCCGTAACGGAAAAGGAAGCTATGATCTGATCGTTCCGAAGTTCCAGAAGCTGGCAGAGAGCCGTAATCAGGAGAAGTACTACATTAGAGGTACATTTACAAGAAATAACTTGGATTTTTCCAAGGATGTAGAACATTTTGCAGATCTTGGATTCAAGCAGATGTCAATCGAGCCTGTAGTAGGTGATGACACAGAACCATATGCAATCCAGAAAGAAGATCTTCCACAGATCTTTGAAGAATATGATAAACTCGCAAAATTCCTGATCGAGCGTGAGAAGAGCGGAAGAGGATTCAATTTCTTCCATTTCATGATCGATCTTGAAGGAGGACCGTGCGTGTCCAAGCGTCTGTCCGGCTGTGGTTCAGGTACAGAGTATCTGGCAGTGACACCTTGGGGAGATTTCTACCCATGTCATCAGTTTGTAGGACAGGAAGAATTCCTCATGGGAAATGTCGATGAGGGAATTACAAAACCGGAGATTGCGGAAGAATTCCGTGGATGCAGCGTATATTCCAAGGAAAGCTGCAGAACCTGCTTTGCCAGATTCTACTGCAGTGGTGGCTGTATGGCGAATTCTTACAAGTTCCACAATACGATCCATGATACTTACGAAGTGAGCTGTGAGATGGAGAGAAAACGTGTGGAATGTGCGATCATGATAAAGGCTGCCCTGGCGGATGAAGAACAATAA",
      "translation": "MIHQYQNNGYNIVLDVNSGAVHVVDQEAYDVIEVLNRMNEDHTVETLKSPETAEALKKELGEKYSEKDLLDILEAVTELTEQGRLFTKDIYESFIDVVKQRKTVVKALCLHIAHDCNLACKYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGTRRNLEVDFFGGEPLMNWQVVKDLVAYGREQEKLHDKHFRFTLTTNGVLLNDEVQEFVNKEMDNVVISLDGRKEVNDQMRPFRNGKGSYDLIVPKFQKLAESRNQEKYYIRGTFTRNNLDFSKDVEHFADLGFKQMSIEPVVGDDTEPYAIQKEDLPQIFEEYDKLAKFLIEREKSGRGFNFFHFMIDLEGGPCVSKRLSGCGSGTEYLAVTPWGDFYPCHQFVGQEEFLMGNVDEGITKPEIAEEFRGCSVYSKESCRTCFARFYCSGGCMANSYKFHNTIHDTYEVSCEMERKRVECAIMIKAALADEEQ",
      "product": ""
     },
     {
      "start": 2966,
      "end": 5374,
      "strand": 1,
      "locus_tag": "ctg21_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,966 - 5,374,\n (total: 2409 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAAAGGTAAGAGTATTCTCAGCCTCATTCTCGTAATCGCAGTTACAGCACTCTTCGGTATGACCTGTGTGCTTGGACTTGATTTAAAGGGAATGGGAGCTGCGAAGAACATCAATCTCGGTCTTGACCTGGAAGGCGGAGTCAGCATTACATATCAGGTAAAAGGTGACAAGCCATCTCAGGCAGACATGGATGACACCGTGTACAAGCTTCAGAAACGTGTGGAGCAGTACAGCACAGAGGCACAGGCTTATCAGGTTGGAGACAACCGTATCAGTATCGAGATTCCGGGTGTGAGCGACGCAAACAAGATCCTGGAAGAACTTGGACAGCCGGGTTCACTGTACTTTATCAAGCATAAAGACAGTGAGGGAAATGAAAACTATTCCCTGACAGCTTCCGGATATACACTGAATAAGTCAATCGACGAACTGAAAGATACAGACTCCATCGTACTGACAGGTACAGAGGTAAAGACAGCTTCAGCCGGAGTGCTCAACGACTCAACAACAGGAAATAAAAAGTATGGTGTTGATCTTGAGTTGACAGATGAGGGTGCTGAGAAGTTCAAGACAGCAACAGAAGAAGCTTATAACAATAACCATGACACAATCGCTATTTACTATGATGGTTCTCTGATCAGCGTGCCAAGCGTAAATGCAGTGATTGAGAATGGAAAAGCTCAGATTTCAGGAAACATGGATTATGAAGAGGCTGATAACATCGCTTCTACAATCCGTATCGGTGGACTGAATCTGGAACTTGAAGAGCTTAGCTCAGAAGTTGTAGGAGCACAGCTTGGACAGGACGCTCTTAAAGGAAGTCTGATCGCAGGTATCATCGGTCTGGCAATCGTATGTGTATTCATGTGCTGGGTATACCTCCTTCCGGGACTTGCATCCAGCCTTGCACTGATCCTTTACACAGAATTGATCCTGATCCTTCTGAATGCATTTGACATTACACTGACACTTCCGGGTATCGCAGGTATCATCCTCGGTATCGGTATGGCGGTAGATGCGAACGTTATCATCTTCGCCCGTGTGAAAGAAGAGCTGACAGCAGGAAAGAGCGTACACGCTTCACTGAAATCAGGATTCCAGAAGGCAATGTCCGCAATCGTTGACGGAAATATCACAACACTGATCGCAGCCGGCGTGCTGTGGCTTCGCGGAAGCGGTACTGTAAAGGGATTCGCCCAGACACTTGCACTGGGTATCGTCGTATCCATGTTTACAGCACTCGTGATCACAAGACTGATCATCTTTGCATTCTATGGAGCAGGCATCCACAATGAGAAAGTATACGGAAGACATCTGAAAGAACGTAAACCGGTTGATTTCCTTGGAAAGAAAAAAATCTTCTTCGTTATTTCTATCATCCTTTGTCTGGCCGGACCGGTCATGATGGGTGTGAACCATGCAAGAGGAATCGGCGCAATGAATTACAGCCTTGATTTTGTAGGCGGTACTTCAACAAATGTAACATTTGATAAAGAATATACACTGGAAGAGATCGACAGCCAGATGATCCCAAGCCTGGAAGAGATCACAGGAGATAAGAATATTCAGGTTCAGACAGTAAAAGACAGCAATCAGGTAGTCTTCAAGACACAGACACTTGATCTTGAGAAACGTGAAGCACTTGCTTCTTATCTGAATGAGAACTACGGGGTAGAGGTATCTGATATCGCTACAGAGAATATCAGTTCAACAGTAAGTTCTGAGATGAGAAGAGACGCTGTTATAGCTGTGATCATTGCTACAATCTGTATGCTGCTTTACATCTGGTTCCGTTTCAAAGATATTCGTTTCGCAACAAGTGCTGTTGTCGCACTGATGCATGACGTACTTGTAGTTCTTGGATTCTATGTAATCGCAAGAGTATCTGTCGGAAATACATTTATTGCATGTATGCTGACAATCGTTGGATATTCTATCAACGGTACGATCGTTATCTTTGACCGTATCCGTGAGGCGCTGGCAACAAAGAGCCGTACAGAAGATCTGAAGGATCTTGTAAACCGCTGTATTACTCAGACACTGACAAGAACGATCTATACAAACTTTACAACATTTGTCATGGTCGTTGCTCTGTATATCCTTGGTGTAAGCTCCATTAAGGAATTCGCTGCACCTCTGATGGTAGGTATCATCTGCGGTGGATATACATCCGTATGCATCACAGGTGCTCTGTGGTATGTGATGAAGACAAGACTTGGTGAGGAAGCGAAGGCTGCGAGAGCAGCTTCTGGCACAAAGACAACTTCTGCAAAAGCAGCAGACAAGAAAGAAGGAACTACTTCCACAGAGAGTAACGCAGCAGATACATCTGCAGACGACAGCTCCAAGAAGAAAAAAGGAAAGAAGACTTCTTTCAAAAATAAAAAGAGCAAAAAGCGCTAA",
      "translation": "MKKGKSILSLILVIAVTALFGMTCVLGLDLKGMGAAKNINLGLDLEGGVSITYQVKGDKPSQADMDDTVYKLQKRVEQYSTEAQAYQVGDNRISIEIPGVSDANKILEELGQPGSLYFIKHKDSEGNENYSLTASGYTLNKSIDELKDTDSIVLTGTEVKTASAGVLNDSTTGNKKYGVDLELTDEGAEKFKTATEEAYNNNHDTIAIYYDGSLISVPSVNAVIENGKAQISGNMDYEEADNIASTIRIGGLNLELEELSSEVVGAQLGQDALKGSLIAGIIGLAIVCVFMCWVYLLPGLASSLALILYTELILILLNAFDITLTLPGIAGIILGIGMAVDANVIIFARVKEELTAGKSVHASLKSGFQKAMSAIVDGNITTLIAAGVLWLRGSGTVKGFAQTLALGIVVSMFTALVITRLIIFAFYGAGIHNEKVYGRHLKERKPVDFLGKKKIFFVISIILCLAGPVMMGVNHARGIGAMNYSLDFVGGTSTNVTFDKEYTLEEIDSQMIPSLEEITGDKNIQVQTVKDSNQVVFKTQTLDLEKREALASYLNENYGVEVSDIATENISSTVSSEMRRDAVIAVIIATICMLLYIWFRFKDIRFATSAVVALMHDVLVVLGFYVIARVSVGNTFIACMLTIVGYSINGTIVIFDRIREALATKSRTEDLKDLVNRCITQTLTRTIYTNFTTFVMVVALYILGVSSIKEFAAPLMVGIICGGYTSVCITGALWYVMKTRLGEEAKAARAASGTKTTSAKAADKKEGTTSTESNAADTSADDSSKKKKGKKTSFKNKKSKKR",
      "product": ""
     },
     {
      "start": 5508,
      "end": 7232,
      "strand": 1,
      "locus_tag": "ctg21_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,508 - 7,232,\n (total: 1725 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAATGGTTCGTCGCAATGAAAAAGGCGGATTTTAATGGAATAGCAGAGAAATATCAGATTTCCCCGATCATTGCGCGGCTGATGAGGAACCGTGATGTGGTCGGAGATGATGCAATTGATTTTTATCTGAATGGAACAGTGGAGAATCTGTATGACGGTTTACTGATGAAAGATATGGATCGTGCAGTAGATATTCTTAAGGAGAAAATAGAAGAGGGAAAGAAAATCCGTGTGATCGGTGATTATGATATTGATGGAGTCAATGCAACGTATATTTTGCAACAGGGGCTTGCAGGACTTGGGGCAGATGTCGATACGGATATTCCAGACAGGATCAAAGACGGATATGGATTGAATCAGATGCTGATCGACCGTGCACTGGATGATGATGTAGACACGATCATCACCTGTGATAATGGAATTGCGGCAATGAGTGAGATTGCTTACGGAAAAGAAAATGGGATGACGATCGTTGTGACAGATCACCATGAAGTTCCGTATCTGGAAGAAAATGGGGAGAAAAAGCATCTTCTGCCACCGGCGGATGCAGTGGTCGATCCGCACAGAGCAGACTGTGAGTATCCATTTAAAGGGCTGTGCGGCGCAGCTGTAGCGTATAAGCTGGTTGAGGTTTTGTACAGAGTGTCTGGAAAGTCAGAGCAGGAGGTAGAGCATCTGCAGGAAAGCCTGATGGAAAATGTTGCGATTGCCACGATCGGTGATGTGATGGATCTGGTTGGAGAGAATCGTGTCTTTGTGAAAAAGGGACTTGAGCTTCTGAAGACAACGAAGAATGAAGGGCTTCACGCATTGATGCAATGTACAGGGGTAGATACAGCGAACCTGAATACTTATCATATCGGATTTATGATCGGACCGTGCATCAATGCCGGCGGAAGACTGGATACAGCCAAGCGTGCACTAGAACTCCTTAATGCATCGAACCGGAGAGAGGCAGTGACACTGGCAGCAGATCTGAAAGAATTAAATGACAGCCGGAAAGAAATGACCGAAGAAGGTGTAGAAGAAGCTGTCCGGCAGATTGAATCAAGTTCCTGGAAGGACGACCAGGTGCTGGTCGTGTATCTTCCAGAGTGTCACGAAAGTATCGCCGGAATTATTGCGGGGAGGATCAAGGAACGTTATTATCGTCCGACCTTTGTACTGACAAAGGGAGAGACAGGAGTGAAAGGTTCCGGACGGTCGATCGAAGCCTATGATATGTTTGCGGAAATGAGCCGCTGCAGGGAATTATTTACGAAGTTCGGAGGACATAAGCTGGCAGCAGGACTTTCTTTAGAAGAGGAAAAGGTCGAAGTTTTCCGGAAACGGATCAATGAACTGGCGGATCTGACAGAAGAGGATCTGCAGATGAAGGTGTCGATCGATATGCGGCTTCCGTTTCCATATATTAATGAAGAGCTGATCCATGAGCTTAAGATATTGGAGCCTTTTGGAAAAGGCAATGGGAAACCGTTATTTGCAGAAAGTAAACTGCGTGTGATCCAGCCAAGAATCTTCGGAAAGAACCGGAATGTGCTGAAATGCAGACTGGAGGACCAGCAGGGAAATCAGATGGAAGCGGTTTATTTCGGAGAAGTGGAAGACTGTCTGCGGCAGATGGAAAAGAAGCAGATCATGTCTTTTACATACTATCCATCCATCAATGAGTACATGGGACGAAGAACAATTCAGCTTACAATTGTCAATTATCAGTAG",
      "translation": "MEKWFVAMKKADFNGIAEKYQISPIIARLMRNRDVVGDDAIDFYLNGTVENLYDGLLMKDMDRAVDILKEKIEEGKKIRVIGDYDIDGVNATYILQQGLAGLGADVDTDIPDRIKDGYGLNQMLIDRALDDDVDTIITCDNGIAAMSEIAYGKENGMTIVVTDHHEVPYLEENGEKKHLLPPADAVVDPHRADCEYPFKGLCGAAVAYKLVEVLYRVSGKSEQEVEHLQESLMENVAIATIGDVMDLVGENRVFVKKGLELLKTTKNEGLHALMQCTGVDTANLNTYHIGFMIGPCINAGGRLDTAKRALELLNASNRREAVTLAADLKELNDSRKEMTEEGVEEAVRQIESSSWKDDQVLVVYLPECHESIAGIIAGRIKERYYRPTFVLTKGETGVKGSGRSIEAYDMFAEMSRCRELFTKFGGHKLAAGLSLEEEKVEVFRKRINELADLTEEDLQMKVSIDMRLPFPYINEELIHELKILEPFGKGNGKPLFAESKLRVIQPRIFGKNRNVLKCRLEDQQGNQMEAVYFGEVEDCLRQMEKKQIMSFTYYPSINEYMGRRTIQLTIVNYQ",
      "product": ""
     },
     {
      "start": 7433,
      "end": 9754,
      "strand": 1,
      "locus_tag": "ctg21_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,433 - 9,754,\n (total: 2322 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGGGGAAGATGATATGGCAGGCACTCGGGAATATGAAGATCTGAATAAAAATCTGGAGATAGTGGACGGGCATGCAGTAAAAGCACCAGAGGATTATCAGGATCCGGAGGAGTTATATCAGGCCTTAATAGCTCGTGTGCGTAAGTATCACCCCTCTGCGGATATTACGATGATCGAGAAGGCCTATCAGATAGGCAAAGAAGCGCATAAGAATCAGTTCCGTAAATCCGGAGAACCTTATATCATCCATCCACTCTGGGTGGCAATCATACTTGCAGATCTCGAGATGGACAAAGAAACGATCGTGGCTGGAATGCTTCATGACGTGGTAGAAGATACGACAATGACACTCGATGAGATCTCAGCAGAGTTTGGTGAAGAGGTGGCACTTCTTGTAGACGGCGTTACCAAGCTGGGACAGTTGAACTATTCCAAGGACAAGCTGGAGGCCCAGGCAGAGAACCTGAGAAAGATGTTCCTTGCGATGGCGAAAGATATCCGTGTCATCATTGTAAAACTCGCAGACCGTCTGCATAATATGCGTACAATGGAGTTTATGACACCGGCCAAGCAGAAAGAGAAATCAAGAGAGACGATGGATATCTACGCTCCGATCGCTCAGCGTCTCGGTATTTCCAAGATCAAGACAGAACTCGATGACCTTTCTCTGAAATATTATCAGCCGGAAGTTTATAATCAGCTGGTTCATGATCTGAATGCACGTAAGACGGAACGTGAAGAATTTGTGCAACAGATCGTTGCTGAAGTATCAAAGCATATGAAGAATGCTGATATTGAAGCGAAAGTATACGGACGTGTAAAACATTTCTTCAGTATTTATAAGAAGATGGTGAATCAGAACAAGACACTTGATCAGGTGTATGACCTGTTCGCTGTCCGCATTATCGTAGATTCAGTGAAAGACTGTTACGCAGCACTTGGTGTGATCCATGAGATGTATACGCCGATTCCGGGACGTTTCAAGGATTATATTGCTATGCCGAAGGCGAATATGTACCAGTCTCTGCATACAACGCTGATTGGACCTTCCGGACAGCCGTTCGAGATCCAGATCCGTACAGAAGAGATGCATAAGACAGCGGAATATGGTATCGCAGCACACTGGAAATATAAAGAGACAGGCGGAAGCAACACGAAAGGACTGAACACACAGGAAGAGAAGTTGAACTGGCTGCGTCAGATCCTGGAATGGCAGAGAGACATGTCTGATAACCGTGAGTTCTTAAGCCTGCTGAAAGGTGACCTGGATCTGTTCCAGGAAGATGTATACTGCTTCACACCGAACGGGGATGTGAAGAACCTTCCGAATGGCTCCACACCGGTTGACTTCGCCTATGCGATCCACAGTGCAGTCGGCAATAAGATGGTTGGCGCCAGAGTGAATGGCAAGCTTGTGAACATTGATTATAAGATTCAGAACGGAGACAGAATCGAGATCCTTACATCTCAGAATTCCAAGGGACCGAGCCGTGACTGGCTGAATATCGTCAAGAGCACACAGGCAAAGAGTAAGATTAATTCATGGTTTAAGAAGGAATACAAAGAAGATAATATTATCCGCGGAAAGGATCTGATCAGTGCCTACTGTAAGAGCAAGGGCATCAATTTGCCGGATATCATCAAGCCGAAATATCAGCAGATCGTTCAGAAGAAATACGGATTCCGTGACTGGGATGCAGTACTTGCAGCAATCGGACACGGCGGACTCAAAGAAGGTCAGGTTGTGAACCGCCTGTTGGAAGAGTACGAGAAAGAGCATAAGAAAGAGATCACGGATGAGAATATTTTGGAGAAGATCTCAGAAGCGAATAAACAGAGAGTCCACATTGCCAAATCAAAGAGCGGAATCGTAGTTAAGGGAATCAATGATATGGCAGTACGCTTCTCAAAGTGCTGTAATCCGGTGCCGGGAGATGAGATTGTCGGTTTTGTAACAAGAGGGCGCGGAATGTCAATCCACAGAACAGATTGTATCAATATCATCAATCTTTCTGATGTGGAGAGATCCCGTCTGATCACAGCAGAATGGGAGGATAATGATCTCGAAGAAGGCGGTCAGTATCTTGCAGAACTGAAGATATTTGCAGACGACAGAAGAGGACTTCTGCTGGATGTATCAAAGGTATTTACCGAAGAGAAGATTGACGTGAAGTCCATGAATACCCGGACGAGCAAGAAGGGTACGGCAACAATGGAGATGGGATTTGTTGTACACGGAAGAGAAGAATTGAACCGTGTGATCGGAAAGCTCAGACAGATTGAAAATGTAATTGATATTGAGAGAACAACAGGCTGA",
      "translation": "MKGEDDMAGTREYEDLNKNLEIVDGHAVKAPEDYQDPEELYQALIARVRKYHPSADITMIEKAYQIGKEAHKNQFRKSGEPYIIHPLWVAIILADLEMDKETIVAGMLHDVVEDTTMTLDEISAEFGEEVALLVDGVTKLGQLNYSKDKLEAQAENLRKMFLAMAKDIRVIIVKLADRLHNMRTMEFMTPAKQKEKSRETMDIYAPIAQRLGISKIKTELDDLSLKYYQPEVYNQLVHDLNARKTEREEFVQQIVAEVSKHMKNADIEAKVYGRVKHFFSIYKKMVNQNKTLDQVYDLFAVRIIVDSVKDCYAALGVIHEMYTPIPGRFKDYIAMPKANMYQSLHTTLIGPSGQPFEIQIRTEEMHKTAEYGIAAHWKYKETGGSNTKGLNTQEEKLNWLRQILEWQRDMSDNREFLSLLKGDLDLFQEDVYCFTPNGDVKNLPNGSTPVDFAYAIHSAVGNKMVGARVNGKLVNIDYKIQNGDRIEILTSQNSKGPSRDWLNIVKSTQAKSKINSWFKKEYKEDNIIRGKDLISAYCKSKGINLPDIIKPKYQQIVQKKYGFRDWDAVLAAIGHGGLKEGQVVNRLLEEYEKEHKKEITDENILEKISEANKQRVHIAKSKSGIVVKGINDMAVRFSKCCNPVPGDEIVGFVTRGRGMSIHRTDCINIINLSDVERSRLITAEWEDNDLEEGGQYLAELKIFADDRRGLLLDVSKVFTEEKIDVKSMNTRTSKKGTATMEMGFVVHGREELNRVIGKLRQIENVIDIERTTG",
      "product": ""
     },
     {
      "start": 9768,
      "end": 10388,
      "strand": 1,
      "locus_tag": "ctg21_8",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,768 - 10,388,\n (total: 621 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1170:metallo-beta-lactamase family protein (Score: 162.1; E-value: 1.8e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGTTGAAAGTATTGTACTGGGGTCAATTGGAACGAATTGCTATATTGTAACCAATGAAGAGACGAAGGAATGTTTTGCAGTGGATATGGCAGAATGTCCGCAGGAATATGTCAATTATATCAAGAACAATGGACTAGAAATGAAAGCATTGTTTCTGACACATGGACATTTTGACCACATCATGGGAATCGATGATTTCCTCAAAGCCTTTCCTGTGCCGGTTTACGCAGGCGAAGATGAACTTCCGGTGATCGAGGATGACCGCCTGAATGTTTCTTGTATGTACGGACCGAAATACGCATTCCACGGAGCACAGCCTGTAAGAGACGGTCAGGTGATCGAATGCGCAGGAATTGAAGTTGATGTACTTCATACACCGGGACATACAGTAGGAGGATGCTGCTATTACCTACCAAAAGAACATAGATTGTTTAGTGGAGATACGCTGTTCTGTGCTTCCATCGGAAGAACAGACCTACCGACAGGAAGCAGCAGCCAGCTGGTCCGCTCTGTACAGGAGAAGATTATGACACTTCCGGATGATACAAAGATCTATCCGGGACATATGGAAGAGACATCAGTTCAGTTTGAGAAGGAGCATAATCCATTCATATGA",
      "translation": "MKVESIVLGSIGTNCYIVTNEETKECFAVDMAECPQEYVNYIKNNGLEMKALFLTHGHFDHIMGIDDFLKAFPVPVYAGEDELPVIEDDRLNVSCMYGPKYAFHGAQPVRDGQVIECAGIEVDVLHTPGHTVGGCCYYLPKEHRLFSGDTLFCASIGRTDLPTGSSSQLVRSVQEKIMTLPDDTKIYPGHMEETSVQFEKEHNPFI",
      "product": ""
     },
     {
      "start": 10652,
      "end": 11797,
      "strand": 1,
      "locus_tag": "ctg21_9",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,652 - 11,797,\n (total: 1146 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGACCGGAGTCCGTCCGACAAAGCTTGTAATGCAGAAAATCGAGCAGGGAATGACAAAAGAAGAAATCTTTGGATTTCTAAAAGAACAATATTGTGTTGGTGATAAAAAGGCACAGATTGCCTATGAAATTGCTTGCCGTGAAAAGGCACTTCTTGATCAGTTGGACTGTAAAAATGGCTATAGCCTGTATGCAGGAATTCCATTCTGTCCAAGCATCTGCTCCTACTGCTCATTCAGCTCTTCACCAATCGCTGAGTGGAAAGATCAGGTAGATCGTTACCTTGACGCAATGATCAAAGAATTGAAAGCTACAGCAAAGCTGATGCAGGGAAAGACGCTGGATACCGTATATATCGGCGGCGGAACACCGACAACACTCGAGGCAGATCAGCTTGACCGTCTGCTTGGAACAATCCGGAAGAATTTTGACCTGGAGCATGTGCTTGAGTTTACAGTTGAAGCCGGAAGACCGGACAGTATCACACGAGAAAAGCTCGAAGTGATCCGCAAATATCCTGTAACCCGCATCTCTGTCAACCCACAGACAATGCAGCAGAAGACACTGGATCTTGTCGGAAGAAAACATACGGTAGAAGATGTAGAACAAATCTTCAACCTCGCACGTGAGCTTGGATTCGATAATATCAATATGGATCTGATCGCCGGACTTCCGGGAGAAGATGCGGCAGATATGCAGGATACACTTGAGAAGATCGAGAAGCTTCACCCGGACAGCCTGACAGTACACGCACTCGCGATCAAACGTGCTGCGAAGTTCGGTCAGGAAGGAAGAACAATGGATCCGGGGACTGAGATCACACAGATGGTCGAGGCGGCAGCAGCGTCAGCAGAACGCATGGGACTTGTGCCATATTACCTGTATCGCCAGAAGAACATTGCCGGAAACTTCGAGAATGTTGGATATGCAGAGCAGGACAAGGCTGGGGTGTATAACATTTTGATCATGGAAGAGAAACAGGCCATCCTTGCTTGCGGGGCCGGAGCATCCACCAAACGTGTATGGAATCTACCAGACGGTTATCACATCGAAAGATGCGAGAATGTCAAGGATATCAAGCAATATATCGCTAGAATTGATGAGATGATTGAACGAAAAAAAGCACTTTTTGAGAAGGATTGA",
      "translation": "MLTGVRPTKLVMQKIEQGMTKEEIFGFLKEQYCVGDKKAQIAYEIACREKALLDQLDCKNGYSLYAGIPFCPSICSYCSFSSSPIAEWKDQVDRYLDAMIKELKATAKLMQGKTLDTVYIGGGTPTTLEADQLDRLLGTIRKNFDLEHVLEFTVEAGRPDSITREKLEVIRKYPVTRISVNPQTMQQKTLDLVGRKHTVEDVEQIFNLARELGFDNINMDLIAGLPGEDAADMQDTLEKIEKLHPDSLTVHALAIKRAAKFGQEGRTMDPGTEITQMVEAAAASAERMGLVPYYLYRQKNIAGNFENVGYAEQDKAGVYNILIMEEKQAILACGAGASTKRVWNLPDGYHIERCENVKDIKQYIARIDEMIERKKALFEKD",
      "product": ""
     },
     {
      "start": 12016,
      "end": 12246,
      "strand": 1,
      "locus_tag": "ctg21_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,016 - 12,246,\n (total: 231 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTACAGCGTTAGGAGGAAACAGCAGATGTTAAAGATACGATTAATGGGAACGAAAAGTGATATTAGATGGTTTCAAAATTTTTTACAGATTGATTCTGACATAGAGGTATTAGAATTATCAGATATCTATCCGAATAAAGGAACAGATAGATATTATAGATCATATGCAGAAGTAGAAAGAAAAGATGGCAACGCAGGCCGCCCAACAGAGAATGGAAAAAGCAAATAA",
      "translation": "MYSVRRKQQMLKIRLMGTKSDIRWFQNFLQIDSDIEVLELSDIYPNKGTDRYYRSYAEVERKDGNAGRPTENGKSK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 1047,
      "end": 2929,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 12929,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r21c1"
   }
  ]
 },
 {
  "length": 25177,
  "seq_id": "NZ_JANGDO010000029.1",
  "regions": []
 },
 {
  "length": 197335,
  "seq_id": "NZ_JANGDO010000003.1",
  "regions": []
 },
 {
  "length": 25153,
  "seq_id": "NZ_JANGDO010000030.1",
  "regions": []
 },
 {
  "length": 24117,
  "seq_id": "NZ_JANGDO010000031.1",
  "regions": []
 },
 {
  "length": 23469,
  "seq_id": "NZ_JANGDO010000032.1",
  "regions": []
 },
 {
  "length": 16318,
  "seq_id": "NZ_JANGDO010000033.1",
  "regions": [
   {
    "start": 1,
    "end": 16318,
    "idx": 1,
    "orfs": [
     {
      "start": 108,
      "end": 770,
      "strand": -1,
      "locus_tag": "ctg27_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 108 - 770,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGGTTAGTATTGATGAAACGAAAGTAAAAGAATGGATGAATGAATTTTGCTCTACATACGATTCCATTGGAAAAATACGTTCTATTACGACACCGACGGGAAAAACAGCAAGTGTTTCGGGAGGAACATATGGTTGGTCAGTCGACGAGCCAGAAGAAATCAGGAAATTGATTGAGAATATTAAAAGTGGTGAAAGAGTAGAAAGAGAACCGGTGTATGAAAAAACGGTAGCATCTCATTCGCAGCAGGATTGGGGAGATACATATGTTGAGGTAGATCTTTCAACGCAGCATATGTGGTATATTGTGAATGGTTCAGTACAATTAGAAACAGATATTGTTACAGGACTTGCAAGTGATCCGAACAGAGCGACTCCATCAGGGGTATATTCTATTCTTGAAATGAAAAGAGATAAAGTACTTACTGGAGAAACAAATCCAAGCACAGGAGAACCTATTTATAGAACGAAAGTTTCTTATTGGATGCGTGTTACATGGACGGGAATCGGATTTCATGATGCAATCTGGCAGTCGGCGTTTGGTGGAAACAGGTATCAGACTTCGGCAGGCTCGCATGGTTGTATTAATATGCCGTTGGATCAGGCAGCTTCTTTATATGATATGTTAGAGATGGGAACACCAGTAGTTATACACGAGTGA",
      "translation": "MEVSIDETKVKEWMNEFCSTYDSIGKIRSITTPTGKTASVSGGTYGWSVDEPEEIRKLIENIKSGERVEREPVYEKTVASHSQQDWGDTYVEVDLSTQHMWYIVNGSVQLETDIVTGLASDPNRATPSGVYSILEMKRDKVLTGETNPSTGEPIYRTKVSYWMRVTWTGIGFHDAIWQSAFGGNRYQTSAGSHGCINMPLDQAASLYDMLEMGTPVVIHE",
      "product": ""
     },
     {
      "start": 957,
      "end": 2627,
      "strand": -1,
      "locus_tag": "ctg27_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 957 - 2,627,\n (total: 1671 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAAACCCGAAAGAGAAAACCCGCGAGGAGCTGCAAGCCGAGATTGAGGACGGAAAGAAGAAAATCCGGCAGTTTGAAAACCGGGAAAAGATGTTGCGTCAGAAGTTATCCAAAGAAGAACGCAGAACGCGCAGCCACCGTCTTATCGTCCGGGGTGCAGTCTTTGAAAGCATTGTTCCGGAAGCAAAGAACATGACCGACGAGGAAGCCGCCCACCATAACGCCGTATTCGTAGGACGGGACGAGGACGGAGTACCACGCTACGCCCACCAACGCGGCACAGCCGGGAACTTCCGGCTTGATGTGAAAGGCAGCGACAAAGCCTTTAACTTCTGCTATCGGGGCGAGGGCGAAAGATTGTTTGTCTTTGAAGCCCCTATTGACCTCTTATCTTTTCTCTGTCTGTTCAAAAAGGACTGGCAAAAGCAAAGCTATCTTGCGCTGGGTGGCGTGGGAGATAAAGCCCTTATGTGCTTTCTCTCTGACCGCCCGAACATCAAGACCGTATATCTCTGCCTTGACAGCGACCAAGCCGGAAACGACGCTTGCAGCCGCCTTGTGGAGCTTATGCCGGAGGACTTGACCGTCCACCGCCTTATCCCTCTTTTCAAAGACTGGAACGAGGTGCAGACGCGCCGGAATGAAATCACAGACGGAAAATATCTGCGGGAAGCTGTCTATGGCTTGAAAGAACCGCCGCAGGAAGAAACCGTTGAGATTATCCGCATGAGCGAGGTTGACACACAGACCGTTGAATGGCTATGGAAACCGTATATCCCCTTTGGGAAAGTAACCATAGTACAGGGCAACCCCGGCGAGGGAAAGACCACCTTTGCGCTGCGCCTTGCCGTTGCCTGTAGTACTGGCGGGACGCTTCCGGGCATGAAGCCCATACAGCCGTTTCAAGTGATTTATCAGACCGCCGAGGACGGTTTGGGCGATACCGTCAAGCCCCGCTTGATAGAAGCCGCAGCAGACCTTGACCGGGTGCTTGTGATTGATGAAGCAAAACGGGAGCTTACCCTGTCCGACGAGCGCATAGAGAAAGCAATCATACAGAACGGGGCGCGTCTGATTATCCTTGACCCCATACAGGCGTATATGGGCGACAAAGCCGACATGAACAAGGCAAACGAGGTGCGCCCCATTTTTCGCCGCCTTGCCGAAGTTGCGGAGCGTACCGGGTGCGCCGTTATCCTTATCGGACACCTTAACAAAGCTGCCGGAGGACAGAGCGCATACAGGGGCTTAGGTTCTATCGACTTTAGAGCCGCAGCAAGGAGCGTCCTTTTAATCGGGCGCGTGAAGCGTGAGCCGAATGTGCGCGTTATCATTCACGACAAATCTTCCCTTGCGCCGGAGGGAAAGCCCGTTGCCTTTTGCCTTGACCCGGAAACAGGCTTTGAGTGGATAGGCGAATATGATATAACTGCCGACGAGCTGCTGTCCGGCGCGGGCGGCAACAACGCCACCAAAACCGAACAGGCTGAAAAGCTGATACTTGACCTACTGGCAGACGGAAAAGAATTTGCCAGCGAGGACATAGAGAAAGCCGCAGCCGACGCGGGGATTTCTGCCCGTACTGTCCGGGCGGCAAAGAAAAACCTTGACGGGCGCATTACTTCAAAGCGTATCGGCGCAGCATGGTATCACGCCCTAAAAAAGTGA",
      "translation": "MTNPKEKTREELQAEIEDGKKKIRQFENREKMLRQKLSKEERRTRSHRLIVRGAVFESIVPEAKNMTDEEAAHHNAVFVGRDEDGVPRYAHQRGTAGNFRLDVKGSDKAFNFCYRGEGERLFVFEAPIDLLSFLCLFKKDWQKQSYLALGGVGDKALMCFLSDRPNIKTVYLCLDSDQAGNDACSRLVELMPEDLTVHRLIPLFKDWNEVQTRRNEITDGKYLREAVYGLKEPPQEETVEIIRMSEVDTQTVEWLWKPYIPFGKVTIVQGNPGEGKTTFALRLAVACSTGGTLPGMKPIQPFQVIYQTAEDGLGDTVKPRLIEAAADLDRVLVIDEAKRELTLSDERIEKAIIQNGARLIILDPIQAYMGDKADMNKANEVRPIFRRLAEVAERTGCAVILIGHLNKAAGGQSAYRGLGSIDFRAAARSVLLIGRVKREPNVRVIIHDKSSLAPEGKPVAFCLDPETGFEWIGEYDITADELLSGAGGNNATKTEQAEKLILDLLADGKEFASEDIEKAAADAGISARTVRAAKKNLDGRITSKRIGAAWYHALKK",
      "product": ""
     },
     {
      "start": 2741,
      "end": 3763,
      "strand": -1,
      "locus_tag": "ctg27_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,741 - 3,763,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACGCAAAGAAGTTTTCCGACGCTATGGGCGAGCTTGACAATAAATACATTGACGAAGCCCTTAACTATAAGAAAAAGGTCAAGAAGCCCATTTGGATTAAATGGGGAGCTATGGTAGCTAGTTTACTTCTTGTCTTTACTATGTCTGTTCCAGCATTAGCGGCAGCAGATTTTGGACCAGCTTATAATCTACTCTACAAGGTATCGCCAGCAATTGCTCAAAAGTTAAAGCCTGTTAGTATGTCCTGCGAGGATAATGGGATTAAGTTTGAGGTCATTTCGGCTTATGTTGAGGGTAACGAAGCAAAGATTTTTATTTCCGTACAAGATATTGACGGAGATAGAATTGATGAAACGACAGATTTGTTTGATAACTTTAGTATCAATACACCTTTTGATTGTAGCAGTTCGTGTGAAAATATAAGCTATGACACCGAAACAAAAACCGCCACTTTCCTAATTTCTATATCACAATGGAATGAGAAAGACATTATTGGTGAAAAAATTACTTTTTGTGTCCGAGAAATGCTGAGCAATAAGCAGGAATATGACGCGATATTGACAAATTTGGATTTGATCCAAATTAGTGCTACACCAAAAACAATTACCCCGACTCAAATTTTTGGTGGTGGGGGAACAAACTACAATGAAATGAAAAACAATTTTCAGGCATTGAAAACAACAGGTATTCTTTGTTCCCCTATTGCTGGGGTAGATATTACAGCTATGGGATATGTGGATGGGAAATTGCATATACAAGTCAAGTACGAGGATAGTTTAGAAACGGATAATCATGGCTATATCTATTTCAAAAATGACAAGGGTGAGGAAATCCACTGTATCGCAAATATTGCATTTTCTACTGATAGTGAACATCAAGAACGGTATGTAGAATATGTTTATGATTTGTCAGATGTTGATTTGACCCAATATAAAGCATATGGATATTTTGTTACGAGCGATACACATATCGAAGGAAATTGGAGTGTTACTTTCCCATTAGAAAGCATAAGTCAATAA",
      "translation": "MNAKKFSDAMGELDNKYIDEALNYKKKVKKPIWIKWGAMVASLLLVFTMSVPALAAADFGPAYNLLYKVSPAIAQKLKPVSMSCEDNGIKFEVISAYVEGNEAKIFISVQDIDGDRIDETTDLFDNFSINTPFDCSSSCENISYDTETKTATFLISISQWNEKDIIGEKITFCVREMLSNKQEYDAILTNLDLIQISATPKTITPTQIFGGGGTNYNEMKNNFQALKTTGILCSPIAGVDITAMGYVDGKLHIQVKYEDSLETDNHGYIYFKNDKGEEIHCIANIAFSTDSEHQERYVEYVYDLSDVDLTQYKAYGYFVTSDTHIEGNWSVTFPLESISQ",
      "product": ""
     },
     {
      "start": 3760,
      "end": 4320,
      "strand": -1,
      "locus_tag": "ctg27_4",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,760 - 4,320,\n (total: 561 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 75.2; E-value: 8.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATAGAGGATGAAAAAATCATAGAAATGTTTTTTGAGCGTTCAGAACAAGGCATACGGGAGTTGGATATAAAATACGGAACAGTCTGCCACAAGCTTTCCTATCATATCGTAGGAAGTAGGCAGAACGCAGAGGAATGTGTAAACGACGCTTATTTAGGTGTATGGAACACTATTCCCCCTGCACGACCTAACCCACTTTTATCCTATGTTCTGAAAATCGTTCGGAACATTTCAATCAAAATTTATTGGAGAAAGGAAGCAGCCAAACGAAGCAGCCATTACACGATTGCTTTGGAGGAAATTGAAACCTATATAGCAGATACTCACACAGTAGAAGCAGAAATTGAAGCTAAAGAATTAGCCCGTATCATTGAAAGTTTTTTAGATACGCTGACTACTGAAAACCGCGTTATTTTCATGCGCCGCTATTGGTTTTCTGACAGCTACAAAGACATAGCCGAGGTTGTGGGGCTTTCAGAGAAAAATGTCTCTGTCCGGCTGACCCGTATCCGCGAAAAGATGAAACAATATTTAATTGAAAGAGAGGTATTTATATGA",
      "translation": "MIEDEKIIEMFFERSEQGIRELDIKYGTVCHKLSYHIVGSRQNAEECVNDAYLGVWNTIPPARPNPLLSYVLKIVRNISIKIYWRKEAAKRSSHYTIALEEIETYIADTHTVEAEIEAKELARIIESFLDTLTTENRVIFMRRYWFSDSYKDIAEVVGLSEKNVSVRLTRIREKMKQYLIEREVFI",
      "product": ""
     },
     {
      "start": 4404,
      "end": 4706,
      "strand": -1,
      "locus_tag": "ctg27_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,404 - 4,706,\n (total: 303 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGAACAGGGCTTACCAAACAGGAAAAGACCACTGATATATGGTTTGACGAGAAAGACCCCTTTATCCATATCCGCACCCACAACACCAACCTCAAAAAGCGGCTTGCCGCTTATGCCGAGCAGTACCCCGACGAGTGCTGCAAGACCGACACAGACCCCGAAACAGGCTGCATGGAGTTTGATATTGCAAAGGGGCGTTTCTCTTTCCGTCTGACCGCCCCATACAGTGAGGAACGCCGGAGAGCCGCCAGCGAAGCGGCGAAAGTTAACGCAAGCAATCTCACGCGAAGTGTGGTATAA",
      "translation": "MRTGLTKQEKTTDIWFDEKDPFIHIRTHNTNLKKRLAAYAEQYPDECCKTDTDPETGCMEFDIAKGRFSFRLTAPYSEERRRAASEAAKVNASNLTRSVV",
      "product": ""
     },
     {
      "start": 4841,
      "end": 5056,
      "strand": -1,
      "locus_tag": "ctg27_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,841 - 5,056,\n (total: 216 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGACAGAAAAGAAAGGAACACCCACCCCGCCGACCAAGCCGGACGGAATTATCACGACACAGAGGAACGGGCAGACCATTGTTGCGGAGCTGTTTTTCAATCCCAACGGCACAGAAACATTCTCCGACAAGCTGCTGAAAACGATACTTGCCGACAGTCTGCGTTTTTCTGCGTCTGACGGTCAAGAGCTGGAAAAAACAGAAATCTTGCGATAA",
      "translation": "MTEKKGTPTPPTKPDGIITTQRNGQTIVAELFFNPNGTETFSDKLLKTILADSLRFSASDGQELEKTEILR",
      "product": ""
     },
     {
      "start": 5136,
      "end": 6677,
      "strand": -1,
      "locus_tag": "ctg27_7",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,136 - 6,677,\n (total: 1542 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGCTGATAATTCGGCTGACACTTTTCAGGCCTAAGCCGTGGTTTTGTACATCCTCTATAGTATTGTTTTTTTGGGTGTGGGTAGTTGATAAGTTAAGTGCGGATACTTTATTAAATATATTAGTATTCTGTGCAATATTTAGTTTAGCATTATTTAGCCCTATAGATTCTGAAAGACGTCATTTAAATACAGATCAGAAAAAACAGTATAGAATTATAACAATATTCATAACGATAATATTTTGGGTGATATATGAATTATTGCTGTATATGGAATTTGAGGTATATGCAGTATGTATTGCGGAAGGAATTATGTTGACTGCAATATTACAGATTCCATGTGTAGTAAAAAAATATGAAAGAAATTTAACTTGTAAAAATAAGACGCTCAACGAGGATAACCGTTACAAGTGGAATAAAGCCACCTTGACCCATATCCTCACGCGGCAGGAGTATTGCGGCGATGTAGTCAATTTCAAGACTACAAAGCATTTCCGAGATAAGCGAAACCACTATGTAGACAGAAGCCAGTGGCACATCACAGAAAATGTGCATGAGCCGATTATTGACCGCACTGACTTTGAAAATGTGCAGCGGATTTTGGAAAACGCACCTGTCAAACGCCCCAACGGGGACGGAGAAATCCACCCTCTGTCCGGCTTGCTTTTCTGTAAAGACTGCGGTGCAAAAATGCACATTCGCATAGATTACAGGAACGGCGGCAAGCGCCATGTTGCCTATTGCAGCGAGTATCACAAGGGAAAAGACAAAAATCCCAAGTGCAGCTCTCCGCACATCATGGACGCGGATCTGCTCATGCAGACCGTCGCAGATGTGCTGAAAAAAATCGCGGAATACTCTATCAGCAACCGGGCAGAGTTTGAAGCCTTAGTGAAAAAGAGCCTTGCCATGCAGCAGACCGACAAGACAAAGAAACAGCAAAAGCGTATCCCGCAAATCACGACGCGCCTTGAACAGATTGACAAGGTGCTGAATAAACTTTATGAGGACAACGCGCTGGGTACTATCCCACAAGACCGCTATGAGCAGATGTCGCAGAAGTATTCCGAAGAATACTACTCACTGAAAGCGGAGCTTGAACAGCTTAGGGAGCAGCTATCCGCTTTTGAAAACGCGGGAGGACGGGCGCAGAAGTTTGTAAAGCTGATAGACCGTTACGCTGACTTTACCGACCTTACCCCGACTATCCTCAACGAGTTTATCAGCCGGATTGAAGTGCATGAGCGCGACAAGAAAAGGGCGAAACAGGCTATTCAGCATATCGGGATATACTTTAACCATATCGGCAGATTTGAAAATGAACTGACACAGCTTGCAGAGCCGACAGAGCAGGAAATCCGGCAAATGCGGGAGGAAATCGAAGAAGCAAGAAAGGAAAAGAGCCGCGCCTACCACCGCAACTATTCAAGAGAATACCGGGCGAGAAATCTTGAAAAGCAACGGGAGTATGACCGTATCAAAGCGCGGGAATATCGAGCGAAGAAAAAGGCGCAGGCTGCCGCCGCACTGTCCGCACCATAA",
      "translation": "MLIIRLTLFRPKPWFCTSSIVLFFWVWVVDKLSADTLLNILVFCAIFSLALFSPIDSERRHLNTDQKKQYRIITIFITIIFWVIYELLLYMEFEVYAVCIAEGIMLTAILQIPCVVKKYERNLTCKNKTLNEDNRYKWNKATLTHILTRQEYCGDVVNFKTTKHFRDKRNHYVDRSQWHITENVHEPIIDRTDFENVQRILENAPVKRPNGDGEIHPLSGLLFCKDCGAKMHIRIDYRNGGKRHVAYCSEYHKGKDKNPKCSSPHIMDADLLMQTVADVLKKIAEYSISNRAEFEALVKKSLAMQQTDKTKKQQKRIPQITTRLEQIDKVLNKLYEDNALGTIPQDRYEQMSQKYSEEYYSLKAELEQLREQLSAFENAGGRAQKFVKLIDRYADFTDLTPTILNEFISRIEVHERDKKRAKQAIQHIGIYFNHIGRFENELTQLAEPTEQEIRQMREEIEEARKEKSRAYHRNYSREYRARNLEKQREYDRIKAREYRAKKKAQAAAALSAP",
      "product": ""
     },
     {
      "start": 6962,
      "end": 7204,
      "strand": -1,
      "locus_tag": "ctg27_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,962 - 7,204,\n (total: 243 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAAGTAACAATTCCAAAGGAAAAAATGAATTATACAATAGACCTTCTTATCACTATGGTGACAGATGAGATTGCAGAAGAAACGGGCAAGGACAGAAAAGAGATATTGACAGATTTTCTTTGTTCAAAGACAGGAAAAGCACTGTATGATGAGAACACAAAGCTGTGGTGCAATGGTCCAGCATATATTGCTGAATTGTATAGGGAAGAGTTAAAGAAATCCGGATATCAGATTTGA",
      "translation": "MAEVTIPKEKMNYTIDLLITMVTDEIAEETGKDRKEILTDFLCSKTGKALYDENTKLWCNGPAYIAELYREELKKSGYQI",
      "product": ""
     },
     {
      "start": 7192,
      "end": 7758,
      "strand": -1,
      "locus_tag": "ctg27_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,192 - 7,758,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCTTGAGTTAAAAGATGGATTTGTTCTCTATCATGGAAGTTATTGTGAAGTAAAAGAGCCAGATCTTGCCAAATGTGCAAAGAGAAAAGATTTTGGGCAGGGATTTTATTTAACCACATCCAAGGAGCAGGCAGAAAGTTTTCTGAGAACCTCAATAGCCAAAGCAATCGCAACCGGAACAATTGAAGAAGGACAGAAGTTTGGATATATTTCAACTTTTGAATTCAACCTTTCAGGAAATCTTGAAACGCATATTTTTGAAAAGGCAGATGTAGACTGGTTACATTGCATTGCAGCTCATCGAAAGAAAAAAATGTTTATCGAAGTGGAACGTGAAATGGCAAGGTATGATATCATTGCAGGAAAGATTGCGGATGATGCAACAAACGCTACCCTTACCGCTTATCTCGCCGGGGCTTTCGGGACAGCAGGCGATAAGGAGGCAGACGATTTCTGCATCAGACAGTTGTTGCCCAATAAACTAAAAGATCAATATTGTTTTAAAACAGAAGCAGCTATTGAGTGTCTGAAATTTGTGAAAGGTGAGAAGATATGGCTGAAGTAA",
      "translation": "MLELKDGFVLYHGSYCEVKEPDLAKCAKRKDFGQGFYLTTSKEQAESFLRTSIAKAIATGTIEEGQKFGYISTFEFNLSGNLETHIFEKADVDWLHCIAAHRKKKMFIEVEREMARYDIIAGKIADDATNATLTAYLAGAFGTAGDKEADDFCIRQLLPNKLKDQYCFKTEAAIECLKFVKGEKIWLK",
      "product": ""
     },
     {
      "start": 7751,
      "end": 7975,
      "strand": -1,
      "locus_tag": "ctg27_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,751 - 7,975,\n (total: 225 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAAAAAACAGAGATTACTTTCATGCAAACAAGACTAATCCGGCTTGCTTCAGAAGAGTGGCATTTATCTGTTGAACAGATTATCTACTTGTTTAAAGAAGCTGATGTTTTTGGATATATAGAAAAATGCTATGGGATTTTTCATTGTGAGGGTGATGAAGCTGTGCTTGAAGACATTACAGAATTTCTGGAAGGAAAGGGGATAAAGATTAGTGCTTGA",
      "translation": "MSEKTEITFMQTRLIRLASEEWHLSVEQIIYLFKEADVFGYIEKCYGIFHCEGDEAVLEDITEFLEGKGIKISA",
      "product": ""
     },
     {
      "start": 8000,
      "end": 8173,
      "strand": -1,
      "locus_tag": "ctg27_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,000 - 8,173,\n (total: 174 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGATATAAAAAATGAAGAATATGTTACATGCCCTCGCTGCGAGAAAGAAGTCTATAAGGATGCAATAACTTGTCCGTTTTGTAACTTTGGTATTATGGCATGGCTTGAAGGAGAGATTAATGAGAATGGAGAGTCAGTGAAAAAGAGTTCTAAGCAAAAATTTTATTGA",
      "translation": "MQDIKNEEYVTCPRCEKEVYKDAITCPFCNFGIMAWLEGEINENGESVKKSSKQKFY",
      "product": ""
     },
     {
      "start": 8221,
      "end": 8598,
      "strand": -1,
      "locus_tag": "ctg27_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,221 - 8,598,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGTTTTGGATTTTTATGTTGATTATGGATTTGCTTCTTCCATTTACGATGATTGGTTTTGGAAGATATTTTATGAAAAAGGCTCCAAAGGAAATAAATTCAGTTTTTGGATATCGGACTTCGATGTCTATGAAGAATAAAGACACATGGGAATTTGCTCATAAATATTGTGGTAAAGTCTGGTATGTCTGTGGAATGGTTATGTTGCCGATAACAGTAATATTCATGCTTTTAGTAATTGGAAAAAATGAAGATTGTGTTGGGAGTATGGGAGGTATTATCTGTGGTGTTCAACTTATTCCTTTAATTGGGTCTATTCTCCCAACAGAAATAGCATTAAAAAAGAATTTTGATAAGAATGGAACAAGACGATAA",
      "translation": "MGFWIFMLIMDLLLPFTMIGFGRYFMKKAPKEINSVFGYRTSMSMKNKDTWEFAHKYCGKVWYVCGMVMLPITVIFMLLVIGKNEDCVGSMGGIICGVQLIPLIGSILPTEIALKKNFDKNGTRR",
      "product": ""
     },
     {
      "start": 8629,
      "end": 9261,
      "strand": -1,
      "locus_tag": "ctg27_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,629 - 9,261,\n (total: 633 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCTTTTGATTTTAAGAAAGAATATAAAGAGTTTTATATGCCTAAAAATACACCAGCGATTCTAACAGTTCCTAAAGCAAATTATATTGCAGTCAGAGGAAAAGGTAATCCAAACGAAGAAGGCGGGGCATATCAGCAGGCAATTAGTGCATTATATGCGGTTGCGTATACTTTGAGAATGAGTTACAAGACAGATCATAAAATTGAAGGATTTTTTGAATATGTAGTTCCACCACTTGAAGGATTCTGGTGGCAGGAAAATATACATGGTGTAAATTATGCAGATAAAGATTCATTTAATTGGATTTCAGTTATCCGCCTGCCTGATTTTGTGAATCAAAAAGATTTTGAATGGGCTGTTGAAACAGCAGCTAAAAAGAAAAAAATAGATTGTTCATCGGCAGAGTTTTTGACCATTGATGAGGGATTGTGTGTTCAAATAATGCACTTGGGGGCATTTGATGATGAACCTGCAACTGTTGCACTTATGGATGCTTATTTGGAGCAGAATGGATATGTTAATGATATGAATATGGAAAGATTGCATCATGAAATATATCTGTCTGATGCAAGAAAGGTTGTTCCAGAAAAATGGAAAACGGTCATTAGACATCCTATAAAGAAACTGTAA",
      "translation": "MAFDFKKEYKEFYMPKNTPAILTVPKANYIAVRGKGNPNEEGGAYQQAISALYAVAYTLRMSYKTDHKIEGFFEYVVPPLEGFWWQENIHGVNYADKDSFNWISVIRLPDFVNQKDFEWAVETAAKKKKIDCSSAEFLTIDEGLCVQIMHLGAFDDEPATVALMDAYLEQNGYVNDMNMERLHHEIYLSDARKVVPEKWKTVIRHPIKKL",
      "product": ""
     },
     {
      "start": 9287,
      "end": 9625,
      "strand": -1,
      "locus_tag": "ctg27_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,287 - 9,625,\n (total: 339 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAAAATATTAATATTGTTGCTATGTCTTTTACTTACGGCCTCAATCACGGGTTGTGGTACACAGTCAATAAAGCCGATTGACACAATTGAAGGAAACATGAAAACATACAGTGAAATGTCAGACGGTACATGGCAGTGCGATGGACATATCTACAAATACAGGTTGGAAATCAGTGGACGACTGAGTAATGCCGTTAAGGACAGCACATACATTTATTTAAGCAACATAGAAGATATTACCTTCGAACAAGCTTGGAAAGCATCTGGGCTTAGCAGTAATATGGATGATTACTTTGATATTGACGAAGCAGTATTGGTTGAATTACCAGACTGA",
      "translation": "MKKILILLLCLLLTASITGCGTQSIKPIDTIEGNMKTYSEMSDGTWQCDGHIYKYRLEISGRLSNAVKDSTYIYLSNIEDITFEQAWKASGLSSNMDDYFDIDEAVLVELPD",
      "product": ""
     },
     {
      "start": 9702,
      "end": 10034,
      "strand": -1,
      "locus_tag": "ctg27_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,702 - 10,034,\n (total: 333 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTAGCAGATTTAGCAACAGGCTCTGATTGGATAGTGTGGATTGTCTTTGCGATATTTGCTGTACTTTCTATTATTTTACTTTCTGGACATGGAAGCTGGTTCATTTCTGGATATAATACAGCTTCAAATGAAGAAAAGGAAAAATATGATGAAAAGAAGTTATGCAGAACAATGGGAATTGGAATGTCTATTATAGCAATTCTTGCATTAACTATGGGCTTGTTTGAAAATATTTTGCCTGCATTTTTTGTATATATTGCATTGGGGATTATTTTGGTTGATGTCGTGGTAATTATCATTTTAGGAAACACACTATGCAGAAAGTAA",
      "translation": "MKLADLATGSDWIVWIVFAIFAVLSIILLSGHGSWFISGYNTASNEEKEKYDEKKLCRTMGIGMSIIAILALTMGLFENILPAFFVYIALGIILVDVVVIIILGNTLCRK",
      "product": ""
     },
     {
      "start": 10084,
      "end": 10302,
      "strand": -1,
      "locus_tag": "ctg27_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,084 - 10,302,\n (total: 219 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATGTCCATATTGTGGTGAAGAAATGATAAGAGGATACCTAATGAGCTCACGAGATATTGCTTTTGCAGTTGATGATGTGACAAAAGTAAAATTTTTTCGTATTAGAAAATCGGATGATTTGGAGTTGAGTAAAGGTTCAGGCGGAATCCCTCATTGTGAAGCTTATCGTTGCAGTAGTTGCAAAAAGATTTTGATTGATTATGCAAATAGATAA",
      "translation": "MKCPYCGEEMIRGYLMSSRDIAFAVDDVTKVKFFRIRKSDDLELSKGSGGIPHCEAYRCSSCKKILIDYANR",
      "product": ""
     },
     {
      "start": 10382,
      "end": 10564,
      "strand": -1,
      "locus_tag": "ctg27_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,382 - 10,564,\n (total: 183 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGGAGGATACAATCACAAATCGAATGCTGCACTGGTCATATACGCCGGAGCAGAAAGAGGAAGTGAAGAAGGCACTTGCGGCAGGAGTTCCGAAGGCAACGATTCTGACTTATTTCTATCCGGAGGTTACTGTGGAGAGGATGAGTTCATATCGGAAGAAGCAGTAAATGTTATCGCATAG",
      "translation": "MGGYNHKSNAALVIYAGAERGSEEGTCGRSSEGNDSDLFLSGGYCGEDEFISEEAVNVIA",
      "product": ""
     },
     {
      "start": 11106,
      "end": 13571,
      "strand": -1,
      "locus_tag": "ctg27_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,106 - 13,571,\n (total: 2466 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAACAGTAACAAAAACAGCGCTTGCCAATGTAAAACAGAACAAAGGAAGAAACTTTTTATGTGGATGCGCCATTGCACTGACTACGTTTCTGATATTTGTTGTTTTAACGGTGGGATATGGAATGATCCGCGTACAGCTTGCATCGGTGGATGCTTATTATCCAACTTACCATATTATGTTCCGCCAAGTTTCCGAGAAAAACACCAAAGCACTTCAGGTGCATAATGATATAGAAGAAATTGGTCTGAGAATGGATTTGGGACAGATTATAGATGATGATGCCACAATCATTATGACCGCTATGGATAATAATGGGATTCGGTTGAACAAAGCGGAGTTAGAAGAAGGAACTTTCCCAAAAAATGAAAAAGATATTGTTGTTTCCAAGGGAGTTTTAGAGGAACTGGGAATTCAGGGGAAATTGGGTGATGAAATCACGATTCCATACCAAATTTACGAAAAAGACGGTATGGGATATGCGAAAGAAGACACTTTCCGCATCTGTGGCTTTATGGAATCTTCTGATTTGAATAAAGAAAAGAAAATGTATTTTGTGATGAATTCCATGGAATATGCGAAACAGATGATACCGGAAGCAGACAGAGAATATCGTGTGATGTTCCGTCTGGCAGATGCAGAGCATATGACAACAGATGAAATCGAAGAGAGGGGAAAAGAAATCGGAGAGGATTTTGGTGTACCTGAGGGAAATGTGGTAGAAAACAGAGAGTATTTGGTTGCAAATTATACGGATCCGTCATTTGTAAAAGGAATGATCGTGGTAATCGTTATGGTTGTTTTAGCAGGAATCCTGACTATTTACAGTATTTATTATGTGTCTATGATACCAAAAGTACAGGAATATGGAAAATTAAAAGCCATAGGCTCCACCAAAAGACAGATTCGGCAGATGGTATTCCGTGAAGGAATGCTGGTTACGGCGCTTGCCCTCCCTGTAGGATTGCTTATCAGTAGTTTCCTGTCCAGATGGATTATGAAACAGATGATTACTTTTATGGCAGGCGAAGACCCTCTAATGCAGGTAGCAGCAGAACTTGTAAAAAATGGTGAGGTATCTTTGCTGCACTGGTGGATTTATGCGATTACCATTATGGCGGTACTCTTTACTTCCGCAGTTTCTTTGGCAAAACCGATGCGAATTGCTGCCAAAGTTTCGCCCATTGAGGCTATGCGTTATCAGGGGTTAGAAAAACGTGGGAAAAAAGTACGGAAAGGCTATCAGAATCTCACGATTTTTCGTTTGACAAAAGCAAATATGGCAAGAAATAAAAAGAGGACTGGGATTACGATTGTTACATTAGGAGCAACTGGTATTCTGTTCATGGTTGTGGCAACTATTTTATCTTGCGCGGCACCGAAAGAAATTGCAAGAAAGGATATTGAATCTGATTATAAAATTGAATTGGAAACATGGGGTGGGGACAAAATGAATCCGGACAGAGACTGGAGACAGGTTCAGCAGAATAACCCTTTGACGAAAGCGTTTATTGATCAGGTTCGTGATGTAGACGGTGTGGAAGAGGTAAAGGTAAAAACATTTATGAATGGCGAAATTCCGAAACTATCTATGGATGGTGAAATTTGGGGCGCGGATATTATTGGACTGGATGCATCTTATGCAGAAACGCTGGAAAAAGGAGAGATACAAGGACATGTGACATATGAAGAATTGGAAAAAGGAGATAAAATCCTCATGTCTGCTAATATGCTATACTGGTTCCCGGAACTGAAAGTGGGAGATTCCTTGAAGATGGTTTTGAATATGGGAGATGATCAGGTAGAAAAGACTTTTGAGATAGGAGCCATCGGAGATTACTATGAAAGCCTTGGCGGAAGTTCATTTTATCTGCCCCAATCAGTGTTGGAAAAAATGAATCCCAATAATCTGAACTACACACTGGAAATCACAGTGAATGATCAGAAAAAGAACAGTGCATATCAGGAACTTCAGGCACTTGCCGACAACAGTGAATACCTGGTGACAGGAAGTTATGAAGAGCAACTTCAGAAGTGGGAAAAGAATATGCGGTTGATGAGCGTTTTGTGTTATGCATTTCTGATTATTCTGGGTGGAATTGGAATCATGAATCTTGTGAACACTATGATGAACAGTATTTACACAAGAAGGCGGGAGCTTGGAATGATACAGGCGATAGGAATGTCTGAAAAACAGTTGATCCGTATGCTGCAACTGGAAGGAATCATCTATACTTTGGGAACATTGGCAGTTTCTGTGGGCATTGGAAGTCTTGTAGGATATGGTGCATTTCTTTATGCAAAAACCAAACACATGTTTCAGATCAGTGAGTATCATTTTCCAGTGGTCCCAGCAGTGCTTTTGATTTGTGTGGTTGCCTTTTTACAGGTACTGCTCACATATGGAGTATCTGCAAATTTCCGAAAATTGAGTTTGATTGATCGGATACGATATGCAGAGTAA",
      "translation": "MKTVTKTALANVKQNKGRNFLCGCAIALTTFLIFVVLTVGYGMIRVQLASVDAYYPTYHIMFRQVSEKNTKALQVHNDIEEIGLRMDLGQIIDDDATIIMTAMDNNGIRLNKAELEEGTFPKNEKDIVVSKGVLEELGIQGKLGDEITIPYQIYEKDGMGYAKEDTFRICGFMESSDLNKEKKMYFVMNSMEYAKQMIPEADREYRVMFRLADAEHMTTDEIEERGKEIGEDFGVPEGNVVENREYLVANYTDPSFVKGMIVVIVMVVLAGILTIYSIYYVSMIPKVQEYGKLKAIGSTKRQIRQMVFREGMLVTALALPVGLLISSFLSRWIMKQMITFMAGEDPLMQVAAELVKNGEVSLLHWWIYAITIMAVLFTSAVSLAKPMRIAAKVSPIEAMRYQGLEKRGKKVRKGYQNLTIFRLTKANMARNKKRTGITIVTLGATGILFMVVATILSCAAPKEIARKDIESDYKIELETWGGDKMNPDRDWRQVQQNNPLTKAFIDQVRDVDGVEEVKVKTFMNGEIPKLSMDGEIWGADIIGLDASYAETLEKGEIQGHVTYEELEKGDKILMSANMLYWFPELKVGDSLKMVLNMGDDQVEKTFEIGAIGDYYESLGGSSFYLPQSVLEKMNPNNLNYTLEITVNDQKKNSAYQELQALADNSEYLVTGSYEEQLQKWEKNMRLMSVLCYAFLIILGGIGIMNLVNTMMNSIYTRRRELGMIQAIGMSEKQLIRMLQLEGIIYTLGTLAVSVGIGSLVGYGAFLYAKTKHMFQISEYHFPVVPAVLLICVVAFLQVLLTYGVSANFRKLSLIDRIRYAE",
      "product": ""
     },
     {
      "start": 13568,
      "end": 14239,
      "strand": -1,
      "locus_tag": "ctg27_19",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,568 - 14,239,\n (total: 672 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 213.5; E-value: 5.4e-65)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKAILETRDLVKYYGKGDNLVKAIDHTDLIIEPGEFTAIVGRSGSGKSTLLHMLGGLDRPDSGKVLIEGRDIFKLKDEKLAVFRRRKIGFIFQSYNLVPSLNVWENIVLPIGLDGKKVDTEYVMDIICRIGMEDKLKSLPNTLSGGQQQRVAIARALASRPAIILADEPTGNLDSKTELEVISMLKSCVSEYGQTLVMITHDETIAQMADRMIVIEDGKVVRA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGCAATATTAGAAACAAGAGATCTTGTGAAATATTATGGAAAAGGCGATAATTTGGTGAAAGCTATTGACCATACAGATTTAATAATCGAACCAGGTGAATTTACAGCAATTGTAGGACGTTCTGGATCGGGAAAAAGTACTCTTCTTCATATGCTGGGAGGATTGGACCGTCCTGATTCCGGAAAGGTTTTGATAGAAGGAAGAGATATTTTTAAACTGAAAGATGAAAAACTTGCAGTGTTCCGCAGAAGAAAGATTGGGTTTATTTTCCAAAGTTATAATTTAGTACCATCCTTAAATGTTTGGGAAAATATTGTGCTACCCATTGGATTGGATGGAAAGAAAGTGGATACAGAGTATGTTATGGATATTATCTGTAGAATCGGAATGGAGGATAAATTGAAATCCTTACCGAATACTCTTTCTGGTGGGCAACAGCAGCGGGTTGCTATTGCAAGAGCGTTGGCATCCCGCCCGGCGATTATTTTAGCAGATGAACCAACAGGAAATTTGGATTCCAAGACGGAGTTAGAAGTGATTTCTATGTTGAAATCCTGTGTTTCAGAATATGGGCAGACACTGGTTATGATCACGCATGATGAGACCATTGCGCAGATGGCTGACCGTATGATTGTCATTGAAGACGGTAAGGTGGTGAGAGCATGA",
      "translation": "MKAILETRDLVKYYGKGDNLVKAIDHTDLIIEPGEFTAIVGRSGSGKSTLLHMLGGLDRPDSGKVLIEGRDIFKLKDEKLAVFRRRKIGFIFQSYNLVPSLNVWENIVLPIGLDGKKVDTEYVMDIICRIGMEDKLKSLPNTLSGGQQQRVAIARALASRPAIILADEPTGNLDSKTELEVISMLKSCVSEYGQTLVMITHDETIAQMADRMIVIEDGKVVRA",
      "product": ""
     },
     {
      "start": 14348,
      "end": 15484,
      "strand": -1,
      "locus_tag": "ctg27_20",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,348 - 15,484,\n (total: 1137 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1003:sensor histidine kinase (Score: 133.2; E-value: 2.7e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCGAAGAAAGCGTACAGGAGTAGCTCTGGCAGCAGGGCTGCTTTTTCTGTTTGTGACAGAGATATTGTTGCTGTTTCTGGCAGGAAATAGTTTATACAAGGAAGAGCAGGGGAAATTAGGGGCGTTAGTGCTGTCCCATCCGGAACAGGAGACGGAGTATATAGAGTTATTTGACAGAGGAAAGCAAAGAAATCGTCAGGAAGAGGAAGCGGGGAAAGAGCTGGAGGAGCGTTACGGGTATACTCCTTTTGATGGGAGAAGCGTGAAAACTTTTGCTGCATATGGAATAGGAATGGCGATGGTTTTTGTGGCAGGACTTGGAGTTTCATGGGTTTTGTTTTTGCGAAATAAAAGAGACCGGCAGCAAGATGAAAATAACCAGGAAGAACTTCGGGAAAAATATATAGAACTGCAGAATCATTTTGAAAAAGTAAGAGAAAAACTTTCCAGAGAAGAAAACAATACAAAATCTTTAATTACAGATATTTCCCACCAATTGAAAACACCGATTGCTTCATTGAAGATGAGTTGTGAACTGGCGGGGTCTGCCGATTTAACCTGGGAGGAACGGGAAGAATTTTATAAAAAGGAATGGGATGAAATTCAAAGACTGGAAAATCTTTTGGATTCACTGATTCATGTGTCCAGATTGGAATCTGGGATGATTCAGATTCAGCCAGAGATGGGCAGTCTGAAAAATACATTGGTACAGGCTGTAAACAGTGTGTATATGAAAGCGTATGAAAAATCCATAGATATTTCTCTGGATGAATTTCAGGATGTGCAAATTGTACATGACTCGAAATGGACAGGAGAAGTGTTCGTAAATATTTTAGACAACGCAGTAAAGTATTCGCCGGAGCATACAGAAATCCGAATTCGGGTAACAGAGCTTGCTACCTGCATGATGCTGGAATTTATCGACCAGGGAACAGGTATTCCGGCAGAAGAGGCGCATCGGGTATTTCAGCGTTTTTACAGAGGAAACCAAGAGTATGTAAAAAAACAGGAGGGCTCTGGGGTTGGACTTTATCTTGCCAGAAAAATTTTGGAGGAGCAGAAAGGCACGATTTGTGTAAAAGTAGCACCTGAAGGCGGTAATAATTTTGTGGTGACATTACCAAAGAAATAG",
      "translation": "MDRRKRTGVALAAGLLFLFVTEILLLFLAGNSLYKEEQGKLGALVLSHPEQETEYIELFDRGKQRNRQEEEAGKELEERYGYTPFDGRSVKTFAAYGIGMAMVFVAGLGVSWVLFLRNKRDRQQDENNQEELREKYIELQNHFEKVREKLSREENNTKSLITDISHQLKTPIASLKMSCELAGSADLTWEEREEFYKKEWDEIQRLENLLDSLIHVSRLESGMIQIQPEMGSLKNTLVQAVNSVYMKAYEKSIDISLDEFQDVQIVHDSKWTGEVFVNILDNAVKYSPEHTEIRIRVTELATCMMLEFIDQGTGIPAEEAHRVFQRFYRGNQEYVKKQEGSGVGLYLARKILEEQKGTICVKVAPEGGNNFVVTLPKK",
      "product": ""
     },
     {
      "start": 15457,
      "end": 16134,
      "strand": -1,
      "locus_tag": "ctg27_21",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,457 - 16,134,\n (total: 678 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 154.6; E-value: 5e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTTATTGGAAGATGATGAGAATCTGAACCGTGGAATCGCGCTAAAACTGCAGAAAGAAGGGTATCAGGTTTTTTCCGCTTTTCAGATTTCAGAGGCAGAAAAATTGTTTGATGAAAATAGAATAGATCTGGTAATCAGTGATATTACTCTGCCGGACGGAAACGGACTGGAGTTTTGCAGGAAGATTCGAAATAAGAGCAAAGTCTTTGTACTGTTTCTCACGGCAATGGATTCGGAAATTGATATGGTAAACGGCTATGATGCAGGGGCGGATGATTATATTACAAAGCCATTCAGCCTGATGGTACTGGTTTCAAAAGTTCAGGCATTTATGAGAAGAATGGAAGGAGTCTGCGGACACAACAGAATCTTATCGGGAAATATCGAAGTAAATTATGGAGAAATGAGAGCGTTAAAACGAAATGCTGATGGAGTGACTCCTTTGACATTAAGTAAAAAGGAACTTCAGATAATGATTTACTTTATGGAAAACGCAAGGCAGATTTTATCAAAAGAACAGATTTTAGAGTATGTCTGGGATGTTGACGGGCAGTTTGTAGACGATAATACAGTTCCTGTAAATATCAGCCGATTGAAAGGAAAAATCGGGAATGATTATATACAAAATGTAAGGGGGATGGGATATATATGGACCGAAGAAAGCGTACAGGAGTAG",
      "translation": "MLLEDDENLNRGIALKLQKEGYQVFSAFQISEAEKLFDENRIDLVISDITLPDGNGLEFCRKIRNKSKVFVLFLTAMDSEIDMVNGYDAGADDYITKPFSLMVLVSKVQAFMRRMEGVCGHNRILSGNIEVNYGEMRALKRNADGVTPLTLSKKELQIMIYFMENARQILSKEQILEYVWDVDGQFVDDNTVPVNISRLKGKIGNDYIQNVRGMGYIWTEESVQE",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 5135,
      "end": 6677,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 16318,
      "product": "cyclic-lactone-autoinducer",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "cyclic-lactone-autoinducer",
    "products": [
     "cyclic-lactone-autoinducer"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP cyclic-lactone-autoinducer",
    "anchor": "r27c1"
   }
  ]
 },
 {
  "length": 13179,
  "seq_id": "NZ_JANGDO010000034.1",
  "regions": [
   {
    "start": 728,
    "end": 13179,
    "idx": 1,
    "orfs": [
     {
      "start": 1754,
      "end": 2416,
      "strand": -1,
      "locus_tag": "ctg28_3",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,754 - 2,416,\n (total: 663 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 182.1; E-value: 1.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAAAATACTGGCAGTTGATGATGAACCGGCAATTTTGGAAATGATAGAAAGCATTTTGAATAAGGATGGACATCTGGTTACCAAAGTAAGTAATCCACTAAAAATTAATATGGAAGAATTACATCGTTATGACCTGATTTTACTTGACATTATGATGCCTGGAATGGACGGCTTTGAATTATGCAAAAGAATCAGGGCACTTGTGGATTGTCCGATTTTGTTTCTTACCGCAAAAACGGAGGAAAACAGTCTGGTAAACGGACTTTCTTTAGGAGCAGATGATTATATTTCAAAGCCATTTGGAGTGATGGAACTTTGGGCAAGGATCAATGCACATCTTAGAAGAGAGCACAGGGAACATTCTGTCCGGATGGTTTTGGGGAGGGTCTGTATTCAAATATCTCAAAAGAAACTATTGGTTGATGATAAGGAACTTCCTCTTACGAAAGCGGAGTACGAAATCTGTGAATTTCTGGCTAAAAACAGAGGACAGGTTTTCTCGAAGGAACAGATATTGGAAGCGGTCTTTGGCTTTGACAATGAGAGTAATGACAGTACTATAATCACGCATATCAAAAATATAAGAGCAAAATTTGCGGATTATGATTATACACCGATAAAAACAGTCTGGGGGATTGGATATAAATGGGAAGAGTAA",
      "translation": "MAKILAVDDEPAILEMIESILNKDGHLVTKVSNPLKINMEELHRYDLILLDIMMPGMDGFELCKRIRALVDCPILFLTAKTEENSLVNGLSLGADDYISKPFGVMELWARINAHLRREHREHSVRMVLGRVCIQISQKKLLVDDKELPLTKAEYEICEFLAKNRGQVFSKEQILEAVFGFDNESNDSTIITHIKNIRAKFADYDYTPIKTVWGIGYKWEE",
      "product": ""
     },
     {
      "start": 2431,
      "end": 3171,
      "strand": -1,
      "locus_tag": "ctg28_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,431 - 3,171,\n (total: 741 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTGGAAGATCTCTTAATGCAGACTTGCGAAAGATGAAAGGAACATCTGTGATTCTGGCACACTTACTGATTCCGATTATAACCAGCGTTATATTTTTAATATATTACTTTTTTTCACCATGGAATGAAAATATGAAAGTGATTGCATTTTATCAGGCAATAGGAGCAGGACTTCCGGTACTTATTGGAATTTTTACAGCAAGTGTGATGGAACAGGAACAAAATGCAGGTGATTTTCAAAATCTGTTGTCTTTACCGGATAAACCTGCAGCATTTTTATCGAAACTGTTGATGCTACTGTTTTTGTGTCTGTGCTCTATCCTATTGACAGCAATCATATTCGGAATTGGATTTGGAAGAATCGCATCAAGCGATATCGAAATCATGAAAGGATGTATATTTGCAGCATTGCTGCTGTGGGGAAGCAGTGTTCCACTTTATCTGTGGCAGCTGATTCTGGCTTTTCAGTTTGGAAAAGGGGTATCCATTGGAGCAGGGATTATATCAGGACTAATTAGTGCATTGATGCTTACCGGACTTGGAGATTATGTGTGGAAATATGTATTTGTCTGCTGGACGGGTAGAGTACCATATACTTATCTGCAATCTGTATTGGGAGAAACTAGTGTAGGTGAATGGTTGTCATTCATACCAGGTTGCTTAATATTTACAGGGATTAGTATGGTATACTATTTTTGGTGGGTAAACCACTGGGAAGGAAACAGAATATCGGAATAG",
      "translation": "MIGRSLNADLRKMKGTSVILAHLLIPIITSVIFLIYYFFSPWNENMKVIAFYQAIGAGLPVLIGIFTASVMEQEQNAGDFQNLLSLPDKPAAFLSKLLMLLFLCLCSILLTAIIFGIGFGRIASSDIEIMKGCIFAALLLWGSSVPLYLWQLILAFQFGKGVSIGAGIISGLISALMLTGLGDYVWKYVFVCWTGRVPYTYLQSVLGETSVGEWLSFIPGCLIFTGISMVYYFWWVNHWEGNRISE",
      "product": ""
     },
     {
      "start": 3173,
      "end": 3904,
      "strand": -1,
      "locus_tag": "ctg28_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,173 - 3,904,\n (total: 732 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTTAATATTATAAAAGCAGAACATCAAAAAGCCAAAAGAACCATGCGAAAAAAGTTTATCTGGGGATTTCCTCTTCTTACATTTGTCATGGCATTTATATTTACTTTTGGGATGACAAATGTTTATGCAGAAAGTGTTTGGAACTGGTGGTATACACTTTTGCTGCCGGGGATGATTGCTCTATTTTGTTATCTTTCTGTGGCGCAGGAGAAAAAGATAAAATACTATCATTTAATGACTATTCCCACAGACAGAAGAAAATTGTTGCTGGGGAAAATTATTTATATTGGGTACATGATTTTGTTTTCTAATGTGATTGTGTTTGCAGGAGCAACGCTTGGAGGCTTTCTTCTAACGACACATGTTCCAGTTGGAGGAGCGTTGATTGCAGTATTGTTTCTGACGGTTTCTGAGTTATGGGAGATTCCGGTAGCTTTATTTTTAAGTGAACGATTTGGAATGATTGTAAACCTGTTCGTCTGCCTATTTATTACCGTCAGCGGTGTGGTAATATCACAAACCAGAATCTGGTATGTACTTGTTTCTGCAATCCCTATGCGAATGATGTGCCCGTTGCTTCATGTTTTACCAAATGGACTTGCCGCAGAAGCAGGGAATCCTCTTTTGGATACGGGAGTCATTGTTCCGGGAATGTGTCTCTCAATCATCTGGTTTGTTTTTGTAACGGTTCTGTTTTTGAAATGGTTTGAGAGAAGAGAGGTGAAATAA",
      "translation": "MVNIIKAEHQKAKRTMRKKFIWGFPLLTFVMAFIFTFGMTNVYAESVWNWWYTLLLPGMIALFCYLSVAQEKKIKYYHLMTIPTDRRKLLLGKIIYIGYMILFSNVIVFAGATLGGFLLTTHVPVGGALIAVLFLTVSELWEIPVALFLSERFGMIVNLFVCLFITVSGVVISQTRIWYVLVSAIPMRMMCPLLHVLPNGLAAEAGNPLLDTGVIVPGMCLSIIWFVFVTVLFLKWFERREVK",
      "product": ""
     },
     {
      "start": 3897,
      "end": 4610,
      "strand": -1,
      "locus_tag": "ctg28_6",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,897 - 4,610,\n (total: 714 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 180.7; E-value: 5.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMEMMLQTQNLCKYFRKQKAVNNVSLNIEKGQIYGLLGPNGAGKSTTLKMLTGMMKPTAGKIYFDGKLLDRKDLSKIGALIENPPIYENLSARENLKVRQLLLGTDENRIDEVLQIVSLTNTGKKKAGQFSLGMKQRLGIAMALLGEPELLILDEPTNGLDPIGIEELRELIRSFPEQGITVILSSHILSEVQLLADKVGIISGGILGYEGALKQGDNLEDLFMNVVRKNQKAGEIHG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAATGATGTTACAGACACAAAATCTATGTAAATATTTTAGAAAACAGAAAGCGGTAAATAATGTTTCACTTAATATCGAAAAGGGACAGATTTATGGACTGCTTGGACCGAATGGCGCTGGTAAATCTACCACATTGAAAATGCTGACCGGTATGATGAAACCAACTGCAGGAAAGATTTACTTTGATGGAAAACTTTTGGATAGGAAAGATTTATCAAAAATAGGAGCGTTAATTGAAAATCCGCCTATTTATGAAAATCTTTCCGCCAGAGAGAATTTGAAGGTAAGACAATTATTGCTTGGTACAGATGAAAACAGAATTGATGAGGTCTTGCAGATTGTATCACTTACAAACACCGGAAAGAAGAAAGCAGGACAGTTTTCTTTGGGGATGAAGCAAAGACTAGGCATTGCAATGGCATTGCTTGGAGAACCGGAACTTTTGATATTGGATGAACCTACGAATGGATTAGATCCAATAGGCATCGAGGAATTACGAGAGCTGATCCGGTCTTTTCCGGAACAGGGAATCACTGTAATTCTCTCCAGTCATATTCTCTCAGAGGTACAGTTACTTGCAGATAAAGTCGGGATTATTTCAGGTGGAATCTTAGGATACGAAGGAGCATTAAAGCAGGGAGATAATCTTGAAGATTTATTTATGAATGTGGTAAGAAAAAACCAGAAAGCAGGTGAAATCCATGGTTAA",
      "translation": "MEMMLQTQNLCKYFRKQKAVNNVSLNIEKGQIYGLLGPNGAGKSTTLKMLTGMMKPTAGKIYFDGKLLDRKDLSKIGALIENPPIYENLSARENLKVRQLLLGTDENRIDEVLQIVSLTNTGKKKAGQFSLGMKQRLGIAMALLGEPELLILDEPTNGLDPIGIEELRELIRSFPEQGITVILSSHILSEVQLLADKVGIISGGILGYEGALKQGDNLEDLFMNVVRKNQKAGEIHG",
      "product": ""
     },
     {
      "start": 4929,
      "end": 5411,
      "strand": -1,
      "locus_tag": "ctg28_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,929 - 5,411,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAGTCTTGACTCTGACAAAAAAGCAGGAAAATCCGGAGCAGTAGAAGAAGCAACTGCAAACGACAACAACGGATTCTTCAAAGACAACGCGAAGATTGACTTCTCCAACGTAAAGGTTGAGCCTTTATTTGAAGAAGAGGTTGATTTCGATACATTCAGCAAATCTGATTTCCGTGCCGTAAAGGTTAAAGAGTGTGTAGCAGTTCCGAAGAGCAAGAAGCTCCTTCAGTTCACACTGGATGACGGAACAGGTATTGATAGAACAATCCTTTCTGGTATTCATGCATATTACGAACCAGAAGAATTAGTTGGAAAGACACTTATTGCGATCACTAACCTGCCACCGAGAAAAATGATGGGAATTGAATCTTGTGGTATGTTGCTTTCAGCAGTGAATAATCTGAAAGATTCAGAGGATGAAGAACTGCATCTTATTATGGTTGATAATCACATTCCGGCAGGCGCAAAGTTATACTAG",
      "translation": "MKSLDSDKKAGKSGAVEEATANDNNGFFKDNAKIDFSNVKVEPLFEEEVDFDTFSKSDFRAVKVKECVAVPKSKKLLQFTLDDGTGIDRTILSGIHAYYEPEELVGKTLIAITNLPPRKMMGIESCGMLLSAVNNLKDSEDEELHLIMVDNHIPAGAKLY",
      "product": ""
     },
     {
      "start": 5663,
      "end": 6904,
      "strand": -1,
      "locus_tag": "ctg28_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,663 - 6,904,\n (total: 1242 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1077:phage integrase family protein (Score: 143.3; E-value: 2.2e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGAAAGCAAAAGTAAAGCAGAGGAAGGACAGCAAAGGACGAGTTCTTCAAAAGGGCGAAAGCCAAAGAAAATTAGATGGGATGTACATATATACCTATGTAAATCCCTATGGAAAACGTTGTTATGTATATTCCAAAGATCTTTTTACACTACGAGAGAAAGAACAAGAATTAATTAAAGCCCAGATGGATGGATTGGATTACTATGTAGGTGGCCATGCGACAATTAACATGACATTTGACAGATATATGAGTACAAAACATAATCTGAGAGAAACCACGAGATCCAATTACCTGTATATGTTCAATCGATTTATTCGAGAGGATTTCGGAAATAAGTTTTTGACTGAGGTGAAGTATACAGATGTGAAATTGTTTTATTATCATCTGTTAAATGAGAAGGATATTGCAATCAATACATTAGATACGATTCATACTGTATTACATCCAATTTTTGATATGGCAGTTAGAGACGATATTATTAATAAAAACCCTACAGACGGAGTTCTGGCTGAAATTAAACGAAATAGTGGAAAGAATAAAGGGATTCGACACGCACTTACAATTGAACAGCAACAGGCATTTATGGATACTATCAGAACATTTCCTGAATATTATCACTGGTACCCATTATTTGCAACATTACTTGGTACCGGAATGAGAATCGGTGAATGTACAGGATTAACTTGGAATGATGTTGATTTTAAAAGGAGATGTATTAGTGTAAATCATGCAGCAACCTATTATACAAGAAATGGAGTTGCAGGATTTGCGATTTCAAGACCGAAAACAGAAGCTGGTATAAGACAGATACCAATGATGGATGCAGTCTATAATGCTTTGAAAAATGAATATGACAGACAGAAGAAAGACGGATTTTGTACCTATGAGCTTGATGGTGTTTCAGGATTTATATTCTCAAATAAATTAGGTTTGCTTCATAATCCACATTGCGTAAATTTGGCAATCAAAAGAATCTACGAAGCACATAATGCAAGAGAGATTATAGATGCGAAGAGAGAACACAGAGAGCCGGTTATTATCCCGCACTTTTCCTGTCATGTGTTGAGGCATACATTCTGTTCACGTTTATGTGAGAGTGATATGAATGTAAAAGTTATTCAAGAGATCATGGGACATAAAAACGTAGAAACAACATTAGATATCTATACAGAAGTCAACTATAATAAGAAAAAAGATTCATTAGAAGAATTAGCAAGTAAAATGCAATTCTTTTAA",
      "translation": "MAKAKVKQRKDSKGRVLQKGESQRKLDGMYIYTYVNPYGKRCYVYSKDLFTLREKEQELIKAQMDGLDYYVGGHATINMTFDRYMSTKHNLRETTRSNYLYMFNRFIREDFGNKFLTEVKYTDVKLFYYHLLNEKDIAINTLDTIHTVLHPIFDMAVRDDIINKNPTDGVLAEIKRNSGKNKGIRHALTIEQQQAFMDTIRTFPEYYHWYPLFATLLGTGMRIGECTGLTWNDVDFKRRCISVNHAATYYTRNGVAGFAISRPKTEAGIRQIPMMDAVYNALKNEYDRQKKDGFCTYELDGVSGFIFSNKLGLLHNPHCVNLAIKRIYEAHNAREIIDAKREHREPVIIPHFSCHVLRHTFCSRLCESDMNVKVIQEIMGHKNVETTLDIYTEVNYNKKKDSLEELASKMQFF",
      "product": ""
     },
     {
      "start": 6947,
      "end": 7156,
      "strand": -1,
      "locus_tag": "ctg28_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,947 - 7,156,\n (total: 210 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGATTCGGGGAGGTGTTAAGCTTATGGCAAATAAAGACGGGAGACCGCCAGTGGATGATCCAAAACAGAAAATCTTAGGGGTGCGGGTAACGGTCAGTGATCATGAGAGGATTAAGAAATACGCAGCCGAGCATCATAAGACAATATCACAAGTTGTAATTGAAGGTCTAGATCTTTTATGTAATAAAGAAGAAAAAGACAACTAA",
      "translation": "MMIRGGVKLMANKDGRPPVDDPKQKILGVRVTVSDHERIKKYAAEHHKTISQVVIEGLDLLCNKEEKDN",
      "product": ""
     },
     {
      "start": 7219,
      "end": 7485,
      "strand": -1,
      "locus_tag": "ctg28_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,219 - 7,485,\n (total: 267 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGAGAACAGAAAAAGCAAAATCTTACAGATCCTAACGTGAGAAAAAGATTTGTTACTTACAAGGAAGCAGCGGAACTCTATAGTATGGGACTGACGAGAATACAGGAACATACAAAGATGGCAGGAGCAACTTATAAAATGGGTAATAAGGTGCTTGTAAATACGGACATCTTTGAAGCGTATCTTGAACAATATAGAATTCCAGGAGATTATGAAGGAATGGCAAAGAAGTTTACTCCAGATCTTGTGGAATTGTACCAATGA",
      "translation": "MREQKKQNLTDPNVRKRFVTYKEAAELYSMGLTRIQEHTKMAGATYKMGNKVLVNTDIFEAYLEQYRIPGDYEGMAKKFTPDLVELYQ",
      "product": ""
     },
     {
      "start": 8648,
      "end": 8797,
      "strand": 1,
      "locus_tag": "ctg28_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,648 - 8,797,\n (total: 150 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAGATAGAAAAAACTTCTTGAGAAACTGGATTATGAAAATAGGTGAGAATTCTGTAGGAAAAAGCCTATTGTTCGGTACATATGATCCGTTAATTCCGGATGAACTTAAGCGAGAGGTTCAAAAGCAAAAAAGTAAAAGGAAATAA",
      "translation": "MVDRKNFLRNWIMKIGENSVGKSLLFGTYDPLIPDELKREVQKQKSKRK",
      "product": ""
     },
     {
      "start": 8878,
      "end": 9453,
      "strand": 1,
      "locus_tag": "ctg28_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,878 - 9,453,\n (total: 576 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAAAATTAATAGGATCAGGAACAGAAAAAAAGTAGTTGTGCTTTTAATGGCATTAAGTTTATTTACATCATATTGTTTATCTACAACTACAGTGTCTGCAACTCCAAAACAATTGCAGAATGAATTGGTAGAAAGTACTAAAACAGTGCCCCTTAATGATGAACCTTTAGAATCTAGGGTAGGTGGAATAACATATTCATATGGTACAGGACCATTATATGGAAAGAGTAGTGATTATACAGTATATAAAAACACGGTAAGTAATCCTAATTTACCACTTACAAAAGAAATTGGAAGCTATTCACTAACAGCGTTAGGTATTTTGTTAGGAAAGGAAAGCACTCCAGCAGGGATAGCAGCAACATGTGTTCAAACAGTATATGATAAATTTTATGGAACAAAAACAAAAGGTCTTTCATATAAGACCAAAATATATACACATAAGAGCTATTCTACTGGAAACACTCCATCAGGATATTGTGAAAAACAGGTTACTACATGGTATTCACAAAAGAATTATACAGGAACTTCAGTTACAACTATACAATTTAAGAACGGGTATTTATATTAA",
      "translation": "MKKINRIRNRKKVVVLLMALSLFTSYCLSTTTVSATPKQLQNELVESTKTVPLNDEPLESRVGGITYSYGTGPLYGKSSDYTVYKNTVSNPNLPLTKEIGSYSLTALGILLGKESTPAGIAATCVQTVYDKFYGTKTKGLSYKTKIYTHKSYSTGNTPSGYCEKQVTTWYSQKNYTGTSVTTIQFKNGYLY",
      "product": ""
     },
     {
      "start": 9453,
      "end": 9638,
      "strand": 1,
      "locus_tag": "ctg28_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,453 - 9,638,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAATTTAAAATTTATTTTTATTCTGTTAATAATATTAAATGTTATAGTAACTATTTTAGGTAGTGCATATTTATCTATAAAACAACAGGCAGAATTTTATAGAATAGTTATCCATATTAATGTAGGAATTGAATGTTTAATTTTATTGAAAACTTTCAAATATTTAAAAGAAAACGGATAA",
      "translation": "MKNLKFIFILLIILNVIVTILGSAYLSIKQQAEFYRIVIHINVGIECLILLKTFKYLKENG",
      "product": ""
     },
     {
      "start": 9756,
      "end": 10550,
      "strand": -1,
      "locus_tag": "ctg28_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,756 - 10,550,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTAGATATTTATGTTTGTGAAGATAACAAAATACAATTAGAGCTTATTTCTAAATATGTGTCAAATACAATTTTGATTGAACAACTAGATATGCAACTCGCTTGTGCATCAACAACTTCTGGAAAAATATTAGAACAAGCAAAAAAATCAGAAAACACAGGGGTATTTTTTCTTGACATTTGTTTGCAATCAGAAATGACTGGATTGATTTTGGCACAAGAACTAAGAAAAATTCAACCTAGATGTTTTATTATATTTATCACAAGCCATTCCGAAATGAGCATTTTAACATTTCAATATAAAGTAGAAGCACTGGATTTTATAATCAAAGATTCCTCAGAAAATATTAGAAAAAGAATACATGAATGCTTAATGGATATCAACAAAAAAATTTTGACTGTTAATAAAAAGCAACAAAAAAGTATTCTTATTACTCAAAATGACAGATTGATTGCTGTAGACTATGATGAAGTGTTATTTTTTGAAACTTCAGAAAACAACCATAAAATAATACTGCATGCCAAAAAGCGAGTAGTTGAATTTACCGGACACTTAAAAAGTGTTGAAGTACAATTAGATTATCGTTTTTATAGGTGTCACCGTTCTTATATTGTAAATACAGATAATATCAAAGAAGTTAATTTTCAAAAACTAACAATTTATATGGAAAATGGAGAAATCTGTCCAATCTCTGTCCGTGCCAAAACTAGCTTTAAAAAATATTATAATGAGCATCTAATATCAATAGGCAACACTGTGACTAGAATATCTAAGAAATGCAACAATGAGTAA",
      "translation": "MLDIYVCEDNKIQLELISKYVSNTILIEQLDMQLACASTTSGKILEQAKKSENTGVFFLDICLQSEMTGLILAQELRKIQPRCFIIFITSHSEMSILTFQYKVEALDFIIKDSSENIRKRIHECLMDINKKILTVNKKQQKSILITQNDRLIAVDYDEVLFFETSENNHKIILHAKKRVVEFTGHLKSVEVQLDYRFYRCHRSYIVNTDNIKEVNFQKLTIYMENGEICPISVRAKTSFKKYYNEHLISIGNTVTRISKKCNNE",
      "product": ""
     },
     {
      "start": 10728,
      "end": 11294,
      "strand": 1,
      "locus_tag": "ctg28_15",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,728 - 11,294,\n (total: 567 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAATTTATAACAGAAAAATTATTAAATATATTAGCGTGTGCTGAGACTACCCAGTTAGAGCGTATGAAACTAAAATTAGGACTACAAGTCTTATGCCACAATATTTGGATGACATGTGTTATATTAATTTTAGCAGGGTATTTAAGATTATTTCAGGAGTCATTTATTTTATTTATTAGTTATGGAATTTTAAAAATTCATGTCGGTGGGATTCACTTCCACAAAAGTTGGCAATGTTTAACTGTAACCACTAGTTTTATAATAGGAGGGGTTTTACTTGCGCAACATATGACGCTTCAATTGAAATGGATTATTTTCCTATATATACTCAGTATCTTACTACTATGGATTATTGGTCCACAAGGTACAAGGAATAATCCAATTACGGAATATCATTATCCAATATTATATTGCCGAAGCCTTTGTATTGTGATTTTTTATGCTTTATTAACACTTTCTGGTATGTTAAACCAGAACACAATTAATCTTCTTTTGTTGGCAGTTCTGTTTGGGATTTTTTCTATTATACCAAACAAAATTCAGAATAGCCATTATTCTTTTTGA",
      "translation": "MEFITEKLLNILACAETTQLERMKLKLGLQVLCHNIWMTCVILILAGYLRLFQESFILFISYGILKIHVGGIHFHKSWQCLTVTTSFIIGGVLLAQHMTLQLKWIIFLYILSILLLWIIGPQGTRNNPITEYHYPILYCRSLCIVIFYALLTLSGMLNQNTINLLLLAVLFGIFSIIPNKIQNSHYSF",
      "product": ""
     },
     {
      "start": 11545,
      "end": 12858,
      "strand": -1,
      "locus_tag": "ctg28_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,545 - 12,858,\n (total: 1314 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATGCATTATTACAATTAATGAGCTGTTTTTTAAATGCAATTATGTACATGATTTTAATCTATTACTTCTTACCTTTCAAATTGCAATTTAAAGAAATTACAATTCTTTTTACAATTCTTTCAACCAACATGTTTCTAATAAATAAAGTTGGAAATTATGGGGTTATTTTTCTATTGATAAGTGTAAGTATTTATCTAATGTTTATACGTAAAAATAGATTCATAAATATTATGTCTTTCGTTATCAGCTATTTATTTATAGTGATATTTGACCAATTTTTTTCCTTGCTGTGGAATGTTTTTGTTTGTCCTATTTCCACTCTTTTGAAAAATACTATATATTATATTTTATATGTAATTTCAGCTATTGTTGTACTTCTTATAATATGCCCTTTTATCGGAAAATATTATCATTTATTGATAAGAAAAATAGAAGCATATGTAAACAAACAATTATTTGTTCTGATAGGATCTAATCTAGGAATTTGTCTAATTATAGTTCTATTTAATGTGTTTATTGGTGAATACATTGGATATACATCTAGGAGTATAGGTTTCAATTGCATCCTGTTTGCCTGTTATTTTATAATTAGTACGATTCTAATCATAAATATTACAAAGCAAAATGAAAAAAGAATTGAACTGGAAAAGCGCCAAGAAGCATACCAGCATCTGCAAGAATATACAAATCAGATTGAGCATATGTATTCCACACTTCGTTCCTTCAAACATGACTACTCAAATATGATGCTGACAATGGCCGAATATATTGCTTCTGAGGATATCAATGGATTAAAAAATTATTTTACAAACGAATTTATGCCAAAGAACCAAAAGTTGACATCAGATACAACAAAAATAAATTCGTTGATTAACTTAAAAGATATAGAATTGAAAAGTCTGCTCTCTGCCAAGTTATTATATGCATTGAACCTAGGGATTAATGTAGAAATAGAAATTATAGAAGAAATCTCTCACATCCAAATGGACATTATAGATTTAGCAAGAATAGTTGGGATTTTTTTGGATAATGCAATCGAATCCGCTTTGGAAACTGAGCAACCAAAACTTCACTTTGCAGCAATTAACTCTGAAAACAAAAAAGTAATTATTATTGCAAATACTTTTTTAGATAAAGGTATTCCTATCGCAACATTAAAAGAAGAGGGGGTATCTACAAAAGGAAAAAACAGAGGGATTGGTCTGCTTCATGTAAAAGAAATTGTCTCTAATTATCAAAATGTATTATGGGATATGGAAGTAAAGCACAACTATTTTATACAAACACTAACAATAACAGAAACTTTTTAA",
      "translation": "MDALLQLMSCFLNAIMYMILIYYFLPFKLQFKEITILFTILSTNMFLINKVGNYGVIFLLISVSIYLMFIRKNRFINIMSFVISYLFIVIFDQFFSLLWNVFVCPISTLLKNTIYYILYVISAIVVLLIICPFIGKYYHLLIRKIEAYVNKQLFVLIGSNLGICLIIVLFNVFIGEYIGYTSRSIGFNCILFACYFIISTILIINITKQNEKRIELEKRQEAYQHLQEYTNQIEHMYSTLRSFKHDYSNMMLTMAEYIASEDINGLKNYFTNEFMPKNQKLTSDTTKINSLINLKDIELKSLLSAKLLYALNLGINVEIEIIEEISHIQMDIIDLARIVGIFLDNAIESALETEQPKLHFAAINSENKKVIIIANTFLDKGIPIATLKEEGVSTKGKNRGIGLLHVKEIVSNYQNVLWDMEVKHNYFIQTLTITETF",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 10727,
      "end": 11294,
      "tool": "rule-based-clusters",
      "neighbouring_start": 727,
      "neighbouring_end": 13179,
      "product": "cyclic-lactone-autoinducer",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "cyclic-lactone-autoinducer",
    "products": [
     "cyclic-lactone-autoinducer"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP cyclic-lactone-autoinducer",
    "anchor": "r28c1"
   }
  ]
 },
 {
  "length": 10746,
  "seq_id": "NZ_JANGDO010000035.1",
  "regions": []
 },
 {
  "length": 10024,
  "seq_id": "NZ_JANGDO010000036.1",
  "regions": []
 },
 {
  "length": 9649,
  "seq_id": "NZ_JANGDO010000037.1",
  "regions": []
 },
 {
  "length": 6884,
  "seq_id": "NZ_JANGDO010000038.1",
  "regions": []
 },
 {
  "length": 5096,
  "seq_id": "NZ_JANGDO010000039.1",
  "regions": []
 },
 {
  "length": 183864,
  "seq_id": "NZ_JANGDO010000004.1",
  "regions": []
 },
 {
  "length": 4239,
  "seq_id": "NZ_JANGDO010000040.1",
  "regions": []
 },
 {
  "length": 2921,
  "seq_id": "NZ_JANGDO010000041.1",
  "regions": []
 },
 {
  "length": 2380,
  "seq_id": "NZ_JANGDO010000042.1",
  "regions": []
 },
 {
  "length": 2359,
  "seq_id": "NZ_JANGDO010000043.1",
  "regions": []
 },
 {
  "length": 1716,
  "seq_id": "NZ_JANGDO010000044.1",
  "regions": []
 },
 {
  "length": 1491,
  "seq_id": "NZ_JANGDO010000045.1",
  "regions": []
 },
 {
  "length": 1434,
  "seq_id": "NZ_JANGDO010000046.1",
  "regions": []
 },
 {
  "length": 1066,
  "seq_id": "NZ_JANGDO010000047.1",
  "regions": []
 },
 {
  "length": 1021,
  "seq_id": "NZ_JANGDO010000048.1",
  "regions": []
 },
 {
  "length": 165773,
  "seq_id": "NZ_JANGDO010000005.1",
  "regions": []
 },
 {
  "length": 148810,
  "seq_id": "NZ_JANGDO010000006.1",
  "regions": []
 },
 {
  "length": 147527,
  "seq_id": "NZ_JANGDO010000007.1",
  "regions": []
 },
 {
  "length": 142600,
  "seq_id": "NZ_JANGDO010000008.1",
  "regions": []
 },
 {
  "length": 141058,
  "seq_id": "NZ_JANGDO010000009.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r21c1",
  "r27c1",
  "r28c1"
 ],
 "r21c1": {
  "start": 1,
  "end": 12929,
  "idx": 1,
  "orfs": [
   {
    "start": 194,
    "end": 607,
    "strand": 1,
    "locus_tag": "ctg21_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 194 - 607,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATTTTAAAGAAATATTCTCCAATCGGTGAATTAGGAACACTGGCAGGGATTTATGCAGATAGTCTTTCGAAGACACTTGATTGTACAGTCTGTATCACTGATACAGATCAGGTGATCGCGGCAGCAGGAAACGGGAAGAAAGAACTTCAGGAAATGCTGTTGAGTGCAGAGCTGGCAGAAGTGTTTCAAGAAAGAAAGACCGTGTTGAAAAAGAGTAGTGACGCTGAGTTTGTAGCAATTACAAAAGACAGGAGTGAATACAGCGAGGAAATAATCAGTGTGATTCTCAGTGAAGGTGATATTGCAGGTGGAGTGATCTTTCTGCAGAAAAATGAGAAAAAGCATTTCGGAGAAATGGAAAAGAAGTTTGCGGCAGGCGCAGCAGATCTGCTTGGGAGGCAGTTAAGTTAA",
    "translation": "MILKKYSPIGELGTLAGIYADSLSKTLDCTVCITDTDQVIAAAGNGKKELQEMLLSAELAEVFQERKTVLKKSSDAEFVAITKDRSEYSEEIISVILSEGDIAGGVIFLQKNEKKHFGEMEKKFAAGAADLLGRQLS",
    "product": ""
   },
   {
    "start": 684,
    "end": 1064,
    "strand": 1,
    "locus_tag": "ctg21_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 684 - 1,064,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGAGAAAATCATGGGAAAAAAGGGATAATATACGCAGAAAATTTAGTGAAGGCATTACTTTGCGCCTATCTGGTCACAGGAATGTTTCTGTTAATTCTTGCACTTCTCCTTTATAAAGCAGGATTGAGTGAAGAAAATGTAAATCTGGGAATTATTCTCATTTATGTAATAGGAACTTTTTCCGGTGGTTTTGTGATGGGAAAACTGGAAGGTCAAAAGAAGTTCCTCTGGGGGCTTGGAACCGGTGTGGTTTATTTTGTTTTATTACTGATCATCTCATTTGGAATGTACCGTGAGGTTTCGTCGGGGACAGGAGATTTGTTTCTGACATTTGTACTTTGTACCGGAGGTGGAATGCTCGGTGGGATGGTCGCATGA",
    "translation": "MRENHGKKGIIYAENLVKALLCAYLVTGMFLLILALLLYKAGLSEENVNLGIILIYVIGTFSGGFVMGKLEGQKKFLWGLGTGVVYFVLLLIISFGMYREVSSGTGDLFLTFVLCTGGGMLGGMVA",
    "product": ""
   },
   {
    "start": 1048,
    "end": 1305,
    "strand": 1,
    "locus_tag": "ctg21_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,048 - 1,305,\n (total: 258 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGGATGGTCGCATGAAGAAAAACCAGACGGATGTGTGAAAAAATACTTTAAAAACCTGACTGTGTGTGCTATAATAGCGAAAGCAATATGTGCGAAGTTAGGAGGAGTAAAAATGAAACACATTAAAACACTGAATACACAGACACTGAACAACACAGTTAAAAAAGGTGGATGCGGAGAGTGCCAGACATCTTGCCAGTCTGCATGTAAGACATCCTGTACAGTAGGAAACCAGACTTGCGAAAACGCAAAATAA",
    "translation": "MGWSHEEKPDGCVKKYFKNLTVCAIIAKAICAKLGGVKMKHIKTLNTQTLNNTVKKGGCGECQTSCQSACKTSCTVGNQTCENAK",
    "product": ""
   },
   {
    "start": 1529,
    "end": 2929,
    "strand": 1,
    "locus_tag": "ctg21_4",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,529 - 2,929,\n (total: 1401 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATACATCAGTACCAGAACAATGGATATAATATCGTCCTCGACGTGAACAGCGGAGCTGTACATGTTGTGGATCAGGAAGCGTATGATGTCATCGAAGTGCTTAATCGCATGAATGAAGATCATACAGTGGAGACATTGAAATCTCCGGAAACAGCAGAAGCATTGAAAAAAGAGCTTGGAGAAAAATATTCCGAGAAAGATCTGCTGGATATTTTAGAGGCAGTAACAGAACTGACGGAACAGGGACGTCTGTTTACAAAAGACATTTATGAGAGCTTTATCGACGTTGTAAAGCAGCGTAAGACAGTTGTTAAGGCTTTATGTCTTCATATTGCACATGACTGTAACCTTGCCTGTAAGTACTGCTTTGCGGAAGAGGGAGAATATCACGGCCGCAGGGCTCTGATGTCTTACGAGGTTGGTAAGAAAGCACTTGATTTCCTGATCGCGAATTCAGGAACAAGAAGAAACCTTGAGGTTGACTTCTTCGGTGGTGAGCCGCTGATGAACTGGCAGGTTGTTAAAGACCTGGTTGCTTACGGAAGAGAGCAGGAGAAACTTCATGACAAGCATTTCCGTTTCACACTTACAACAAACGGAGTTCTTTTGAACGATGAAGTTCAGGAGTTCGTGAACAAAGAGATGGACAACGTTGTCATCAGTCTTGACGGAAGAAAAGAAGTGAATGACCAGATGCGCCCGTTCCGTAACGGAAAAGGAAGCTATGATCTGATCGTTCCGAAGTTCCAGAAGCTGGCAGAGAGCCGTAATCAGGAGAAGTACTACATTAGAGGTACATTTACAAGAAATAACTTGGATTTTTCCAAGGATGTAGAACATTTTGCAGATCTTGGATTCAAGCAGATGTCAATCGAGCCTGTAGTAGGTGATGACACAGAACCATATGCAATCCAGAAAGAAGATCTTCCACAGATCTTTGAAGAATATGATAAACTCGCAAAATTCCTGATCGAGCGTGAGAAGAGCGGAAGAGGATTCAATTTCTTCCATTTCATGATCGATCTTGAAGGAGGACCGTGCGTGTCCAAGCGTCTGTCCGGCTGTGGTTCAGGTACAGAGTATCTGGCAGTGACACCTTGGGGAGATTTCTACCCATGTCATCAGTTTGTAGGACAGGAAGAATTCCTCATGGGAAATGTCGATGAGGGAATTACAAAACCGGAGATTGCGGAAGAATTCCGTGGATGCAGCGTATATTCCAAGGAAAGCTGCAGAACCTGCTTTGCCAGATTCTACTGCAGTGGTGGCTGTATGGCGAATTCTTACAAGTTCCACAATACGATCCATGATACTTACGAAGTGAGCTGTGAGATGGAGAGAAAACGTGTGGAATGTGCGATCATGATAAAGGCTGCCCTGGCGGATGAAGAACAATAA",
    "translation": "MIHQYQNNGYNIVLDVNSGAVHVVDQEAYDVIEVLNRMNEDHTVETLKSPETAEALKKELGEKYSEKDLLDILEAVTELTEQGRLFTKDIYESFIDVVKQRKTVVKALCLHIAHDCNLACKYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGTRRNLEVDFFGGEPLMNWQVVKDLVAYGREQEKLHDKHFRFTLTTNGVLLNDEVQEFVNKEMDNVVISLDGRKEVNDQMRPFRNGKGSYDLIVPKFQKLAESRNQEKYYIRGTFTRNNLDFSKDVEHFADLGFKQMSIEPVVGDDTEPYAIQKEDLPQIFEEYDKLAKFLIEREKSGRGFNFFHFMIDLEGGPCVSKRLSGCGSGTEYLAVTPWGDFYPCHQFVGQEEFLMGNVDEGITKPEIAEEFRGCSVYSKESCRTCFARFYCSGGCMANSYKFHNTIHDTYEVSCEMERKRVECAIMIKAALADEEQ",
    "product": ""
   },
   {
    "start": 2966,
    "end": 5374,
    "strand": 1,
    "locus_tag": "ctg21_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,966 - 5,374,\n (total: 2409 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAAAGGTAAGAGTATTCTCAGCCTCATTCTCGTAATCGCAGTTACAGCACTCTTCGGTATGACCTGTGTGCTTGGACTTGATTTAAAGGGAATGGGAGCTGCGAAGAACATCAATCTCGGTCTTGACCTGGAAGGCGGAGTCAGCATTACATATCAGGTAAAAGGTGACAAGCCATCTCAGGCAGACATGGATGACACCGTGTACAAGCTTCAGAAACGTGTGGAGCAGTACAGCACAGAGGCACAGGCTTATCAGGTTGGAGACAACCGTATCAGTATCGAGATTCCGGGTGTGAGCGACGCAAACAAGATCCTGGAAGAACTTGGACAGCCGGGTTCACTGTACTTTATCAAGCATAAAGACAGTGAGGGAAATGAAAACTATTCCCTGACAGCTTCCGGATATACACTGAATAAGTCAATCGACGAACTGAAAGATACAGACTCCATCGTACTGACAGGTACAGAGGTAAAGACAGCTTCAGCCGGAGTGCTCAACGACTCAACAACAGGAAATAAAAAGTATGGTGTTGATCTTGAGTTGACAGATGAGGGTGCTGAGAAGTTCAAGACAGCAACAGAAGAAGCTTATAACAATAACCATGACACAATCGCTATTTACTATGATGGTTCTCTGATCAGCGTGCCAAGCGTAAATGCAGTGATTGAGAATGGAAAAGCTCAGATTTCAGGAAACATGGATTATGAAGAGGCTGATAACATCGCTTCTACAATCCGTATCGGTGGACTGAATCTGGAACTTGAAGAGCTTAGCTCAGAAGTTGTAGGAGCACAGCTTGGACAGGACGCTCTTAAAGGAAGTCTGATCGCAGGTATCATCGGTCTGGCAATCGTATGTGTATTCATGTGCTGGGTATACCTCCTTCCGGGACTTGCATCCAGCCTTGCACTGATCCTTTACACAGAATTGATCCTGATCCTTCTGAATGCATTTGACATTACACTGACACTTCCGGGTATCGCAGGTATCATCCTCGGTATCGGTATGGCGGTAGATGCGAACGTTATCATCTTCGCCCGTGTGAAAGAAGAGCTGACAGCAGGAAAGAGCGTACACGCTTCACTGAAATCAGGATTCCAGAAGGCAATGTCCGCAATCGTTGACGGAAATATCACAACACTGATCGCAGCCGGCGTGCTGTGGCTTCGCGGAAGCGGTACTGTAAAGGGATTCGCCCAGACACTTGCACTGGGTATCGTCGTATCCATGTTTACAGCACTCGTGATCACAAGACTGATCATCTTTGCATTCTATGGAGCAGGCATCCACAATGAGAAAGTATACGGAAGACATCTGAAAGAACGTAAACCGGTTGATTTCCTTGGAAAGAAAAAAATCTTCTTCGTTATTTCTATCATCCTTTGTCTGGCCGGACCGGTCATGATGGGTGTGAACCATGCAAGAGGAATCGGCGCAATGAATTACAGCCTTGATTTTGTAGGCGGTACTTCAACAAATGTAACATTTGATAAAGAATATACACTGGAAGAGATCGACAGCCAGATGATCCCAAGCCTGGAAGAGATCACAGGAGATAAGAATATTCAGGTTCAGACAGTAAAAGACAGCAATCAGGTAGTCTTCAAGACACAGACACTTGATCTTGAGAAACGTGAAGCACTTGCTTCTTATCTGAATGAGAACTACGGGGTAGAGGTATCTGATATCGCTACAGAGAATATCAGTTCAACAGTAAGTTCTGAGATGAGAAGAGACGCTGTTATAGCTGTGATCATTGCTACAATCTGTATGCTGCTTTACATCTGGTTCCGTTTCAAAGATATTCGTTTCGCAACAAGTGCTGTTGTCGCACTGATGCATGACGTACTTGTAGTTCTTGGATTCTATGTAATCGCAAGAGTATCTGTCGGAAATACATTTATTGCATGTATGCTGACAATCGTTGGATATTCTATCAACGGTACGATCGTTATCTTTGACCGTATCCGTGAGGCGCTGGCAACAAAGAGCCGTACAGAAGATCTGAAGGATCTTGTAAACCGCTGTATTACTCAGACACTGACAAGAACGATCTATACAAACTTTACAACATTTGTCATGGTCGTTGCTCTGTATATCCTTGGTGTAAGCTCCATTAAGGAATTCGCTGCACCTCTGATGGTAGGTATCATCTGCGGTGGATATACATCCGTATGCATCACAGGTGCTCTGTGGTATGTGATGAAGACAAGACTTGGTGAGGAAGCGAAGGCTGCGAGAGCAGCTTCTGGCACAAAGACAACTTCTGCAAAAGCAGCAGACAAGAAAGAAGGAACTACTTCCACAGAGAGTAACGCAGCAGATACATCTGCAGACGACAGCTCCAAGAAGAAAAAAGGAAAGAAGACTTCTTTCAAAAATAAAAAGAGCAAAAAGCGCTAA",
    "translation": "MKKGKSILSLILVIAVTALFGMTCVLGLDLKGMGAAKNINLGLDLEGGVSITYQVKGDKPSQADMDDTVYKLQKRVEQYSTEAQAYQVGDNRISIEIPGVSDANKILEELGQPGSLYFIKHKDSEGNENYSLTASGYTLNKSIDELKDTDSIVLTGTEVKTASAGVLNDSTTGNKKYGVDLELTDEGAEKFKTATEEAYNNNHDTIAIYYDGSLISVPSVNAVIENGKAQISGNMDYEEADNIASTIRIGGLNLELEELSSEVVGAQLGQDALKGSLIAGIIGLAIVCVFMCWVYLLPGLASSLALILYTELILILLNAFDITLTLPGIAGIILGIGMAVDANVIIFARVKEELTAGKSVHASLKSGFQKAMSAIVDGNITTLIAAGVLWLRGSGTVKGFAQTLALGIVVSMFTALVITRLIIFAFYGAGIHNEKVYGRHLKERKPVDFLGKKKIFFVISIILCLAGPVMMGVNHARGIGAMNYSLDFVGGTSTNVTFDKEYTLEEIDSQMIPSLEEITGDKNIQVQTVKDSNQVVFKTQTLDLEKREALASYLNENYGVEVSDIATENISSTVSSEMRRDAVIAVIIATICMLLYIWFRFKDIRFATSAVVALMHDVLVVLGFYVIARVSVGNTFIACMLTIVGYSINGTIVIFDRIREALATKSRTEDLKDLVNRCITQTLTRTIYTNFTTFVMVVALYILGVSSIKEFAAPLMVGIICGGYTSVCITGALWYVMKTRLGEEAKAARAASGTKTTSAKAADKKEGTTSTESNAADTSADDSSKKKKGKKTSFKNKKSKKR",
    "product": ""
   },
   {
    "start": 5508,
    "end": 7232,
    "strand": 1,
    "locus_tag": "ctg21_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,508 - 7,232,\n (total: 1725 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAATGGTTCGTCGCAATGAAAAAGGCGGATTTTAATGGAATAGCAGAGAAATATCAGATTTCCCCGATCATTGCGCGGCTGATGAGGAACCGTGATGTGGTCGGAGATGATGCAATTGATTTTTATCTGAATGGAACAGTGGAGAATCTGTATGACGGTTTACTGATGAAAGATATGGATCGTGCAGTAGATATTCTTAAGGAGAAAATAGAAGAGGGAAAGAAAATCCGTGTGATCGGTGATTATGATATTGATGGAGTCAATGCAACGTATATTTTGCAACAGGGGCTTGCAGGACTTGGGGCAGATGTCGATACGGATATTCCAGACAGGATCAAAGACGGATATGGATTGAATCAGATGCTGATCGACCGTGCACTGGATGATGATGTAGACACGATCATCACCTGTGATAATGGAATTGCGGCAATGAGTGAGATTGCTTACGGAAAAGAAAATGGGATGACGATCGTTGTGACAGATCACCATGAAGTTCCGTATCTGGAAGAAAATGGGGAGAAAAAGCATCTTCTGCCACCGGCGGATGCAGTGGTCGATCCGCACAGAGCAGACTGTGAGTATCCATTTAAAGGGCTGTGCGGCGCAGCTGTAGCGTATAAGCTGGTTGAGGTTTTGTACAGAGTGTCTGGAAAGTCAGAGCAGGAGGTAGAGCATCTGCAGGAAAGCCTGATGGAAAATGTTGCGATTGCCACGATCGGTGATGTGATGGATCTGGTTGGAGAGAATCGTGTCTTTGTGAAAAAGGGACTTGAGCTTCTGAAGACAACGAAGAATGAAGGGCTTCACGCATTGATGCAATGTACAGGGGTAGATACAGCGAACCTGAATACTTATCATATCGGATTTATGATCGGACCGTGCATCAATGCCGGCGGAAGACTGGATACAGCCAAGCGTGCACTAGAACTCCTTAATGCATCGAACCGGAGAGAGGCAGTGACACTGGCAGCAGATCTGAAAGAATTAAATGACAGCCGGAAAGAAATGACCGAAGAAGGTGTAGAAGAAGCTGTCCGGCAGATTGAATCAAGTTCCTGGAAGGACGACCAGGTGCTGGTCGTGTATCTTCCAGAGTGTCACGAAAGTATCGCCGGAATTATTGCGGGGAGGATCAAGGAACGTTATTATCGTCCGACCTTTGTACTGACAAAGGGAGAGACAGGAGTGAAAGGTTCCGGACGGTCGATCGAAGCCTATGATATGTTTGCGGAAATGAGCCGCTGCAGGGAATTATTTACGAAGTTCGGAGGACATAAGCTGGCAGCAGGACTTTCTTTAGAAGAGGAAAAGGTCGAAGTTTTCCGGAAACGGATCAATGAACTGGCGGATCTGACAGAAGAGGATCTGCAGATGAAGGTGTCGATCGATATGCGGCTTCCGTTTCCATATATTAATGAAGAGCTGATCCATGAGCTTAAGATATTGGAGCCTTTTGGAAAAGGCAATGGGAAACCGTTATTTGCAGAAAGTAAACTGCGTGTGATCCAGCCAAGAATCTTCGGAAAGAACCGGAATGTGCTGAAATGCAGACTGGAGGACCAGCAGGGAAATCAGATGGAAGCGGTTTATTTCGGAGAAGTGGAAGACTGTCTGCGGCAGATGGAAAAGAAGCAGATCATGTCTTTTACATACTATCCATCCATCAATGAGTACATGGGACGAAGAACAATTCAGCTTACAATTGTCAATTATCAGTAG",
    "translation": "MEKWFVAMKKADFNGIAEKYQISPIIARLMRNRDVVGDDAIDFYLNGTVENLYDGLLMKDMDRAVDILKEKIEEGKKIRVIGDYDIDGVNATYILQQGLAGLGADVDTDIPDRIKDGYGLNQMLIDRALDDDVDTIITCDNGIAAMSEIAYGKENGMTIVVTDHHEVPYLEENGEKKHLLPPADAVVDPHRADCEYPFKGLCGAAVAYKLVEVLYRVSGKSEQEVEHLQESLMENVAIATIGDVMDLVGENRVFVKKGLELLKTTKNEGLHALMQCTGVDTANLNTYHIGFMIGPCINAGGRLDTAKRALELLNASNRREAVTLAADLKELNDSRKEMTEEGVEEAVRQIESSSWKDDQVLVVYLPECHESIAGIIAGRIKERYYRPTFVLTKGETGVKGSGRSIEAYDMFAEMSRCRELFTKFGGHKLAAGLSLEEEKVEVFRKRINELADLTEEDLQMKVSIDMRLPFPYINEELIHELKILEPFGKGNGKPLFAESKLRVIQPRIFGKNRNVLKCRLEDQQGNQMEAVYFGEVEDCLRQMEKKQIMSFTYYPSINEYMGRRTIQLTIVNYQ",
    "product": ""
   },
   {
    "start": 7433,
    "end": 9754,
    "strand": 1,
    "locus_tag": "ctg21_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,433 - 9,754,\n (total: 2322 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGGGGAAGATGATATGGCAGGCACTCGGGAATATGAAGATCTGAATAAAAATCTGGAGATAGTGGACGGGCATGCAGTAAAAGCACCAGAGGATTATCAGGATCCGGAGGAGTTATATCAGGCCTTAATAGCTCGTGTGCGTAAGTATCACCCCTCTGCGGATATTACGATGATCGAGAAGGCCTATCAGATAGGCAAAGAAGCGCATAAGAATCAGTTCCGTAAATCCGGAGAACCTTATATCATCCATCCACTCTGGGTGGCAATCATACTTGCAGATCTCGAGATGGACAAAGAAACGATCGTGGCTGGAATGCTTCATGACGTGGTAGAAGATACGACAATGACACTCGATGAGATCTCAGCAGAGTTTGGTGAAGAGGTGGCACTTCTTGTAGACGGCGTTACCAAGCTGGGACAGTTGAACTATTCCAAGGACAAGCTGGAGGCCCAGGCAGAGAACCTGAGAAAGATGTTCCTTGCGATGGCGAAAGATATCCGTGTCATCATTGTAAAACTCGCAGACCGTCTGCATAATATGCGTACAATGGAGTTTATGACACCGGCCAAGCAGAAAGAGAAATCAAGAGAGACGATGGATATCTACGCTCCGATCGCTCAGCGTCTCGGTATTTCCAAGATCAAGACAGAACTCGATGACCTTTCTCTGAAATATTATCAGCCGGAAGTTTATAATCAGCTGGTTCATGATCTGAATGCACGTAAGACGGAACGTGAAGAATTTGTGCAACAGATCGTTGCTGAAGTATCAAAGCATATGAAGAATGCTGATATTGAAGCGAAAGTATACGGACGTGTAAAACATTTCTTCAGTATTTATAAGAAGATGGTGAATCAGAACAAGACACTTGATCAGGTGTATGACCTGTTCGCTGTCCGCATTATCGTAGATTCAGTGAAAGACTGTTACGCAGCACTTGGTGTGATCCATGAGATGTATACGCCGATTCCGGGACGTTTCAAGGATTATATTGCTATGCCGAAGGCGAATATGTACCAGTCTCTGCATACAACGCTGATTGGACCTTCCGGACAGCCGTTCGAGATCCAGATCCGTACAGAAGAGATGCATAAGACAGCGGAATATGGTATCGCAGCACACTGGAAATATAAAGAGACAGGCGGAAGCAACACGAAAGGACTGAACACACAGGAAGAGAAGTTGAACTGGCTGCGTCAGATCCTGGAATGGCAGAGAGACATGTCTGATAACCGTGAGTTCTTAAGCCTGCTGAAAGGTGACCTGGATCTGTTCCAGGAAGATGTATACTGCTTCACACCGAACGGGGATGTGAAGAACCTTCCGAATGGCTCCACACCGGTTGACTTCGCCTATGCGATCCACAGTGCAGTCGGCAATAAGATGGTTGGCGCCAGAGTGAATGGCAAGCTTGTGAACATTGATTATAAGATTCAGAACGGAGACAGAATCGAGATCCTTACATCTCAGAATTCCAAGGGACCGAGCCGTGACTGGCTGAATATCGTCAAGAGCACACAGGCAAAGAGTAAGATTAATTCATGGTTTAAGAAGGAATACAAAGAAGATAATATTATCCGCGGAAAGGATCTGATCAGTGCCTACTGTAAGAGCAAGGGCATCAATTTGCCGGATATCATCAAGCCGAAATATCAGCAGATCGTTCAGAAGAAATACGGATTCCGTGACTGGGATGCAGTACTTGCAGCAATCGGACACGGCGGACTCAAAGAAGGTCAGGTTGTGAACCGCCTGTTGGAAGAGTACGAGAAAGAGCATAAGAAAGAGATCACGGATGAGAATATTTTGGAGAAGATCTCAGAAGCGAATAAACAGAGAGTCCACATTGCCAAATCAAAGAGCGGAATCGTAGTTAAGGGAATCAATGATATGGCAGTACGCTTCTCAAAGTGCTGTAATCCGGTGCCGGGAGATGAGATTGTCGGTTTTGTAACAAGAGGGCGCGGAATGTCAATCCACAGAACAGATTGTATCAATATCATCAATCTTTCTGATGTGGAGAGATCCCGTCTGATCACAGCAGAATGGGAGGATAATGATCTCGAAGAAGGCGGTCAGTATCTTGCAGAACTGAAGATATTTGCAGACGACAGAAGAGGACTTCTGCTGGATGTATCAAAGGTATTTACCGAAGAGAAGATTGACGTGAAGTCCATGAATACCCGGACGAGCAAGAAGGGTACGGCAACAATGGAGATGGGATTTGTTGTACACGGAAGAGAAGAATTGAACCGTGTGATCGGAAAGCTCAGACAGATTGAAAATGTAATTGATATTGAGAGAACAACAGGCTGA",
    "translation": "MKGEDDMAGTREYEDLNKNLEIVDGHAVKAPEDYQDPEELYQALIARVRKYHPSADITMIEKAYQIGKEAHKNQFRKSGEPYIIHPLWVAIILADLEMDKETIVAGMLHDVVEDTTMTLDEISAEFGEEVALLVDGVTKLGQLNYSKDKLEAQAENLRKMFLAMAKDIRVIIVKLADRLHNMRTMEFMTPAKQKEKSRETMDIYAPIAQRLGISKIKTELDDLSLKYYQPEVYNQLVHDLNARKTEREEFVQQIVAEVSKHMKNADIEAKVYGRVKHFFSIYKKMVNQNKTLDQVYDLFAVRIIVDSVKDCYAALGVIHEMYTPIPGRFKDYIAMPKANMYQSLHTTLIGPSGQPFEIQIRTEEMHKTAEYGIAAHWKYKETGGSNTKGLNTQEEKLNWLRQILEWQRDMSDNREFLSLLKGDLDLFQEDVYCFTPNGDVKNLPNGSTPVDFAYAIHSAVGNKMVGARVNGKLVNIDYKIQNGDRIEILTSQNSKGPSRDWLNIVKSTQAKSKINSWFKKEYKEDNIIRGKDLISAYCKSKGINLPDIIKPKYQQIVQKKYGFRDWDAVLAAIGHGGLKEGQVVNRLLEEYEKEHKKEITDENILEKISEANKQRVHIAKSKSGIVVKGINDMAVRFSKCCNPVPGDEIVGFVTRGRGMSIHRTDCINIINLSDVERSRLITAEWEDNDLEEGGQYLAELKIFADDRRGLLLDVSKVFTEEKIDVKSMNTRTSKKGTATMEMGFVVHGREELNRVIGKLRQIENVIDIERTTG",
    "product": ""
   },
   {
    "start": 9768,
    "end": 10388,
    "strand": 1,
    "locus_tag": "ctg21_8",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,768 - 10,388,\n (total: 621 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1170:metallo-beta-lactamase family protein (Score: 162.1; E-value: 1.8e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGTTGAAAGTATTGTACTGGGGTCAATTGGAACGAATTGCTATATTGTAACCAATGAAGAGACGAAGGAATGTTTTGCAGTGGATATGGCAGAATGTCCGCAGGAATATGTCAATTATATCAAGAACAATGGACTAGAAATGAAAGCATTGTTTCTGACACATGGACATTTTGACCACATCATGGGAATCGATGATTTCCTCAAAGCCTTTCCTGTGCCGGTTTACGCAGGCGAAGATGAACTTCCGGTGATCGAGGATGACCGCCTGAATGTTTCTTGTATGTACGGACCGAAATACGCATTCCACGGAGCACAGCCTGTAAGAGACGGTCAGGTGATCGAATGCGCAGGAATTGAAGTTGATGTACTTCATACACCGGGACATACAGTAGGAGGATGCTGCTATTACCTACCAAAAGAACATAGATTGTTTAGTGGAGATACGCTGTTCTGTGCTTCCATCGGAAGAACAGACCTACCGACAGGAAGCAGCAGCCAGCTGGTCCGCTCTGTACAGGAGAAGATTATGACACTTCCGGATGATACAAAGATCTATCCGGGACATATGGAAGAGACATCAGTTCAGTTTGAGAAGGAGCATAATCCATTCATATGA",
    "translation": "MKVESIVLGSIGTNCYIVTNEETKECFAVDMAECPQEYVNYIKNNGLEMKALFLTHGHFDHIMGIDDFLKAFPVPVYAGEDELPVIEDDRLNVSCMYGPKYAFHGAQPVRDGQVIECAGIEVDVLHTPGHTVGGCCYYLPKEHRLFSGDTLFCASIGRTDLPTGSSSQLVRSVQEKIMTLPDDTKIYPGHMEETSVQFEKEHNPFI",
    "product": ""
   },
   {
    "start": 10652,
    "end": 11797,
    "strand": 1,
    "locus_tag": "ctg21_9",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,652 - 11,797,\n (total: 1146 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGACCGGAGTCCGTCCGACAAAGCTTGTAATGCAGAAAATCGAGCAGGGAATGACAAAAGAAGAAATCTTTGGATTTCTAAAAGAACAATATTGTGTTGGTGATAAAAAGGCACAGATTGCCTATGAAATTGCTTGCCGTGAAAAGGCACTTCTTGATCAGTTGGACTGTAAAAATGGCTATAGCCTGTATGCAGGAATTCCATTCTGTCCAAGCATCTGCTCCTACTGCTCATTCAGCTCTTCACCAATCGCTGAGTGGAAAGATCAGGTAGATCGTTACCTTGACGCAATGATCAAAGAATTGAAAGCTACAGCAAAGCTGATGCAGGGAAAGACGCTGGATACCGTATATATCGGCGGCGGAACACCGACAACACTCGAGGCAGATCAGCTTGACCGTCTGCTTGGAACAATCCGGAAGAATTTTGACCTGGAGCATGTGCTTGAGTTTACAGTTGAAGCCGGAAGACCGGACAGTATCACACGAGAAAAGCTCGAAGTGATCCGCAAATATCCTGTAACCCGCATCTCTGTCAACCCACAGACAATGCAGCAGAAGACACTGGATCTTGTCGGAAGAAAACATACGGTAGAAGATGTAGAACAAATCTTCAACCTCGCACGTGAGCTTGGATTCGATAATATCAATATGGATCTGATCGCCGGACTTCCGGGAGAAGATGCGGCAGATATGCAGGATACACTTGAGAAGATCGAGAAGCTTCACCCGGACAGCCTGACAGTACACGCACTCGCGATCAAACGTGCTGCGAAGTTCGGTCAGGAAGGAAGAACAATGGATCCGGGGACTGAGATCACACAGATGGTCGAGGCGGCAGCAGCGTCAGCAGAACGCATGGGACTTGTGCCATATTACCTGTATCGCCAGAAGAACATTGCCGGAAACTTCGAGAATGTTGGATATGCAGAGCAGGACAAGGCTGGGGTGTATAACATTTTGATCATGGAAGAGAAACAGGCCATCCTTGCTTGCGGGGCCGGAGCATCCACCAAACGTGTATGGAATCTACCAGACGGTTATCACATCGAAAGATGCGAGAATGTCAAGGATATCAAGCAATATATCGCTAGAATTGATGAGATGATTGAACGAAAAAAAGCACTTTTTGAGAAGGATTGA",
    "translation": "MLTGVRPTKLVMQKIEQGMTKEEIFGFLKEQYCVGDKKAQIAYEIACREKALLDQLDCKNGYSLYAGIPFCPSICSYCSFSSSPIAEWKDQVDRYLDAMIKELKATAKLMQGKTLDTVYIGGGTPTTLEADQLDRLLGTIRKNFDLEHVLEFTVEAGRPDSITREKLEVIRKYPVTRISVNPQTMQQKTLDLVGRKHTVEDVEQIFNLARELGFDNINMDLIAGLPGEDAADMQDTLEKIEKLHPDSLTVHALAIKRAAKFGQEGRTMDPGTEITQMVEAAAASAERMGLVPYYLYRQKNIAGNFENVGYAEQDKAGVYNILIMEEKQAILACGAGASTKRVWNLPDGYHIERCENVKDIKQYIARIDEMIERKKALFEKD",
    "product": ""
   },
   {
    "start": 12016,
    "end": 12246,
    "strand": 1,
    "locus_tag": "ctg21_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg21_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg21_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,016 - 12,246,\n (total: 231 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg21_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg21_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTACAGCGTTAGGAGGAAACAGCAGATGTTAAAGATACGATTAATGGGAACGAAAAGTGATATTAGATGGTTTCAAAATTTTTTACAGATTGATTCTGACATAGAGGTATTAGAATTATCAGATATCTATCCGAATAAAGGAACAGATAGATATTATAGATCATATGCAGAAGTAGAAAGAAAAGATGGCAACGCAGGCCGCCCAACAGAGAATGGAAAAAGCAAATAA",
    "translation": "MYSVRRKQQMLKIRLMGTKSDIRWFQNFLQIDSDIEVLELSDIYPNKGTDRYYRSYAEVERKDGNAGRPTENGKSK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 1047,
    "end": 2929,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 12929,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r21c1"
 },
 "r27c1": {
  "start": 1,
  "end": 16318,
  "idx": 1,
  "orfs": [
   {
    "start": 108,
    "end": 770,
    "strand": -1,
    "locus_tag": "ctg27_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 108 - 770,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGGTTAGTATTGATGAAACGAAAGTAAAAGAATGGATGAATGAATTTTGCTCTACATACGATTCCATTGGAAAAATACGTTCTATTACGACACCGACGGGAAAAACAGCAAGTGTTTCGGGAGGAACATATGGTTGGTCAGTCGACGAGCCAGAAGAAATCAGGAAATTGATTGAGAATATTAAAAGTGGTGAAAGAGTAGAAAGAGAACCGGTGTATGAAAAAACGGTAGCATCTCATTCGCAGCAGGATTGGGGAGATACATATGTTGAGGTAGATCTTTCAACGCAGCATATGTGGTATATTGTGAATGGTTCAGTACAATTAGAAACAGATATTGTTACAGGACTTGCAAGTGATCCGAACAGAGCGACTCCATCAGGGGTATATTCTATTCTTGAAATGAAAAGAGATAAAGTACTTACTGGAGAAACAAATCCAAGCACAGGAGAACCTATTTATAGAACGAAAGTTTCTTATTGGATGCGTGTTACATGGACGGGAATCGGATTTCATGATGCAATCTGGCAGTCGGCGTTTGGTGGAAACAGGTATCAGACTTCGGCAGGCTCGCATGGTTGTATTAATATGCCGTTGGATCAGGCAGCTTCTTTATATGATATGTTAGAGATGGGAACACCAGTAGTTATACACGAGTGA",
    "translation": "MEVSIDETKVKEWMNEFCSTYDSIGKIRSITTPTGKTASVSGGTYGWSVDEPEEIRKLIENIKSGERVEREPVYEKTVASHSQQDWGDTYVEVDLSTQHMWYIVNGSVQLETDIVTGLASDPNRATPSGVYSILEMKRDKVLTGETNPSTGEPIYRTKVSYWMRVTWTGIGFHDAIWQSAFGGNRYQTSAGSHGCINMPLDQAASLYDMLEMGTPVVIHE",
    "product": ""
   },
   {
    "start": 957,
    "end": 2627,
    "strand": -1,
    "locus_tag": "ctg27_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 957 - 2,627,\n (total: 1671 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAAACCCGAAAGAGAAAACCCGCGAGGAGCTGCAAGCCGAGATTGAGGACGGAAAGAAGAAAATCCGGCAGTTTGAAAACCGGGAAAAGATGTTGCGTCAGAAGTTATCCAAAGAAGAACGCAGAACGCGCAGCCACCGTCTTATCGTCCGGGGTGCAGTCTTTGAAAGCATTGTTCCGGAAGCAAAGAACATGACCGACGAGGAAGCCGCCCACCATAACGCCGTATTCGTAGGACGGGACGAGGACGGAGTACCACGCTACGCCCACCAACGCGGCACAGCCGGGAACTTCCGGCTTGATGTGAAAGGCAGCGACAAAGCCTTTAACTTCTGCTATCGGGGCGAGGGCGAAAGATTGTTTGTCTTTGAAGCCCCTATTGACCTCTTATCTTTTCTCTGTCTGTTCAAAAAGGACTGGCAAAAGCAAAGCTATCTTGCGCTGGGTGGCGTGGGAGATAAAGCCCTTATGTGCTTTCTCTCTGACCGCCCGAACATCAAGACCGTATATCTCTGCCTTGACAGCGACCAAGCCGGAAACGACGCTTGCAGCCGCCTTGTGGAGCTTATGCCGGAGGACTTGACCGTCCACCGCCTTATCCCTCTTTTCAAAGACTGGAACGAGGTGCAGACGCGCCGGAATGAAATCACAGACGGAAAATATCTGCGGGAAGCTGTCTATGGCTTGAAAGAACCGCCGCAGGAAGAAACCGTTGAGATTATCCGCATGAGCGAGGTTGACACACAGACCGTTGAATGGCTATGGAAACCGTATATCCCCTTTGGGAAAGTAACCATAGTACAGGGCAACCCCGGCGAGGGAAAGACCACCTTTGCGCTGCGCCTTGCCGTTGCCTGTAGTACTGGCGGGACGCTTCCGGGCATGAAGCCCATACAGCCGTTTCAAGTGATTTATCAGACCGCCGAGGACGGTTTGGGCGATACCGTCAAGCCCCGCTTGATAGAAGCCGCAGCAGACCTTGACCGGGTGCTTGTGATTGATGAAGCAAAACGGGAGCTTACCCTGTCCGACGAGCGCATAGAGAAAGCAATCATACAGAACGGGGCGCGTCTGATTATCCTTGACCCCATACAGGCGTATATGGGCGACAAAGCCGACATGAACAAGGCAAACGAGGTGCGCCCCATTTTTCGCCGCCTTGCCGAAGTTGCGGAGCGTACCGGGTGCGCCGTTATCCTTATCGGACACCTTAACAAAGCTGCCGGAGGACAGAGCGCATACAGGGGCTTAGGTTCTATCGACTTTAGAGCCGCAGCAAGGAGCGTCCTTTTAATCGGGCGCGTGAAGCGTGAGCCGAATGTGCGCGTTATCATTCACGACAAATCTTCCCTTGCGCCGGAGGGAAAGCCCGTTGCCTTTTGCCTTGACCCGGAAACAGGCTTTGAGTGGATAGGCGAATATGATATAACTGCCGACGAGCTGCTGTCCGGCGCGGGCGGCAACAACGCCACCAAAACCGAACAGGCTGAAAAGCTGATACTTGACCTACTGGCAGACGGAAAAGAATTTGCCAGCGAGGACATAGAGAAAGCCGCAGCCGACGCGGGGATTTCTGCCCGTACTGTCCGGGCGGCAAAGAAAAACCTTGACGGGCGCATTACTTCAAAGCGTATCGGCGCAGCATGGTATCACGCCCTAAAAAAGTGA",
    "translation": "MTNPKEKTREELQAEIEDGKKKIRQFENREKMLRQKLSKEERRTRSHRLIVRGAVFESIVPEAKNMTDEEAAHHNAVFVGRDEDGVPRYAHQRGTAGNFRLDVKGSDKAFNFCYRGEGERLFVFEAPIDLLSFLCLFKKDWQKQSYLALGGVGDKALMCFLSDRPNIKTVYLCLDSDQAGNDACSRLVELMPEDLTVHRLIPLFKDWNEVQTRRNEITDGKYLREAVYGLKEPPQEETVEIIRMSEVDTQTVEWLWKPYIPFGKVTIVQGNPGEGKTTFALRLAVACSTGGTLPGMKPIQPFQVIYQTAEDGLGDTVKPRLIEAAADLDRVLVIDEAKRELTLSDERIEKAIIQNGARLIILDPIQAYMGDKADMNKANEVRPIFRRLAEVAERTGCAVILIGHLNKAAGGQSAYRGLGSIDFRAAARSVLLIGRVKREPNVRVIIHDKSSLAPEGKPVAFCLDPETGFEWIGEYDITADELLSGAGGNNATKTEQAEKLILDLLADGKEFASEDIEKAAADAGISARTVRAAKKNLDGRITSKRIGAAWYHALKK",
    "product": ""
   },
   {
    "start": 2741,
    "end": 3763,
    "strand": -1,
    "locus_tag": "ctg27_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,741 - 3,763,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACGCAAAGAAGTTTTCCGACGCTATGGGCGAGCTTGACAATAAATACATTGACGAAGCCCTTAACTATAAGAAAAAGGTCAAGAAGCCCATTTGGATTAAATGGGGAGCTATGGTAGCTAGTTTACTTCTTGTCTTTACTATGTCTGTTCCAGCATTAGCGGCAGCAGATTTTGGACCAGCTTATAATCTACTCTACAAGGTATCGCCAGCAATTGCTCAAAAGTTAAAGCCTGTTAGTATGTCCTGCGAGGATAATGGGATTAAGTTTGAGGTCATTTCGGCTTATGTTGAGGGTAACGAAGCAAAGATTTTTATTTCCGTACAAGATATTGACGGAGATAGAATTGATGAAACGACAGATTTGTTTGATAACTTTAGTATCAATACACCTTTTGATTGTAGCAGTTCGTGTGAAAATATAAGCTATGACACCGAAACAAAAACCGCCACTTTCCTAATTTCTATATCACAATGGAATGAGAAAGACATTATTGGTGAAAAAATTACTTTTTGTGTCCGAGAAATGCTGAGCAATAAGCAGGAATATGACGCGATATTGACAAATTTGGATTTGATCCAAATTAGTGCTACACCAAAAACAATTACCCCGACTCAAATTTTTGGTGGTGGGGGAACAAACTACAATGAAATGAAAAACAATTTTCAGGCATTGAAAACAACAGGTATTCTTTGTTCCCCTATTGCTGGGGTAGATATTACAGCTATGGGATATGTGGATGGGAAATTGCATATACAAGTCAAGTACGAGGATAGTTTAGAAACGGATAATCATGGCTATATCTATTTCAAAAATGACAAGGGTGAGGAAATCCACTGTATCGCAAATATTGCATTTTCTACTGATAGTGAACATCAAGAACGGTATGTAGAATATGTTTATGATTTGTCAGATGTTGATTTGACCCAATATAAAGCATATGGATATTTTGTTACGAGCGATACACATATCGAAGGAAATTGGAGTGTTACTTTCCCATTAGAAAGCATAAGTCAATAA",
    "translation": "MNAKKFSDAMGELDNKYIDEALNYKKKVKKPIWIKWGAMVASLLLVFTMSVPALAAADFGPAYNLLYKVSPAIAQKLKPVSMSCEDNGIKFEVISAYVEGNEAKIFISVQDIDGDRIDETTDLFDNFSINTPFDCSSSCENISYDTETKTATFLISISQWNEKDIIGEKITFCVREMLSNKQEYDAILTNLDLIQISATPKTITPTQIFGGGGTNYNEMKNNFQALKTTGILCSPIAGVDITAMGYVDGKLHIQVKYEDSLETDNHGYIYFKNDKGEEIHCIANIAFSTDSEHQERYVEYVYDLSDVDLTQYKAYGYFVTSDTHIEGNWSVTFPLESISQ",
    "product": ""
   },
   {
    "start": 3760,
    "end": 4320,
    "strand": -1,
    "locus_tag": "ctg27_4",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,760 - 4,320,\n (total: 561 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily (Score: 75.2; E-value: 8.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATAGAGGATGAAAAAATCATAGAAATGTTTTTTGAGCGTTCAGAACAAGGCATACGGGAGTTGGATATAAAATACGGAACAGTCTGCCACAAGCTTTCCTATCATATCGTAGGAAGTAGGCAGAACGCAGAGGAATGTGTAAACGACGCTTATTTAGGTGTATGGAACACTATTCCCCCTGCACGACCTAACCCACTTTTATCCTATGTTCTGAAAATCGTTCGGAACATTTCAATCAAAATTTATTGGAGAAAGGAAGCAGCCAAACGAAGCAGCCATTACACGATTGCTTTGGAGGAAATTGAAACCTATATAGCAGATACTCACACAGTAGAAGCAGAAATTGAAGCTAAAGAATTAGCCCGTATCATTGAAAGTTTTTTAGATACGCTGACTACTGAAAACCGCGTTATTTTCATGCGCCGCTATTGGTTTTCTGACAGCTACAAAGACATAGCCGAGGTTGTGGGGCTTTCAGAGAAAAATGTCTCTGTCCGGCTGACCCGTATCCGCGAAAAGATGAAACAATATTTAATTGAAAGAGAGGTATTTATATGA",
    "translation": "MIEDEKIIEMFFERSEQGIRELDIKYGTVCHKLSYHIVGSRQNAEECVNDAYLGVWNTIPPARPNPLLSYVLKIVRNISIKIYWRKEAAKRSSHYTIALEEIETYIADTHTVEAEIEAKELARIIESFLDTLTTENRVIFMRRYWFSDSYKDIAEVVGLSEKNVSVRLTRIREKMKQYLIEREVFI",
    "product": ""
   },
   {
    "start": 4404,
    "end": 4706,
    "strand": -1,
    "locus_tag": "ctg27_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,404 - 4,706,\n (total: 303 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGAACAGGGCTTACCAAACAGGAAAAGACCACTGATATATGGTTTGACGAGAAAGACCCCTTTATCCATATCCGCACCCACAACACCAACCTCAAAAAGCGGCTTGCCGCTTATGCCGAGCAGTACCCCGACGAGTGCTGCAAGACCGACACAGACCCCGAAACAGGCTGCATGGAGTTTGATATTGCAAAGGGGCGTTTCTCTTTCCGTCTGACCGCCCCATACAGTGAGGAACGCCGGAGAGCCGCCAGCGAAGCGGCGAAAGTTAACGCAAGCAATCTCACGCGAAGTGTGGTATAA",
    "translation": "MRTGLTKQEKTTDIWFDEKDPFIHIRTHNTNLKKRLAAYAEQYPDECCKTDTDPETGCMEFDIAKGRFSFRLTAPYSEERRRAASEAAKVNASNLTRSVV",
    "product": ""
   },
   {
    "start": 4841,
    "end": 5056,
    "strand": -1,
    "locus_tag": "ctg27_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,841 - 5,056,\n (total: 216 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGACAGAAAAGAAAGGAACACCCACCCCGCCGACCAAGCCGGACGGAATTATCACGACACAGAGGAACGGGCAGACCATTGTTGCGGAGCTGTTTTTCAATCCCAACGGCACAGAAACATTCTCCGACAAGCTGCTGAAAACGATACTTGCCGACAGTCTGCGTTTTTCTGCGTCTGACGGTCAAGAGCTGGAAAAAACAGAAATCTTGCGATAA",
    "translation": "MTEKKGTPTPPTKPDGIITTQRNGQTIVAELFFNPNGTETFSDKLLKTILADSLRFSASDGQELEKTEILR",
    "product": ""
   },
   {
    "start": 5136,
    "end": 6677,
    "strand": -1,
    "locus_tag": "ctg27_7",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,136 - 6,677,\n (total: 1542 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGCTGATAATTCGGCTGACACTTTTCAGGCCTAAGCCGTGGTTTTGTACATCCTCTATAGTATTGTTTTTTTGGGTGTGGGTAGTTGATAAGTTAAGTGCGGATACTTTATTAAATATATTAGTATTCTGTGCAATATTTAGTTTAGCATTATTTAGCCCTATAGATTCTGAAAGACGTCATTTAAATACAGATCAGAAAAAACAGTATAGAATTATAACAATATTCATAACGATAATATTTTGGGTGATATATGAATTATTGCTGTATATGGAATTTGAGGTATATGCAGTATGTATTGCGGAAGGAATTATGTTGACTGCAATATTACAGATTCCATGTGTAGTAAAAAAATATGAAAGAAATTTAACTTGTAAAAATAAGACGCTCAACGAGGATAACCGTTACAAGTGGAATAAAGCCACCTTGACCCATATCCTCACGCGGCAGGAGTATTGCGGCGATGTAGTCAATTTCAAGACTACAAAGCATTTCCGAGATAAGCGAAACCACTATGTAGACAGAAGCCAGTGGCACATCACAGAAAATGTGCATGAGCCGATTATTGACCGCACTGACTTTGAAAATGTGCAGCGGATTTTGGAAAACGCACCTGTCAAACGCCCCAACGGGGACGGAGAAATCCACCCTCTGTCCGGCTTGCTTTTCTGTAAAGACTGCGGTGCAAAAATGCACATTCGCATAGATTACAGGAACGGCGGCAAGCGCCATGTTGCCTATTGCAGCGAGTATCACAAGGGAAAAGACAAAAATCCCAAGTGCAGCTCTCCGCACATCATGGACGCGGATCTGCTCATGCAGACCGTCGCAGATGTGCTGAAAAAAATCGCGGAATACTCTATCAGCAACCGGGCAGAGTTTGAAGCCTTAGTGAAAAAGAGCCTTGCCATGCAGCAGACCGACAAGACAAAGAAACAGCAAAAGCGTATCCCGCAAATCACGACGCGCCTTGAACAGATTGACAAGGTGCTGAATAAACTTTATGAGGACAACGCGCTGGGTACTATCCCACAAGACCGCTATGAGCAGATGTCGCAGAAGTATTCCGAAGAATACTACTCACTGAAAGCGGAGCTTGAACAGCTTAGGGAGCAGCTATCCGCTTTTGAAAACGCGGGAGGACGGGCGCAGAAGTTTGTAAAGCTGATAGACCGTTACGCTGACTTTACCGACCTTACCCCGACTATCCTCAACGAGTTTATCAGCCGGATTGAAGTGCATGAGCGCGACAAGAAAAGGGCGAAACAGGCTATTCAGCATATCGGGATATACTTTAACCATATCGGCAGATTTGAAAATGAACTGACACAGCTTGCAGAGCCGACAGAGCAGGAAATCCGGCAAATGCGGGAGGAAATCGAAGAAGCAAGAAAGGAAAAGAGCCGCGCCTACCACCGCAACTATTCAAGAGAATACCGGGCGAGAAATCTTGAAAAGCAACGGGAGTATGACCGTATCAAAGCGCGGGAATATCGAGCGAAGAAAAAGGCGCAGGCTGCCGCCGCACTGTCCGCACCATAA",
    "translation": "MLIIRLTLFRPKPWFCTSSIVLFFWVWVVDKLSADTLLNILVFCAIFSLALFSPIDSERRHLNTDQKKQYRIITIFITIIFWVIYELLLYMEFEVYAVCIAEGIMLTAILQIPCVVKKYERNLTCKNKTLNEDNRYKWNKATLTHILTRQEYCGDVVNFKTTKHFRDKRNHYVDRSQWHITENVHEPIIDRTDFENVQRILENAPVKRPNGDGEIHPLSGLLFCKDCGAKMHIRIDYRNGGKRHVAYCSEYHKGKDKNPKCSSPHIMDADLLMQTVADVLKKIAEYSISNRAEFEALVKKSLAMQQTDKTKKQQKRIPQITTRLEQIDKVLNKLYEDNALGTIPQDRYEQMSQKYSEEYYSLKAELEQLREQLSAFENAGGRAQKFVKLIDRYADFTDLTPTILNEFISRIEVHERDKKRAKQAIQHIGIYFNHIGRFENELTQLAEPTEQEIRQMREEIEEARKEKSRAYHRNYSREYRARNLEKQREYDRIKAREYRAKKKAQAAAALSAP",
    "product": ""
   },
   {
    "start": 6962,
    "end": 7204,
    "strand": -1,
    "locus_tag": "ctg27_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,962 - 7,204,\n (total: 243 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAAGTAACAATTCCAAAGGAAAAAATGAATTATACAATAGACCTTCTTATCACTATGGTGACAGATGAGATTGCAGAAGAAACGGGCAAGGACAGAAAAGAGATATTGACAGATTTTCTTTGTTCAAAGACAGGAAAAGCACTGTATGATGAGAACACAAAGCTGTGGTGCAATGGTCCAGCATATATTGCTGAATTGTATAGGGAAGAGTTAAAGAAATCCGGATATCAGATTTGA",
    "translation": "MAEVTIPKEKMNYTIDLLITMVTDEIAEETGKDRKEILTDFLCSKTGKALYDENTKLWCNGPAYIAELYREELKKSGYQI",
    "product": ""
   },
   {
    "start": 7192,
    "end": 7758,
    "strand": -1,
    "locus_tag": "ctg27_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,192 - 7,758,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCTTGAGTTAAAAGATGGATTTGTTCTCTATCATGGAAGTTATTGTGAAGTAAAAGAGCCAGATCTTGCCAAATGTGCAAAGAGAAAAGATTTTGGGCAGGGATTTTATTTAACCACATCCAAGGAGCAGGCAGAAAGTTTTCTGAGAACCTCAATAGCCAAAGCAATCGCAACCGGAACAATTGAAGAAGGACAGAAGTTTGGATATATTTCAACTTTTGAATTCAACCTTTCAGGAAATCTTGAAACGCATATTTTTGAAAAGGCAGATGTAGACTGGTTACATTGCATTGCAGCTCATCGAAAGAAAAAAATGTTTATCGAAGTGGAACGTGAAATGGCAAGGTATGATATCATTGCAGGAAAGATTGCGGATGATGCAACAAACGCTACCCTTACCGCTTATCTCGCCGGGGCTTTCGGGACAGCAGGCGATAAGGAGGCAGACGATTTCTGCATCAGACAGTTGTTGCCCAATAAACTAAAAGATCAATATTGTTTTAAAACAGAAGCAGCTATTGAGTGTCTGAAATTTGTGAAAGGTGAGAAGATATGGCTGAAGTAA",
    "translation": "MLELKDGFVLYHGSYCEVKEPDLAKCAKRKDFGQGFYLTTSKEQAESFLRTSIAKAIATGTIEEGQKFGYISTFEFNLSGNLETHIFEKADVDWLHCIAAHRKKKMFIEVEREMARYDIIAGKIADDATNATLTAYLAGAFGTAGDKEADDFCIRQLLPNKLKDQYCFKTEAAIECLKFVKGEKIWLK",
    "product": ""
   },
   {
    "start": 7751,
    "end": 7975,
    "strand": -1,
    "locus_tag": "ctg27_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,751 - 7,975,\n (total: 225 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAAAAAACAGAGATTACTTTCATGCAAACAAGACTAATCCGGCTTGCTTCAGAAGAGTGGCATTTATCTGTTGAACAGATTATCTACTTGTTTAAAGAAGCTGATGTTTTTGGATATATAGAAAAATGCTATGGGATTTTTCATTGTGAGGGTGATGAAGCTGTGCTTGAAGACATTACAGAATTTCTGGAAGGAAAGGGGATAAAGATTAGTGCTTGA",
    "translation": "MSEKTEITFMQTRLIRLASEEWHLSVEQIIYLFKEADVFGYIEKCYGIFHCEGDEAVLEDITEFLEGKGIKISA",
    "product": ""
   },
   {
    "start": 8000,
    "end": 8173,
    "strand": -1,
    "locus_tag": "ctg27_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,000 - 8,173,\n (total: 174 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGATATAAAAAATGAAGAATATGTTACATGCCCTCGCTGCGAGAAAGAAGTCTATAAGGATGCAATAACTTGTCCGTTTTGTAACTTTGGTATTATGGCATGGCTTGAAGGAGAGATTAATGAGAATGGAGAGTCAGTGAAAAAGAGTTCTAAGCAAAAATTTTATTGA",
    "translation": "MQDIKNEEYVTCPRCEKEVYKDAITCPFCNFGIMAWLEGEINENGESVKKSSKQKFY",
    "product": ""
   },
   {
    "start": 8221,
    "end": 8598,
    "strand": -1,
    "locus_tag": "ctg27_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,221 - 8,598,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGTTTTGGATTTTTATGTTGATTATGGATTTGCTTCTTCCATTTACGATGATTGGTTTTGGAAGATATTTTATGAAAAAGGCTCCAAAGGAAATAAATTCAGTTTTTGGATATCGGACTTCGATGTCTATGAAGAATAAAGACACATGGGAATTTGCTCATAAATATTGTGGTAAAGTCTGGTATGTCTGTGGAATGGTTATGTTGCCGATAACAGTAATATTCATGCTTTTAGTAATTGGAAAAAATGAAGATTGTGTTGGGAGTATGGGAGGTATTATCTGTGGTGTTCAACTTATTCCTTTAATTGGGTCTATTCTCCCAACAGAAATAGCATTAAAAAAGAATTTTGATAAGAATGGAACAAGACGATAA",
    "translation": "MGFWIFMLIMDLLLPFTMIGFGRYFMKKAPKEINSVFGYRTSMSMKNKDTWEFAHKYCGKVWYVCGMVMLPITVIFMLLVIGKNEDCVGSMGGIICGVQLIPLIGSILPTEIALKKNFDKNGTRR",
    "product": ""
   },
   {
    "start": 8629,
    "end": 9261,
    "strand": -1,
    "locus_tag": "ctg27_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,629 - 9,261,\n (total: 633 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCTTTTGATTTTAAGAAAGAATATAAAGAGTTTTATATGCCTAAAAATACACCAGCGATTCTAACAGTTCCTAAAGCAAATTATATTGCAGTCAGAGGAAAAGGTAATCCAAACGAAGAAGGCGGGGCATATCAGCAGGCAATTAGTGCATTATATGCGGTTGCGTATACTTTGAGAATGAGTTACAAGACAGATCATAAAATTGAAGGATTTTTTGAATATGTAGTTCCACCACTTGAAGGATTCTGGTGGCAGGAAAATATACATGGTGTAAATTATGCAGATAAAGATTCATTTAATTGGATTTCAGTTATCCGCCTGCCTGATTTTGTGAATCAAAAAGATTTTGAATGGGCTGTTGAAACAGCAGCTAAAAAGAAAAAAATAGATTGTTCATCGGCAGAGTTTTTGACCATTGATGAGGGATTGTGTGTTCAAATAATGCACTTGGGGGCATTTGATGATGAACCTGCAACTGTTGCACTTATGGATGCTTATTTGGAGCAGAATGGATATGTTAATGATATGAATATGGAAAGATTGCATCATGAAATATATCTGTCTGATGCAAGAAAGGTTGTTCCAGAAAAATGGAAAACGGTCATTAGACATCCTATAAAGAAACTGTAA",
    "translation": "MAFDFKKEYKEFYMPKNTPAILTVPKANYIAVRGKGNPNEEGGAYQQAISALYAVAYTLRMSYKTDHKIEGFFEYVVPPLEGFWWQENIHGVNYADKDSFNWISVIRLPDFVNQKDFEWAVETAAKKKKIDCSSAEFLTIDEGLCVQIMHLGAFDDEPATVALMDAYLEQNGYVNDMNMERLHHEIYLSDARKVVPEKWKTVIRHPIKKL",
    "product": ""
   },
   {
    "start": 9287,
    "end": 9625,
    "strand": -1,
    "locus_tag": "ctg27_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,287 - 9,625,\n (total: 339 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAAAATATTAATATTGTTGCTATGTCTTTTACTTACGGCCTCAATCACGGGTTGTGGTACACAGTCAATAAAGCCGATTGACACAATTGAAGGAAACATGAAAACATACAGTGAAATGTCAGACGGTACATGGCAGTGCGATGGACATATCTACAAATACAGGTTGGAAATCAGTGGACGACTGAGTAATGCCGTTAAGGACAGCACATACATTTATTTAAGCAACATAGAAGATATTACCTTCGAACAAGCTTGGAAAGCATCTGGGCTTAGCAGTAATATGGATGATTACTTTGATATTGACGAAGCAGTATTGGTTGAATTACCAGACTGA",
    "translation": "MKKILILLLCLLLTASITGCGTQSIKPIDTIEGNMKTYSEMSDGTWQCDGHIYKYRLEISGRLSNAVKDSTYIYLSNIEDITFEQAWKASGLSSNMDDYFDIDEAVLVELPD",
    "product": ""
   },
   {
    "start": 9702,
    "end": 10034,
    "strand": -1,
    "locus_tag": "ctg27_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,702 - 10,034,\n (total: 333 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTAGCAGATTTAGCAACAGGCTCTGATTGGATAGTGTGGATTGTCTTTGCGATATTTGCTGTACTTTCTATTATTTTACTTTCTGGACATGGAAGCTGGTTCATTTCTGGATATAATACAGCTTCAAATGAAGAAAAGGAAAAATATGATGAAAAGAAGTTATGCAGAACAATGGGAATTGGAATGTCTATTATAGCAATTCTTGCATTAACTATGGGCTTGTTTGAAAATATTTTGCCTGCATTTTTTGTATATATTGCATTGGGGATTATTTTGGTTGATGTCGTGGTAATTATCATTTTAGGAAACACACTATGCAGAAAGTAA",
    "translation": "MKLADLATGSDWIVWIVFAIFAVLSIILLSGHGSWFISGYNTASNEEKEKYDEKKLCRTMGIGMSIIAILALTMGLFENILPAFFVYIALGIILVDVVVIIILGNTLCRK",
    "product": ""
   },
   {
    "start": 10084,
    "end": 10302,
    "strand": -1,
    "locus_tag": "ctg27_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,084 - 10,302,\n (total: 219 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATGTCCATATTGTGGTGAAGAAATGATAAGAGGATACCTAATGAGCTCACGAGATATTGCTTTTGCAGTTGATGATGTGACAAAAGTAAAATTTTTTCGTATTAGAAAATCGGATGATTTGGAGTTGAGTAAAGGTTCAGGCGGAATCCCTCATTGTGAAGCTTATCGTTGCAGTAGTTGCAAAAAGATTTTGATTGATTATGCAAATAGATAA",
    "translation": "MKCPYCGEEMIRGYLMSSRDIAFAVDDVTKVKFFRIRKSDDLELSKGSGGIPHCEAYRCSSCKKILIDYANR",
    "product": ""
   },
   {
    "start": 10382,
    "end": 10564,
    "strand": -1,
    "locus_tag": "ctg27_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,382 - 10,564,\n (total: 183 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGGAGGATACAATCACAAATCGAATGCTGCACTGGTCATATACGCCGGAGCAGAAAGAGGAAGTGAAGAAGGCACTTGCGGCAGGAGTTCCGAAGGCAACGATTCTGACTTATTTCTATCCGGAGGTTACTGTGGAGAGGATGAGTTCATATCGGAAGAAGCAGTAAATGTTATCGCATAG",
    "translation": "MGGYNHKSNAALVIYAGAERGSEEGTCGRSSEGNDSDLFLSGGYCGEDEFISEEAVNVIA",
    "product": ""
   },
   {
    "start": 11106,
    "end": 13571,
    "strand": -1,
    "locus_tag": "ctg27_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,106 - 13,571,\n (total: 2466 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAACAGTAACAAAAACAGCGCTTGCCAATGTAAAACAGAACAAAGGAAGAAACTTTTTATGTGGATGCGCCATTGCACTGACTACGTTTCTGATATTTGTTGTTTTAACGGTGGGATATGGAATGATCCGCGTACAGCTTGCATCGGTGGATGCTTATTATCCAACTTACCATATTATGTTCCGCCAAGTTTCCGAGAAAAACACCAAAGCACTTCAGGTGCATAATGATATAGAAGAAATTGGTCTGAGAATGGATTTGGGACAGATTATAGATGATGATGCCACAATCATTATGACCGCTATGGATAATAATGGGATTCGGTTGAACAAAGCGGAGTTAGAAGAAGGAACTTTCCCAAAAAATGAAAAAGATATTGTTGTTTCCAAGGGAGTTTTAGAGGAACTGGGAATTCAGGGGAAATTGGGTGATGAAATCACGATTCCATACCAAATTTACGAAAAAGACGGTATGGGATATGCGAAAGAAGACACTTTCCGCATCTGTGGCTTTATGGAATCTTCTGATTTGAATAAAGAAAAGAAAATGTATTTTGTGATGAATTCCATGGAATATGCGAAACAGATGATACCGGAAGCAGACAGAGAATATCGTGTGATGTTCCGTCTGGCAGATGCAGAGCATATGACAACAGATGAAATCGAAGAGAGGGGAAAAGAAATCGGAGAGGATTTTGGTGTACCTGAGGGAAATGTGGTAGAAAACAGAGAGTATTTGGTTGCAAATTATACGGATCCGTCATTTGTAAAAGGAATGATCGTGGTAATCGTTATGGTTGTTTTAGCAGGAATCCTGACTATTTACAGTATTTATTATGTGTCTATGATACCAAAAGTACAGGAATATGGAAAATTAAAAGCCATAGGCTCCACCAAAAGACAGATTCGGCAGATGGTATTCCGTGAAGGAATGCTGGTTACGGCGCTTGCCCTCCCTGTAGGATTGCTTATCAGTAGTTTCCTGTCCAGATGGATTATGAAACAGATGATTACTTTTATGGCAGGCGAAGACCCTCTAATGCAGGTAGCAGCAGAACTTGTAAAAAATGGTGAGGTATCTTTGCTGCACTGGTGGATTTATGCGATTACCATTATGGCGGTACTCTTTACTTCCGCAGTTTCTTTGGCAAAACCGATGCGAATTGCTGCCAAAGTTTCGCCCATTGAGGCTATGCGTTATCAGGGGTTAGAAAAACGTGGGAAAAAAGTACGGAAAGGCTATCAGAATCTCACGATTTTTCGTTTGACAAAAGCAAATATGGCAAGAAATAAAAAGAGGACTGGGATTACGATTGTTACATTAGGAGCAACTGGTATTCTGTTCATGGTTGTGGCAACTATTTTATCTTGCGCGGCACCGAAAGAAATTGCAAGAAAGGATATTGAATCTGATTATAAAATTGAATTGGAAACATGGGGTGGGGACAAAATGAATCCGGACAGAGACTGGAGACAGGTTCAGCAGAATAACCCTTTGACGAAAGCGTTTATTGATCAGGTTCGTGATGTAGACGGTGTGGAAGAGGTAAAGGTAAAAACATTTATGAATGGCGAAATTCCGAAACTATCTATGGATGGTGAAATTTGGGGCGCGGATATTATTGGACTGGATGCATCTTATGCAGAAACGCTGGAAAAAGGAGAGATACAAGGACATGTGACATATGAAGAATTGGAAAAAGGAGATAAAATCCTCATGTCTGCTAATATGCTATACTGGTTCCCGGAACTGAAAGTGGGAGATTCCTTGAAGATGGTTTTGAATATGGGAGATGATCAGGTAGAAAAGACTTTTGAGATAGGAGCCATCGGAGATTACTATGAAAGCCTTGGCGGAAGTTCATTTTATCTGCCCCAATCAGTGTTGGAAAAAATGAATCCCAATAATCTGAACTACACACTGGAAATCACAGTGAATGATCAGAAAAAGAACAGTGCATATCAGGAACTTCAGGCACTTGCCGACAACAGTGAATACCTGGTGACAGGAAGTTATGAAGAGCAACTTCAGAAGTGGGAAAAGAATATGCGGTTGATGAGCGTTTTGTGTTATGCATTTCTGATTATTCTGGGTGGAATTGGAATCATGAATCTTGTGAACACTATGATGAACAGTATTTACACAAGAAGGCGGGAGCTTGGAATGATACAGGCGATAGGAATGTCTGAAAAACAGTTGATCCGTATGCTGCAACTGGAAGGAATCATCTATACTTTGGGAACATTGGCAGTTTCTGTGGGCATTGGAAGTCTTGTAGGATATGGTGCATTTCTTTATGCAAAAACCAAACACATGTTTCAGATCAGTGAGTATCATTTTCCAGTGGTCCCAGCAGTGCTTTTGATTTGTGTGGTTGCCTTTTTACAGGTACTGCTCACATATGGAGTATCTGCAAATTTCCGAAAATTGAGTTTGATTGATCGGATACGATATGCAGAGTAA",
    "translation": "MKTVTKTALANVKQNKGRNFLCGCAIALTTFLIFVVLTVGYGMIRVQLASVDAYYPTYHIMFRQVSEKNTKALQVHNDIEEIGLRMDLGQIIDDDATIIMTAMDNNGIRLNKAELEEGTFPKNEKDIVVSKGVLEELGIQGKLGDEITIPYQIYEKDGMGYAKEDTFRICGFMESSDLNKEKKMYFVMNSMEYAKQMIPEADREYRVMFRLADAEHMTTDEIEERGKEIGEDFGVPEGNVVENREYLVANYTDPSFVKGMIVVIVMVVLAGILTIYSIYYVSMIPKVQEYGKLKAIGSTKRQIRQMVFREGMLVTALALPVGLLISSFLSRWIMKQMITFMAGEDPLMQVAAELVKNGEVSLLHWWIYAITIMAVLFTSAVSLAKPMRIAAKVSPIEAMRYQGLEKRGKKVRKGYQNLTIFRLTKANMARNKKRTGITIVTLGATGILFMVVATILSCAAPKEIARKDIESDYKIELETWGGDKMNPDRDWRQVQQNNPLTKAFIDQVRDVDGVEEVKVKTFMNGEIPKLSMDGEIWGADIIGLDASYAETLEKGEIQGHVTYEELEKGDKILMSANMLYWFPELKVGDSLKMVLNMGDDQVEKTFEIGAIGDYYESLGGSSFYLPQSVLEKMNPNNLNYTLEITVNDQKKNSAYQELQALADNSEYLVTGSYEEQLQKWEKNMRLMSVLCYAFLIILGGIGIMNLVNTMMNSIYTRRRELGMIQAIGMSEKQLIRMLQLEGIIYTLGTLAVSVGIGSLVGYGAFLYAKTKHMFQISEYHFPVVPAVLLICVVAFLQVLLTYGVSANFRKLSLIDRIRYAE",
    "product": ""
   },
   {
    "start": 13568,
    "end": 14239,
    "strand": -1,
    "locus_tag": "ctg27_19",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,568 - 14,239,\n (total: 672 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 213.5; E-value: 5.4e-65)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKAILETRDLVKYYGKGDNLVKAIDHTDLIIEPGEFTAIVGRSGSGKSTLLHMLGGLDRPDSGKVLIEGRDIFKLKDEKLAVFRRRKIGFIFQSYNLVPSLNVWENIVLPIGLDGKKVDTEYVMDIICRIGMEDKLKSLPNTLSGGQQQRVAIARALASRPAIILADEPTGNLDSKTELEVISMLKSCVSEYGQTLVMITHDETIAQMADRMIVIEDGKVVRA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGCAATATTAGAAACAAGAGATCTTGTGAAATATTATGGAAAAGGCGATAATTTGGTGAAAGCTATTGACCATACAGATTTAATAATCGAACCAGGTGAATTTACAGCAATTGTAGGACGTTCTGGATCGGGAAAAAGTACTCTTCTTCATATGCTGGGAGGATTGGACCGTCCTGATTCCGGAAAGGTTTTGATAGAAGGAAGAGATATTTTTAAACTGAAAGATGAAAAACTTGCAGTGTTCCGCAGAAGAAAGATTGGGTTTATTTTCCAAAGTTATAATTTAGTACCATCCTTAAATGTTTGGGAAAATATTGTGCTACCCATTGGATTGGATGGAAAGAAAGTGGATACAGAGTATGTTATGGATATTATCTGTAGAATCGGAATGGAGGATAAATTGAAATCCTTACCGAATACTCTTTCTGGTGGGCAACAGCAGCGGGTTGCTATTGCAAGAGCGTTGGCATCCCGCCCGGCGATTATTTTAGCAGATGAACCAACAGGAAATTTGGATTCCAAGACGGAGTTAGAAGTGATTTCTATGTTGAAATCCTGTGTTTCAGAATATGGGCAGACACTGGTTATGATCACGCATGATGAGACCATTGCGCAGATGGCTGACCGTATGATTGTCATTGAAGACGGTAAGGTGGTGAGAGCATGA",
    "translation": "MKAILETRDLVKYYGKGDNLVKAIDHTDLIIEPGEFTAIVGRSGSGKSTLLHMLGGLDRPDSGKVLIEGRDIFKLKDEKLAVFRRRKIGFIFQSYNLVPSLNVWENIVLPIGLDGKKVDTEYVMDIICRIGMEDKLKSLPNTLSGGQQQRVAIARALASRPAIILADEPTGNLDSKTELEVISMLKSCVSEYGQTLVMITHDETIAQMADRMIVIEDGKVVRA",
    "product": ""
   },
   {
    "start": 14348,
    "end": 15484,
    "strand": -1,
    "locus_tag": "ctg27_20",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,348 - 15,484,\n (total: 1137 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1003:sensor histidine kinase (Score: 133.2; E-value: 2.7e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCGAAGAAAGCGTACAGGAGTAGCTCTGGCAGCAGGGCTGCTTTTTCTGTTTGTGACAGAGATATTGTTGCTGTTTCTGGCAGGAAATAGTTTATACAAGGAAGAGCAGGGGAAATTAGGGGCGTTAGTGCTGTCCCATCCGGAACAGGAGACGGAGTATATAGAGTTATTTGACAGAGGAAAGCAAAGAAATCGTCAGGAAGAGGAAGCGGGGAAAGAGCTGGAGGAGCGTTACGGGTATACTCCTTTTGATGGGAGAAGCGTGAAAACTTTTGCTGCATATGGAATAGGAATGGCGATGGTTTTTGTGGCAGGACTTGGAGTTTCATGGGTTTTGTTTTTGCGAAATAAAAGAGACCGGCAGCAAGATGAAAATAACCAGGAAGAACTTCGGGAAAAATATATAGAACTGCAGAATCATTTTGAAAAAGTAAGAGAAAAACTTTCCAGAGAAGAAAACAATACAAAATCTTTAATTACAGATATTTCCCACCAATTGAAAACACCGATTGCTTCATTGAAGATGAGTTGTGAACTGGCGGGGTCTGCCGATTTAACCTGGGAGGAACGGGAAGAATTTTATAAAAAGGAATGGGATGAAATTCAAAGACTGGAAAATCTTTTGGATTCACTGATTCATGTGTCCAGATTGGAATCTGGGATGATTCAGATTCAGCCAGAGATGGGCAGTCTGAAAAATACATTGGTACAGGCTGTAAACAGTGTGTATATGAAAGCGTATGAAAAATCCATAGATATTTCTCTGGATGAATTTCAGGATGTGCAAATTGTACATGACTCGAAATGGACAGGAGAAGTGTTCGTAAATATTTTAGACAACGCAGTAAAGTATTCGCCGGAGCATACAGAAATCCGAATTCGGGTAACAGAGCTTGCTACCTGCATGATGCTGGAATTTATCGACCAGGGAACAGGTATTCCGGCAGAAGAGGCGCATCGGGTATTTCAGCGTTTTTACAGAGGAAACCAAGAGTATGTAAAAAAACAGGAGGGCTCTGGGGTTGGACTTTATCTTGCCAGAAAAATTTTGGAGGAGCAGAAAGGCACGATTTGTGTAAAAGTAGCACCTGAAGGCGGTAATAATTTTGTGGTGACATTACCAAAGAAATAG",
    "translation": "MDRRKRTGVALAAGLLFLFVTEILLLFLAGNSLYKEEQGKLGALVLSHPEQETEYIELFDRGKQRNRQEEEAGKELEERYGYTPFDGRSVKTFAAYGIGMAMVFVAGLGVSWVLFLRNKRDRQQDENNQEELREKYIELQNHFEKVREKLSREENNTKSLITDISHQLKTPIASLKMSCELAGSADLTWEEREEFYKKEWDEIQRLENLLDSLIHVSRLESGMIQIQPEMGSLKNTLVQAVNSVYMKAYEKSIDISLDEFQDVQIVHDSKWTGEVFVNILDNAVKYSPEHTEIRIRVTELATCMMLEFIDQGTGIPAEEAHRVFQRFYRGNQEYVKKQEGSGVGLYLARKILEEQKGTICVKVAPEGGNNFVVTLPKK",
    "product": ""
   },
   {
    "start": 15457,
    "end": 16134,
    "strand": -1,
    "locus_tag": "ctg27_21",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg27_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg27_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,457 - 16,134,\n (total: 678 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 154.6; E-value: 5e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg27_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg27_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTTATTGGAAGATGATGAGAATCTGAACCGTGGAATCGCGCTAAAACTGCAGAAAGAAGGGTATCAGGTTTTTTCCGCTTTTCAGATTTCAGAGGCAGAAAAATTGTTTGATGAAAATAGAATAGATCTGGTAATCAGTGATATTACTCTGCCGGACGGAAACGGACTGGAGTTTTGCAGGAAGATTCGAAATAAGAGCAAAGTCTTTGTACTGTTTCTCACGGCAATGGATTCGGAAATTGATATGGTAAACGGCTATGATGCAGGGGCGGATGATTATATTACAAAGCCATTCAGCCTGATGGTACTGGTTTCAAAAGTTCAGGCATTTATGAGAAGAATGGAAGGAGTCTGCGGACACAACAGAATCTTATCGGGAAATATCGAAGTAAATTATGGAGAAATGAGAGCGTTAAAACGAAATGCTGATGGAGTGACTCCTTTGACATTAAGTAAAAAGGAACTTCAGATAATGATTTACTTTATGGAAAACGCAAGGCAGATTTTATCAAAAGAACAGATTTTAGAGTATGTCTGGGATGTTGACGGGCAGTTTGTAGACGATAATACAGTTCCTGTAAATATCAGCCGATTGAAAGGAAAAATCGGGAATGATTATATACAAAATGTAAGGGGGATGGGATATATATGGACCGAAGAAAGCGTACAGGAGTAG",
    "translation": "MLLEDDENLNRGIALKLQKEGYQVFSAFQISEAEKLFDENRIDLVISDITLPDGNGLEFCRKIRNKSKVFVLFLTAMDSEIDMVNGYDAGADDYITKPFSLMVLVSKVQAFMRRMEGVCGHNRILSGNIEVNYGEMRALKRNADGVTPLTLSKKELQIMIYFMENARQILSKEQILEYVWDVDGQFVDDNTVPVNISRLKGKIGNDYIQNVRGMGYIWTEESVQE",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 5135,
    "end": 6677,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 16318,
    "product": "cyclic-lactone-autoinducer",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "cyclic-lactone-autoinducer",
  "products": [
   "cyclic-lactone-autoinducer"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP cyclic-lactone-autoinducer",
  "anchor": "r27c1"
 },
 "r28c1": {
  "start": 728,
  "end": 13179,
  "idx": 1,
  "orfs": [
   {
    "start": 1754,
    "end": 2416,
    "strand": -1,
    "locus_tag": "ctg28_3",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,754 - 2,416,\n (total: 663 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 182.1; E-value: 1.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAAAATACTGGCAGTTGATGATGAACCGGCAATTTTGGAAATGATAGAAAGCATTTTGAATAAGGATGGACATCTGGTTACCAAAGTAAGTAATCCACTAAAAATTAATATGGAAGAATTACATCGTTATGACCTGATTTTACTTGACATTATGATGCCTGGAATGGACGGCTTTGAATTATGCAAAAGAATCAGGGCACTTGTGGATTGTCCGATTTTGTTTCTTACCGCAAAAACGGAGGAAAACAGTCTGGTAAACGGACTTTCTTTAGGAGCAGATGATTATATTTCAAAGCCATTTGGAGTGATGGAACTTTGGGCAAGGATCAATGCACATCTTAGAAGAGAGCACAGGGAACATTCTGTCCGGATGGTTTTGGGGAGGGTCTGTATTCAAATATCTCAAAAGAAACTATTGGTTGATGATAAGGAACTTCCTCTTACGAAAGCGGAGTACGAAATCTGTGAATTTCTGGCTAAAAACAGAGGACAGGTTTTCTCGAAGGAACAGATATTGGAAGCGGTCTTTGGCTTTGACAATGAGAGTAATGACAGTACTATAATCACGCATATCAAAAATATAAGAGCAAAATTTGCGGATTATGATTATACACCGATAAAAACAGTCTGGGGGATTGGATATAAATGGGAAGAGTAA",
    "translation": "MAKILAVDDEPAILEMIESILNKDGHLVTKVSNPLKINMEELHRYDLILLDIMMPGMDGFELCKRIRALVDCPILFLTAKTEENSLVNGLSLGADDYISKPFGVMELWARINAHLRREHREHSVRMVLGRVCIQISQKKLLVDDKELPLTKAEYEICEFLAKNRGQVFSKEQILEAVFGFDNESNDSTIITHIKNIRAKFADYDYTPIKTVWGIGYKWEE",
    "product": ""
   },
   {
    "start": 2431,
    "end": 3171,
    "strand": -1,
    "locus_tag": "ctg28_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,431 - 3,171,\n (total: 741 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTGGAAGATCTCTTAATGCAGACTTGCGAAAGATGAAAGGAACATCTGTGATTCTGGCACACTTACTGATTCCGATTATAACCAGCGTTATATTTTTAATATATTACTTTTTTTCACCATGGAATGAAAATATGAAAGTGATTGCATTTTATCAGGCAATAGGAGCAGGACTTCCGGTACTTATTGGAATTTTTACAGCAAGTGTGATGGAACAGGAACAAAATGCAGGTGATTTTCAAAATCTGTTGTCTTTACCGGATAAACCTGCAGCATTTTTATCGAAACTGTTGATGCTACTGTTTTTGTGTCTGTGCTCTATCCTATTGACAGCAATCATATTCGGAATTGGATTTGGAAGAATCGCATCAAGCGATATCGAAATCATGAAAGGATGTATATTTGCAGCATTGCTGCTGTGGGGAAGCAGTGTTCCACTTTATCTGTGGCAGCTGATTCTGGCTTTTCAGTTTGGAAAAGGGGTATCCATTGGAGCAGGGATTATATCAGGACTAATTAGTGCATTGATGCTTACCGGACTTGGAGATTATGTGTGGAAATATGTATTTGTCTGCTGGACGGGTAGAGTACCATATACTTATCTGCAATCTGTATTGGGAGAAACTAGTGTAGGTGAATGGTTGTCATTCATACCAGGTTGCTTAATATTTACAGGGATTAGTATGGTATACTATTTTTGGTGGGTAAACCACTGGGAAGGAAACAGAATATCGGAATAG",
    "translation": "MIGRSLNADLRKMKGTSVILAHLLIPIITSVIFLIYYFFSPWNENMKVIAFYQAIGAGLPVLIGIFTASVMEQEQNAGDFQNLLSLPDKPAAFLSKLLMLLFLCLCSILLTAIIFGIGFGRIASSDIEIMKGCIFAALLLWGSSVPLYLWQLILAFQFGKGVSIGAGIISGLISALMLTGLGDYVWKYVFVCWTGRVPYTYLQSVLGETSVGEWLSFIPGCLIFTGISMVYYFWWVNHWEGNRISE",
    "product": ""
   },
   {
    "start": 3173,
    "end": 3904,
    "strand": -1,
    "locus_tag": "ctg28_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,173 - 3,904,\n (total: 732 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTTAATATTATAAAAGCAGAACATCAAAAAGCCAAAAGAACCATGCGAAAAAAGTTTATCTGGGGATTTCCTCTTCTTACATTTGTCATGGCATTTATATTTACTTTTGGGATGACAAATGTTTATGCAGAAAGTGTTTGGAACTGGTGGTATACACTTTTGCTGCCGGGGATGATTGCTCTATTTTGTTATCTTTCTGTGGCGCAGGAGAAAAAGATAAAATACTATCATTTAATGACTATTCCCACAGACAGAAGAAAATTGTTGCTGGGGAAAATTATTTATATTGGGTACATGATTTTGTTTTCTAATGTGATTGTGTTTGCAGGAGCAACGCTTGGAGGCTTTCTTCTAACGACACATGTTCCAGTTGGAGGAGCGTTGATTGCAGTATTGTTTCTGACGGTTTCTGAGTTATGGGAGATTCCGGTAGCTTTATTTTTAAGTGAACGATTTGGAATGATTGTAAACCTGTTCGTCTGCCTATTTATTACCGTCAGCGGTGTGGTAATATCACAAACCAGAATCTGGTATGTACTTGTTTCTGCAATCCCTATGCGAATGATGTGCCCGTTGCTTCATGTTTTACCAAATGGACTTGCCGCAGAAGCAGGGAATCCTCTTTTGGATACGGGAGTCATTGTTCCGGGAATGTGTCTCTCAATCATCTGGTTTGTTTTTGTAACGGTTCTGTTTTTGAAATGGTTTGAGAGAAGAGAGGTGAAATAA",
    "translation": "MVNIIKAEHQKAKRTMRKKFIWGFPLLTFVMAFIFTFGMTNVYAESVWNWWYTLLLPGMIALFCYLSVAQEKKIKYYHLMTIPTDRRKLLLGKIIYIGYMILFSNVIVFAGATLGGFLLTTHVPVGGALIAVLFLTVSELWEIPVALFLSERFGMIVNLFVCLFITVSGVVISQTRIWYVLVSAIPMRMMCPLLHVLPNGLAAEAGNPLLDTGVIVPGMCLSIIWFVFVTVLFLKWFERREVK",
    "product": ""
   },
   {
    "start": 3897,
    "end": 4610,
    "strand": -1,
    "locus_tag": "ctg28_6",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,897 - 4,610,\n (total: 714 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 180.7; E-value: 5.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMEMMLQTQNLCKYFRKQKAVNNVSLNIEKGQIYGLLGPNGAGKSTTLKMLTGMMKPTAGKIYFDGKLLDRKDLSKIGALIENPPIYENLSARENLKVRQLLLGTDENRIDEVLQIVSLTNTGKKKAGQFSLGMKQRLGIAMALLGEPELLILDEPTNGLDPIGIEELRELIRSFPEQGITVILSSHILSEVQLLADKVGIISGGILGYEGALKQGDNLEDLFMNVVRKNQKAGEIHG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAATGATGTTACAGACACAAAATCTATGTAAATATTTTAGAAAACAGAAAGCGGTAAATAATGTTTCACTTAATATCGAAAAGGGACAGATTTATGGACTGCTTGGACCGAATGGCGCTGGTAAATCTACCACATTGAAAATGCTGACCGGTATGATGAAACCAACTGCAGGAAAGATTTACTTTGATGGAAAACTTTTGGATAGGAAAGATTTATCAAAAATAGGAGCGTTAATTGAAAATCCGCCTATTTATGAAAATCTTTCCGCCAGAGAGAATTTGAAGGTAAGACAATTATTGCTTGGTACAGATGAAAACAGAATTGATGAGGTCTTGCAGATTGTATCACTTACAAACACCGGAAAGAAGAAAGCAGGACAGTTTTCTTTGGGGATGAAGCAAAGACTAGGCATTGCAATGGCATTGCTTGGAGAACCGGAACTTTTGATATTGGATGAACCTACGAATGGATTAGATCCAATAGGCATCGAGGAATTACGAGAGCTGATCCGGTCTTTTCCGGAACAGGGAATCACTGTAATTCTCTCCAGTCATATTCTCTCAGAGGTACAGTTACTTGCAGATAAAGTCGGGATTATTTCAGGTGGAATCTTAGGATACGAAGGAGCATTAAAGCAGGGAGATAATCTTGAAGATTTATTTATGAATGTGGTAAGAAAAAACCAGAAAGCAGGTGAAATCCATGGTTAA",
    "translation": "MEMMLQTQNLCKYFRKQKAVNNVSLNIEKGQIYGLLGPNGAGKSTTLKMLTGMMKPTAGKIYFDGKLLDRKDLSKIGALIENPPIYENLSARENLKVRQLLLGTDENRIDEVLQIVSLTNTGKKKAGQFSLGMKQRLGIAMALLGEPELLILDEPTNGLDPIGIEELRELIRSFPEQGITVILSSHILSEVQLLADKVGIISGGILGYEGALKQGDNLEDLFMNVVRKNQKAGEIHG",
    "product": ""
   },
   {
    "start": 4929,
    "end": 5411,
    "strand": -1,
    "locus_tag": "ctg28_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,929 - 5,411,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAGTCTTGACTCTGACAAAAAAGCAGGAAAATCCGGAGCAGTAGAAGAAGCAACTGCAAACGACAACAACGGATTCTTCAAAGACAACGCGAAGATTGACTTCTCCAACGTAAAGGTTGAGCCTTTATTTGAAGAAGAGGTTGATTTCGATACATTCAGCAAATCTGATTTCCGTGCCGTAAAGGTTAAAGAGTGTGTAGCAGTTCCGAAGAGCAAGAAGCTCCTTCAGTTCACACTGGATGACGGAACAGGTATTGATAGAACAATCCTTTCTGGTATTCATGCATATTACGAACCAGAAGAATTAGTTGGAAAGACACTTATTGCGATCACTAACCTGCCACCGAGAAAAATGATGGGAATTGAATCTTGTGGTATGTTGCTTTCAGCAGTGAATAATCTGAAAGATTCAGAGGATGAAGAACTGCATCTTATTATGGTTGATAATCACATTCCGGCAGGCGCAAAGTTATACTAG",
    "translation": "MKSLDSDKKAGKSGAVEEATANDNNGFFKDNAKIDFSNVKVEPLFEEEVDFDTFSKSDFRAVKVKECVAVPKSKKLLQFTLDDGTGIDRTILSGIHAYYEPEELVGKTLIAITNLPPRKMMGIESCGMLLSAVNNLKDSEDEELHLIMVDNHIPAGAKLY",
    "product": ""
   },
   {
    "start": 5663,
    "end": 6904,
    "strand": -1,
    "locus_tag": "ctg28_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,663 - 6,904,\n (total: 1242 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1077:phage integrase family protein (Score: 143.3; E-value: 2.2e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGAAAGCAAAAGTAAAGCAGAGGAAGGACAGCAAAGGACGAGTTCTTCAAAAGGGCGAAAGCCAAAGAAAATTAGATGGGATGTACATATATACCTATGTAAATCCCTATGGAAAACGTTGTTATGTATATTCCAAAGATCTTTTTACACTACGAGAGAAAGAACAAGAATTAATTAAAGCCCAGATGGATGGATTGGATTACTATGTAGGTGGCCATGCGACAATTAACATGACATTTGACAGATATATGAGTACAAAACATAATCTGAGAGAAACCACGAGATCCAATTACCTGTATATGTTCAATCGATTTATTCGAGAGGATTTCGGAAATAAGTTTTTGACTGAGGTGAAGTATACAGATGTGAAATTGTTTTATTATCATCTGTTAAATGAGAAGGATATTGCAATCAATACATTAGATACGATTCATACTGTATTACATCCAATTTTTGATATGGCAGTTAGAGACGATATTATTAATAAAAACCCTACAGACGGAGTTCTGGCTGAAATTAAACGAAATAGTGGAAAGAATAAAGGGATTCGACACGCACTTACAATTGAACAGCAACAGGCATTTATGGATACTATCAGAACATTTCCTGAATATTATCACTGGTACCCATTATTTGCAACATTACTTGGTACCGGAATGAGAATCGGTGAATGTACAGGATTAACTTGGAATGATGTTGATTTTAAAAGGAGATGTATTAGTGTAAATCATGCAGCAACCTATTATACAAGAAATGGAGTTGCAGGATTTGCGATTTCAAGACCGAAAACAGAAGCTGGTATAAGACAGATACCAATGATGGATGCAGTCTATAATGCTTTGAAAAATGAATATGACAGACAGAAGAAAGACGGATTTTGTACCTATGAGCTTGATGGTGTTTCAGGATTTATATTCTCAAATAAATTAGGTTTGCTTCATAATCCACATTGCGTAAATTTGGCAATCAAAAGAATCTACGAAGCACATAATGCAAGAGAGATTATAGATGCGAAGAGAGAACACAGAGAGCCGGTTATTATCCCGCACTTTTCCTGTCATGTGTTGAGGCATACATTCTGTTCACGTTTATGTGAGAGTGATATGAATGTAAAAGTTATTCAAGAGATCATGGGACATAAAAACGTAGAAACAACATTAGATATCTATACAGAAGTCAACTATAATAAGAAAAAAGATTCATTAGAAGAATTAGCAAGTAAAATGCAATTCTTTTAA",
    "translation": "MAKAKVKQRKDSKGRVLQKGESQRKLDGMYIYTYVNPYGKRCYVYSKDLFTLREKEQELIKAQMDGLDYYVGGHATINMTFDRYMSTKHNLRETTRSNYLYMFNRFIREDFGNKFLTEVKYTDVKLFYYHLLNEKDIAINTLDTIHTVLHPIFDMAVRDDIINKNPTDGVLAEIKRNSGKNKGIRHALTIEQQQAFMDTIRTFPEYYHWYPLFATLLGTGMRIGECTGLTWNDVDFKRRCISVNHAATYYTRNGVAGFAISRPKTEAGIRQIPMMDAVYNALKNEYDRQKKDGFCTYELDGVSGFIFSNKLGLLHNPHCVNLAIKRIYEAHNAREIIDAKREHREPVIIPHFSCHVLRHTFCSRLCESDMNVKVIQEIMGHKNVETTLDIYTEVNYNKKKDSLEELASKMQFF",
    "product": ""
   },
   {
    "start": 6947,
    "end": 7156,
    "strand": -1,
    "locus_tag": "ctg28_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,947 - 7,156,\n (total: 210 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGATTCGGGGAGGTGTTAAGCTTATGGCAAATAAAGACGGGAGACCGCCAGTGGATGATCCAAAACAGAAAATCTTAGGGGTGCGGGTAACGGTCAGTGATCATGAGAGGATTAAGAAATACGCAGCCGAGCATCATAAGACAATATCACAAGTTGTAATTGAAGGTCTAGATCTTTTATGTAATAAAGAAGAAAAAGACAACTAA",
    "translation": "MMIRGGVKLMANKDGRPPVDDPKQKILGVRVTVSDHERIKKYAAEHHKTISQVVIEGLDLLCNKEEKDN",
    "product": ""
   },
   {
    "start": 7219,
    "end": 7485,
    "strand": -1,
    "locus_tag": "ctg28_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,219 - 7,485,\n (total: 267 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGAGAACAGAAAAAGCAAAATCTTACAGATCCTAACGTGAGAAAAAGATTTGTTACTTACAAGGAAGCAGCGGAACTCTATAGTATGGGACTGACGAGAATACAGGAACATACAAAGATGGCAGGAGCAACTTATAAAATGGGTAATAAGGTGCTTGTAAATACGGACATCTTTGAAGCGTATCTTGAACAATATAGAATTCCAGGAGATTATGAAGGAATGGCAAAGAAGTTTACTCCAGATCTTGTGGAATTGTACCAATGA",
    "translation": "MREQKKQNLTDPNVRKRFVTYKEAAELYSMGLTRIQEHTKMAGATYKMGNKVLVNTDIFEAYLEQYRIPGDYEGMAKKFTPDLVELYQ",
    "product": ""
   },
   {
    "start": 8648,
    "end": 8797,
    "strand": 1,
    "locus_tag": "ctg28_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,648 - 8,797,\n (total: 150 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAGATAGAAAAAACTTCTTGAGAAACTGGATTATGAAAATAGGTGAGAATTCTGTAGGAAAAAGCCTATTGTTCGGTACATATGATCCGTTAATTCCGGATGAACTTAAGCGAGAGGTTCAAAAGCAAAAAAGTAAAAGGAAATAA",
    "translation": "MVDRKNFLRNWIMKIGENSVGKSLLFGTYDPLIPDELKREVQKQKSKRK",
    "product": ""
   },
   {
    "start": 8878,
    "end": 9453,
    "strand": 1,
    "locus_tag": "ctg28_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,878 - 9,453,\n (total: 576 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAAAATTAATAGGATCAGGAACAGAAAAAAAGTAGTTGTGCTTTTAATGGCATTAAGTTTATTTACATCATATTGTTTATCTACAACTACAGTGTCTGCAACTCCAAAACAATTGCAGAATGAATTGGTAGAAAGTACTAAAACAGTGCCCCTTAATGATGAACCTTTAGAATCTAGGGTAGGTGGAATAACATATTCATATGGTACAGGACCATTATATGGAAAGAGTAGTGATTATACAGTATATAAAAACACGGTAAGTAATCCTAATTTACCACTTACAAAAGAAATTGGAAGCTATTCACTAACAGCGTTAGGTATTTTGTTAGGAAAGGAAAGCACTCCAGCAGGGATAGCAGCAACATGTGTTCAAACAGTATATGATAAATTTTATGGAACAAAAACAAAAGGTCTTTCATATAAGACCAAAATATATACACATAAGAGCTATTCTACTGGAAACACTCCATCAGGATATTGTGAAAAACAGGTTACTACATGGTATTCACAAAAGAATTATACAGGAACTTCAGTTACAACTATACAATTTAAGAACGGGTATTTATATTAA",
    "translation": "MKKINRIRNRKKVVVLLMALSLFTSYCLSTTTVSATPKQLQNELVESTKTVPLNDEPLESRVGGITYSYGTGPLYGKSSDYTVYKNTVSNPNLPLTKEIGSYSLTALGILLGKESTPAGIAATCVQTVYDKFYGTKTKGLSYKTKIYTHKSYSTGNTPSGYCEKQVTTWYSQKNYTGTSVTTIQFKNGYLY",
    "product": ""
   },
   {
    "start": 9453,
    "end": 9638,
    "strand": 1,
    "locus_tag": "ctg28_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,453 - 9,638,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAATTTAAAATTTATTTTTATTCTGTTAATAATATTAAATGTTATAGTAACTATTTTAGGTAGTGCATATTTATCTATAAAACAACAGGCAGAATTTTATAGAATAGTTATCCATATTAATGTAGGAATTGAATGTTTAATTTTATTGAAAACTTTCAAATATTTAAAAGAAAACGGATAA",
    "translation": "MKNLKFIFILLIILNVIVTILGSAYLSIKQQAEFYRIVIHINVGIECLILLKTFKYLKENG",
    "product": ""
   },
   {
    "start": 9756,
    "end": 10550,
    "strand": -1,
    "locus_tag": "ctg28_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,756 - 10,550,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTAGATATTTATGTTTGTGAAGATAACAAAATACAATTAGAGCTTATTTCTAAATATGTGTCAAATACAATTTTGATTGAACAACTAGATATGCAACTCGCTTGTGCATCAACAACTTCTGGAAAAATATTAGAACAAGCAAAAAAATCAGAAAACACAGGGGTATTTTTTCTTGACATTTGTTTGCAATCAGAAATGACTGGATTGATTTTGGCACAAGAACTAAGAAAAATTCAACCTAGATGTTTTATTATATTTATCACAAGCCATTCCGAAATGAGCATTTTAACATTTCAATATAAAGTAGAAGCACTGGATTTTATAATCAAAGATTCCTCAGAAAATATTAGAAAAAGAATACATGAATGCTTAATGGATATCAACAAAAAAATTTTGACTGTTAATAAAAAGCAACAAAAAAGTATTCTTATTACTCAAAATGACAGATTGATTGCTGTAGACTATGATGAAGTGTTATTTTTTGAAACTTCAGAAAACAACCATAAAATAATACTGCATGCCAAAAAGCGAGTAGTTGAATTTACCGGACACTTAAAAAGTGTTGAAGTACAATTAGATTATCGTTTTTATAGGTGTCACCGTTCTTATATTGTAAATACAGATAATATCAAAGAAGTTAATTTTCAAAAACTAACAATTTATATGGAAAATGGAGAAATCTGTCCAATCTCTGTCCGTGCCAAAACTAGCTTTAAAAAATATTATAATGAGCATCTAATATCAATAGGCAACACTGTGACTAGAATATCTAAGAAATGCAACAATGAGTAA",
    "translation": "MLDIYVCEDNKIQLELISKYVSNTILIEQLDMQLACASTTSGKILEQAKKSENTGVFFLDICLQSEMTGLILAQELRKIQPRCFIIFITSHSEMSILTFQYKVEALDFIIKDSSENIRKRIHECLMDINKKILTVNKKQQKSILITQNDRLIAVDYDEVLFFETSENNHKIILHAKKRVVEFTGHLKSVEVQLDYRFYRCHRSYIVNTDNIKEVNFQKLTIYMENGEICPISVRAKTSFKKYYNEHLISIGNTVTRISKKCNNE",
    "product": ""
   },
   {
    "start": 10728,
    "end": 11294,
    "strand": 1,
    "locus_tag": "ctg28_15",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,728 - 11,294,\n (total: 567 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAATTTATAACAGAAAAATTATTAAATATATTAGCGTGTGCTGAGACTACCCAGTTAGAGCGTATGAAACTAAAATTAGGACTACAAGTCTTATGCCACAATATTTGGATGACATGTGTTATATTAATTTTAGCAGGGTATTTAAGATTATTTCAGGAGTCATTTATTTTATTTATTAGTTATGGAATTTTAAAAATTCATGTCGGTGGGATTCACTTCCACAAAAGTTGGCAATGTTTAACTGTAACCACTAGTTTTATAATAGGAGGGGTTTTACTTGCGCAACATATGACGCTTCAATTGAAATGGATTATTTTCCTATATATACTCAGTATCTTACTACTATGGATTATTGGTCCACAAGGTACAAGGAATAATCCAATTACGGAATATCATTATCCAATATTATATTGCCGAAGCCTTTGTATTGTGATTTTTTATGCTTTATTAACACTTTCTGGTATGTTAAACCAGAACACAATTAATCTTCTTTTGTTGGCAGTTCTGTTTGGGATTTTTTCTATTATACCAAACAAAATTCAGAATAGCCATTATTCTTTTTGA",
    "translation": "MEFITEKLLNILACAETTQLERMKLKLGLQVLCHNIWMTCVILILAGYLRLFQESFILFISYGILKIHVGGIHFHKSWQCLTVTTSFIIGGVLLAQHMTLQLKWIIFLYILSILLLWIIGPQGTRNNPITEYHYPILYCRSLCIVIFYALLTLSGMLNQNTINLLLLAVLFGIFSIIPNKIQNSHYSF",
    "product": ""
   },
   {
    "start": 11545,
    "end": 12858,
    "strand": -1,
    "locus_tag": "ctg28_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg28_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg28_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,545 - 12,858,\n (total: 1314 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg28_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg28_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATGCATTATTACAATTAATGAGCTGTTTTTTAAATGCAATTATGTACATGATTTTAATCTATTACTTCTTACCTTTCAAATTGCAATTTAAAGAAATTACAATTCTTTTTACAATTCTTTCAACCAACATGTTTCTAATAAATAAAGTTGGAAATTATGGGGTTATTTTTCTATTGATAAGTGTAAGTATTTATCTAATGTTTATACGTAAAAATAGATTCATAAATATTATGTCTTTCGTTATCAGCTATTTATTTATAGTGATATTTGACCAATTTTTTTCCTTGCTGTGGAATGTTTTTGTTTGTCCTATTTCCACTCTTTTGAAAAATACTATATATTATATTTTATATGTAATTTCAGCTATTGTTGTACTTCTTATAATATGCCCTTTTATCGGAAAATATTATCATTTATTGATAAGAAAAATAGAAGCATATGTAAACAAACAATTATTTGTTCTGATAGGATCTAATCTAGGAATTTGTCTAATTATAGTTCTATTTAATGTGTTTATTGGTGAATACATTGGATATACATCTAGGAGTATAGGTTTCAATTGCATCCTGTTTGCCTGTTATTTTATAATTAGTACGATTCTAATCATAAATATTACAAAGCAAAATGAAAAAAGAATTGAACTGGAAAAGCGCCAAGAAGCATACCAGCATCTGCAAGAATATACAAATCAGATTGAGCATATGTATTCCACACTTCGTTCCTTCAAACATGACTACTCAAATATGATGCTGACAATGGCCGAATATATTGCTTCTGAGGATATCAATGGATTAAAAAATTATTTTACAAACGAATTTATGCCAAAGAACCAAAAGTTGACATCAGATACAACAAAAATAAATTCGTTGATTAACTTAAAAGATATAGAATTGAAAAGTCTGCTCTCTGCCAAGTTATTATATGCATTGAACCTAGGGATTAATGTAGAAATAGAAATTATAGAAGAAATCTCTCACATCCAAATGGACATTATAGATTTAGCAAGAATAGTTGGGATTTTTTTGGATAATGCAATCGAATCCGCTTTGGAAACTGAGCAACCAAAACTTCACTTTGCAGCAATTAACTCTGAAAACAAAAAAGTAATTATTATTGCAAATACTTTTTTAGATAAAGGTATTCCTATCGCAACATTAAAAGAAGAGGGGGTATCTACAAAAGGAAAAAACAGAGGGATTGGTCTGCTTCATGTAAAAGAAATTGTCTCTAATTATCAAAATGTATTATGGGATATGGAAGTAAAGCACAACTATTTTATACAAACACTAACAATAACAGAAACTTTTTAA",
    "translation": "MDALLQLMSCFLNAIMYMILIYYFLPFKLQFKEITILFTILSTNMFLINKVGNYGVIFLLISVSIYLMFIRKNRFINIMSFVISYLFIVIFDQFFSLLWNVFVCPISTLLKNTIYYILYVISAIVVLLIICPFIGKYYHLLIRKIEAYVNKQLFVLIGSNLGICLIIVLFNVFIGEYIGYTSRSIGFNCILFACYFIISTILIINITKQNEKRIELEKRQEAYQHLQEYTNQIEHMYSTLRSFKHDYSNMMLTMAEYIASEDINGLKNYFTNEFMPKNQKLTSDTTKINSLINLKDIELKSLLSAKLLYALNLGINVEIEIIEEISHIQMDIIDLARIVGIFLDNAIESALETEQPKLHFAAINSENKKVIIIANTFLDKGIPIATLKEEGVSTKGKNRGIGLLHVKEIVSNYQNVLWDMEVKHNYFIQTLTITETF",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 10727,
    "end": 11294,
    "tool": "rule-based-clusters",
    "neighbouring_start": 727,
    "neighbouring_end": 13179,
    "product": "cyclic-lactone-autoinducer",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "cyclic-lactone-autoinducer",
  "products": [
   "cyclic-lactone-autoinducer"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP cyclic-lactone-autoinducer",
  "anchor": "r28c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {
 "r21c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg21_1": {
     "functions": []
    },
    "ctg21_2": {
     "functions": []
    },
    "ctg21_3": {
     "functions": [
      {
       "description": "SCIFF",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR03973",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg21_4": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Ranthipeptide_rSAM_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR04085",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Fer4_12",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg21_5": {
     "functions": []
    },
    "ctg21_6": {
     "functions": []
    },
    "ctg21_7": {
     "functions": []
    },
    "ctg21_8": {
     "functions": [
      {
       "description": "SMCOG1170:metallo-beta-lactamase family protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg21_9": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg21_10": {
     "functions": []
    }
   }
  }
 },
 "r27c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg27_1": {
     "functions": []
    },
    "ctg27_2": {
     "functions": []
    },
    "ctg27_3": {
     "functions": []
    },
    "ctg27_4": {
     "functions": [
      {
       "description": "SMCOG1032:RNA polymerase, sigma-24 subunit, ECF subfamily ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg27_5": {
     "functions": []
    },
    "ctg27_6": {
     "functions": []
    },
    "ctg27_7": {
     "functions": [
      {
       "description": "AgrB",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg27_8": {
     "functions": []
    },
    "ctg27_9": {
     "functions": []
    },
    "ctg27_10": {
     "functions": []
    },
    "ctg27_11": {
     "functions": []
    },
    "ctg27_12": {
     "functions": []
    },
    "ctg27_13": {
     "functions": []
    },
    "ctg27_14": {
     "functions": []
    },
    "ctg27_15": {
     "functions": []
    },
    "ctg27_16": {
     "functions": []
    },
    "ctg27_17": {
     "functions": []
    },
    "ctg27_18": {
     "functions": []
    },
    "ctg27_19": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg27_20": {
     "functions": [
      {
       "description": "SMCOG1003:sensor histidine kinase ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg27_21": {
     "functions": [
      {
       "description": "SMCOG1008:response regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 },
 "r28c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg28_3": {
     "functions": [
      {
       "description": "SMCOG1008:response regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg28_4": {
     "functions": []
    },
    "ctg28_5": {
     "functions": []
    },
    "ctg28_6": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg28_7": {
     "functions": []
    },
    "ctg28_8": {
     "functions": [
      {
       "description": "SMCOG1077:phage integrase family protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg28_9": {
     "functions": []
    },
    "ctg28_10": {
     "functions": []
    },
    "ctg28_11": {
     "functions": []
    },
    "ctg28_12": {
     "functions": []
    },
    "ctg28_13": {
     "functions": []
    },
    "ctg28_14": {
     "functions": []
    },
    "ctg28_15": {
     "functions": [
      {
       "description": "AgrB",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg28_16": {
     "functions": []
    }
   }
  }
 }
};
