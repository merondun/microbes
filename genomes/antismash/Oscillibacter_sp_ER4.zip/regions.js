var recordData = [
 {
  "length": 43768,
  "seq_id": "JPJG01000001.1",
  "regions": []
 },
 {
  "length": 31369,
  "seq_id": "JPJG01000010.1",
  "regions": []
 },
 {
  "length": 4737,
  "seq_id": "JPJG01000089.1",
  "regions": []
 },
 {
  "length": 1278,
  "seq_id": "JPJG01000090.1",
  "regions": []
 },
 {
  "length": 51489,
  "seq_id": "JPJG01000091.1",
  "regions": []
 },
 {
  "length": 8965,
  "seq_id": "JPJG01000092.1",
  "regions": []
 },
 {
  "length": 2591,
  "seq_id": "JPJG01000093.1",
  "regions": []
 },
 {
  "length": 1862,
  "seq_id": "JPJG01000094.1",
  "regions": []
 },
 {
  "length": 15882,
  "seq_id": "JPJG01000095.1",
  "regions": []
 },
 {
  "length": 26254,
  "seq_id": "JPJG01000011.1",
  "regions": []
 },
 {
  "length": 8766,
  "seq_id": "JPJG01000096.1",
  "regions": []
 },
 {
  "length": 1380,
  "seq_id": "JPJG01000097.1",
  "regions": []
 },
 {
  "length": 5886,
  "seq_id": "JPJG01000098.1",
  "regions": []
 },
 {
  "length": 51239,
  "seq_id": "JPJG01000012.1",
  "regions": []
 },
 {
  "length": 8713,
  "seq_id": "JPJG01000099.1",
  "regions": []
 },
 {
  "length": 6503,
  "seq_id": "JPJG01000101.1",
  "regions": []
 },
 {
  "length": 20630,
  "seq_id": "JPJG01000102.1",
  "regions": []
 },
 {
  "length": 14191,
  "seq_id": "JPJG01000013.1",
  "regions": []
 },
 {
  "length": 10516,
  "seq_id": "JPJG01000104.1",
  "regions": []
 },
 {
  "length": 8680,
  "seq_id": "JPJG01000106.1",
  "regions": []
 },
 {
  "length": 10363,
  "seq_id": "JPJG01000107.1",
  "regions": []
 },
 {
  "length": 1087,
  "seq_id": "JPJG01000108.1",
  "regions": []
 },
 {
  "length": 113770,
  "seq_id": "JPJG01000014.1",
  "regions": []
 },
 {
  "length": 12515,
  "seq_id": "JPJG01000015.1",
  "regions": []
 },
 {
  "length": 7013,
  "seq_id": "JPJG01000110.1",
  "regions": []
 },
 {
  "length": 40106,
  "seq_id": "JPJG01000016.1",
  "regions": []
 },
 {
  "length": 13940,
  "seq_id": "JPJG01000112.1",
  "regions": []
 },
 {
  "length": 2192,
  "seq_id": "JPJG01000113.1",
  "regions": []
 },
 {
  "length": 23705,
  "seq_id": "JPJG01000017.1",
  "regions": []
 },
 {
  "length": 9300,
  "seq_id": "JPJG01000114.1",
  "regions": []
 },
 {
  "length": 15874,
  "seq_id": "JPJG01000115.1",
  "regions": []
 },
 {
  "length": 81855,
  "seq_id": "JPJG01000018.1",
  "regions": []
 },
 {
  "length": 22633,
  "seq_id": "JPJG01000116.1",
  "regions": []
 },
 {
  "length": 1947,
  "seq_id": "JPJG01000117.1",
  "regions": []
 },
 {
  "length": 57080,
  "seq_id": "JPJG01000019.1",
  "regions": []
 },
 {
  "length": 2441,
  "seq_id": "JPJG01000118.1",
  "regions": []
 },
 {
  "length": 105267,
  "seq_id": "JPJG01000002.1",
  "regions": []
 },
 {
  "length": 7321,
  "seq_id": "JPJG01000020.1",
  "regions": []
 },
 {
  "length": 5393,
  "seq_id": "JPJG01000122.1",
  "regions": []
 },
 {
  "length": 3731,
  "seq_id": "JPJG01000021.1",
  "regions": []
 },
 {
  "length": 39544,
  "seq_id": "JPJG01000022.1",
  "regions": []
 },
 {
  "length": 7658,
  "seq_id": "JPJG01000124.1",
  "regions": []
 },
 {
  "length": 38317,
  "seq_id": "JPJG01000023.1",
  "regions": []
 },
 {
  "length": 12538,
  "seq_id": "JPJG01000125.1",
  "regions": []
 },
 {
  "length": 1748,
  "seq_id": "JPJG01000126.1",
  "regions": []
 },
 {
  "length": 11679,
  "seq_id": "JPJG01000024.1",
  "regions": []
 },
 {
  "length": 5405,
  "seq_id": "JPJG01000025.1",
  "regions": []
 },
 {
  "length": 31923,
  "seq_id": "JPJG01000026.1",
  "regions": [
   {
    "start": 2893,
    "end": 24281,
    "idx": 1,
    "orfs": [
     {
      "start": 4452,
      "end": 6203,
      "strand": -1,
      "locus_tag": "ctg48_4",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,452 - 6,203,\n (total: 1752 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 324.2; E-value: 2.7e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNMIHRFMGCIREYKKPTILTLLCMVGEVAIEVLIPFFTANLVNEIKGGAELSGVVRVGLGLILMSLVSLGCGALGGLYGSRASAGFAKNVRHDVFTRVQSFAFENIDKFSSASLVTRMTTDINNVQMSFMMCIRIAVRAPLMFLFAVIMAYIMGGALATTFLIIIPVLVIGLLLIARKAMPAFRAVFRKYDKLNESVEENVRAMRVVKGFAREGYEKQKFAAASHDIAKDFTFAERVVALNAPLMQFCVYFNMIFVLFVGSRIIITNGGTTIDVGQLSAMLTYGMQILMSLMMISMIYVMMTMSYESFVRICEVLEEEPALTDPASPAMDVKDGSIDFENVSFKYSAQAKKFALQDINLHIDSGMTVGILGGTGSSKSTLVQLIPRLYDVSEGCVKVGGRDVREYDLEALRGAVSVVLQKNVLFSGTVKDNLRWGNENATDDEMIEACRLAQADEFVRSFPDGYDTYIEQGGSNVSGGQKQRLCIARALLKKPKILILDDSTSAVDTRTDALIREGFRTYIPETTKIIIAQRVASVQDADLILVMDNGHIADMGTHDQLLASSEIYREVYESQTNGGEQDEA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATATGATCCATCGCTTCATGGGCTGCATCCGCGAGTATAAAAAGCCCACGATCCTGACGCTCTTGTGCATGGTCGGCGAGGTCGCGATTGAAGTGCTGATCCCGTTTTTCACCGCCAACCTCGTCAACGAAATCAAGGGCGGCGCGGAGCTCAGCGGCGTTGTGCGCGTGGGCCTTGGGCTCATCCTGATGTCGCTCGTGTCGCTCGGCTGCGGCGCGCTCGGCGGGCTTTACGGCTCGCGCGCGAGCGCCGGCTTTGCCAAAAACGTCCGCCACGATGTTTTCACCCGCGTGCAGAGCTTCGCGTTTGAAAATATCGACAAATTCTCCTCCGCCTCGCTCGTCACGCGCATGACGACCGATATCAACAATGTGCAGATGTCCTTTATGATGTGCATCCGCATCGCGGTACGCGCACCGCTGATGTTTCTCTTCGCCGTCATCATGGCCTATATCATGGGCGGCGCGCTGGCGACGACATTCCTCATTATCATTCCCGTGCTGGTAATCGGACTTCTTCTGATCGCACGTAAGGCAATGCCCGCGTTCCGCGCGGTGTTCCGCAAGTACGATAAGCTCAATGAATCGGTCGAGGAAAATGTGCGCGCGATGCGCGTGGTCAAGGGCTTTGCCCGCGAAGGGTATGAAAAGCAGAAGTTCGCCGCGGCCTCGCACGATATCGCCAAGGACTTCACCTTCGCCGAGCGCGTCGTCGCGCTCAACGCGCCGCTGATGCAGTTCTGCGTATACTTCAACATGATCTTCGTGCTATTTGTCGGCTCGCGGATCATCATCACGAACGGCGGCACGACCATCGACGTTGGCCAGCTCTCGGCCATGCTGACCTACGGCATGCAGATCTTAATGTCGCTGATGATGATCTCGATGATCTACGTGATGATGACGATGTCGTATGAGTCCTTCGTCCGTATCTGCGAGGTACTCGAGGAAGAGCCCGCGCTCACCGATCCCGCATCTCCCGCGATGGACGTGAAGGACGGCTCCATCGACTTTGAAAACGTCAGCTTCAAGTACTCCGCACAGGCGAAGAAATTCGCGCTGCAGGACATCAACCTGCACATCGACTCAGGCATGACCGTCGGCATCCTCGGCGGTACGGGCTCGAGCAAGTCGACCCTCGTGCAGCTCATCCCGCGCCTTTACGATGTGAGCGAGGGCTGCGTCAAGGTCGGCGGCAGAGATGTGCGCGAATACGACCTTGAGGCGCTGCGCGGCGCGGTCAGCGTCGTGCTGCAAAAGAATGTGCTGTTTTCCGGCACGGTCAAGGATAACCTGCGCTGGGGCAACGAAAACGCCACCGACGACGAGATGATCGAGGCGTGCAGGCTCGCGCAGGCGGACGAATTCGTCCGCTCCTTCCCCGACGGGTATGACACCTATATCGAGCAGGGCGGCTCGAACGTCTCCGGCGGACAGAAGCAGCGTCTCTGCATCGCCCGGGCGCTTCTCAAAAAGCCGAAGATTCTGATCCTCGACGACTCGACCTCCGCGGTCGACACGCGCACCGACGCGCTGATCCGCGAGGGCTTCCGCACCTATATCCCCGAGACGACGAAGATCATCATTGCCCAGCGCGTCGCGTCCGTGCAGGATGCCGACCTCATTCTCGTGATGGACAACGGCCATATTGCGGACATGGGCACGCACGATCAGCTCCTCGCTTCGAGTGAAATTTACCGCGAGGTCTACGAATCCCAGACGAACGGAGGTGAGCAGGATGAAGCGTGA",
      "translation": "MNMIHRFMGCIREYKKPTILTLLCMVGEVAIEVLIPFFTANLVNEIKGGAELSGVVRVGLGLILMSLVSLGCGALGGLYGSRASAGFAKNVRHDVFTRVQSFAFENIDKFSSASLVTRMTTDINNVQMSFMMCIRIAVRAPLMFLFAVIMAYIMGGALATTFLIIIPVLVIGLLLIARKAMPAFRAVFRKYDKLNESVEENVRAMRVVKGFAREGYEKQKFAAASHDIAKDFTFAERVVALNAPLMQFCVYFNMIFVLFVGSRIIITNGGTTIDVGQLSAMLTYGMQILMSLMMISMIYVMMTMSYESFVRICEVLEEEPALTDPASPAMDVKDGSIDFENVSFKYSAQAKKFALQDINLHIDSGMTVGILGGTGSSKSTLVQLIPRLYDVSEGCVKVGGRDVREYDLEALRGAVSVVLQKNVLFSGTVKDNLRWGNENATDDEMIEACRLAQADEFVRSFPDGYDTYIEQGGSNVSGGQKQRLCIARALLKKPKILILDDSTSAVDTRTDALIREGFRTYIPETTKIIIAQRVASVQDADLILVMDNGHIADMGTHDQLLASSEIYREVYESQTNGGEQDEA",
      "product": ""
     },
     {
      "start": 6200,
      "end": 6706,
      "strand": -1,
      "locus_tag": "ctg48_5",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,200 - 6,706,\n (total: 507 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 70.5; E-value: 1.8e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAGACCAACGAGATCCAGGAGCTGCTGCTCGACACGATCCCCGCGTGGCACTACTGGTTTGCCCGTCCGTTCAAGCGCATGCTGAATGACGGCGTCAGCCTTGACATGTACTACTGCATCCAGTCGATGCGCCGCAGCGGCCGCACGATGACGATGACAGAGCTTGCAAACTTTGCCCGCATGCCCAAGCAGCAGATGAGCAAGCTCGTCGACAAGCTGGTCGAGGGCGGCTTTGCCGAGCGGCTGAGCGACCCCGACGACCGCCGCGTCATCCGCCTGCGGGCGACTGAGAAGGCCGACGAATACGTGGCGAGCTTTTTAGAGAAGGATGCGGCGGAGTTCCGCGCATTTTTCGACCAGCTCGAAGGCGAAGAGCGTGAGACCTTCTGCACGGCGCTTCGCACCATCCACGACACCTTTGAGGCCAAACGCAAGCGCATGATCGAGCAGGGCAAGCTGCCCGACTGTCCCCCACAAACTAAGAAAGAAGGCCACTGCCGATGA",
      "translation": "MQTNEIQELLLDTIPAWHYWFARPFKRMLNDGVSLDMYYCIQSMRRSGRTMTMTELANFARMPKQQMSKLVDKLVEGGFAERLSDPDDRRVIRLRATEKADEYVASFLEKDAAEFRAFFDQLEGEERETFCTALRTIHDTFEAKRKRMIEQGKLPDCPPQTKKEGHCR",
      "product": ""
     },
     {
      "start": 6871,
      "end": 9495,
      "strand": -1,
      "locus_tag": "ctg48_6",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,871 - 9,495,\n (total: 2625 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 124.2; E-value: 1.1e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAGAAGGTCACGCTCGGCATTCTCGCCCACGTCGACTCGGGAAAAACGACCCTGTCCGAGGGGCTTTTATACGCCTCCGGCGCACTGCGGAAGCTCGGCCGCGTCGACCACGGCGACGCCTTCCTCGACACCGACGCGCTCGAGCGCGAGCGCGGCATCACGATCTTTTCCAAGCAGGCAATGCTGTTTGCGGGCGATAAGGAGTTCACGCTGCTTGACACGCCGGGCCACGTCGATTTCTCCGCCGAGATGGAGCGCACGCTGTCGGTACTCGACTACGCAGTGCTCGTCATCAGCGGCAGCGACGGCGTGCAGAGCCACACGCGAACGCTCTGGCGCCTGCTCACGCGCTACGAGGTGCCGACGTTTCTTTTCATCAACAAGATGGACTTGGCGGGCGCGGACAAGGACGCGCTTCTGCGCCAGCTCGCGGCGACACTGAGCGCGGAATGCGTCGATTTCTCCGCATCGCAGGAAACGCGCGACGAAGCGCTCGCCCTCTGCGACGAGGCGGCGCTCGAGCAGCTTTTGGAGCGTGGAAAAATCGACGACGCTCTGATTGCTGAGATGGTCAAAAACCGCAAGGTCTTCCCCTGCTTTTTCGGTTCGGCGCTCAAGCTGGACGGCGTGGAGGACTTTCTCACCGCGCTCGCGTGCTTCACGCGCGAGCCGGTCTATCCGAAGGAATTCGGCGCAAAGGTCTTCAAGATCTCGCGCGACGCGCAGGGCGCGCGGCTCACGTGGCTCAAGGTCACAGGCGGCGCGCTGCGCGTGAAGGCACCTCTCACCTATCGCGCGCAGAATCAGGACTATAATGAAAAGGCCGATCAGCTGCGGCTATACTCCGGCGTCAAATTCCGCGCGCTCGAAGAGGCGGGCGCGGGCAGCGTCGTCGCCGTCACGGGCCTCAGCCACAGCTATGTTGGTCTCGGCCTCGGCGCGGAGGCGGAGGCGTCCGCCCCGCTTTTGCAGCCGGTTTTGACCTATCAGCTCATCCTACCCGACGGCGCGGACGCGCACAGCGCGCTTATAAAGCTCCGCGAGCTTGAAGAAGAGGACCCGATGCTGCGCATCGTCTGGGACGAGCGCTACGGGCAGATCCACGTGCAGCTCATGGGCAAAATTCAGCTCGAAATTCTGCGCCGCCGCATCCTCGACCGCTTCGGCCTCGACGTGACCTTCGGCGAGGGCAGCATCGTCTATCGCGAGACCATCACCGCCCCCGTCCTCGGCATGGGACATTTCGAGCCCCTGCGCCACTATGCGGAAGTACAGCTTCTAATAGAGCCGCTTCCGCGCGGGGCGGGCATCCAGCTTGCGTCAAACGTGCCGACGGACGCGCTCGACCTCAACTGGCAGCGGCTGATTTTCACCCATCTTTTAGAGCGCGAGCACGCGGGCGTGCTAACCGGCTCACCGTTGACGGATGTGAAGTTCACACTTGTCGCGGGCCGCGCGCATCTGAAGCACACCGAGGGCGGCGACTTCCGTCAAGCGACGTACCGTGCCGTGCGGCAGGGCTTGATGCAGGCAGAAAATGTGCTGCTCGAGCCGTATTACGACTTCCGTCTCGAGGTGCCCGCCGAGTGCGTCGGCCGCGCGATGACCGACCTCCAGAACATGGGCGGCACCGTCGAACCGCCGCAGAACGAGGGGGAAAACGCCGTACTCACGGGCTATGCGCCGGTGCGCACGCTGCGCGACTACTTTGCCGACGTCGCGGCCTACACCCGCGGCCGCGGACAGCTCTCCTGCGCCGTGCGCGGGTATGAGGCCTGCCAAAATCAGGACGAGATCGTCGCGTCCCTTGGCTACGACGCCGAGCGCGACACGGATAATCCCGCGTCCTCCGTCTTCTGCGACCACGGCGGCAGCATCACGGTCCCGTGGAATGAAGTTCCCGCGCATGTTCACTGCGACAGCGGCATCCGCCTTGGTGAAGAGGCCGTCGAAGAAGCGCCCGCGCCGCTCCCCCGACGCAGCGTCGGCGCAGGCGGCGCATATGCCGAGGACAAGGAATTGCAGGACATTTTTGAGCGCACATACGGCAAGGTCGAGCGCCGCGCGTTCGAACCGAGCAAAAAGCCCGCGCGCACCTCGCTCGCCGATCACTATGACGTCACGATCCACTCAGAGGACACGGAATATCTGCTCGTCGACGGCTACAACATCATCTTCGCGTGGGACGAGCTCCATCGGCTCGCCGCGCAGGATGTCGCCGCGGCGCGCGGCGCGCTGATCGACATTCTCGCCAACTATCAGGGCTTTCGCAAGTGCCGCGTCATCGTCGTGTTCGACGCCTATAAGGTCAAGGGCAACCCCGGCAGTGTGCAGACGGTGCACGGCGTCAAGGTCGTCTACACGAAAGAGGCTGAGACTGCCGACACCTACATCGAGCGCGCGACCTACGAGCTGCGCCGCGAACGCCGCGTGCGCGTGGCGACGTCCGACGGCCCCGAGCAGGTCATCATCCTCGGCCACGGGGCGCTGCGCGTCTCCGCCCGCGCGTTCCATGCCGAGGTCGAAGCCGCCGAGGGGCAGATCAGCGCCGTGCTGCAACGCCTGACGAACCGCCCCAGAAGTGAGCGCACGATCAGAAACAATGTAAAACTCAAGCAATAA",
      "translation": "MQKVTLGILAHVDSGKTTLSEGLLYASGALRKLGRVDHGDAFLDTDALERERGITIFSKQAMLFAGDKEFTLLDTPGHVDFSAEMERTLSVLDYAVLVISGSDGVQSHTRTLWRLLTRYEVPTFLFINKMDLAGADKDALLRQLAATLSAECVDFSASQETRDEALALCDEAALEQLLERGKIDDALIAEMVKNRKVFPCFFGSALKLDGVEDFLTALACFTREPVYPKEFGAKVFKISRDAQGARLTWLKVTGGALRVKAPLTYRAQNQDYNEKADQLRLYSGVKFRALEEAGAGSVVAVTGLSHSYVGLGLGAEAEASAPLLQPVLTYQLILPDGADAHSALIKLRELEEEDPMLRIVWDERYGQIHVQLMGKIQLEILRRRILDRFGLDVTFGEGSIVYRETITAPVLGMGHFEPLRHYAEVQLLIEPLPRGAGIQLASNVPTDALDLNWQRLIFTHLLEREHAGVLTGSPLTDVKFTLVAGRAHLKHTEGGDFRQATYRAVRQGLMQAENVLLEPYYDFRLEVPAECVGRAMTDLQNMGGTVEPPQNEGENAVLTGYAPVRTLRDYFADVAAYTRGRGQLSCAVRGYEACQNQDEIVASLGYDAERDTDNPASSVFCDHGGSITVPWNEVPAHVHCDSGIRLGEEAVEEAPAPLPRRSVGAGGAYAEDKELQDIFERTYGKVERRAFEPSKKPARTSLADHYDVTIHSEDTEYLLVDGYNIIFAWDELHRLAAQDVAAARGALIDILANYQGFRKCRVIVVFDAYKVKGNPGSVQTVHGVKVVYTKEAETADTYIERATYELRRERRVRVATSDGPEQVIILGHGALRVSARAFHAEVEAAEGQISAVLQRLTNRPRSERTIRNNVKLKQ",
      "product": ""
     },
     {
      "start": 10052,
      "end": 10441,
      "strand": -1,
      "locus_tag": "ctg48_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,052 - 10,441,\n (total: 390 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGATTGATAGCGCAAAGGATCTTCAAATGAACATTGCAAAAGAGGGATTGGCACTGCTGATGTTCCATCCCAGCTTCAATGTGCAGCCCCATAGGGAGTGCATCTTCCTCATTGGCACAGCGTGGGACATCCCCGTGGGTGACACGCAGGAGGTCATCTCGCTTCTGGATCGTGAGCTGGATGCGATCCGCGCCGCAGGCGAAGGTGGCACGGCAGCGCATGTGTTGCCGGAGGATGAACTCCCGATGAATGCCACCGGCTTGGAAACGCTGGACAACATCTGGGACCTGTTCGAAACGAGCCTGCGCATGGACAGTATGCAAGCCAGAACAAAGAAGTTCGAAATGGCAAAGTGGTTAGAGAAAAGCCAAAACCTTCTGGACTGA",
      "translation": "MTIDSAKDLQMNIAKEGLALLMFHPSFNVQPHRECIFLIGTAWDIPVGDTQEVISLLDRELDAIRAAGEGGTAAHVLPEDELPMNATGLETLDNIWDLFETSLRMDSMQARTKKFEMAKWLEKSQNLLD",
      "product": ""
     },
     {
      "start": 10685,
      "end": 11068,
      "strand": 1,
      "locus_tag": "ctg48_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,685 - 11,068,\n (total: 384 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAACAAACCTTGTGGTGGCGGATATCAGCCGTACCGAGAAAACGATATGCCTTGCGGTTTCGCCAGCCCTGAAAGCCTACGGGATACCCGTTAGAGCTCGCCTCTTTGAGGTGGTGGAACGCGTCAAAGAAGTCAACGCCGAACGCCGGCGTGAAGAATCCGCCATCGTCATCAAGGCCACAGACCGATACTCGGAGACAGTCAAGCGCAAGGGCGAGACTACGAAGAGCTTCGGGAAGAACCTTGGCAAAACGGAGGACATCCTGACGCTCCTGAGCAAAAACAAAGCAACCATCAGGGTTGATGTGAAGCAGGCGAAAGCACCTTGCAGGATGCGGAAAAGCAGTTTGCGAAAACCCGCAGCGAAGCGGACAAGCTGA",
      "translation": "MTTNLVVADISRTEKTICLAVSPALKAYGIPVRARLFEVVERVKEVNAERRREESAIVIKATDRYSETVKRKGETTKSFGKNLGKTEDILTLLSKNKATIRVDVKQAKAPCRMRKSSLRKPAAKRTS",
      "product": ""
     },
     {
      "start": 11568,
      "end": 12893,
      "strand": -1,
      "locus_tag": "ctg48_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,568 - 12,893,\n (total: 1326 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAACGCCCATTGCTGATTTTGTCCGGCGGTACGCGGATTCCGGGATGGTCCGGGCGCATATGCCCGGCCACAAGGGAAAACCCTTTCTGGGTTGCGAGGCGCTGGACATCACCGAGATCCAAGGCGCGGACAGCCTGTATGAAGCGGAAGGCATCATCCGGCGCAGTGAGTCCTATGCCGGGAAGCTGTTCGGCTCTGGCCGGACGGTGTACTCCACAGAGGGGTCCAGCCAGTGCATCCGGGCGATGCTGTATCTGGCGCTGACCTGCGGAAACGGGTCCCGGACGGTGGTGGCGGCCCGAAACGTACACCGGGCGTTTGTATATGCGGCGGCCCTGCTGGATTTTGAGATCGTCTGGCTGTGGCCAGAGCGCAGCTCGTCTCTCTGCGGCTGCCCGGTATCGCCGGACACATTGGGGCGGACGCTGGAGGAGCTGCCTGCGCCGCCGGCGGCGGTCTATCTTACCAGCCCGGACTATCTGGGCGGCATGGCGGATATTTCCGCTCTGGCAGAGGTGTGCCGGAAACACGGTACGCTGCTGGCGGTGGACAACGCCCACGGCGCCTATCTGCGGTTTCTGGAACCATCCTGTCACCCGTTGGATCTCGGCGCAGATCTGTGCTGTGATTCGGCGCACAAGACGCTGCCGGTGCTGACCGGCGGCGCGTACCTGCACATCAGCCGCGCGGCGCCGGCATCTCTCCGGGAGAGTGCAAAAACAGCGATGGCCATGTTTGGTTCCACCAGTCCGTCCTACCTGACGCTGGCGTCGCTGGATCTGTGCAACCGCTATCTGGCGGATGGGTACCAGGACCACCTGCGGGAGATGTGTGGGCATCTGGAGGAAGCGCAAAAGGCGCTGACGGCTGCCGGTTGGCAGATAGAGCCATCGGACCCGCTGCGGCTGACCGTCAAGGCTCCAGCCGGGATGACCGGCGGAGCGCTGGCAGACCGCCTGCGAGAGAGCGGCGTGGAATGTGAATACGCCAATCCGGACTTTCTGGTGCTGATGCTGACGCCGGAGAATAGTGCGGCGGATATCGAGCGGCTTGTGTATGCCATAGGAACAAACGACGCCGTTTATGCGCCGCAGCCGTCGCTGCCGTTGGCTCGTGGAGAACGGGTATGTTCCGCGCGAGAGGCACTGTTCGCCCCACGGGAGACCATACCGGCGGCGCAGTCGTTAGGGCGGGTCTGCGGCGCCCCTACCGTGGGGTGTCCGCCTGCGATCCCCATTGCGGTGTCCGGTGAGCGAATTGGTCCGGAAGCGCTGGAGCTGTTCCGGCGGTACGGCGTGGAGCGGGTGGAAGTCTTGCGCTGA",
      "translation": "METPIADFVRRYADSGMVRAHMPGHKGKPFLGCEALDITEIQGADSLYEAEGIIRRSESYAGKLFGSGRTVYSTEGSSQCIRAMLYLALTCGNGSRTVVAARNVHRAFVYAAALLDFEIVWLWPERSSSLCGCPVSPDTLGRTLEELPAPPAAVYLTSPDYLGGMADISALAEVCRKHGTLLAVDNAHGAYLRFLEPSCHPLDLGADLCCDSAHKTLPVLTGGAYLHISRAAPASLRESAKTAMAMFGSTSPSYLTLASLDLCNRYLADGYQDHLREMCGHLEEAQKALTAAGWQIEPSDPLRLTVKAPAGMTGGALADRLRESGVECEYANPDFLVLMLTPENSAADIERLVYAIGTNDAVYAPQPSLPLARGERVCSAREALFAPRETIPAAQSLGRVCGAPTVGCPPAIPIAVSGERIGPEALELFRRYGVERVEVLR",
      "product": ""
     },
     {
      "start": 12893,
      "end": 14281,
      "strand": -1,
      "locus_tag": "ctg48_10",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,893 - 14,281,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTACATCAGTATCAACTGAACGGCTACAACATCGTGCTGGATACCTGCTCCGGCGCCATTCATGTAGTGGATGAGGTAGCCTATGACATCATTGCGCTTTACCCGGATCACACGGCGGATGAGATCGTAACGGCGATGATGGAAAAATACGGCGAGCGCGAGGATGTGACGGAGCAGGATCTGCGGAACTGCATTGATGACGTGGAGGCACTGAAGCAGGCCGGGAAGCTCTATACCCCCGACACCTTCGCAGACATGGCCGGTACGTTCAAGGAGCGTTCTGGCGATGTGGTGAAGGCGCTGTGCCTGCATGTGGCGCACACCTGCAACCTGAACTGCTCCTACTGCTTCGCCAGCCAGGGAAAATACCATGGAGACCGTGCGCTGATGAGCTTTGAGGTTGGCAAGCAGGCTCTGGACTTTCTGATGGATCACTCCGGCAGCCGCACCAATCTGGAGGTGGACTTCTTCGGCGGTGAGCCGCTGATGAACTGGGACGTGGTGAAGCAGTTGGTGGAGTATGCCCGCAGTGTGGAAAAGGAGCGGGGCAAAAATTTCCGCTTTACGCTGACCACAAACGGTATGCTCATCGACGATGACGTGATCGACTTCGCCAACCGGGAAATGAGCAATGTGGTGCTGTCGCTGGATGGCCGCAAGGAAATTCATGACCGGCTGCGGGTGGACTATGCAGGCAACGGCAGCTATGAGCGCATTGTGCCTAAGTTCCAGAAGCTGGTAGAGGCCAGAGGCAACAAGAACTATTATATGCGCGGCACCTTTACCCATGCCAATCCGGACTTTACGAAGGACCTGTTCCACATGGCGGATCTGGGCTTCACGGAGTTGAGCATGGAGCCTGTGGTGTGCGCGCCGGAGGACCCCGCCGCGCTGACGGCGGAGGATCTGGAGATCGTGAAGGACCAGTACGAGCTGCTGGCCAAGGATATGCTGCGCCGGGAAAAAGAAGGCAAGCCCATCACCTTCTATCACTACATGCTGGACCTGACGGGCGGCCCCTGCATTTACAAGCGAATCTCCGGCTGCGGCTCCGGCACGGAGTATATGGCTGTGACCCCTTGGGGAGACCTGTATCCCTGCCATCAGTTCGTGGGTGAGGAAGCCTACAAGCTGGGCGACATCTGGAACGGCGTGACCAATACGGCCCTGCGGGAGGAATTCCGCTCCTGCAACGCCTATGCCCGGCCAGAGTGCAATGACTGCTGGGCGAGATTCTACTGCTCCGGCGGCTGCGCAGCCAACGCCTTCCACGCCACGGGCTCTATCCGCGGCGTTTACGAGGCAGGCTGCGAATTGTTCCGCAAGCGTATTGAATGTGCCATCATGATGAAGGTGGCGGAAGATTCTGCCAAGGCCAACGGCTGA",
      "translation": "MVHQYQLNGYNIVLDTCSGAIHVVDEVAYDIIALYPDHTADEIVTAMMEKYGEREDVTEQDLRNCIDDVEALKQAGKLYTPDTFADMAGTFKERSGDVVKALCLHVAHTCNLNCSYCFASQGKYHGDRALMSFEVGKQALDFLMDHSGSRTNLEVDFFGGEPLMNWDVVKQLVEYARSVEKERGKNFRFTLTTNGMLIDDDVIDFANREMSNVVLSLDGRKEIHDRLRVDYAGNGSYERIVPKFQKLVEARGNKNYYMRGTFTHANPDFTKDLFHMADLGFTELSMEPVVCAPEDPAALTAEDLEIVKDQYELLAKDMLRREKEGKPITFYHYMLDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGEEAYKLGDIWNGVTNTALREEFRSCNAYARPECNDCWARFYCSGGCAANAFHATGSIRGVYEAGCELFRKRIECAIMMKVAEDSAKANG",
      "product": ""
     },
     {
      "start": 14334,
      "end": 14630,
      "strand": 1,
      "locus_tag": "ctg48_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,334 - 14,630,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAAAATTGCGATTGATTACTTGTTGGTGTTCTCGCACTTCTGGTTTGCCACGCCGCAGCTGGTCTTGCAGGCAGACTGGCAGGAGGTCTGGCACTCACCGCAGCCGCCGTTCTTGGCGCTGTCGCACAGGCTACGAGTCTCAAGAGTCTTGATTCTTTCCATAATATGTATCTCCGATCTGTTAAATTCTAATGGATTTTCCGGCAGACCACCCGCAGACAGTCACCTAAAAACCGGAGAAATTCTAGCATATCATCCGTATAAAGTCAAGATATTCCAGCAATTTGGCTATTAG",
      "translation": "MKIAIDYLLVFSHFWFATPQLVLQADWQEVWHSPQPPFLALSHRLRVSRVLILSIICISDLLNSNGFSGRPPADSHLKTGEILAYHPYKVKIFQQFGY",
      "product": ""
     },
     {
      "start": 14880,
      "end": 15485,
      "strand": 1,
      "locus_tag": "ctg48_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,880 - 15,485,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATTTTCGGCTTCAGCCATGGCTGGGAACCATTGCAATTACTACTCTTTTGGAGTTTTACTCATGGCTGTGTCTACTCCATTGATGAGGTGATGATTGACGCCACCAGTTACCTTGGGACGTATCACATGACGGCGCGGGAACTGGCACGAACCATGATCCTTGATGTGCTGCGCACAACGAGGATCACCGCGACCGCGGGGATCGGCACAAACCTCTATCTTTGCAAGGTCGCTATGGACATCATGGCCAAACACGTCGCGCCGGATGAGAGCGGTGTCCGGATCGCGGAGCTGGATGAAATGAGCTACCGCAGACAGCTTTGGATGCACCGCCCGCTGACCGACTTCTGGCGGGTGGGAAAAGGCTATGCCAAAAAGCTCGAGGCCATCGGCATCTACACCATGGGAGATATCGCCCGGTGCTCCATCGGGAAGGCCGGGGAATACTATAACGAGGCGCTGCTCTATAAGCTGTTTGGCATCAACGCCGAGCTGTTGATCGACCACGCCTGGGGCTGGGAGCCCTGCCGGATCTCCGACATAAAAGCCTATAGGCCGGAGACGAACTGTGTCAGTTCTGGGCAGGTCCTTCAATCCCCTTAG",
      "translation": "MIFGFSHGWEPLQLLLFWSFTHGCVYSIDEVMIDATSYLGTYHMTARELARTMILDVLRTTRITATAGIGTNLYLCKVAMDIMAKHVAPDESGVRIAELDEMSYRRQLWMHRPLTDFWRVGKGYAKKLEAIGIYTMGDIARCSIGKAGEYYNEALLYKLFGINAELLIDHAWGWEPCRISDIKAYRPETNCVSSGQVLQSP",
      "product": ""
     },
     {
      "start": 15482,
      "end": 15658,
      "strand": -1,
      "locus_tag": "ctg48_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,482 - 15,658,\n (total: 177 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCAAGCAAAATCAAAAGACGCTTTACAGACACAGAAATGCAAATTGTCGGGGAAACGGATCTGCCGGAGCTGCTGACCCATCTGGGCTATCAGATCAAACGCATTGGCCGGTACCACACCACAGCAGAAATGGACAGCCTGCGGATCAAGGACCGTCGCACATGGTTCCGCTAA",
      "translation": "MASKIKRRFTDTEMQIVGETDLPELLTHLGYQIKRIGRYHTTAEMDSLRIKDRRTWFR",
      "product": ""
     },
     {
      "start": 15777,
      "end": 16208,
      "strand": -1,
      "locus_tag": "ctg48_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,777 - 16,208,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAACTACCAAAAACTTGTGTGCTCAGATCCCCATCGACCTGCACGAGCGAGTCAGTGAAGAACGGGAACGGTTGGGCCAGACCACCAGCGAGTACATCGCCAACCTCATCCAAGACTATTACAACATGATCGAAAATCAGAAAGGCGGCATTCACATGACTGAAAAAGGCAGAACAATGGCATTCCAGGTCCCCGAAGAACTCTTCCAGCGCATCAAACGTCACCTCGAGCGTGAAACGCTCCGCACCGGCAAAAAACTCACCCAGCGAGACTTCGTGCTGAACCTGATCACGCAGGCGCTGGACGAAGCGGACGCCGAGAGCGCTACAGAGCAGGACTCCCCTGCTGAGGCCCCTGTCGAGGCCCGTGTGGCCGACGAGACCGCCCCTGCGGACACGGATACCCCTGACGAGGAAAGCGCCGTGTAA",
      "translation": "MATTKNLCAQIPIDLHERVSEERERLGQTTSEYIANLIQDYYNMIENQKGGIHMTEKGRTMAFQVPEELFQRIKRHLERETLRTGKKLTQRDFVLNLITQALDEADAESATEQDSPAEAPVEARVADETAPADTDTPDEESAV",
      "product": ""
     },
     {
      "start": 16782,
      "end": 17759,
      "strand": 1,
      "locus_tag": "ctg48_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,782 - 17,759,\n (total: 978 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGCGCAGCACCGATCATGGGAGGACTCCGCCGTGCAGAACGCTTATCCGGACTATTATCCGCTTTTCCATTGCATCGCCGACCGATGCCGACACAACTGCTGCATCGGCTGGGAGATCGACGTGGACGGGGATTCCCTCGCCGCCTACGATCAGATCGGCGGCGAGATGGGCGAGCGCCTGCATAAATGTATCGACCGCAGCGGCGAGATGCCGCACTTTATCCTCAGCGAGCAGGAGCGCTGCCCGTTTTTGAACGGCAAAAACCTCTGCGATCTCATTTTATACGGCGGGGAGGGTATGCTCTGCCAGATCTGCACCGACCACCCGCGCTACCGCAGCTTTTTTTCGGAGCGCACGGAGATTGGCGTTGGCCTCTGCTGCGAGGAGGCCGCGCGCCTCATTTTGACCAAGCCGGAGAAGACAACGCTTGTCGTGACGGGCGAAGGCGAGCTTGATGAAGAGGAGACGGCGCTGCTCACGCTGCGCGACCGCCTTTTCACCCTTGCGCAAAACCGTGAGGAACCGATCGAGCGGCGAATAGAGCAGATTTTATCGGCCTGCGGTGCACACGTGCCGGACGTCCCGCTTGCGCAGTGGGCAGAGTTTTATCTCTCGCTCGAGCGTATGGACGAGGTGTGGACGGGCATTTTGGAAGCGCTGCGCGAGCACGCAGATGAGTTGCCGCTCGACGATTTTGCCGCGCACATGAAAGGACGCGAGACGGAGTATGAGCAGCTGCTCGTCTACTTCCTCTATCGTCACGTGCCGACGGCGCTCGTCGACGGGGACGTGAGCAGCAAGGCGGCGTTCGCCGTGCTGTCTGTCCGGCTGCTTTTCTCGCTTGGTGCGCTGCACCTTTTGCTGCACGGCGAGTTCACGGTGGAGGACCAGATCGAGCTCTGCCGATTGTACAGCGCGGAGGTCGAGTATTCCGACGATAATATGGACGCGCTCTTCGACGCGCTGCTATAA",
      "translation": "MTAQHRSWEDSAVQNAYPDYYPLFHCIADRCRHNCCIGWEIDVDGDSLAAYDQIGGEMGERLHKCIDRSGEMPHFILSEQERCPFLNGKNLCDLILYGGEGMLCQICTDHPRYRSFFSERTEIGVGLCCEEAARLILTKPEKTTLVVTGEGELDEEETALLTLRDRLFTLAQNREEPIERRIEQILSACGAHVPDVPLAQWAEFYLSLERMDEVWTGILEALREHADELPLDDFAAHMKGRETEYEQLLVYFLYRHVPTALVDGDVSSKAAFAVLSVRLLFSLGALHLLLHGEFTVEDQIELCRLYSAEVEYSDDNMDALFDALL",
      "product": ""
     },
     {
      "start": 17899,
      "end": 19929,
      "strand": 1,
      "locus_tag": "ctg48_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,899 - 19,929,\n (total: 2031 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCAGAACATGAGAAAGAGAACGCCGCTGGCCGTGCTTCTGGCGCTGTGCCTTGCCATGCAGCTCTGCGTGCCCGCCGCGATGGCGAGCAATCGGCTGATGCGCGCGGGCGACGCGGCCATTGCGCAGATCGAGGAGGAAGAGGGCTTCCGCGCGGAGAAGTATTCCTCCGGCGGCAAGTGGTACATCGGCTACGGCACGGAGTGCGGTGCCGAGGATTATCCCGAGGGCATCACGCGCGAAGAGGCGGAGCTTCTTCTGATGAGCAAGGTCGAGGCGTATGAGGCCAAGCTCAACGACTTTTTTGGCCGCTACGACGTCACGCCCACGCAGGGGCAGTTCGACGCGCTGATCTGCTTCAGCTACAATTTCGGCACCGGTTGGATGAGCGGCACGAGCGACTTGGTCAAGATCGCCCGCGGCGAAAAGGACGCGACGCGCCTGGAAGTGGCGCATGCGTTCGGCGAATGGTGCCATTCCGGCGGACAGGCCCAGGCGGGCCTTGCCGACCGCCGCCTGCAGGAGGCTGCCATTTATTTAGATGACGGCACCCGCGCGGCGGAGAACGAGTTTGCGTATCTCATCATCAATATGGAAAGCGGTACGTCCTACGAGACGGACTTTGCCGTCTACGAGATCGGCAAGACCTACGGTAGCTTCCCCAAAGCGGAAAAGCTCGGCTACGGCTTTGCCGGCTTCCGGACGAGCGACGGCAAGACCATCACGGAAAACAGCATCGTGAACGGCAACGCGGTCGTCACGGCGCAGTGGACGGCGACGAGCTACACCGGCAAGACCTATACCGACGTCAACAAGTCCGACTGGTTCTATAACTATGTCATGGAGCTGAGCGAGCAGGGCATCGTCGGCGGCAACGGCGACGGCACGTTTGCCCCCAACCGTCCCACGAGCACGGGCGAAATGCTCAAGCTCGTGCTGCTCTCGACCGGCCACAAGGAGCAGAAGCCCAGCACGGCGCACTGGGCAAGCGGCTACGCGACCTACGCCTATTCCATGGGCTTTGCCGCGCAGAATTACAGCGACTATCAGCTTGACAACGGCATCAGTCGCCTCGATGTGGCGCGCTTTGCGGCCAAGGCGCTGGGCTATGGCGCATCCAACACGACCTCTCCCTTTGCCGACGTGAACGACGGCTATGTGACGGCGCTCTATGAAGCGGGTGTGTTCATCGGCACGAAGGTCGGCGACCTGACGTATTTCTACCCCAACAGCAGCATCACGCGCGCGGAGGTGGCGACGATCGTTTACCGCATCTATCAGCTCAGCTCGCTCGACCAGAAGCAGAAGATCTACTACAAGGACTACACGCTTGATGTGCTCGAGGGTGTGCCGACGAACACCTATAATCAGTCTGCGTTCGTCAAGAACGGCAGCATCATGACCTACAACGATCCCAGCGTGCGCACGCGCGTCGGTATCGACGTGTCGCAGTATCAGGGCGATGTGGACTGGAACGCGGTCGCGCGCACTGATGTGGACTTTGTCATCGCGCGCGTGGGCGGCCGCGGCTACACTGTGGGCGCGATCTATGACGACACGAAGTTTGACGAGTATGCCGACGGCGCGGCGAGAGCGGGCCTTCAGGTGGGCGCTTACTTCTTCTCGCAGGCTGTGAGCGTGGCAGAGGCGCAGGAGGAGGCCTATCACGTGCTCGACAAGCTGCGCGGCCATGAGATCACGGGTCCCGTCGTCTTCGACTGGGAGGTCATCGGCAAGAGCGAGGCGCGCACCTACGGCATCGAGACCGGCGTGCTCTGCGCTGCGGCGAACGCCTTCTGCAAGATCATTAAGGACGCGGGCTACGACCCGATGATCTACATCACCGACTACGCGGGTTATGTCAAGTATGACCTCAGCGAGGTCATGGATTACCCGCTGTGGTACGCGCGCTACGATGTGGACGCGCCCTCGTTCTACTACGATTTTGCCATGTGGCAGTATTCATCCAAGGGCAGCGTGGACGGCATCAAGGGCAACGTCGATATGGACATCTGGTTCATCAAGTAA",
      "translation": "MKQNMRKRTPLAVLLALCLAMQLCVPAAMASNRLMRAGDAAIAQIEEEEGFRAEKYSSGGKWYIGYGTECGAEDYPEGITREEAELLLMSKVEAYEAKLNDFFGRYDVTPTQGQFDALICFSYNFGTGWMSGTSDLVKIARGEKDATRLEVAHAFGEWCHSGGQAQAGLADRRLQEAAIYLDDGTRAAENEFAYLIINMESGTSYETDFAVYEIGKTYGSFPKAEKLGYGFAGFRTSDGKTITENSIVNGNAVVTAQWTATSYTGKTYTDVNKSDWFYNYVMELSEQGIVGGNGDGTFAPNRPTSTGEMLKLVLLSTGHKEQKPSTAHWASGYATYAYSMGFAAQNYSDYQLDNGISRLDVARFAAKALGYGASNTTSPFADVNDGYVTALYEAGVFIGTKVGDLTYFYPNSSITRAEVATIVYRIYQLSSLDQKQKIYYKDYTLDVLEGVPTNTYNQSAFVKNGSIMTYNDPSVRTRVGIDVSQYQGDVDWNAVARTDVDFVIARVGGRGYTVGAIYDDTKFDEYADGAARAGLQVGAYFFSQAVSVAEAQEEAYHVLDKLRGHEITGPVVFDWEVIGKSEARTYGIETGVLCAAANAFCKIIKDAGYDPMIYITDYAGYVKYDLSEVMDYPLWYARYDVDAPSFYYDFAMWQYSSKGSVDGIKGNVDMDIWFIK",
      "product": ""
     },
     {
      "start": 19988,
      "end": 20851,
      "strand": -1,
      "locus_tag": "ctg48_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,988 - 20,851,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGCAAAGGTTTATTTTTCCAAGCAGATCACGCCGGAAAAGGTCGTGGAGCTCTACAAGGCCGCGGGTCTCGAGCTGCCCGGTAAGGTCGCCGTCAAGGTTCACTCCGGCGAACCGGGCAACCAGAACTTTCTGACGCCCGAGTTCTGGCAGCCGATGGTCGAGACCGTACACGGCACCATCGTTGAGTGCAACACCGCCTATCCCGGCGAGCGCAACACGACCGACGCCCACCGCCGCACGATGATCAAACACGGCTGGAGCAAGCTCTTCGATGTCGACATTCTTGACGCCGAGGGTCCCGATCTTGAGCTCCCCATCCCGAACGGCAAGCGCATCCAGAAGAATCTGGTCGGCAAGGATATCAAAAATTATGATTCCATGCTCGTTCTTTCCCACTTCAAGGGCCACCCGATGGGCGGCTTCGGCGGCGCGCTCAAACAGCTCTCCATCGGATGCGCGTCCAGCGCAGGCAAGGCGAACATCCACGGCGCGGGCAAGCCCGAAGAGATGTGGACGACCGGGCAGAATGCCTTTCTTGAGTCCATGGCCGATGCGGCGGAGTCCGTCGTCAAGCTTTTCGACGGCAAGATCGTCTACATCAACGTGATGAAGAACATGTCCGTCGACTGCGACTGCTGCGCCGTGGCGGAGGACCCGTGTATGAAAGATATCGGCATTCTCGCCTCCCTTGACCCCATCGCCATCGACCAGGCGTGCCTCGACCTTGTCTACGCGTCCGACGATTCGGGCCGCGACCACCTCGTTGAGCGCATCGAGAGCCTCAACGGCGTCCACACCGTGGAGGCCGCCGCCGAGCTCGGCTTCGGTTCGAGAGAGTATGAGCTGATCGAGCTCTAA",
      "translation": "MKAKVYFSKQITPEKVVELYKAAGLELPGKVAVKVHSGEPGNQNFLTPEFWQPMVETVHGTIVECNTAYPGERNTTDAHRRTMIKHGWSKLFDVDILDAEGPDLELPIPNGKRIQKNLVGKDIKNYDSMLVLSHFKGHPMGGFGGALKQLSIGCASSAGKANIHGAGKPEEMWTTGQNAFLESMADAAESVVKLFDGKIVYINVMKNMSVDCDCCAVAEDPCMKDIGILASLDPIAIDQACLDLVYASDDSGRDHLVERIESLNGVHTVEAAAELGFGSREYELIEL",
      "product": ""
     },
     {
      "start": 21112,
      "end": 22002,
      "strand": 1,
      "locus_tag": "ctg48_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,112 - 22,002,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAAAGCAAAAAAGAACACCGTCATCCATGCGGCGGCTGACCGCATGGCGGCGAACTACAAGAGCTCTCAGATCCCCATGTACGGCGATGCGCTGCGCATGCCCAACCGTAATGCGGTCATCGAGATCATCCGCGACTGTCAGAAGCTCATTTTCCCTGTTTACTACGGCGACCGCGACCTCTTGAAGCTGCCGCCGGAGCAATACAGCGCGCTTTTGATGGAGCACATCCACGAAAAGCTGACGCGCCAGATCACGCTGACGATGCCGGAGTGCGACGAGAACTGCGAAGTGGCCTATGCGATCAGCACGGCATTCATCGAGCGCATCCCTGCCATTCAGGAGTTGCTGCTCAAGGACCTGTCGGCGAACTTTGAGGGCGATCCTGCGGCTTACAGCAAGGAGGAGGTCCTGCTCTCGTACCCCGGCATGTTCGCCATCTTCATCTACCGCATCGCACACGAGCTGTATGAGAACAAGGTCGCGATGATCCCGCGCATGATGTCGGAATACGCGCACTCGCAGACCGGTATCGACATCAACCCCGGCGCGAAGATCGGCGAATACTTCTTCATCGACCACGGTACGGGCGTCGTCGTCGGCGAGACGACGATCATCGGCGACAACGTCAAGCTCTATCAGGGCGCGACGCTCGGCGCGCTCTCGCCCGCGGGTATGGCGACGAACCCGAATGTGCGCCGCCACCCGAAGGTCGGCAACAACGTCGTCATCTACGCAAACTCCACGCTGCTCGGCGGTGCGACGGAGATTGGCGACAATGTCGTCGTCGGTGGCAACGCGTTTCTGACCTCGTCGGTCGCGCCCAACACGGTCGTGAGCGTCAAAAATCCGGAGATGACGTTCCGCGGCAAGCACCACAGGGGATGA",
      "translation": "MDKAKKNTVIHAAADRMAANYKSSQIPMYGDALRMPNRNAVIEIIRDCQKLIFPVYYGDRDLLKLPPEQYSALLMEHIHEKLTRQITLTMPECDENCEVAYAISTAFIERIPAIQELLLKDLSANFEGDPAAYSKEEVLLSYPGMFAIFIYRIAHELYENKVAMIPRMMSEYAHSQTGIDINPGAKIGEYFFIDHGTGVVVGETTIIGDNVKLYQGATLGALSPAGMATNPNVRRHPKVGNNVVIYANSTLLGGATEIGDNVVVGGNAFLTSSVAPNTVVSVKNPEMTFRGKHHRG",
      "product": ""
     },
     {
      "start": 21999,
      "end": 22466,
      "strand": 1,
      "locus_tag": "ctg48_19",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,999 - 22,466,\n (total: 468 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 77; E-value: 2.7e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCTGACGGAGGGGGCGCGCGTCCGCCTGCGGATGATGCGGCGGGGGGACGCGAACGAATTATACGCCCTGCTCTCGGATGAAGCGGTGATGCGCTGGCTGGAGCCGCCGTTTAACCGCGCGCAGGCCGAGCGCTTTTTGGAGCAGGCGGGACTTTCCGATCCGCCGCTCATCTATGCCGCGGAGAATATGGAGGGAGAATTCCTCGGGTACGCCATCTTCCACAACTATGACGAGTACAGCCGGGAGCTCGGCTGGGTGCTCAAGCCTGCCTTTTGGCACAAGGGCTATGCGGACGAAATGACGGCTCTTCTGACCGCGCTTGCGCGGCGGGAGGGGAAGAATGCCGTGATCGAATGCGTCCCCGAACAGACGGCGAGCGCGCACATCGCGCGCAGGCACGGCTTTTCGTATGAGGGCCGCGCGGACAGCTGTGACGTTTACCGCCTGCGCTGTGAAAAATAA",
      "translation": "MILTEGARVRLRMMRRGDANELYALLSDEAVMRWLEPPFNRAQAERFLEQAGLSDPPLIYAAENMEGEFLGYAIFHNYDEYSRELGWVLKPAFWHKGYADEMTALLTALARREGKNAVIECVPEQTASAHIARRHGFSYEGRADSCDVYRLRCEK",
      "product": ""
     },
     {
      "start": 22649,
      "end": 23656,
      "strand": -1,
      "locus_tag": "ctg48_20",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,649 - 23,656,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAAAGTCTATATCCCGCAGGACTACCACACCCCGCTGTCTGTCTATGAAATGCAGCGCGCCATCGAATTCATCAAGAGCAATTTTCAGGTCAATCTGAGCAATGCCCTCAATCTCCGCCGGGTTTCTGCTCCGCTGTTCGTGGATGAAAATTCTGGTCTGAACGACAACCTCAACGGCGTCGAGCGTCCCGTCTCCTTTGACATTCCCGACGTCGGCACCAATGCCCAGGTCGTTCATTCGCTGGCCAAGTGGAAGCGTCTTGCGCTCAAGCGCTACGACTTCAAGGTCGGCAAGGGCCTGTTCACCGACATGAACGCCATCCGCCGCGACGAAGAGGTCGACAACCTCCACTCCGTCTATGTGGACCAGTGGGACTGGGAAAAGGTCATCTCCGCCGAGGACCGCAACGTCGCTTATCTCAAGCGCACCGTGCGCGATATCGTCTCCGCCGTCAGCGAGACGAGCAGCGCGCTGAATGTCGCTTTCCCCTCCCTGCACACCAAGCTCCCCAGTGAGGTCTTCTTCATCACCACGCAGGAGCTCGAAGACCTCTATCCCGACCTGACACCCAAGCAGCGCGAGGATGAGATCTGCAAGAAGAAGGGCGTCGTCTTCCTGATGCAGATCGGCAAGATCTTAAAGTCCGGCATCAAGCACGACGGCCGCGCCCCCGACTATGACGATTGGGAGCTCAACGGCGATATCCTCTACTGGAACGAAGTGCTCGGCCATGCGTTCGAGATCTCTTCCATGGGTATCCGCGTCGACCCCAAGTCCCTCGACTCCCAGCTGACGATCGCCGGCTGCGACGACCGCCGCGCGCTCCCCTTCCACAAGATGCTGCTGAATGGCGAGTTGCCCCTGACCATGGGCGGCGGCATCGGCCAGAGCCGCCTGTGCATGCTGCTCATCGGCACCGCGCACATCGGCGAGGTACAGGTCTCCCTGTGGGATGAAGCCACGCGCAAGACCTGCGAGGATGCGGGCGTCATGCTGCTGTAA",
      "translation": "MSKVYIPQDYHTPLSVYEMQRAIEFIKSNFQVNLSNALNLRRVSAPLFVDENSGLNDNLNGVERPVSFDIPDVGTNAQVVHSLAKWKRLALKRYDFKVGKGLFTDMNAIRRDEEVDNLHSVYVDQWDWEKVISAEDRNVAYLKRTVRDIVSAVSETSSALNVAFPSLHTKLPSEVFFITTQELEDLYPDLTPKQREDEICKKKGVVFLMQIGKILKSGIKHDGRAPDYDDWELNGDILYWNEVLGHAFEISSMGIRVDPKSLDSQLTIAGCDDRRALPFHKMLLNGELPLTMGGGIGQSRLCMLLIGTAHIGEVQVSLWDEATRKTCEDAGVMLL",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 12892,
      "end": 14281,
      "tool": "rule-based-clusters",
      "neighbouring_start": 2892,
      "neighbouring_end": 24281,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r48c1"
   }
  ]
 },
 {
  "length": 41799,
  "seq_id": "JPJG01000027.1",
  "regions": []
 },
 {
  "length": 13265,
  "seq_id": "JPJG01000028.1",
  "regions": []
 },
 {
  "length": 81333,
  "seq_id": "JPJG01000029.1",
  "regions": []
 },
 {
  "length": 5371,
  "seq_id": "JPJG01000003.1",
  "regions": []
 },
 {
  "length": 3689,
  "seq_id": "JPJG01000030.1",
  "regions": []
 },
 {
  "length": 35502,
  "seq_id": "JPJG01000031.1",
  "regions": []
 },
 {
  "length": 9362,
  "seq_id": "JPJG01000130.1",
  "regions": []
 },
 {
  "length": 4319,
  "seq_id": "JPJG01000032.1",
  "regions": []
 },
 {
  "length": 86331,
  "seq_id": "JPJG01000033.1",
  "regions": []
 },
 {
  "length": 80199,
  "seq_id": "JPJG01000034.1",
  "regions": []
 },
 {
  "length": 25929,
  "seq_id": "JPJG01000035.1",
  "regions": []
 },
 {
  "length": 13420,
  "seq_id": "JPJG01000036.1",
  "regions": []
 },
 {
  "length": 23089,
  "seq_id": "JPJG01000004.1",
  "regions": []
 },
 {
  "length": 28805,
  "seq_id": "JPJG01000037.1",
  "regions": []
 },
 {
  "length": 7890,
  "seq_id": "JPJG01000038.1",
  "regions": []
 },
 {
  "length": 10954,
  "seq_id": "JPJG01000039.1",
  "regions": []
 },
 {
  "length": 42238,
  "seq_id": "JPJG01000040.1",
  "regions": []
 },
 {
  "length": 2818,
  "seq_id": "JPJG01000041.1",
  "regions": []
 },
 {
  "length": 24142,
  "seq_id": "JPJG01000042.1",
  "regions": []
 },
 {
  "length": 17633,
  "seq_id": "JPJG01000043.1",
  "regions": []
 },
 {
  "length": 19873,
  "seq_id": "JPJG01000044.1",
  "regions": []
 },
 {
  "length": 20146,
  "seq_id": "JPJG01000045.1",
  "regions": []
 },
 {
  "length": 28270,
  "seq_id": "JPJG01000005.1",
  "regions": []
 },
 {
  "length": 31516,
  "seq_id": "JPJG01000046.1",
  "regions": []
 },
 {
  "length": 4360,
  "seq_id": "JPJG01000047.1",
  "regions": []
 },
 {
  "length": 2429,
  "seq_id": "JPJG01000048.1",
  "regions": []
 },
 {
  "length": 40888,
  "seq_id": "JPJG01000049.1",
  "regions": []
 },
 {
  "length": 37450,
  "seq_id": "JPJG01000050.1",
  "regions": []
 },
 {
  "length": 41459,
  "seq_id": "JPJG01000051.1",
  "regions": []
 },
 {
  "length": 10977,
  "seq_id": "JPJG01000052.1",
  "regions": []
 },
 {
  "length": 29235,
  "seq_id": "JPJG01000053.1",
  "regions": []
 },
 {
  "length": 52133,
  "seq_id": "JPJG01000054.1",
  "regions": []
 },
 {
  "length": 46057,
  "seq_id": "JPJG01000055.1",
  "regions": []
 },
 {
  "length": 45281,
  "seq_id": "JPJG01000006.1",
  "regions": []
 },
 {
  "length": 53274,
  "seq_id": "JPJG01000056.1",
  "regions": []
 },
 {
  "length": 13299,
  "seq_id": "JPJG01000057.1",
  "regions": []
 },
 {
  "length": 30739,
  "seq_id": "JPJG01000058.1",
  "regions": []
 },
 {
  "length": 66278,
  "seq_id": "JPJG01000059.1",
  "regions": []
 },
 {
  "length": 41947,
  "seq_id": "JPJG01000060.1",
  "regions": []
 },
 {
  "length": 41414,
  "seq_id": "JPJG01000061.1",
  "regions": []
 },
 {
  "length": 34508,
  "seq_id": "JPJG01000062.1",
  "regions": []
 },
 {
  "length": 15883,
  "seq_id": "JPJG01000063.1",
  "regions": []
 },
 {
  "length": 32447,
  "seq_id": "JPJG01000064.1",
  "regions": []
 },
 {
  "length": 17289,
  "seq_id": "JPJG01000007.1",
  "regions": []
 },
 {
  "length": 2387,
  "seq_id": "JPJG01000065.1",
  "regions": []
 },
 {
  "length": 62644,
  "seq_id": "JPJG01000066.1",
  "regions": []
 },
 {
  "length": 1560,
  "seq_id": "JPJG01000067.1",
  "regions": []
 },
 {
  "length": 15346,
  "seq_id": "JPJG01000068.1",
  "regions": []
 },
 {
  "length": 10078,
  "seq_id": "JPJG01000069.1",
  "regions": []
 },
 {
  "length": 26167,
  "seq_id": "JPJG01000070.1",
  "regions": []
 },
 {
  "length": 58550,
  "seq_id": "JPJG01000008.1",
  "regions": []
 },
 {
  "length": 28775,
  "seq_id": "JPJG01000071.1",
  "regions": []
 },
 {
  "length": 14385,
  "seq_id": "JPJG01000072.1",
  "regions": []
 },
 {
  "length": 22576,
  "seq_id": "JPJG01000073.1",
  "regions": []
 },
 {
  "length": 18282,
  "seq_id": "JPJG01000074.1",
  "regions": []
 },
 {
  "length": 8930,
  "seq_id": "JPJG01000075.1",
  "regions": []
 },
 {
  "length": 14174,
  "seq_id": "JPJG01000076.1",
  "regions": []
 },
 {
  "length": 3144,
  "seq_id": "JPJG01000077.1",
  "regions": []
 },
 {
  "length": 10971,
  "seq_id": "JPJG01000078.1",
  "regions": []
 },
 {
  "length": 11460,
  "seq_id": "JPJG01000079.1",
  "regions": []
 },
 {
  "length": 1714,
  "seq_id": "JPJG01000009.1",
  "regions": []
 },
 {
  "length": 1135,
  "seq_id": "JPJG01000080.1",
  "regions": []
 },
 {
  "length": 2824,
  "seq_id": "JPJG01000081.1",
  "regions": []
 },
 {
  "length": 10843,
  "seq_id": "JPJG01000082.1",
  "regions": []
 },
 {
  "length": 18062,
  "seq_id": "JPJG01000083.1",
  "regions": []
 },
 {
  "length": 10866,
  "seq_id": "JPJG01000084.1",
  "regions": []
 },
 {
  "length": 17068,
  "seq_id": "JPJG01000085.1",
  "regions": []
 },
 {
  "length": 4823,
  "seq_id": "JPJG01000086.1",
  "regions": []
 },
 {
  "length": 12150,
  "seq_id": "JPJG01000087.1",
  "regions": []
 },
 {
  "length": 4697,
  "seq_id": "JPJG01000088.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r48c1"
 ],
 "r48c1": {
  "start": 2893,
  "end": 24281,
  "idx": 1,
  "orfs": [
   {
    "start": 4452,
    "end": 6203,
    "strand": -1,
    "locus_tag": "ctg48_4",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,452 - 6,203,\n (total: 1752 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 324.2; E-value: 2.7e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNMIHRFMGCIREYKKPTILTLLCMVGEVAIEVLIPFFTANLVNEIKGGAELSGVVRVGLGLILMSLVSLGCGALGGLYGSRASAGFAKNVRHDVFTRVQSFAFENIDKFSSASLVTRMTTDINNVQMSFMMCIRIAVRAPLMFLFAVIMAYIMGGALATTFLIIIPVLVIGLLLIARKAMPAFRAVFRKYDKLNESVEENVRAMRVVKGFAREGYEKQKFAAASHDIAKDFTFAERVVALNAPLMQFCVYFNMIFVLFVGSRIIITNGGTTIDVGQLSAMLTYGMQILMSLMMISMIYVMMTMSYESFVRICEVLEEEPALTDPASPAMDVKDGSIDFENVSFKYSAQAKKFALQDINLHIDSGMTVGILGGTGSSKSTLVQLIPRLYDVSEGCVKVGGRDVREYDLEALRGAVSVVLQKNVLFSGTVKDNLRWGNENATDDEMIEACRLAQADEFVRSFPDGYDTYIEQGGSNVSGGQKQRLCIARALLKKPKILILDDSTSAVDTRTDALIREGFRTYIPETTKIIIAQRVASVQDADLILVMDNGHIADMGTHDQLLASSEIYREVYESQTNGGEQDEA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATATGATCCATCGCTTCATGGGCTGCATCCGCGAGTATAAAAAGCCCACGATCCTGACGCTCTTGTGCATGGTCGGCGAGGTCGCGATTGAAGTGCTGATCCCGTTTTTCACCGCCAACCTCGTCAACGAAATCAAGGGCGGCGCGGAGCTCAGCGGCGTTGTGCGCGTGGGCCTTGGGCTCATCCTGATGTCGCTCGTGTCGCTCGGCTGCGGCGCGCTCGGCGGGCTTTACGGCTCGCGCGCGAGCGCCGGCTTTGCCAAAAACGTCCGCCACGATGTTTTCACCCGCGTGCAGAGCTTCGCGTTTGAAAATATCGACAAATTCTCCTCCGCCTCGCTCGTCACGCGCATGACGACCGATATCAACAATGTGCAGATGTCCTTTATGATGTGCATCCGCATCGCGGTACGCGCACCGCTGATGTTTCTCTTCGCCGTCATCATGGCCTATATCATGGGCGGCGCGCTGGCGACGACATTCCTCATTATCATTCCCGTGCTGGTAATCGGACTTCTTCTGATCGCACGTAAGGCAATGCCCGCGTTCCGCGCGGTGTTCCGCAAGTACGATAAGCTCAATGAATCGGTCGAGGAAAATGTGCGCGCGATGCGCGTGGTCAAGGGCTTTGCCCGCGAAGGGTATGAAAAGCAGAAGTTCGCCGCGGCCTCGCACGATATCGCCAAGGACTTCACCTTCGCCGAGCGCGTCGTCGCGCTCAACGCGCCGCTGATGCAGTTCTGCGTATACTTCAACATGATCTTCGTGCTATTTGTCGGCTCGCGGATCATCATCACGAACGGCGGCACGACCATCGACGTTGGCCAGCTCTCGGCCATGCTGACCTACGGCATGCAGATCTTAATGTCGCTGATGATGATCTCGATGATCTACGTGATGATGACGATGTCGTATGAGTCCTTCGTCCGTATCTGCGAGGTACTCGAGGAAGAGCCCGCGCTCACCGATCCCGCATCTCCCGCGATGGACGTGAAGGACGGCTCCATCGACTTTGAAAACGTCAGCTTCAAGTACTCCGCACAGGCGAAGAAATTCGCGCTGCAGGACATCAACCTGCACATCGACTCAGGCATGACCGTCGGCATCCTCGGCGGTACGGGCTCGAGCAAGTCGACCCTCGTGCAGCTCATCCCGCGCCTTTACGATGTGAGCGAGGGCTGCGTCAAGGTCGGCGGCAGAGATGTGCGCGAATACGACCTTGAGGCGCTGCGCGGCGCGGTCAGCGTCGTGCTGCAAAAGAATGTGCTGTTTTCCGGCACGGTCAAGGATAACCTGCGCTGGGGCAACGAAAACGCCACCGACGACGAGATGATCGAGGCGTGCAGGCTCGCGCAGGCGGACGAATTCGTCCGCTCCTTCCCCGACGGGTATGACACCTATATCGAGCAGGGCGGCTCGAACGTCTCCGGCGGACAGAAGCAGCGTCTCTGCATCGCCCGGGCGCTTCTCAAAAAGCCGAAGATTCTGATCCTCGACGACTCGACCTCCGCGGTCGACACGCGCACCGACGCGCTGATCCGCGAGGGCTTCCGCACCTATATCCCCGAGACGACGAAGATCATCATTGCCCAGCGCGTCGCGTCCGTGCAGGATGCCGACCTCATTCTCGTGATGGACAACGGCCATATTGCGGACATGGGCACGCACGATCAGCTCCTCGCTTCGAGTGAAATTTACCGCGAGGTCTACGAATCCCAGACGAACGGAGGTGAGCAGGATGAAGCGTGA",
    "translation": "MNMIHRFMGCIREYKKPTILTLLCMVGEVAIEVLIPFFTANLVNEIKGGAELSGVVRVGLGLILMSLVSLGCGALGGLYGSRASAGFAKNVRHDVFTRVQSFAFENIDKFSSASLVTRMTTDINNVQMSFMMCIRIAVRAPLMFLFAVIMAYIMGGALATTFLIIIPVLVIGLLLIARKAMPAFRAVFRKYDKLNESVEENVRAMRVVKGFAREGYEKQKFAAASHDIAKDFTFAERVVALNAPLMQFCVYFNMIFVLFVGSRIIITNGGTTIDVGQLSAMLTYGMQILMSLMMISMIYVMMTMSYESFVRICEVLEEEPALTDPASPAMDVKDGSIDFENVSFKYSAQAKKFALQDINLHIDSGMTVGILGGTGSSKSTLVQLIPRLYDVSEGCVKVGGRDVREYDLEALRGAVSVVLQKNVLFSGTVKDNLRWGNENATDDEMIEACRLAQADEFVRSFPDGYDTYIEQGGSNVSGGQKQRLCIARALLKKPKILILDDSTSAVDTRTDALIREGFRTYIPETTKIIIAQRVASVQDADLILVMDNGHIADMGTHDQLLASSEIYREVYESQTNGGEQDEA",
    "product": ""
   },
   {
    "start": 6200,
    "end": 6706,
    "strand": -1,
    "locus_tag": "ctg48_5",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,200 - 6,706,\n (total: 507 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 70.5; E-value: 1.8e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAGACCAACGAGATCCAGGAGCTGCTGCTCGACACGATCCCCGCGTGGCACTACTGGTTTGCCCGTCCGTTCAAGCGCATGCTGAATGACGGCGTCAGCCTTGACATGTACTACTGCATCCAGTCGATGCGCCGCAGCGGCCGCACGATGACGATGACAGAGCTTGCAAACTTTGCCCGCATGCCCAAGCAGCAGATGAGCAAGCTCGTCGACAAGCTGGTCGAGGGCGGCTTTGCCGAGCGGCTGAGCGACCCCGACGACCGCCGCGTCATCCGCCTGCGGGCGACTGAGAAGGCCGACGAATACGTGGCGAGCTTTTTAGAGAAGGATGCGGCGGAGTTCCGCGCATTTTTCGACCAGCTCGAAGGCGAAGAGCGTGAGACCTTCTGCACGGCGCTTCGCACCATCCACGACACCTTTGAGGCCAAACGCAAGCGCATGATCGAGCAGGGCAAGCTGCCCGACTGTCCCCCACAAACTAAGAAAGAAGGCCACTGCCGATGA",
    "translation": "MQTNEIQELLLDTIPAWHYWFARPFKRMLNDGVSLDMYYCIQSMRRSGRTMTMTELANFARMPKQQMSKLVDKLVEGGFAERLSDPDDRRVIRLRATEKADEYVASFLEKDAAEFRAFFDQLEGEERETFCTALRTIHDTFEAKRKRMIEQGKLPDCPPQTKKEGHCR",
    "product": ""
   },
   {
    "start": 6871,
    "end": 9495,
    "strand": -1,
    "locus_tag": "ctg48_6",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,871 - 9,495,\n (total: 2625 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 124.2; E-value: 1.1e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAGAAGGTCACGCTCGGCATTCTCGCCCACGTCGACTCGGGAAAAACGACCCTGTCCGAGGGGCTTTTATACGCCTCCGGCGCACTGCGGAAGCTCGGCCGCGTCGACCACGGCGACGCCTTCCTCGACACCGACGCGCTCGAGCGCGAGCGCGGCATCACGATCTTTTCCAAGCAGGCAATGCTGTTTGCGGGCGATAAGGAGTTCACGCTGCTTGACACGCCGGGCCACGTCGATTTCTCCGCCGAGATGGAGCGCACGCTGTCGGTACTCGACTACGCAGTGCTCGTCATCAGCGGCAGCGACGGCGTGCAGAGCCACACGCGAACGCTCTGGCGCCTGCTCACGCGCTACGAGGTGCCGACGTTTCTTTTCATCAACAAGATGGACTTGGCGGGCGCGGACAAGGACGCGCTTCTGCGCCAGCTCGCGGCGACACTGAGCGCGGAATGCGTCGATTTCTCCGCATCGCAGGAAACGCGCGACGAAGCGCTCGCCCTCTGCGACGAGGCGGCGCTCGAGCAGCTTTTGGAGCGTGGAAAAATCGACGACGCTCTGATTGCTGAGATGGTCAAAAACCGCAAGGTCTTCCCCTGCTTTTTCGGTTCGGCGCTCAAGCTGGACGGCGTGGAGGACTTTCTCACCGCGCTCGCGTGCTTCACGCGCGAGCCGGTCTATCCGAAGGAATTCGGCGCAAAGGTCTTCAAGATCTCGCGCGACGCGCAGGGCGCGCGGCTCACGTGGCTCAAGGTCACAGGCGGCGCGCTGCGCGTGAAGGCACCTCTCACCTATCGCGCGCAGAATCAGGACTATAATGAAAAGGCCGATCAGCTGCGGCTATACTCCGGCGTCAAATTCCGCGCGCTCGAAGAGGCGGGCGCGGGCAGCGTCGTCGCCGTCACGGGCCTCAGCCACAGCTATGTTGGTCTCGGCCTCGGCGCGGAGGCGGAGGCGTCCGCCCCGCTTTTGCAGCCGGTTTTGACCTATCAGCTCATCCTACCCGACGGCGCGGACGCGCACAGCGCGCTTATAAAGCTCCGCGAGCTTGAAGAAGAGGACCCGATGCTGCGCATCGTCTGGGACGAGCGCTACGGGCAGATCCACGTGCAGCTCATGGGCAAAATTCAGCTCGAAATTCTGCGCCGCCGCATCCTCGACCGCTTCGGCCTCGACGTGACCTTCGGCGAGGGCAGCATCGTCTATCGCGAGACCATCACCGCCCCCGTCCTCGGCATGGGACATTTCGAGCCCCTGCGCCACTATGCGGAAGTACAGCTTCTAATAGAGCCGCTTCCGCGCGGGGCGGGCATCCAGCTTGCGTCAAACGTGCCGACGGACGCGCTCGACCTCAACTGGCAGCGGCTGATTTTCACCCATCTTTTAGAGCGCGAGCACGCGGGCGTGCTAACCGGCTCACCGTTGACGGATGTGAAGTTCACACTTGTCGCGGGCCGCGCGCATCTGAAGCACACCGAGGGCGGCGACTTCCGTCAAGCGACGTACCGTGCCGTGCGGCAGGGCTTGATGCAGGCAGAAAATGTGCTGCTCGAGCCGTATTACGACTTCCGTCTCGAGGTGCCCGCCGAGTGCGTCGGCCGCGCGATGACCGACCTCCAGAACATGGGCGGCACCGTCGAACCGCCGCAGAACGAGGGGGAAAACGCCGTACTCACGGGCTATGCGCCGGTGCGCACGCTGCGCGACTACTTTGCCGACGTCGCGGCCTACACCCGCGGCCGCGGACAGCTCTCCTGCGCCGTGCGCGGGTATGAGGCCTGCCAAAATCAGGACGAGATCGTCGCGTCCCTTGGCTACGACGCCGAGCGCGACACGGATAATCCCGCGTCCTCCGTCTTCTGCGACCACGGCGGCAGCATCACGGTCCCGTGGAATGAAGTTCCCGCGCATGTTCACTGCGACAGCGGCATCCGCCTTGGTGAAGAGGCCGTCGAAGAAGCGCCCGCGCCGCTCCCCCGACGCAGCGTCGGCGCAGGCGGCGCATATGCCGAGGACAAGGAATTGCAGGACATTTTTGAGCGCACATACGGCAAGGTCGAGCGCCGCGCGTTCGAACCGAGCAAAAAGCCCGCGCGCACCTCGCTCGCCGATCACTATGACGTCACGATCCACTCAGAGGACACGGAATATCTGCTCGTCGACGGCTACAACATCATCTTCGCGTGGGACGAGCTCCATCGGCTCGCCGCGCAGGATGTCGCCGCGGCGCGCGGCGCGCTGATCGACATTCTCGCCAACTATCAGGGCTTTCGCAAGTGCCGCGTCATCGTCGTGTTCGACGCCTATAAGGTCAAGGGCAACCCCGGCAGTGTGCAGACGGTGCACGGCGTCAAGGTCGTCTACACGAAAGAGGCTGAGACTGCCGACACCTACATCGAGCGCGCGACCTACGAGCTGCGCCGCGAACGCCGCGTGCGCGTGGCGACGTCCGACGGCCCCGAGCAGGTCATCATCCTCGGCCACGGGGCGCTGCGCGTCTCCGCCCGCGCGTTCCATGCCGAGGTCGAAGCCGCCGAGGGGCAGATCAGCGCCGTGCTGCAACGCCTGACGAACCGCCCCAGAAGTGAGCGCACGATCAGAAACAATGTAAAACTCAAGCAATAA",
    "translation": "MQKVTLGILAHVDSGKTTLSEGLLYASGALRKLGRVDHGDAFLDTDALERERGITIFSKQAMLFAGDKEFTLLDTPGHVDFSAEMERTLSVLDYAVLVISGSDGVQSHTRTLWRLLTRYEVPTFLFINKMDLAGADKDALLRQLAATLSAECVDFSASQETRDEALALCDEAALEQLLERGKIDDALIAEMVKNRKVFPCFFGSALKLDGVEDFLTALACFTREPVYPKEFGAKVFKISRDAQGARLTWLKVTGGALRVKAPLTYRAQNQDYNEKADQLRLYSGVKFRALEEAGAGSVVAVTGLSHSYVGLGLGAEAEASAPLLQPVLTYQLILPDGADAHSALIKLRELEEEDPMLRIVWDERYGQIHVQLMGKIQLEILRRRILDRFGLDVTFGEGSIVYRETITAPVLGMGHFEPLRHYAEVQLLIEPLPRGAGIQLASNVPTDALDLNWQRLIFTHLLEREHAGVLTGSPLTDVKFTLVAGRAHLKHTEGGDFRQATYRAVRQGLMQAENVLLEPYYDFRLEVPAECVGRAMTDLQNMGGTVEPPQNEGENAVLTGYAPVRTLRDYFADVAAYTRGRGQLSCAVRGYEACQNQDEIVASLGYDAERDTDNPASSVFCDHGGSITVPWNEVPAHVHCDSGIRLGEEAVEEAPAPLPRRSVGAGGAYAEDKELQDIFERTYGKVERRAFEPSKKPARTSLADHYDVTIHSEDTEYLLVDGYNIIFAWDELHRLAAQDVAAARGALIDILANYQGFRKCRVIVVFDAYKVKGNPGSVQTVHGVKVVYTKEAETADTYIERATYELRRERRVRVATSDGPEQVIILGHGALRVSARAFHAEVEAAEGQISAVLQRLTNRPRSERTIRNNVKLKQ",
    "product": ""
   },
   {
    "start": 10052,
    "end": 10441,
    "strand": -1,
    "locus_tag": "ctg48_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,052 - 10,441,\n (total: 390 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGATTGATAGCGCAAAGGATCTTCAAATGAACATTGCAAAAGAGGGATTGGCACTGCTGATGTTCCATCCCAGCTTCAATGTGCAGCCCCATAGGGAGTGCATCTTCCTCATTGGCACAGCGTGGGACATCCCCGTGGGTGACACGCAGGAGGTCATCTCGCTTCTGGATCGTGAGCTGGATGCGATCCGCGCCGCAGGCGAAGGTGGCACGGCAGCGCATGTGTTGCCGGAGGATGAACTCCCGATGAATGCCACCGGCTTGGAAACGCTGGACAACATCTGGGACCTGTTCGAAACGAGCCTGCGCATGGACAGTATGCAAGCCAGAACAAAGAAGTTCGAAATGGCAAAGTGGTTAGAGAAAAGCCAAAACCTTCTGGACTGA",
    "translation": "MTIDSAKDLQMNIAKEGLALLMFHPSFNVQPHRECIFLIGTAWDIPVGDTQEVISLLDRELDAIRAAGEGGTAAHVLPEDELPMNATGLETLDNIWDLFETSLRMDSMQARTKKFEMAKWLEKSQNLLD",
    "product": ""
   },
   {
    "start": 10685,
    "end": 11068,
    "strand": 1,
    "locus_tag": "ctg48_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,685 - 11,068,\n (total: 384 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAACAAACCTTGTGGTGGCGGATATCAGCCGTACCGAGAAAACGATATGCCTTGCGGTTTCGCCAGCCCTGAAAGCCTACGGGATACCCGTTAGAGCTCGCCTCTTTGAGGTGGTGGAACGCGTCAAAGAAGTCAACGCCGAACGCCGGCGTGAAGAATCCGCCATCGTCATCAAGGCCACAGACCGATACTCGGAGACAGTCAAGCGCAAGGGCGAGACTACGAAGAGCTTCGGGAAGAACCTTGGCAAAACGGAGGACATCCTGACGCTCCTGAGCAAAAACAAAGCAACCATCAGGGTTGATGTGAAGCAGGCGAAAGCACCTTGCAGGATGCGGAAAAGCAGTTTGCGAAAACCCGCAGCGAAGCGGACAAGCTGA",
    "translation": "MTTNLVVADISRTEKTICLAVSPALKAYGIPVRARLFEVVERVKEVNAERRREESAIVIKATDRYSETVKRKGETTKSFGKNLGKTEDILTLLSKNKATIRVDVKQAKAPCRMRKSSLRKPAAKRTS",
    "product": ""
   },
   {
    "start": 11568,
    "end": 12893,
    "strand": -1,
    "locus_tag": "ctg48_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,568 - 12,893,\n (total: 1326 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAACGCCCATTGCTGATTTTGTCCGGCGGTACGCGGATTCCGGGATGGTCCGGGCGCATATGCCCGGCCACAAGGGAAAACCCTTTCTGGGTTGCGAGGCGCTGGACATCACCGAGATCCAAGGCGCGGACAGCCTGTATGAAGCGGAAGGCATCATCCGGCGCAGTGAGTCCTATGCCGGGAAGCTGTTCGGCTCTGGCCGGACGGTGTACTCCACAGAGGGGTCCAGCCAGTGCATCCGGGCGATGCTGTATCTGGCGCTGACCTGCGGAAACGGGTCCCGGACGGTGGTGGCGGCCCGAAACGTACACCGGGCGTTTGTATATGCGGCGGCCCTGCTGGATTTTGAGATCGTCTGGCTGTGGCCAGAGCGCAGCTCGTCTCTCTGCGGCTGCCCGGTATCGCCGGACACATTGGGGCGGACGCTGGAGGAGCTGCCTGCGCCGCCGGCGGCGGTCTATCTTACCAGCCCGGACTATCTGGGCGGCATGGCGGATATTTCCGCTCTGGCAGAGGTGTGCCGGAAACACGGTACGCTGCTGGCGGTGGACAACGCCCACGGCGCCTATCTGCGGTTTCTGGAACCATCCTGTCACCCGTTGGATCTCGGCGCAGATCTGTGCTGTGATTCGGCGCACAAGACGCTGCCGGTGCTGACCGGCGGCGCGTACCTGCACATCAGCCGCGCGGCGCCGGCATCTCTCCGGGAGAGTGCAAAAACAGCGATGGCCATGTTTGGTTCCACCAGTCCGTCCTACCTGACGCTGGCGTCGCTGGATCTGTGCAACCGCTATCTGGCGGATGGGTACCAGGACCACCTGCGGGAGATGTGTGGGCATCTGGAGGAAGCGCAAAAGGCGCTGACGGCTGCCGGTTGGCAGATAGAGCCATCGGACCCGCTGCGGCTGACCGTCAAGGCTCCAGCCGGGATGACCGGCGGAGCGCTGGCAGACCGCCTGCGAGAGAGCGGCGTGGAATGTGAATACGCCAATCCGGACTTTCTGGTGCTGATGCTGACGCCGGAGAATAGTGCGGCGGATATCGAGCGGCTTGTGTATGCCATAGGAACAAACGACGCCGTTTATGCGCCGCAGCCGTCGCTGCCGTTGGCTCGTGGAGAACGGGTATGTTCCGCGCGAGAGGCACTGTTCGCCCCACGGGAGACCATACCGGCGGCGCAGTCGTTAGGGCGGGTCTGCGGCGCCCCTACCGTGGGGTGTCCGCCTGCGATCCCCATTGCGGTGTCCGGTGAGCGAATTGGTCCGGAAGCGCTGGAGCTGTTCCGGCGGTACGGCGTGGAGCGGGTGGAAGTCTTGCGCTGA",
    "translation": "METPIADFVRRYADSGMVRAHMPGHKGKPFLGCEALDITEIQGADSLYEAEGIIRRSESYAGKLFGSGRTVYSTEGSSQCIRAMLYLALTCGNGSRTVVAARNVHRAFVYAAALLDFEIVWLWPERSSSLCGCPVSPDTLGRTLEELPAPPAAVYLTSPDYLGGMADISALAEVCRKHGTLLAVDNAHGAYLRFLEPSCHPLDLGADLCCDSAHKTLPVLTGGAYLHISRAAPASLRESAKTAMAMFGSTSPSYLTLASLDLCNRYLADGYQDHLREMCGHLEEAQKALTAAGWQIEPSDPLRLTVKAPAGMTGGALADRLRESGVECEYANPDFLVLMLTPENSAADIERLVYAIGTNDAVYAPQPSLPLARGERVCSAREALFAPRETIPAAQSLGRVCGAPTVGCPPAIPIAVSGERIGPEALELFRRYGVERVEVLR",
    "product": ""
   },
   {
    "start": 12893,
    "end": 14281,
    "strand": -1,
    "locus_tag": "ctg48_10",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,893 - 14,281,\n (total: 1389 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTACATCAGTATCAACTGAACGGCTACAACATCGTGCTGGATACCTGCTCCGGCGCCATTCATGTAGTGGATGAGGTAGCCTATGACATCATTGCGCTTTACCCGGATCACACGGCGGATGAGATCGTAACGGCGATGATGGAAAAATACGGCGAGCGCGAGGATGTGACGGAGCAGGATCTGCGGAACTGCATTGATGACGTGGAGGCACTGAAGCAGGCCGGGAAGCTCTATACCCCCGACACCTTCGCAGACATGGCCGGTACGTTCAAGGAGCGTTCTGGCGATGTGGTGAAGGCGCTGTGCCTGCATGTGGCGCACACCTGCAACCTGAACTGCTCCTACTGCTTCGCCAGCCAGGGAAAATACCATGGAGACCGTGCGCTGATGAGCTTTGAGGTTGGCAAGCAGGCTCTGGACTTTCTGATGGATCACTCCGGCAGCCGCACCAATCTGGAGGTGGACTTCTTCGGCGGTGAGCCGCTGATGAACTGGGACGTGGTGAAGCAGTTGGTGGAGTATGCCCGCAGTGTGGAAAAGGAGCGGGGCAAAAATTTCCGCTTTACGCTGACCACAAACGGTATGCTCATCGACGATGACGTGATCGACTTCGCCAACCGGGAAATGAGCAATGTGGTGCTGTCGCTGGATGGCCGCAAGGAAATTCATGACCGGCTGCGGGTGGACTATGCAGGCAACGGCAGCTATGAGCGCATTGTGCCTAAGTTCCAGAAGCTGGTAGAGGCCAGAGGCAACAAGAACTATTATATGCGCGGCACCTTTACCCATGCCAATCCGGACTTTACGAAGGACCTGTTCCACATGGCGGATCTGGGCTTCACGGAGTTGAGCATGGAGCCTGTGGTGTGCGCGCCGGAGGACCCCGCCGCGCTGACGGCGGAGGATCTGGAGATCGTGAAGGACCAGTACGAGCTGCTGGCCAAGGATATGCTGCGCCGGGAAAAAGAAGGCAAGCCCATCACCTTCTATCACTACATGCTGGACCTGACGGGCGGCCCCTGCATTTACAAGCGAATCTCCGGCTGCGGCTCCGGCACGGAGTATATGGCTGTGACCCCTTGGGGAGACCTGTATCCCTGCCATCAGTTCGTGGGTGAGGAAGCCTACAAGCTGGGCGACATCTGGAACGGCGTGACCAATACGGCCCTGCGGGAGGAATTCCGCTCCTGCAACGCCTATGCCCGGCCAGAGTGCAATGACTGCTGGGCGAGATTCTACTGCTCCGGCGGCTGCGCAGCCAACGCCTTCCACGCCACGGGCTCTATCCGCGGCGTTTACGAGGCAGGCTGCGAATTGTTCCGCAAGCGTATTGAATGTGCCATCATGATGAAGGTGGCGGAAGATTCTGCCAAGGCCAACGGCTGA",
    "translation": "MVHQYQLNGYNIVLDTCSGAIHVVDEVAYDIIALYPDHTADEIVTAMMEKYGEREDVTEQDLRNCIDDVEALKQAGKLYTPDTFADMAGTFKERSGDVVKALCLHVAHTCNLNCSYCFASQGKYHGDRALMSFEVGKQALDFLMDHSGSRTNLEVDFFGGEPLMNWDVVKQLVEYARSVEKERGKNFRFTLTTNGMLIDDDVIDFANREMSNVVLSLDGRKEIHDRLRVDYAGNGSYERIVPKFQKLVEARGNKNYYMRGTFTHANPDFTKDLFHMADLGFTELSMEPVVCAPEDPAALTAEDLEIVKDQYELLAKDMLRREKEGKPITFYHYMLDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGEEAYKLGDIWNGVTNTALREEFRSCNAYARPECNDCWARFYCSGGCAANAFHATGSIRGVYEAGCELFRKRIECAIMMKVAEDSAKANG",
    "product": ""
   },
   {
    "start": 14334,
    "end": 14630,
    "strand": 1,
    "locus_tag": "ctg48_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,334 - 14,630,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAAAATTGCGATTGATTACTTGTTGGTGTTCTCGCACTTCTGGTTTGCCACGCCGCAGCTGGTCTTGCAGGCAGACTGGCAGGAGGTCTGGCACTCACCGCAGCCGCCGTTCTTGGCGCTGTCGCACAGGCTACGAGTCTCAAGAGTCTTGATTCTTTCCATAATATGTATCTCCGATCTGTTAAATTCTAATGGATTTTCCGGCAGACCACCCGCAGACAGTCACCTAAAAACCGGAGAAATTCTAGCATATCATCCGTATAAAGTCAAGATATTCCAGCAATTTGGCTATTAG",
    "translation": "MKIAIDYLLVFSHFWFATPQLVLQADWQEVWHSPQPPFLALSHRLRVSRVLILSIICISDLLNSNGFSGRPPADSHLKTGEILAYHPYKVKIFQQFGY",
    "product": ""
   },
   {
    "start": 14880,
    "end": 15485,
    "strand": 1,
    "locus_tag": "ctg48_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,880 - 15,485,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATTTTCGGCTTCAGCCATGGCTGGGAACCATTGCAATTACTACTCTTTTGGAGTTTTACTCATGGCTGTGTCTACTCCATTGATGAGGTGATGATTGACGCCACCAGTTACCTTGGGACGTATCACATGACGGCGCGGGAACTGGCACGAACCATGATCCTTGATGTGCTGCGCACAACGAGGATCACCGCGACCGCGGGGATCGGCACAAACCTCTATCTTTGCAAGGTCGCTATGGACATCATGGCCAAACACGTCGCGCCGGATGAGAGCGGTGTCCGGATCGCGGAGCTGGATGAAATGAGCTACCGCAGACAGCTTTGGATGCACCGCCCGCTGACCGACTTCTGGCGGGTGGGAAAAGGCTATGCCAAAAAGCTCGAGGCCATCGGCATCTACACCATGGGAGATATCGCCCGGTGCTCCATCGGGAAGGCCGGGGAATACTATAACGAGGCGCTGCTCTATAAGCTGTTTGGCATCAACGCCGAGCTGTTGATCGACCACGCCTGGGGCTGGGAGCCCTGCCGGATCTCCGACATAAAAGCCTATAGGCCGGAGACGAACTGTGTCAGTTCTGGGCAGGTCCTTCAATCCCCTTAG",
    "translation": "MIFGFSHGWEPLQLLLFWSFTHGCVYSIDEVMIDATSYLGTYHMTARELARTMILDVLRTTRITATAGIGTNLYLCKVAMDIMAKHVAPDESGVRIAELDEMSYRRQLWMHRPLTDFWRVGKGYAKKLEAIGIYTMGDIARCSIGKAGEYYNEALLYKLFGINAELLIDHAWGWEPCRISDIKAYRPETNCVSSGQVLQSP",
    "product": ""
   },
   {
    "start": 15482,
    "end": 15658,
    "strand": -1,
    "locus_tag": "ctg48_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,482 - 15,658,\n (total: 177 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCAAGCAAAATCAAAAGACGCTTTACAGACACAGAAATGCAAATTGTCGGGGAAACGGATCTGCCGGAGCTGCTGACCCATCTGGGCTATCAGATCAAACGCATTGGCCGGTACCACACCACAGCAGAAATGGACAGCCTGCGGATCAAGGACCGTCGCACATGGTTCCGCTAA",
    "translation": "MASKIKRRFTDTEMQIVGETDLPELLTHLGYQIKRIGRYHTTAEMDSLRIKDRRTWFR",
    "product": ""
   },
   {
    "start": 15777,
    "end": 16208,
    "strand": -1,
    "locus_tag": "ctg48_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,777 - 16,208,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAACTACCAAAAACTTGTGTGCTCAGATCCCCATCGACCTGCACGAGCGAGTCAGTGAAGAACGGGAACGGTTGGGCCAGACCACCAGCGAGTACATCGCCAACCTCATCCAAGACTATTACAACATGATCGAAAATCAGAAAGGCGGCATTCACATGACTGAAAAAGGCAGAACAATGGCATTCCAGGTCCCCGAAGAACTCTTCCAGCGCATCAAACGTCACCTCGAGCGTGAAACGCTCCGCACCGGCAAAAAACTCACCCAGCGAGACTTCGTGCTGAACCTGATCACGCAGGCGCTGGACGAAGCGGACGCCGAGAGCGCTACAGAGCAGGACTCCCCTGCTGAGGCCCCTGTCGAGGCCCGTGTGGCCGACGAGACCGCCCCTGCGGACACGGATACCCCTGACGAGGAAAGCGCCGTGTAA",
    "translation": "MATTKNLCAQIPIDLHERVSEERERLGQTTSEYIANLIQDYYNMIENQKGGIHMTEKGRTMAFQVPEELFQRIKRHLERETLRTGKKLTQRDFVLNLITQALDEADAESATEQDSPAEAPVEARVADETAPADTDTPDEESAV",
    "product": ""
   },
   {
    "start": 16782,
    "end": 17759,
    "strand": 1,
    "locus_tag": "ctg48_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,782 - 17,759,\n (total: 978 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGCGCAGCACCGATCATGGGAGGACTCCGCCGTGCAGAACGCTTATCCGGACTATTATCCGCTTTTCCATTGCATCGCCGACCGATGCCGACACAACTGCTGCATCGGCTGGGAGATCGACGTGGACGGGGATTCCCTCGCCGCCTACGATCAGATCGGCGGCGAGATGGGCGAGCGCCTGCATAAATGTATCGACCGCAGCGGCGAGATGCCGCACTTTATCCTCAGCGAGCAGGAGCGCTGCCCGTTTTTGAACGGCAAAAACCTCTGCGATCTCATTTTATACGGCGGGGAGGGTATGCTCTGCCAGATCTGCACCGACCACCCGCGCTACCGCAGCTTTTTTTCGGAGCGCACGGAGATTGGCGTTGGCCTCTGCTGCGAGGAGGCCGCGCGCCTCATTTTGACCAAGCCGGAGAAGACAACGCTTGTCGTGACGGGCGAAGGCGAGCTTGATGAAGAGGAGACGGCGCTGCTCACGCTGCGCGACCGCCTTTTCACCCTTGCGCAAAACCGTGAGGAACCGATCGAGCGGCGAATAGAGCAGATTTTATCGGCCTGCGGTGCACACGTGCCGGACGTCCCGCTTGCGCAGTGGGCAGAGTTTTATCTCTCGCTCGAGCGTATGGACGAGGTGTGGACGGGCATTTTGGAAGCGCTGCGCGAGCACGCAGATGAGTTGCCGCTCGACGATTTTGCCGCGCACATGAAAGGACGCGAGACGGAGTATGAGCAGCTGCTCGTCTACTTCCTCTATCGTCACGTGCCGACGGCGCTCGTCGACGGGGACGTGAGCAGCAAGGCGGCGTTCGCCGTGCTGTCTGTCCGGCTGCTTTTCTCGCTTGGTGCGCTGCACCTTTTGCTGCACGGCGAGTTCACGGTGGAGGACCAGATCGAGCTCTGCCGATTGTACAGCGCGGAGGTCGAGTATTCCGACGATAATATGGACGCGCTCTTCGACGCGCTGCTATAA",
    "translation": "MTAQHRSWEDSAVQNAYPDYYPLFHCIADRCRHNCCIGWEIDVDGDSLAAYDQIGGEMGERLHKCIDRSGEMPHFILSEQERCPFLNGKNLCDLILYGGEGMLCQICTDHPRYRSFFSERTEIGVGLCCEEAARLILTKPEKTTLVVTGEGELDEEETALLTLRDRLFTLAQNREEPIERRIEQILSACGAHVPDVPLAQWAEFYLSLERMDEVWTGILEALREHADELPLDDFAAHMKGRETEYEQLLVYFLYRHVPTALVDGDVSSKAAFAVLSVRLLFSLGALHLLLHGEFTVEDQIELCRLYSAEVEYSDDNMDALFDALL",
    "product": ""
   },
   {
    "start": 17899,
    "end": 19929,
    "strand": 1,
    "locus_tag": "ctg48_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,899 - 19,929,\n (total: 2031 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCAGAACATGAGAAAGAGAACGCCGCTGGCCGTGCTTCTGGCGCTGTGCCTTGCCATGCAGCTCTGCGTGCCCGCCGCGATGGCGAGCAATCGGCTGATGCGCGCGGGCGACGCGGCCATTGCGCAGATCGAGGAGGAAGAGGGCTTCCGCGCGGAGAAGTATTCCTCCGGCGGCAAGTGGTACATCGGCTACGGCACGGAGTGCGGTGCCGAGGATTATCCCGAGGGCATCACGCGCGAAGAGGCGGAGCTTCTTCTGATGAGCAAGGTCGAGGCGTATGAGGCCAAGCTCAACGACTTTTTTGGCCGCTACGACGTCACGCCCACGCAGGGGCAGTTCGACGCGCTGATCTGCTTCAGCTACAATTTCGGCACCGGTTGGATGAGCGGCACGAGCGACTTGGTCAAGATCGCCCGCGGCGAAAAGGACGCGACGCGCCTGGAAGTGGCGCATGCGTTCGGCGAATGGTGCCATTCCGGCGGACAGGCCCAGGCGGGCCTTGCCGACCGCCGCCTGCAGGAGGCTGCCATTTATTTAGATGACGGCACCCGCGCGGCGGAGAACGAGTTTGCGTATCTCATCATCAATATGGAAAGCGGTACGTCCTACGAGACGGACTTTGCCGTCTACGAGATCGGCAAGACCTACGGTAGCTTCCCCAAAGCGGAAAAGCTCGGCTACGGCTTTGCCGGCTTCCGGACGAGCGACGGCAAGACCATCACGGAAAACAGCATCGTGAACGGCAACGCGGTCGTCACGGCGCAGTGGACGGCGACGAGCTACACCGGCAAGACCTATACCGACGTCAACAAGTCCGACTGGTTCTATAACTATGTCATGGAGCTGAGCGAGCAGGGCATCGTCGGCGGCAACGGCGACGGCACGTTTGCCCCCAACCGTCCCACGAGCACGGGCGAAATGCTCAAGCTCGTGCTGCTCTCGACCGGCCACAAGGAGCAGAAGCCCAGCACGGCGCACTGGGCAAGCGGCTACGCGACCTACGCCTATTCCATGGGCTTTGCCGCGCAGAATTACAGCGACTATCAGCTTGACAACGGCATCAGTCGCCTCGATGTGGCGCGCTTTGCGGCCAAGGCGCTGGGCTATGGCGCATCCAACACGACCTCTCCCTTTGCCGACGTGAACGACGGCTATGTGACGGCGCTCTATGAAGCGGGTGTGTTCATCGGCACGAAGGTCGGCGACCTGACGTATTTCTACCCCAACAGCAGCATCACGCGCGCGGAGGTGGCGACGATCGTTTACCGCATCTATCAGCTCAGCTCGCTCGACCAGAAGCAGAAGATCTACTACAAGGACTACACGCTTGATGTGCTCGAGGGTGTGCCGACGAACACCTATAATCAGTCTGCGTTCGTCAAGAACGGCAGCATCATGACCTACAACGATCCCAGCGTGCGCACGCGCGTCGGTATCGACGTGTCGCAGTATCAGGGCGATGTGGACTGGAACGCGGTCGCGCGCACTGATGTGGACTTTGTCATCGCGCGCGTGGGCGGCCGCGGCTACACTGTGGGCGCGATCTATGACGACACGAAGTTTGACGAGTATGCCGACGGCGCGGCGAGAGCGGGCCTTCAGGTGGGCGCTTACTTCTTCTCGCAGGCTGTGAGCGTGGCAGAGGCGCAGGAGGAGGCCTATCACGTGCTCGACAAGCTGCGCGGCCATGAGATCACGGGTCCCGTCGTCTTCGACTGGGAGGTCATCGGCAAGAGCGAGGCGCGCACCTACGGCATCGAGACCGGCGTGCTCTGCGCTGCGGCGAACGCCTTCTGCAAGATCATTAAGGACGCGGGCTACGACCCGATGATCTACATCACCGACTACGCGGGTTATGTCAAGTATGACCTCAGCGAGGTCATGGATTACCCGCTGTGGTACGCGCGCTACGATGTGGACGCGCCCTCGTTCTACTACGATTTTGCCATGTGGCAGTATTCATCCAAGGGCAGCGTGGACGGCATCAAGGGCAACGTCGATATGGACATCTGGTTCATCAAGTAA",
    "translation": "MKQNMRKRTPLAVLLALCLAMQLCVPAAMASNRLMRAGDAAIAQIEEEEGFRAEKYSSGGKWYIGYGTECGAEDYPEGITREEAELLLMSKVEAYEAKLNDFFGRYDVTPTQGQFDALICFSYNFGTGWMSGTSDLVKIARGEKDATRLEVAHAFGEWCHSGGQAQAGLADRRLQEAAIYLDDGTRAAENEFAYLIINMESGTSYETDFAVYEIGKTYGSFPKAEKLGYGFAGFRTSDGKTITENSIVNGNAVVTAQWTATSYTGKTYTDVNKSDWFYNYVMELSEQGIVGGNGDGTFAPNRPTSTGEMLKLVLLSTGHKEQKPSTAHWASGYATYAYSMGFAAQNYSDYQLDNGISRLDVARFAAKALGYGASNTTSPFADVNDGYVTALYEAGVFIGTKVGDLTYFYPNSSITRAEVATIVYRIYQLSSLDQKQKIYYKDYTLDVLEGVPTNTYNQSAFVKNGSIMTYNDPSVRTRVGIDVSQYQGDVDWNAVARTDVDFVIARVGGRGYTVGAIYDDTKFDEYADGAARAGLQVGAYFFSQAVSVAEAQEEAYHVLDKLRGHEITGPVVFDWEVIGKSEARTYGIETGVLCAAANAFCKIIKDAGYDPMIYITDYAGYVKYDLSEVMDYPLWYARYDVDAPSFYYDFAMWQYSSKGSVDGIKGNVDMDIWFIK",
    "product": ""
   },
   {
    "start": 19988,
    "end": 20851,
    "strand": -1,
    "locus_tag": "ctg48_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,988 - 20,851,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGCAAAGGTTTATTTTTCCAAGCAGATCACGCCGGAAAAGGTCGTGGAGCTCTACAAGGCCGCGGGTCTCGAGCTGCCCGGTAAGGTCGCCGTCAAGGTTCACTCCGGCGAACCGGGCAACCAGAACTTTCTGACGCCCGAGTTCTGGCAGCCGATGGTCGAGACCGTACACGGCACCATCGTTGAGTGCAACACCGCCTATCCCGGCGAGCGCAACACGACCGACGCCCACCGCCGCACGATGATCAAACACGGCTGGAGCAAGCTCTTCGATGTCGACATTCTTGACGCCGAGGGTCCCGATCTTGAGCTCCCCATCCCGAACGGCAAGCGCATCCAGAAGAATCTGGTCGGCAAGGATATCAAAAATTATGATTCCATGCTCGTTCTTTCCCACTTCAAGGGCCACCCGATGGGCGGCTTCGGCGGCGCGCTCAAACAGCTCTCCATCGGATGCGCGTCCAGCGCAGGCAAGGCGAACATCCACGGCGCGGGCAAGCCCGAAGAGATGTGGACGACCGGGCAGAATGCCTTTCTTGAGTCCATGGCCGATGCGGCGGAGTCCGTCGTCAAGCTTTTCGACGGCAAGATCGTCTACATCAACGTGATGAAGAACATGTCCGTCGACTGCGACTGCTGCGCCGTGGCGGAGGACCCGTGTATGAAAGATATCGGCATTCTCGCCTCCCTTGACCCCATCGCCATCGACCAGGCGTGCCTCGACCTTGTCTACGCGTCCGACGATTCGGGCCGCGACCACCTCGTTGAGCGCATCGAGAGCCTCAACGGCGTCCACACCGTGGAGGCCGCCGCCGAGCTCGGCTTCGGTTCGAGAGAGTATGAGCTGATCGAGCTCTAA",
    "translation": "MKAKVYFSKQITPEKVVELYKAAGLELPGKVAVKVHSGEPGNQNFLTPEFWQPMVETVHGTIVECNTAYPGERNTTDAHRRTMIKHGWSKLFDVDILDAEGPDLELPIPNGKRIQKNLVGKDIKNYDSMLVLSHFKGHPMGGFGGALKQLSIGCASSAGKANIHGAGKPEEMWTTGQNAFLESMADAAESVVKLFDGKIVYINVMKNMSVDCDCCAVAEDPCMKDIGILASLDPIAIDQACLDLVYASDDSGRDHLVERIESLNGVHTVEAAAELGFGSREYELIEL",
    "product": ""
   },
   {
    "start": 21112,
    "end": 22002,
    "strand": 1,
    "locus_tag": "ctg48_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,112 - 22,002,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAAAGCAAAAAAGAACACCGTCATCCATGCGGCGGCTGACCGCATGGCGGCGAACTACAAGAGCTCTCAGATCCCCATGTACGGCGATGCGCTGCGCATGCCCAACCGTAATGCGGTCATCGAGATCATCCGCGACTGTCAGAAGCTCATTTTCCCTGTTTACTACGGCGACCGCGACCTCTTGAAGCTGCCGCCGGAGCAATACAGCGCGCTTTTGATGGAGCACATCCACGAAAAGCTGACGCGCCAGATCACGCTGACGATGCCGGAGTGCGACGAGAACTGCGAAGTGGCCTATGCGATCAGCACGGCATTCATCGAGCGCATCCCTGCCATTCAGGAGTTGCTGCTCAAGGACCTGTCGGCGAACTTTGAGGGCGATCCTGCGGCTTACAGCAAGGAGGAGGTCCTGCTCTCGTACCCCGGCATGTTCGCCATCTTCATCTACCGCATCGCACACGAGCTGTATGAGAACAAGGTCGCGATGATCCCGCGCATGATGTCGGAATACGCGCACTCGCAGACCGGTATCGACATCAACCCCGGCGCGAAGATCGGCGAATACTTCTTCATCGACCACGGTACGGGCGTCGTCGTCGGCGAGACGACGATCATCGGCGACAACGTCAAGCTCTATCAGGGCGCGACGCTCGGCGCGCTCTCGCCCGCGGGTATGGCGACGAACCCGAATGTGCGCCGCCACCCGAAGGTCGGCAACAACGTCGTCATCTACGCAAACTCCACGCTGCTCGGCGGTGCGACGGAGATTGGCGACAATGTCGTCGTCGGTGGCAACGCGTTTCTGACCTCGTCGGTCGCGCCCAACACGGTCGTGAGCGTCAAAAATCCGGAGATGACGTTCCGCGGCAAGCACCACAGGGGATGA",
    "translation": "MDKAKKNTVIHAAADRMAANYKSSQIPMYGDALRMPNRNAVIEIIRDCQKLIFPVYYGDRDLLKLPPEQYSALLMEHIHEKLTRQITLTMPECDENCEVAYAISTAFIERIPAIQELLLKDLSANFEGDPAAYSKEEVLLSYPGMFAIFIYRIAHELYENKVAMIPRMMSEYAHSQTGIDINPGAKIGEYFFIDHGTGVVVGETTIIGDNVKLYQGATLGALSPAGMATNPNVRRHPKVGNNVVIYANSTLLGGATEIGDNVVVGGNAFLTSSVAPNTVVSVKNPEMTFRGKHHRG",
    "product": ""
   },
   {
    "start": 21999,
    "end": 22466,
    "strand": 1,
    "locus_tag": "ctg48_19",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,999 - 22,466,\n (total: 468 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 77; E-value: 2.7e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCTGACGGAGGGGGCGCGCGTCCGCCTGCGGATGATGCGGCGGGGGGACGCGAACGAATTATACGCCCTGCTCTCGGATGAAGCGGTGATGCGCTGGCTGGAGCCGCCGTTTAACCGCGCGCAGGCCGAGCGCTTTTTGGAGCAGGCGGGACTTTCCGATCCGCCGCTCATCTATGCCGCGGAGAATATGGAGGGAGAATTCCTCGGGTACGCCATCTTCCACAACTATGACGAGTACAGCCGGGAGCTCGGCTGGGTGCTCAAGCCTGCCTTTTGGCACAAGGGCTATGCGGACGAAATGACGGCTCTTCTGACCGCGCTTGCGCGGCGGGAGGGGAAGAATGCCGTGATCGAATGCGTCCCCGAACAGACGGCGAGCGCGCACATCGCGCGCAGGCACGGCTTTTCGTATGAGGGCCGCGCGGACAGCTGTGACGTTTACCGCCTGCGCTGTGAAAAATAA",
    "translation": "MILTEGARVRLRMMRRGDANELYALLSDEAVMRWLEPPFNRAQAERFLEQAGLSDPPLIYAAENMEGEFLGYAIFHNYDEYSRELGWVLKPAFWHKGYADEMTALLTALARREGKNAVIECVPEQTASAHIARRHGFSYEGRADSCDVYRLRCEK",
    "product": ""
   },
   {
    "start": 22649,
    "end": 23656,
    "strand": -1,
    "locus_tag": "ctg48_20",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg48_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg48_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,649 - 23,656,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg48_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg48_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAAAGTCTATATCCCGCAGGACTACCACACCCCGCTGTCTGTCTATGAAATGCAGCGCGCCATCGAATTCATCAAGAGCAATTTTCAGGTCAATCTGAGCAATGCCCTCAATCTCCGCCGGGTTTCTGCTCCGCTGTTCGTGGATGAAAATTCTGGTCTGAACGACAACCTCAACGGCGTCGAGCGTCCCGTCTCCTTTGACATTCCCGACGTCGGCACCAATGCCCAGGTCGTTCATTCGCTGGCCAAGTGGAAGCGTCTTGCGCTCAAGCGCTACGACTTCAAGGTCGGCAAGGGCCTGTTCACCGACATGAACGCCATCCGCCGCGACGAAGAGGTCGACAACCTCCACTCCGTCTATGTGGACCAGTGGGACTGGGAAAAGGTCATCTCCGCCGAGGACCGCAACGTCGCTTATCTCAAGCGCACCGTGCGCGATATCGTCTCCGCCGTCAGCGAGACGAGCAGCGCGCTGAATGTCGCTTTCCCCTCCCTGCACACCAAGCTCCCCAGTGAGGTCTTCTTCATCACCACGCAGGAGCTCGAAGACCTCTATCCCGACCTGACACCCAAGCAGCGCGAGGATGAGATCTGCAAGAAGAAGGGCGTCGTCTTCCTGATGCAGATCGGCAAGATCTTAAAGTCCGGCATCAAGCACGACGGCCGCGCCCCCGACTATGACGATTGGGAGCTCAACGGCGATATCCTCTACTGGAACGAAGTGCTCGGCCATGCGTTCGAGATCTCTTCCATGGGTATCCGCGTCGACCCCAAGTCCCTCGACTCCCAGCTGACGATCGCCGGCTGCGACGACCGCCGCGCGCTCCCCTTCCACAAGATGCTGCTGAATGGCGAGTTGCCCCTGACCATGGGCGGCGGCATCGGCCAGAGCCGCCTGTGCATGCTGCTCATCGGCACCGCGCACATCGGCGAGGTACAGGTCTCCCTGTGGGATGAAGCCACGCGCAAGACCTGCGAGGATGCGGGCGTCATGCTGCTGTAA",
    "translation": "MSKVYIPQDYHTPLSVYEMQRAIEFIKSNFQVNLSNALNLRRVSAPLFVDENSGLNDNLNGVERPVSFDIPDVGTNAQVVHSLAKWKRLALKRYDFKVGKGLFTDMNAIRRDEEVDNLHSVYVDQWDWEKVISAEDRNVAYLKRTVRDIVSAVSETSSALNVAFPSLHTKLPSEVFFITTQELEDLYPDLTPKQREDEICKKKGVVFLMQIGKILKSGIKHDGRAPDYDDWELNGDILYWNEVLGHAFEISSMGIRVDPKSLDSQLTIAGCDDRRALPFHKMLLNGELPLTMGGGIGQSRLCMLLIGTAHIGEVQVSLWDEATRKTCEDAGVMLL",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 12892,
    "end": 14281,
    "tool": "rule-based-clusters",
    "neighbouring_start": 2892,
    "neighbouring_end": 24281,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r48c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {
 "r48c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg48_4": {
     "functions": [
      {
       "description": "SMCOG1288:ABC transporter related protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg48_5": {
     "functions": [
      {
       "description": "SMCOG1135:MarR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg48_6": {
     "functions": [
      {
       "description": "SMCOG1190:GTP-binding protein LepA ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg48_7": {
     "functions": []
    },
    "ctg48_8": {
     "functions": []
    },
    "ctg48_9": {
     "functions": []
    },
    "ctg48_10": {
     "functions": [
      {
       "description": "SPASM",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF04055",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR04085",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Ranthipeptide_rSAM_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF05402",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Fer4_12",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg48_11": {
     "functions": []
    },
    "ctg48_12": {
     "functions": []
    },
    "ctg48_13": {
     "functions": []
    },
    "ctg48_14": {
     "functions": []
    },
    "ctg48_15": {
     "functions": []
    },
    "ctg48_16": {
     "functions": []
    },
    "ctg48_17": {
     "functions": []
    },
    "ctg48_18": {
     "functions": []
    },
    "ctg48_19": {
     "functions": [
      {
       "description": "SMCOG1111:GCN5-related N-acetyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg48_20": {
     "functions": []
    }
   }
  }
 }
};
