var recordData = [
 {
  "length": 80277,
  "seq_id": "NZ_WHCC01000001.1",
  "regions": []
 },
 {
  "length": 51130,
  "seq_id": "NZ_WHCC01000010.1",
  "regions": []
 },
 {
  "length": 44241,
  "seq_id": "NZ_WHCC01000011.1",
  "regions": []
 },
 {
  "length": 41004,
  "seq_id": "NZ_WHCC01000012.1",
  "regions": []
 },
 {
  "length": 40213,
  "seq_id": "NZ_WHCC01000013.1",
  "regions": []
 },
 {
  "length": 40157,
  "seq_id": "NZ_WHCC01000014.1",
  "regions": []
 },
 {
  "length": 36264,
  "seq_id": "NZ_WHCC01000015.1",
  "regions": []
 },
 {
  "length": 35678,
  "seq_id": "NZ_WHCC01000016.1",
  "regions": []
 },
 {
  "length": 35593,
  "seq_id": "NZ_WHCC01000017.1",
  "regions": []
 },
 {
  "length": 33285,
  "seq_id": "NZ_WHCC01000018.1",
  "regions": []
 },
 {
  "length": 30808,
  "seq_id": "NZ_WHCC01000019.1",
  "regions": []
 },
 {
  "length": 74639,
  "seq_id": "NZ_WHCC01000002.1",
  "regions": [
   {
    "start": 20930,
    "end": 41193,
    "idx": 1,
    "orfs": [
     {
      "start": 22299,
      "end": 23801,
      "strand": -1,
      "locus_tag": "ctg12_16",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,299 - 23,801,\n (total: 1503 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Wzy_C<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGATTTTAAACAAAAGCTCAGAGGATTTTTTTCCGATTCATCGCTTTTTAGAAGAATCTACATTATAGATTTGTTTTTTACAAACATTGCGTTTCTCCAGATTCCTGCGTATGTACTTCTTGTTTTTCTCTTTATATGGGGTGTATGCCTTTCGGTATATAATCAAAAACATAATAATACTTTTTTTAAACTGCGCTTCGGAATATGGATCGGAGCATTTCTTGCCGTAACGGTATTTACGATGCTCATCAATTTTTCACAGACTTTTCTTTTCAGCCTTCTTATGCTTCTGCACGTTGTAATGTGTTTTTTTCTTTTTTACGGAATGCACACAGAGCCTGAATTTGATTACAGAATAGAGCTTTATCACATTGCAAAATTCATAATATACGCAACCACGTTAATGAACATAATCGGGATAACCTGCCTTATGTTCGGCTTTAAATTTGAATGGTACTGGATTAAATTTACCGTTTACGAAAACAGGTTCACCGGTTGTTATGTCAACCCGAATCTCCTCGGCTTCATAGCTGTGGTGTCGATTTTCTGTTGCCATATACTTTCAAAAGGGCATTTTATGCGCAGAATTGCCGAAAAAATTCCTGAACCCGGCATCAGTAAGATATGGATTGTAGCCTGTCTTTCCACAAATGCGTTTTCGCTCATTCTGTGCGATTCAAATGCCTCACTTGTGCTTGCTCTCGGATATGCAATTGTTTATATAGTTTATATGTTCTTTGCCGACAAGGCGGGACTTTCACCTTCAAAAATTATTTTGAAAATTACTGCGCTGTTTCTTGTGGGAGTTTTCCTTACAGGCTCTGCCTTGATGTTCAGAACAATTTGTCAGGAAGGCTTTTCCGTTGTTGTATCAAAGACAACCTCTGTTGTCGATTTGCTTTTAGGCAAAACCGAAAGCGAACTTGTGCAGGAAGGACTGACTCCCGAACAGAGAGAACAGCTTGAAAAGGATAAAATCACCTTTTCACACGAAAACAAAAACATTGACAGCGGAAGAAAGAAGCTTTGGCTTGAATCAATCAATCTTTTCAAACTGTCGCCGATTATCGGAATTTCCAACGGAAATATTGTTCTCTACAGTGCCGAATATTCAAACGGTGCTTTGGAATATTCGTATCACAAAAGTGATTTGCATAACGGTTTTCTTACAATTCTTGTTTCAACGGGTGTAATCGGTTTTGTTCTTTTCGGAATTTTTGGTTTTCGATTTGCAAAACACTCCGCACAGCACCTGTTTTTGCAGAAAAAAACATATCGTGACGATGTTTATCCCTGTCTGTTTGCTTTTCTTTTCGCATATTTGATTTTTGCCTGCTTTGAAAAGGCATTGCTTTATGACATATCGTTTATGGTGGTGTGGTTCTGGCTGATTATGGGATATATGAGTTGCTACATCACAAAGTTTGAACCGACGCTTGAAAGTCAGTATCTTTTTCACGGAAAAAGACTCAGACGGGTAACAAGAACAATGCTCTGA",
      "translation": "MTDFKQKLRGFFSDSSLFRRIYIIDLFFTNIAFLQIPAYVLLVFLFIWGVCLSVYNQKHNNTFFKLRFGIWIGAFLAVTVFTMLINFSQTFLFSLLMLLHVVMCFFLFYGMHTEPEFDYRIELYHIAKFIIYATTLMNIIGITCLMFGFKFEWYWIKFTVYENRFTGCYVNPNLLGFIAVVSIFCCHILSKGHFMRRIAEKIPEPGISKIWIVACLSTNAFSLILCDSNASLVLALGYAIVYIVYMFFADKAGLSPSKIILKITALFLVGVFLTGSALMFRTICQEGFSVVVSKTTSVVDLLLGKTESELVQEGLTPEQREQLEKDKITFSHENKNIDSGRKKLWLESINLFKLSPIIGISNGNIVLYSAEYSNGALEYSYHKSDLHNGFLTILVSTGVIGFVLFGIFGFRFAKHSAQHLFLQKKTYRDDVYPCLFAFLFAYLIFACFEKALLYDISFMVVWFWLIMGYMSCYITKFEPTLESQYLFHGKRLRRVTRTML",
      "product": ""
     },
     {
      "start": 23826,
      "end": 24506,
      "strand": -1,
      "locus_tag": "ctg12_17",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,826 - 24,506,\n (total: 681 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Bac_transf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1146:sugar transferase (Score: 229.5; E-value: 1.3e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATCATTTCAAAAGCTTCCGCCGCAGTTTCAGTGTGCCGAAGTAAAAGAATACTATGACATTCTCTGCAAAAAACAGGGAAGTTTTGTTTTAAAGCGAATTCTTGATATTTTTGCTTCTGTTATTCTTCTTGTGTTTCTCATCATTCCGATTGCAATTATTGCGATTTTAGTTAAAACCGACTCAAAAGGTCCTGTGTTTTACAGACAGGAAAGGGTTACAACCTACGGAAAGAAGTTCAGAATTCTTAAATTCCGTACAATGGTAACGGGAGCTGACAGGCTCGGAACACTTGTCACAACCGACAGCGACTCCCGAGTTACAAAAACAGGAAGAATTTTGCGAAAATATCGTCTTGATGAGCTGCCGCAGATTTTCAATGTTCTTTCGGGCAGTATGTCAATAGTCGGAACCCGTCCGGAGGTTCAGCATTATGTAGATATGTACGAACCCGAATATCTTGCAACACTCCTTATGCCTGCCGGAATAACCTCGTTGGCTTCAATTATGTATAAGGATGAAGAAAAGCTGTTGAAAGGCGAGATAGATGTTGACAGGGTTTATGTTGAAAAAATTCTTCCCGAAAAAATGAAGTTCAATCTTTCATATGTCAAAAATTTCAGCTTTGGTTCCGATATAAAGCTGATGTTCAAAACCGTAAAAGAAGTTTTCAGCTGA",
      "translation": "MKSFQKLPPQFQCAEVKEYYDILCKKQGSFVLKRILDIFASVILLVFLIIPIAIIAILVKTDSKGPVFYRQERVTTYGKKFRILKFRTMVTGADRLGTLVTTDSDSRVTKTGRILRKYRLDELPQIFNVLSGSMSIVGTRPEVQHYVDMYEPEYLATLLMPAGITSLASIMYKDEEKLLKGEIDVDRVYVEKILPEKMKFNLSYVKNFSFGSDIKLMFKTVKEVFS",
      "product": ""
     },
     {
      "start": 24983,
      "end": 25279,
      "strand": 1,
      "locus_tag": "ctg12_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,983 - 25,279,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTAACGAATATACACCCGACCTCATTACCCTTATCGGTGATGACGGTAAAGAAATAGAATTTGAAATACTTGATATCATTGAAAACGATGAGGGTAAGTTTTATGTACTCTACCCGTTCTTTGAAAATCCCGAGGATGCTGTAAATGATTCGGGAGAATATTATATTTTTGAAGTTACCGAAATTGACGGCGAAGAAGAGCTTGCCGAAATTGAGGATGATGACAAGCTCGACAGAATTGCCGCTGTTTTTGAAGAGCGTTACAATGAAGAATTTTATGATGAAGATGACTAA",
      "translation": "MANEYTPDLITLIGDDGKEIEFEILDIIENDEGKFYVLYPFFENPEDAVNDSGEYYIFEVTEIDGEEELAEIEDDDKLDRIAAVFEERYNEEFYDEDD",
      "product": ""
     },
     {
      "start": 25582,
      "end": 26544,
      "strand": 1,
      "locus_tag": "ctg12_19",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,582 - 26,544,\n (total: 963 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATATTTCCGTTTTAGGTTGCGGACGCTGGGGCAGCTGCATTGCCTGGTATCTCGACAAAATCGGTCACAATGTTTTAAGCTGCGGACTTGCCGACGCACCCGAATTTATACAGCTTAAAGAAACACACAAAAACGACTATCTCACCTTTCCAAAGTCAATTGAGGTTTCTTCGGATCTTGAATATGCGATTGAAAGAGCCGAGGTTATTATAATTTCGATTTCATCGCAGTATCTTCGTTCGTATTTTGCAGATATTTCAAAGTACAATCTCGACGGCAAGACAATTGTCCTCTGTATGAAGGGTGTTGAGGCAACTACAGGAAAAAGGCTCAGTGAGGTTGTCGGTGAATTTGTTGACGAAAGCAAGACACCCGTTGCAGTTTGGGTAGGTCCGGGACATCCCCAGGATTATGTAAGAGGTATTCCGAACTGTATGGTTATTGACAGCAATAATCACGATATTAAGGAAAAGCTTGTAAATGAATTCACAAGCGACCTTATCAGATTTTACCTTGGAACGGATCTTATCGGCAGTGAAATCGGTGCTGCCGCAAAGAATGTTATCGGCATCGCCGCAGGTATGCTTGACGGACTTAACTACACCTCACTAAAAGGTGCGTTAATGGCAAGAGGCACACGAGAGATTGCAAGACTCATTAAGGCACTCGGAGGCAATGAGATGAGTGCTTACGGTCTTTGTCATCTCGGCGACTATGAGGCTACCTTGTTTTCAAAATGGAGTCACAACAGAATGTACGGTGAAAGCTTTGCAAAGGGAGACAGATTCACAAAGCTTGCCGAGGGTGTTATGACATCAAAAGCGTTATACAAGCTCGGTCAGGAATATGGTGTTGACCTTCCGATTGTTGAGTCTGTATACAAGGTTTTATTCGACGGAACAGATATCAAAGAGGCACTCGGAACTCTGTTTATGCGTTCTGTCAAGAAAGAATTTTAA",
      "translation": "MNISVLGCGRWGSCIAWYLDKIGHNVLSCGLADAPEFIQLKETHKNDYLTFPKSIEVSSDLEYAIERAEVIIISISSQYLRSYFADISKYNLDGKTIVLCMKGVEATTGKRLSEVVGEFVDESKTPVAVWVGPGHPQDYVRGIPNCMVIDSNNHDIKEKLVNEFTSDLIRFYLGTDLIGSEIGAAAKNVIGIAAGMLDGLNYTSLKGALMARGTREIARLIKALGGNEMSAYGLCHLGDYEATLFSKWSHNRMYGESFAKGDRFTKLAEGVMTSKALYKLGQEYGVDLPIVESVYKVLFDGTDIKEALGTLFMRSVKKEF",
      "product": ""
     },
     {
      "start": 26562,
      "end": 28244,
      "strand": 1,
      "locus_tag": "ctg12_20",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,562 - 28,244,\n (total: 1683 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTAATACTAAAGCTAAGAACAATTCAAATAAACCTAAACAGACTGGGAAAACGGTTACTTCTGTCAAAAAGCAGAATACAGTCGAGTATGTTATTGTAAACATTCTTTGTCTGTTCGTATTCATAGCATTTGCATACATAGCAATTATGAGCTTTGTGCAGACAAGCGTGTTTGATTCGGCAAATTACGGCAGTGAAATAATTTTGTATCAAACGGATAACATTGCGCTGAACATCCTGTTCACTTCCCTGTTTACCGTTTTTATATTCAAAATGAAAAAGCATTGTGACTTTTTTGCAAAAGTCAATCTGAAATATATGCATATAGGTCTTGCGGCGTTCGTCATGATTGTGGGACTTGTCTGGATATTCTCAGTAACCTCTGTTGCCGCGGCTGACAGCTACAACATCTATGAAACAGCGTCACAGGCGGCTAAGGGCAACTATTCGTCATTCAGCAATAACAGCGGTTTTTACAACAGCGATTTTTACAGCGGATATTCTTACTACAACTTCTATCCGTTCCAGCTCGGCTTTGTTTTCATCAGCGAAATTTTTTACAGAATTTTCGGTACTGACAGTACAATGCCGATTCAGGTATTCAATGTAATGTGTACAGCTGCCGCTTATATAGGTATTGTAAACATCACAAAACTTCTTTTCAAAAAGCGTTCGGTTGAATTTATTACAATTCTTCTGCTTGCCGGCTGTTTTCAGCCCGTACTTTTCTGCACATTCGTTTACGGCAACATCATCGGAATGTGCTTTGCAATCTGGGCATCATACTTCCTCATCAAGTATTTTCAGACAAACAAGTACCTGCTCCTCATTCCGTGTGCTGTACTTCTCGTTATTTCAACACTTGCAAAATACAACAACCTGATTTATCTTGTTGCGTTTGTTGTTATGCTGGTTATTCACACAATTAAGGCTAAGAAGTGGCAGAGCATTGCGTTTGCACTTGCAATTTGCATTGTTGTTGTCGGAACAAGCAACCTTGTCATCATGAGTTATGAGAACCGTTCGGGAGTGAAGCTTTCAAGCGGTGTTTCACAGGCTATGTACCTTGATATGGGCATTAACGATTCATATATGGCTCCCGGTTGGTACAACGGAATTGCCCTCAACGATTATAAAAACGCAGGTCTTGACGCAAAAGCCGCAAATGCACAGGCTTGGACCAATATAAAATCAAGAATGAATTACTTTGGTAAAAACACAAACTATATGATTGACTTCTTCTCGAAGAAAATTATCAGCCAATGGAATGAGCCGACATACGAAAGCATATGGGTTAGCAAGGTCAAGTCTCATACAAACGAGCTTAATTGGATCGGCAACGGAATGTATGACGGCAGTATCGGACAGTTCTTTGAACTGTACTTCAACTTCTATATGCAGATTCTTTTCATTGCGTTTGCGGCAGGAATTTACTTCTTGTTCATTAACAGAAAGACAAATATTGAAACCGTACTTCTCCCTCTTGTTATTCTGGGAGCGTTCGGATATCACCTCTTATTTGAAGGCAAGTCGCAGTATGTGCTGACTTACATAATTCTTATGATTCCTACCGCGTCTTTTGCATTTGAGTGTATTCTTAACGGCAAATATACAAAAATCAAAGAATTTGTCGGAAAACTGAAAGAAATTCCCGACGGTAAAGAAAGCGAAAAAGCCTGA",
      "translation": "MGNTKAKNNSNKPKQTGKTVTSVKKQNTVEYVIVNILCLFVFIAFAYIAIMSFVQTSVFDSANYGSEIILYQTDNIALNILFTSLFTVFIFKMKKHCDFFAKVNLKYMHIGLAAFVMIVGLVWIFSVTSVAAADSYNIYETASQAAKGNYSSFSNNSGFYNSDFYSGYSYYNFYPFQLGFVFISEIFYRIFGTDSTMPIQVFNVMCTAAAYIGIVNITKLLFKKRSVEFITILLLAGCFQPVLFCTFVYGNIIGMCFAIWASYFLIKYFQTNKYLLLIPCAVLLVISTLAKYNNLIYLVAFVVMLVIHTIKAKKWQSIAFALAICIVVVGTSNLVIMSYENRSGVKLSSGVSQAMYLDMGINDSYMAPGWYNGIALNDYKNAGLDAKAANAQAWTNIKSRMNYFGKNTNYMIDFFSKKIISQWNEPTYESIWVSKVKSHTNELNWIGNGMYDGSIGQFFELYFNFYMQILFIAFAAGIYFLFINRKTNIETVLLPLVILGAFGYHLLFEGKSQYVLTYIILMIPTASFAFECILNGKYTKIKEFVGKLKEIPDGKESEKA",
      "product": ""
     },
     {
      "start": 28266,
      "end": 29132,
      "strand": -1,
      "locus_tag": "ctg12_21",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,266 - 29,132,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTCAGAATTATTACCGATTCAGCCGCCGATTTTGAACATTCAGAAAGTGAAAAATTCGGAATTTCTACAGTTCCGTTAGCTGTATATATTGACGGAAAAGAATATAAGGATGATTTTTTACATTCAAAGGAACGCTTTTACAGGCTTGCAAAGCTGTCGAAAACTTTGCCGAAAACCTCTCAGCCCTCGCCGTATGTCTACGAATGTGCTTTGAAAAAGGCGAGAGATAACGGCGAATCGGTTGTGGTGATAACTGTTTCTTCGGCATTGAGCGGTTCATATCAGAGTGCAGTTCTTGCAAGAGATTTGCTCGGATATGAGGGGTGTTATGTGATAGACAGCAAATCTGCTTCGGCAGGTCAGAAGCTTCTTGTAAACGAGGCACTTCGCTTGCGTGACAACGGGTTTACAGCAAAAGAAATTGCCGAACATCTTCTGAGGTTCAGAAGCAGAATTATGGTATATGCCTGTATTGACGATATGAAGTACCTCTATGGGGGTGGCAGACATACAAATGCCGCCGCATTACTCGGCTCAACAGGAAGAATAAAGCCCGTAATCAGCATTACGGGTTCGGGCAGTGTAGCATTTGAGGCGAAAACAATCGGAATGCGCCACGGTATGAATCATATGCTGATGTCGCTGAAAAAGCTTGGCATAGACCAAAATTATCCGCTGTATATAATGCACACAAACGCAAAAAATCAGGCATTGTATTTATCAAAGCTCATAATATCAAAAGGAATTCCTTTTGTTGAGGACAGTATTGTCAGCGTGGGTTCTGTTGTCGGCAGTCATATAGGAGAGGGCAGTACGGGTATTGCATTTGTCCAAAAAGAGCAAAGAAAAAGCGGACATGATTAA",
      "translation": "MVRIITDSAADFEHSESEKFGISTVPLAVYIDGKEYKDDFLHSKERFYRLAKLSKTLPKTSQPSPYVYECALKKARDNGESVVVITVSSALSGSYQSAVLARDLLGYEGCYVIDSKSASAGQKLLVNEALRLRDNGFTAKEIAEHLLRFRSRIMVYACIDDMKYLYGGGRHTNAAALLGSTGRIKPVISITGSGSVAFEAKTIGMRHGMNHMLMSLKKLGIDQNYPLYIMHTNAKNQALYLSKLIISKGIPFVEDSIVSVGSVVGSHIGEGSTGIAFVQKEQRKSGHD",
      "product": ""
     },
     {
      "start": 29238,
      "end": 30458,
      "strand": -1,
      "locus_tag": "ctg12_22",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,238 - 30,458,\n (total: 1221 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NTP_transf_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGGAAACATCTTAACGATAACGAAAAAATTGAATTTAAGTATCTGCTTGAGCTTGTTTCATCGTCTGTAAACGGAACAGCACCTCCTATTCCTTATGAGGGGATAAAATGGCAGTCGATAAAAATGCTTGCAAACTATTGCAGTGTTGAATCGCTTGTTGCCAATGCGGTTTTGTCGCTCGACCAAAAGTATGTTTCACCCGAGGTATATGAAAAATTCAAGCAGAATTTGTCGATTGAAATGCTGATTGACGGAAATCTCTCATATGAAACCGAGAAAATTCTCAAGGCTTTTGATGAAAACAAAATCAAGAATATTCCCTTAAAGGGCTATTTTATGAAAAAGGAATATCCTCGTTCCGACTTTCGTTCCGTGTCCGATGTAGATATCCTTTTTGACAGAAAACAGGCTGATTCGGTCAAAAAAGTTTTTGACGGGCTTGGATACACTTTTCTAAATGAAGATGACAACCAGTATCATTTTGAAAAAAAGCCGATGATGAACATTGAAATGCATGCAACTCTTGTCCATGAAAACGAGGAATCTTATCCGTTGCTTGTTAATCAGCTTGACCGTTCAACAAAGCGTGACGGCTACAGCTATTCATATGAAATGAGCCATGAGGACTTTTATATCTATATGCTTGTTCATAACTCGAATCATTTCAGAATCGGCGGAATGGGAGCAAGAATGGTGCTTGACAGCTATGTTTTCTTGAAAAATCATCAATCTGAGCTTGATTATGACTATCTTAATGTGATGCTTGAAAAAATCGGTATTGCAAAGTATGAAAAGCGTGTTCGTGAGATTGCGTTCAACTGGTTCGCAAAGCCACAGGCTGAACTTAAATTTGATGATATCGAAGAATATATTCTGCTCAGCGGTACACTCGGCAGGGTAGATGTTGGCACGATGATAAATTCTCACAAGACAATTACAGAAAATAACAAATCAAAATTCTCATATCTTGTGTCCTCAATATTTCCACCAAAATCCGAAATGCAGTATAAGTATCCATATGTAAAAAAAACACCGTTCCTTTTACCGATTTCATGGTGTCATATGTGGGGAAAAAGGCTTTTTGTAGACAGAAATATCAATTTTAAATCGGGTATCAAAAACCGTATGTCATACACGGATGAAGATGTAAATTTGTACAAGTCCCTTTTGGATGAAATGGGCTTTGACGGTATTGGGATAAATAATTTCGGAAATTGA",
      "translation": "MRKHLNDNEKIEFKYLLELVSSSVNGTAPPIPYEGIKWQSIKMLANYCSVESLVANAVLSLDQKYVSPEVYEKFKQNLSIEMLIDGNLSYETEKILKAFDENKIKNIPLKGYFMKKEYPRSDFRSVSDVDILFDRKQADSVKKVFDGLGYTFLNEDDNQYHFEKKPMMNIEMHATLVHENEESYPLLVNQLDRSTKRDGYSYSYEMSHEDFYIYMLVHNSNHFRIGGMGARMVLDSYVFLKNHQSELDYDYLNVMLEKIGIAKYEKRVREIAFNWFAKPQAELKFDDIEEYILLSGTLGRVDVGTMINSHKTITENNKSKFSYLVSSIFPPKSEMQYKYPYVKKTPFLLPISWCHMWGKRLFVDRNINFKSGIKNRMSYTDEDVNLYKSLLDEMGFDGIGINNFGN",
      "product": ""
     },
     {
      "start": 30455,
      "end": 30943,
      "strand": -1,
      "locus_tag": "ctg12_23",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,455 - 30,943,\n (total: 489 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCTTGAATAAAGAAGTAGGTCTTGATGATGTAATGCAGATTATAGCCGAAAAGCTTGAGGCCGGAGGATCGGTTACTTTCAATCCGAAGGGAACAAGTATGCTCCCAATGCTCCGAGACGGTGACGATACGGTTGTTTTATCAAAACCGAAGGGCAGACTTCATCTTTTTGACTTGCCTTTATACAGACGAAAAGACGGCTCGTATGTATTGCACCGTGTCGTCAATTTCGGAAGTGACGGCAGTTATACTATGTGCGGTGACAATCAGTTTGCCGTTGAAAAAGGTATTACCGATGATGATGTAATCGGAGTGGTAACAGCATTTTACAGAAAGGGCAAGCCATACACGGTTGACTCAATGAAGTACAGAGCATACCTTGAATTTATGTTCTATTCAAAACCGCTAAGAAAGGTTATTGCATCAACTGTGTCAAGAAGTAAAAATGCATTCTCAAAGCTTAAAACGAAAAAAGGGAAAAAATGA",
      "translation": "MSLNKEVGLDDVMQIIAEKLEAGGSVTFNPKGTSMLPMLRDGDDTVVLSKPKGRLHLFDLPLYRRKDGSYVLHRVVNFGSDGSYTMCGDNQFAVEKGITDDDVIGVVTAFYRKGKPYTVDSMKYRAYLEFMFYSKPLRKVIASTVSRSKNAFSKLKTKKGKK",
      "product": ""
     },
     {
      "start": 30930,
      "end": 31193,
      "strand": -1,
      "locus_tag": "ctg12_24",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,930 - 31,193,\n (total: 264 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGATAAAAGAAGATTTTGTTCTGCGAAAGGTTGCAGATTCATATGTTGTAGTTCCCGTAAACAAGCTGACGCTTGATTTTAACGGAATTATCAACCTCAATGAAACGGGTGCATTCCTTTTTGAAAAGCTCCAAAACGATTGCGAAAAGGCTGATTTGCTCAAAGCAATGCTTGATGAGTATGAAGTGAGCGAAGAAAAGGCGAGTGCAGATATTGATACATTTATTCAAAAGCTAAGAGAGGCTGATGTCCTTGAATAA",
      "translation": "MKIKEDFVLRKVADSYVVVPVNKLTLDFNGIINLNETGAFLFEKLQNDCEKADLLKAMLDEYEVSEEKASADIDTFIQKLREADVLE",
      "product": ""
     },
     {
      "start": 31346,
      "end": 32974,
      "strand": -1,
      "locus_tag": "ctg12_25",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,346 - 32,974,\n (total: 1629 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1299:chaperonin GroEL (Score: 814.4; E-value: 5.8e-247)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTAAACAAATCGCATACGGCGAAGATGCAAGAAAAGCTTTAATGAAAGGTATCGACCAGCTCGCTGATACCGTTAAAATCACACTCGGACCTAAGGGCAGAAATGTTGTTCTTGATAAGAAGTTCGGTGCTCCGCTCATCACAAATGACGGTGTAACAATTGCTAAGGAAATTGAACTTGAAGATCCTTTTGAAAATATGGGTGCTCAGCTTGTAAAGGAAGTTTCTATCAAGACTAACGATATTGCAGGCGACGGTACAACAACTGCCACACTTCTTGCTCAGGCTCTCATCAGAGAGGGTATGAAGAATGTAACTGCAGGCGCTAACCCAATGGTACTTAAAAAGGGTATTGCAGACGCTGTAAATGTTGCAGTTGAGGCTGTAAAGAAGAACAGCAAGCAGGTATCCGGTACAGACGATATCGCAAGAGTTGCAACAGTTTCATCACAGGATGAATTCATCGGCAAGCTTATTGCCGAGGCTATGGAAAAGGTTACAACAGACGGTGTTATCACAGTTGAGGAATCAAAGACAGCCGAAACATACAGCGAGGTTGTTGAAGGTATGATGTTTGACAGAGGTTACATCGCTCCTTATATGGTAACAGATACAGATAAGATGGTTGCAGAGCTTGACAATCCGCTTATCCTTATCACAGATAAGAAGATTTCTACTACACAGGAAATTCTCCCACTTCTTGAGCAGATTGTTCAGATGGGTAAGAAGCTCCTTATTATCGCTGAAGATGTTGAAGGCGAGGCTCTTACAACTCTCGTACTTAACAAACTCAGAGGTACATTCACTTGTGTTGCTGTAAAGGCTCCGGGCTTTGGCGACAGAAGAAAAGAAATGCTTCAGGATATCGCAACACTTACAGGCGGTACGGTAATCACATCCGACCTCGGTCTTGAACTCAAGGATACAACAGTTGATCAGCTCGGTACTGCCCGTCAGGTTAAGATTGAAAAGGAAAACACAATCATCGTTGACGGCTCAGGTGACAAGGAAGCTATCAAGGGCAGAGTTGCTCAGATCAGACAGCAGATTGAAACAACAACATCTGACTTTGACCGTGAAAAACTTCAGGAGCGTCTTGCAAAGCTCGCAGGCGGCGTAGCAGTTATCAAGGTTGGTGCTGCAACAGAAGTTGAAATGAAAGAAAAGAAGCTCCGTATTGAGGATGCTCTTGCTGCTACAAAGGCTGCTGTTGAAGAGGGTATCGTAGCAGGCGGCGGTATCGCTTGCATGAACGCTATTCCGGCTGTTGCAGAGTTCGTTGACACTCTCGAGGGTGACGCTAAGACAGGTGCTAAAATTGTTCTTAAAGCACTTGAAGAACCGCTCCGTCAGATTGTTGCTAACGCAGGTCTTGAGGGCAGCGTAATCTGCGATAATGTTAAGAAGGCTAACAAGGTTGGCTATGGCTTCAACGCTCTTACAGAGGAATACACAGATATGGTTTCGGCAGGTATCGTTGACCCAACAAAGGTTACTCGTTCAGCTCTCCAGAACGCAAGCTCTGTTGCAGCAATGGTTCTTACAACAGAATCACTTGTTACAGACATCAAAGAGCCTGCAGCTCCGGCAGCTCCCGCAGCACCTGATATGGGCGGAATGTACTAA",
      "translation": "MAKQIAYGEDARKALMKGIDQLADTVKITLGPKGRNVVLDKKFGAPLITNDGVTIAKEIELEDPFENMGAQLVKEVSIKTNDIAGDGTTTATLLAQALIREGMKNVTAGANPMVLKKGIADAVNVAVEAVKKNSKQVSGTDDIARVATVSSQDEFIGKLIAEAMEKVTTDGVITVEESKTAETYSEVVEGMMFDRGYIAPYMVTDTDKMVAELDNPLILITDKKISTTQEILPLLEQIVQMGKKLLIIAEDVEGEALTTLVLNKLRGTFTCVAVKAPGFGDRRKEMLQDIATLTGGTVITSDLGLELKDTTVDQLGTARQVKIEKENTIIVDGSGDKEAIKGRVAQIRQQIETTTSDFDREKLQERLAKLAGGVAVIKVGAATEVEMKEKKLRIEDALAATKAAVEEGIVAGGGIACMNAIPAVAEFVDTLEGDAKTGAKIVLKALEEPLRQIVANAGLEGSVICDNVKKANKVGYGFNALTEEYTDMVSAGIVDPTKVTRSALQNASSVAAMVLTTESLVTDIKEPAAPAAPAAPDMGGMY",
      "product": ""
     },
     {
      "start": 33003,
      "end": 33287,
      "strand": -1,
      "locus_tag": "ctg12_26",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,003 - 33,287,\n (total: 285 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAATCAAACCATTACTCGACAGAGTCGTTTTAAAAGTTGAAGAGGCTGAAGAGAAAACAAAGAGCGGTATCATTCTTTCATCTGCTGCTCAGGAAAAGCCACAGTTCGCATCAGTTGTTGCTGTTGGCCCCGGCGGTGTTGTTGACGGCAAGGAAGTAAAGATGTATGTCAGCGTAGGCGATAAGGTAATCGCAAGTAAATATGCAGGCACACAGGTAAAGATTGACGGCGAAGAATACACAATCGTAAACCAGTCGGATATACTCGCAACTCTTGAATAA",
      "translation": "MTIKPLLDRVVLKVEEAEEKTKSGIILSSAAQEKPQFASVVAVGPGGVVDGKEVKMYVSVGDKVIASKYAGTQVKIDGEEYTIVNQSDILATLE",
      "product": ""
     },
     {
      "start": 33551,
      "end": 35188,
      "strand": -1,
      "locus_tag": "ctg12_27",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,551 - 35,188,\n (total: 1638 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 81.3; E-value: 1.4e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCATTGTGTATGGGATGCATGCAGGAAATAGGTGACAACAAGATTTGTCCGTCCTGCGGATTTGATACAACTGAAAAACAGCAAGCTCCTTTTTTACCGTACGGAACAATTCTTCAGAACCGCTATATCGTAGGTGCGGGAATTGATACCAACGGCGAAAGCACACGCTATATAAGCCACGACAAGCAGACAGGTGACATTGTAATCATCTGCGAATTTCTTCCTATCGGACTTTTTTCTCGTGAAGAAGGAACTACCGAGGTCAGAATAAATTATGAAAACCGCCTTGTATATAATAAACTCAAGGACGATTTTCTTAACTATTACAGAATTCTTTCAGAACTCCGTGAGCTTTCCGCTCTTATGAATGTTCACAACATTTTTGAAGAAAATAACACAGTTTATGTTGTTGAGGAAAACGAGGATCTTATTCCTTTTGAGGAGTATGTTGAACGTAGTAACGGCCATCTTGAATGGGATATTGCCCGTCCGCTTTTTATGCCTGTAATTTCTGCACTTGAGGCTCTTCACAAGAGAGGTGTTGGTCACTATGCTATCGCACCTAAGAATATGTATATCACAGCATCGGGTAAAATTAAAATTTCAGGCTTTGCGTCGGAAAATGAGCGTAAAAGAGGCACGCCTCTCAAATCTCAGCTTTTTTCAGGCGCTGCGGCTCCCGAACAGTATGACGACAATTTTCCTCTTGACGATATTACGGATATCTACGGATTTTGTGCAACCCTTTTCTATGCCCTCACAGGTCATATGCCAAAGAGTGCGGTAGAACGCCGTAAGGACAGCCGACTTCTTATGAGTACAACAACAGTAAAGAGACTTCCTCCGCATGTTGTTTCGGCTCTTGCTAACGGTTTGCAGGTTGAGCGTGAAAACCGTATTACGGATTTTGACGAGCTTCGTTCACAGCTTTCCGTTGCTCATACAGCAAAGGCAATTCAGGACGAAATTTCAAGAACAGCAAGCATGAACCTCACAAAGTCAGAGCGTACTCGCAAGACTTCAAACGGTATGTCACACGCTTCAATTATTATTATTGCGGCTGCTATCACGGTTCTTGTTCTCGGTATCGCCGGTGTGTTCTGGCTTATGCAGAATCCGCTTGCCGGAATGTTCTCAAATAATACTGATGCGAGTGTAAGCTCAACTCAAAGCACAGAGTGGACAGGTGCTACTGTTCCTAACTATATAGGAATGACATATGAAGAGGCTGTTAAGAGTGTTGACAGCAACAGCAGTATCACAATCTACAGAACTTTTAACGATGAGTACAGCGATGATTATGCAGAAGGTAAGATTATGTCACAGACTCCTGCTGCAGGTTCCAAAATTACTCAGGAAGATTCTGTAGTAGTGAGTGTTTGCGTAAGCAAGGGATCACAGATGAGGACTCTGCCGAAGGTTGAGGGTGAAAAACTTGATACCGTTGCATCCGACATTGCCGCTCAGGGACTTCTTGCAACAGCGGAATATGAGTACAGTGACAAGGTTGCTGAGGGAAGGGTAATCCGCTACAAAGAACATGTTGAGGGTGATACTCTCGAATACGGTTCAACGGTAGTTCTTATTGTCAGCAAGGGCAAGAAACAGACAAGTTCTCAATCATCAAACAGATAA",
      "translation": "MSLCMGCMQEIGDNKICPSCGFDTTEKQQAPFLPYGTILQNRYIVGAGIDTNGESTRYISHDKQTGDIVIICEFLPIGLFSREEGTTEVRINYENRLVYNKLKDDFLNYYRILSELRELSALMNVHNIFEENNTVYVVEENEDLIPFEEYVERSNGHLEWDIARPLFMPVISALEALHKRGVGHYAIAPKNMYITASGKIKISGFASENERKRGTPLKSQLFSGAAAPEQYDDNFPLDDITDIYGFCATLFYALTGHMPKSAVERRKDSRLLMSTTTVKRLPPHVVSALANGLQVERENRITDFDELRSQLSVAHTAKAIQDEISRTASMNLTKSERTRKTSNGMSHASIIIIAAAITVLVLGIAGVFWLMQNPLAGMFSNNTDASVSSTQSTEWTGATVPNYIGMTYEEAVKSVDSNSSITIYRTFNDEYSDDYAEGKIMSQTPAAGSKITQEDSVVVSVCVSKGSQMRTLPKVEGEKLDTVASDIAAQGLLATAEYEYSDKVAEGRVIRYKEHVEGDTLEYGSTVVLIVSKGKKQTSSQSSNR",
      "product": ""
     },
     {
      "start": 35498,
      "end": 36148,
      "strand": -1,
      "locus_tag": "ctg12_28",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,498 - 36,148,\n (total: 651 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGATAAAGGAGTAATTATGCGTTGTGTGATTATTGCAGGCTCGCCTGACACAAATTCGGATTTTTTGTCCGAGGTTATAAAACCTGATGACTATGTGATATGTGCCGACAGAGGTTGCAATTTTGCAAAACAGGCAGGCATTACTCCGAACCTTGTTGTAGGAGATTTTGATTCCGAGCCTGATGTACTGTTTCCAAACTGCGAAACGGTCCGCCTTATTCCCGAAAAGGATGATACCGACACAATGCACTCTGTTGACCTTGCACTTGAAAAAAGGTTTGACGAAATAGCAATTCTCGGTGCATTGGGCGGTCGCTTTGACCACAGCTTTGCAAATGTGGCGGTTCTCTCTTATATTCACGAACACGGAAGTAAGGGCGTTCTCCTTTCTGAAAAAGAGAAAATAGAATTTCTCCCCGTAGGTCATTATGAATATAAAAACTTTAAAGGCAAAACATTTTCGCTTTTCCCTTTCGGATGTCCGAGTGTCTGCGTAAGCTATTCGGGAACAAAGTATCCTCTTGAAAAATACTGTGTTTCGAGCAGCGTTACTCTGGGTGTTTCAAATGTATTCACTTCCGATATGACAACAATTGACATATATGACGGAAATGCAATACTTATAATTAATTTGATAGACTGTTAA",
      "translation": "MADKGVIMRCVIIAGSPDTNSDFLSEVIKPDDYVICADRGCNFAKQAGITPNLVVGDFDSEPDVLFPNCETVRLIPEKDDTDTMHSVDLALEKRFDEIAILGALGGRFDHSFANVAVLSYIHEHGSKGVLLSEKEKIEFLPVGHYEYKNFKGKTFSLFPFGCPSVCVSYSGTKYPLEKYCVSSSVTLGVSNVFTSDMTTIDIYDGNAILIINLIDC",
      "product": ""
     },
     {
      "start": 36130,
      "end": 36993,
      "strand": -1,
      "locus_tag": "ctg12_29",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,130 - 36,993,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATCAATCGGCGGATTTTACTATGTCCGTGCCGATGGCGAGAATTACGAATGTAAGGCAAGGGGGAGCTTTCGCAAAAGCGGAAACTCTCCCGTAGCGGGGGACAGGGTAAATATATCTGTTCCGAATGACGGTTTTTGTGCGATAGAAGAAATTCTTCCACGCAAAAACAAGCTCCGCAGACCTGCTCTTGCAAATCTTGATATTCTTCTTCTCGTGTGTTCAACTGTTGAACCGTTGCCTAATTTTACGATTATTGACAAAATGACTGCGGCGGCGGTAAACAATAATATGGAACCCGTAATTGTCGTTACAAAAAATGATCTGGAAAACGGAGATAAGATTGCCGATATCTACAGACACGCAGGTTTTGAGGTTTTTCTCTGTTCGGAAGATGATTCTTCACAAACCGAAGAACTCAAAAGCTATCTGTCCGGCAAGGTTTCAGCCTTTATCGGTAACAGCGGTGTCGGCAAGTCCACATTGCTCAACAAGCTTTTTCCATCGCTTTCTCTTGAAACAGGGCAGACAAGTAAAAAACTCGGCAGAGGAAGACATACAACAAGAGTTGTTGAACTGTTTGAACTTGACGGTTGTTTTGTGGCAGACACACCCGGATTTTCAACCGTTGATCTTCAGCGTTACGAAATGATTGACAAAAGCCGGCTGCAATATTGCTTTCCTGAATTTGAAAAATATTTAGGGGAGTGTATGTTTACTTCATGTTCGCATACCTGTGAAAAAGGCTGCAGGATTCTTGAGGCGCTATCTGACGGTGAAATTGAAGAAACCCGTCACCGCAGTTATGTTCAGATGTATAACGAGGTCAAGGACATTAAATCATGGCAGATAAAGGAGTAA",
      "translation": "MKSIGGFYYVRADGENYECKARGSFRKSGNSPVAGDRVNISVPNDGFCAIEEILPRKNKLRRPALANLDILLLVCSTVEPLPNFTIIDKMTAAAVNNNMEPVIVVTKNDLENGDKIADIYRHAGFEVFLCSEDDSSQTEELKSYLSGKVSAFIGNSGVGKSTLLNKLFPSLSLETGQTSKKLGRGRHTTRVVELFELDGCFVADTPGFSTVDLQRYEMIDKSRLQYCFPEFEKYLGECMFTSCSHTCEKGCRILEALSDGEIEETRHRSYVQMYNEVKDIKSWQIKE",
      "product": ""
     },
     {
      "start": 37028,
      "end": 39133,
      "strand": -1,
      "locus_tag": "ctg12_30",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,028 - 39,133,\n (total: 2106 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 258.6; E-value: 1.1e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGGATAAATATTTGGGCAAAAGACTTGACGGAAGATATGAAATCCACGAACTTATCGGTGTCGGCGGTATGGCAAATGTTTACCGTTGTACCGACACAGTCGATGACCGTGAAGTTGCCGTAAAAATTCTTAAAGACGAGTATCTCAACAACGAGGAGTTTATCCGCCGTTTCAAAAATGAATCAAAAGCCATCGCAATGCTTTCACATCCGAATATCGTAAAGGTGTATGATGTAAGCTTTGGCGATATGATTCAGTATATCGTAATGGAATATATTGACGGCATTACCCTCAAAGAATATATTGATCAGCAGGGCATTATTGAGTGGAAAGACGCAATCCACCTGACTGCACAAATTCTAAAGGCTTTACAGCACGCTCACGAGTGCGGAATTGTACACCGTGATATAAAGCCGCAAAATATTATGCTGTTGCAGGACGGTACAATCAAAGTTACCGATTTCGGTATTGCAAGATTTTCCGATAAATCAACACGCACAATGACAGAACAGGCAATCGGCTCTGTCCACTACATTGCCCCTGAACAGGCAAGAGGTGATGCAACTGACGGAAAAACAGACATTTATTCTGTCGGTGTAATGCTCTATGAAATGCTTACGGGAAAGCTTCCGTTTGACGGTGATAGTGCCGTTACAATTGCGCTTATGCAGTTGCAGTCAACACCGAAGCATCCTCGTGAAATCAATCCGGGAATCCCGATAGGTCTTGAGCAGATTACTATGAAGGCAATGGAAAAGCTTCCGTCCGACAGATACACTTCTGCCGCAGAAATGCTTTCTAATATCGAAAGATTCAGACTTAATCCGTCAATCGTTTTTGATTACGGCAACAAGTCTTTTGTTGATAATCAGCCCACAAAGTTTGTTCACTCTCTGCGTGACAGCGGGGTAAGAAATAAAATTGACAACGAGGCAACCAAAGTAGTTGATATGCCGCAGGACGATGTTGTTGTTAAAGAAGAACAGTTTGCCGATGAGGATTTTGTAAAGGAACATAAGCCGTCATACTATGCAGTCAAGGGTATTGTAATTGCGGCTGTTGCAGTATGTGCAATTTTCTTTGCACTTGCAATGTTCAGAGGCTGCTCAACCTCACAGGCCAAGGATGTTGAAGTTCCCAATTATGTCGGCAAATCCTTTGTTTCAATAAAAGAAAATAACCCGAATGATTTCAAGTTTGAGGTTAAGAGTGAATATGATGAGTCAAAGGAAATGGGCGTAATTCTTGATCAAGAGCCTAAGGGCGGTTCAATGAAGGTTAAGTCAGGCTCAACAATCACGGTAACCGTAAACGGAACGGACACAGAGGTTTCTGTTCCTTATGTAACCAATTACAGCGAAAAAGAGGCTTCTCAGGCTCTCAAGGAAAAGAATCTTATTCCTGAAATTGTCTATGTAGAAAACACTAAAACACCAAAGGGCTACACAATTGAGTGCTTCCCGAAAGCAGGTGTAAAAACTACAATCGGTTCAACGGTATATGTATATATTGCAAGCGGTGAGAGAACCAAACAGGTTACACTCCCGTCGGTTGACGGACTTATGCTTTCCGAAGCAAAGCAGACTCTTGTTGATCTCGGACTTACCGTTGAAACAGTACAGGATGATGAAAGCAAAGAACCAAAGGATACAGTCCTCGGTATGTCGCCTCTCCAGTACGGCAAGGTTGACGCAGGCTCTGTTGTAACCCTGACTGTAAGCTCAGGACTCGGTGACGAAAACACGGTTAATATCTTCGTTGACCTTCCGTCGGATGTTGAAGATTCAGTCGATATGACTGTAATTGTTGACGGTGCGGTTGATTCCCGTAATTCAAAGACACTTGTTCCGAAATATAACAAGACCTATACTCTTGAGCTCAAGGGCTCAGGCACTTCAACTGTAGTAATTCAGCTTGACGGTCAGGCTTACAGAGAGTATTCGGTTGACTTTGCATCGGCAGCGGTAACCACTACGGCGTCACATGATTATGTCCGTGCGACAACCGCTCCTCCCGAAACCGAACCGCCGACACAGTATTACACAGATCCGTATGTAGCGCCTGACACGACCGTTCAGCCGGTTACGGATGATCCTGAACTTTAA",
      "translation": "MDKYLGKRLDGRYEIHELIGVGGMANVYRCTDTVDDREVAVKILKDEYLNNEEFIRRFKNESKAIAMLSHPNIVKVYDVSFGDMIQYIVMEYIDGITLKEYIDQQGIIEWKDAIHLTAQILKALQHAHECGIVHRDIKPQNIMLLQDGTIKVTDFGIARFSDKSTRTMTEQAIGSVHYIAPEQARGDATDGKTDIYSVGVMLYEMLTGKLPFDGDSAVTIALMQLQSTPKHPREINPGIPIGLEQITMKAMEKLPSDRYTSAAEMLSNIERFRLNPSIVFDYGNKSFVDNQPTKFVHSLRDSGVRNKIDNEATKVVDMPQDDVVVKEEQFADEDFVKEHKPSYYAVKGIVIAAVAVCAIFFALAMFRGCSTSQAKDVEVPNYVGKSFVSIKENNPNDFKFEVKSEYDESKEMGVILDQEPKGGSMKVKSGSTITVTVNGTDTEVSVPYVTNYSEKEASQALKEKNLIPEIVYVENTKTPKGYTIECFPKAGVKTTIGSTVYVYIASGERTKQVTLPSVDGLMLSEAKQTLVDLGLTVETVQDDESKEPKDTVLGMSPLQYGKVDAGSVVTLTVSSGLGDENTVNIFVDLPSDVEDSVDMTVIVDGAVDSRNSKTLVPKYNKTYTLELKGSGTSTVVIQLDGQAYREYSVDFASAAVTTTASHDYVRATTAPPETEPPTQYYTDPYVAPDTTVQPVTDDPEL",
      "product": ""
     },
     {
      "start": 39152,
      "end": 39877,
      "strand": -1,
      "locus_tag": "ctg12_31",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,152 - 39,877,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGGAAGTATTCAGCAAAAGTGATATCGGACTTGTTCGTAATCAGAATCAGGATGACTGTCGCTTCGGAGTTATTTCTCCCAGCTGTGTCTGGGCAGTTGTGTGTGACGGAATGGGCGGTGCAAACGGCGGTAATATTGCCAGCGCAACGGCAGTTGATTATATCAGCACCAAAATTACCGATTTGTACAAAGATGATATGACCAAGGAGCAGATTGGCGAGCTTATGGCAGAAATTGTTGTCAATGCCAATATGAAAGTCTTTGAAATGTCCATGAAAGATCCCGAGCTCACGGGTATGGGAACTACATGTGAATTTGTCTTTGTAAAAGATACAACCGTTCATGTTGTTCATGTCGGTGACAGTCGCACATACGCTATCAGAGGCGGTAAAATCAAGCAGCTTACAGAGGATCATTCCGTTGTTCAGGAAATGGTTAGAAGAGGCGAACTTACATATGAGCAGGCGCAAAATCATCCGAACAAGAACTTTATAACAAGGGCGCTCGGCATAAAACCGTCCGTTCGCCTTGACTATATTGAAGCCAACTTTATTTACGGTGATGTTCTTCTCATCTGTACCGACGGACTTTCAAATTGCGTCACAACAGGAGATATGGTCAAAATTTGCCATGAAAACCGTGGCGAAGGTCTTATCACAAAGCTTGTTGACAAGGCGAAAGACGGCGGAGGTTCTGATAATATCACAGCTACCGTAATTTACTAA",
      "translation": "MEVFSKSDIGLVRNQNQDDCRFGVISPSCVWAVVCDGMGGANGGNIASATAVDYISTKITDLYKDDMTKEQIGELMAEIVVNANMKVFEMSMKDPELTGMGTTCEFVFVKDTTVHVVHVGDSRTYAIRGGKIKQLTEDHSVVQEMVRRGELTYEQAQNHPNKNFITRALGIKPSVRLDYIEANFIYGDVLLICTDGLSNCVTTGDMVKICHENRGEGLITKLVDKAKDGGGSDNITATVIY",
      "product": ""
     },
     {
      "start": 39879,
      "end": 40895,
      "strand": -1,
      "locus_tag": "ctg12_32",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,879 - 40,895,\n (total: 1017 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCTTGATGAGCTGACTGAATTTGTCACAGAAAACGGTTTTCCAAAGTTCAGAGCAAAGCAGATTTATGATTGGTTGTACAAAAATGTGACCGATTTTGACAATATGCGTAACATTCCTGCCGATTTAAAGGCTTTTTTGAAATCAAGTAGTTACATTTCTGTTGCAAATATTGAAAAAAAACTTGTTTCAAGGTATGATAAAACAGTCAAGTACCTTTTTTCGTTTAATGACGGCGAATGTGTAGAGTCTGTTGTAATGAGTTACAAGCACGGATATTCAATCTGTATCTCAACACAGGTTGGCTGTAAAATGGGTTGTACATTTTGTGCAACAGGCAAAAGCGGTTTTTCACGGAGTCTTGCACCGTCGGAAATGCTCGGACAGATTGAGGCCGCACAGCGTGATCTTAACATAAGAATTTCTAACATTGTTCTTATGGGAATGGGTGAACCGCTTGATAATTTTGATAATGTCGTAAAATTTCTCCGACTTGTTTCGTCCGACAACGGTCTTAACATTGGAATGCGACATATTACTCTCTCAACCTGCGGTATAGTTCCGAAAATTTATGAGCTTGCAAAACTTCATTTCGGAATAACGCTTTCCGTTTCATTACACGCACCGAACGATGAGATAAGGCAGCGAACAATGCCCATTGCAAGAAAGTATTCTATTGAAGAATTATTAAAGGCTTGTTCAGATTATTTCAGAACAACAGGTCGCAGAGTTACATTTGAATACTCTATGATAAGCGGAGTTAATGACAGCGATGAAAACGCAAGAGAGCTTGCAAAACGACTTGAGGGTACACAAAGCCATGTTAATCTGATCCCCGTCAATACTGTTGAGGGAACAGGCTACTTAAAAAGCAATATTAAAAGACAGCAGGCATTCATAAATATTCTTGCTGCTAAAAATATCGGAGCAACCGTGCGCAGGACACTCGGAAGTGACATAAACGCATCGTGCGGTCAGCTCAAAAGAAAGCATATTGAAGAAGGAGGTAAATAA",
      "translation": "MTLDELTEFVTENGFPKFRAKQIYDWLYKNVTDFDNMRNIPADLKAFLKSSSYISVANIEKKLVSRYDKTVKYLFSFNDGECVESVVMSYKHGYSICISTQVGCKMGCTFCATGKSGFSRSLAPSEMLGQIEAAQRDLNIRISNIVLMGMGEPLDNFDNVVKFLRLVSSDNGLNIGMRHITLSTCGIVPKIYELAKLHFGITLSVSLHAPNDEIRQRTMPIARKYSIEELLKACSDYFRTTGRRVTFEYSMISGVNDSDENARELAKRLEGTQSHVNLIPVNTVEGTGYLKSNIKRQQAFINILAAKNIGATVRRTLGSDINASCGQLKRKHIEEGGK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 30929,
      "end": 31193,
      "tool": "rule-based-clusters",
      "neighbouring_start": 20929,
      "neighbouring_end": 41193,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r12c1"
   }
  ]
 },
 {
  "length": 30702,
  "seq_id": "NZ_WHCC01000020.1",
  "regions": []
 },
 {
  "length": 26963,
  "seq_id": "NZ_WHCC01000021.1",
  "regions": []
 },
 {
  "length": 25316,
  "seq_id": "NZ_WHCC01000022.1",
  "regions": []
 },
 {
  "length": 25269,
  "seq_id": "NZ_WHCC01000023.1",
  "regions": []
 },
 {
  "length": 25167,
  "seq_id": "NZ_WHCC01000024.1",
  "regions": []
 },
 {
  "length": 24067,
  "seq_id": "NZ_WHCC01000025.1",
  "regions": []
 },
 {
  "length": 23500,
  "seq_id": "NZ_WHCC01000026.1",
  "regions": []
 },
 {
  "length": 22380,
  "seq_id": "NZ_WHCC01000027.1",
  "regions": []
 },
 {
  "length": 21476,
  "seq_id": "NZ_WHCC01000028.1",
  "regions": []
 },
 {
  "length": 20671,
  "seq_id": "NZ_WHCC01000029.1",
  "regions": []
 },
 {
  "length": 73870,
  "seq_id": "NZ_WHCC01000003.1",
  "regions": []
 },
 {
  "length": 20597,
  "seq_id": "NZ_WHCC01000030.1",
  "regions": [
   {
    "start": 796,
    "end": 20597,
    "idx": 1,
    "orfs": [
     {
      "start": 2136,
      "end": 2342,
      "strand": 1,
      "locus_tag": "ctg24_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,136 - 2,342,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTCTGCTGTTCAAAGTCTTGCAAGACGATTTCACAGGTGCAGTTGCGCCGATTGATAATTTGAGTATGGTTGTTTCAATAATCCTTTCGTACATGATTTTCAAAAAAACTGTCCGCAAAATCAAACATAAGTATTCATATAATAATCGCAGACACTTATTTATGCTTTTACGGATTAAATTTAAAATTTACAAATTTGTGTAA",
      "translation": "MTLLFKVLQDDFTGAVAPIDNLSMVVSIILSYMIFKKTVRKIKHKYSYNNRRHLFMLLRIKFKIYKFV",
      "product": ""
     },
     {
      "start": 2779,
      "end": 3066,
      "strand": 1,
      "locus_tag": "ctg24_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,779 - 3,066,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCAACAGGACTTGATTCGGGATTAAGAATAAATGATAACTCAATTCTTGTTGAGTGTGAAGTGGACTCAAAGTATCAATACAAATTAGTTATCTACGACAATACTTTTGACGATAATCCTTTAGAAAAGGTTTATGCAATCCGAAATATAGATTATAATATAACCGATGGCAACAAAATCGCAAATTTTATAATTAAATTAGAGGAAAACAATTATGATAGCAAGAAAGTATTTAGACAATTACTCAGAGATTATACTAAACAGTTTGAACTTATACTCGGATAA",
      "translation": "MSTGLDSGLRINDNSILVECEVDSKYQYKLVIYDNTFDDNPLEKVYAIRNIDYNITDGNKIANFIIKLEENNYDSKKVFRQLLRDYTKQFELILG",
      "product": ""
     },
     {
      "start": 3360,
      "end": 3722,
      "strand": -1,
      "locus_tag": "ctg24_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,360 - 3,722,\n (total: 363 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCATAAATTAACTTGTTGTTACAAAGAAAAAGCTTGTGATAAATGTGTTATTCACGCAGACAGAAAATTCTGTTTTATAGAAGCAACTCAGACGGTGTTCGATAATCTTTTGAGATGCCAACTACAACATTTATTCAGATTAGCTGTTGCTGTCTACCGCTTTACTTGCTTTTGCAGGGCTATTTTGCCAATCACCGAACCATCAGATAAATTGTTTGCTTTGAGTAATATTATTGATTTTTTATTGACACTATCATCAATAGTGCGTATAATGATATTGGAACCCGAATTTTTAAGTCGGCTGGGTAATTGGCACCCTGACTTCTTAAAAATATTCTGGGTTCTTTTTTTGTCTAAATAA",
      "translation": "MHKLTCCYKEKACDKCVIHADRKFCFIEATQTVFDNLLRCQLQHLFRLAVAVYRFTCFCRAILPITEPSDKLFALSNIIDFLLTLSSIVRIMILEPEFLSRLGNWHPDFLKIFWVLFLSK",
      "product": ""
     },
     {
      "start": 3761,
      "end": 4204,
      "strand": 1,
      "locus_tag": "ctg24_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,761 - 4,204,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCATTGAGTACAAGAGAATTGCTTGCAAGGCTTTTAAAATGTGAGGCAGGTGGGGAAGGTGAAAACGGAATGCGTGCCGTTGCGTCGGTAATTGTAAACCGAACCCGTGTTCCAAACGGGGAATTTGCAAGAGTCAGCAAGGGCGGAGATTTCCGTGCCATAATGGAACAACCAAATCAATTTACCTGTCTTAAAACAACTGTCGGAGGACAATATAATCCTCAAAATGTTTACAATATACGCCCTGACGAAATTCACTATAATATTGCCGATTGGGCATTGGCGGGCAATACCGATTCATCTGTCGGAAATTCAATTTTCTATTTTAATCCATTTTCAGATACCTGCCCAACATTTTTTCCGTCAAACAACGGAGTAATTTACAACAGGGTAGGGGATCATTGCTTTTATTCGCCTACCGAGGCTTATTCCAAAACATAA",
      "translation": "MALSTRELLARLLKCEAGGEGENGMRAVASVIVNRTRVPNGEFARVSKGGDFRAIMEQPNQFTCLKTTVGGQYNPQNVYNIRPDEIHYNIADWALAGNTDSSVGNSIFYFNPFSDTCPTFFPSNNGVIYNRVGDHCFYSPTEAYSKT",
      "product": ""
     },
     {
      "start": 4219,
      "end": 4926,
      "strand": 1,
      "locus_tag": "ctg24_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,219 - 4,926,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATAATTCTTCAAATATGGCAGTTAATACAACTCCTATGGCAAATCAGATTAATCCCGAACATCATTACGGACTTGACAAAAACAAAGCCTGCCTCAATAATTCTTGTCCGTCAAACACAGCGGATATCGGATGTTATATTCCTGCGATTGACGAAATTATGCGACACAATCAGGGCGCACCGTCTGTTGCACACCCCAATATGACAGAAAAAGTTCAAAAATCAAATGACAATCCCTCGCTTGAACAGGCAGAAATAGCATATGAAGAGGGCGGAAGTACATCAGAAGAACAACCTGAAAATATAAATAAATACAGCGGAAGTCTTCAAAATATACCGTTCATTAAGAACTTAAAAAAAATAGATACATCTATACCTGTTTTGCCTGCAACCCCGGCTACAACGGCGAGCTCCGGAGCCACCGTTGCAACGCCGATAAGGCAGAATATTGGAATGTCGATGAGTGATTATCAATATCCGTTTCCTGTAACAGCCGAAAATCTGAGATATCACAACGGTTTTATGCGAACACAAATTGGAAGACGAATCACCGTTGATTTTCTCATGGGAGCAAACACAATTGTTCAGAAAACAGGCTATCTTTTAGGTGTTGCTCAGGATTATATCCTTATAAATGAGATTGACACCAACGACATCACAACCTGTGATTACTACAATATAAAATTTATAAGGTATTATTACTAA",
      "translation": "MDNSSNMAVNTTPMANQINPEHHYGLDKNKACLNNSCPSNTADIGCYIPAIDEIMRHNQGAPSVAHPNMTEKVQKSNDNPSLEQAEIAYEEGGSTSEEQPENINKYSGSLQNIPFIKNLKKIDTSIPVLPATPATTASSGATVATPIRQNIGMSMSDYQYPFPVTAENLRYHNGFMRTQIGRRITVDFLMGANTIVQKTGYLLGVAQDYILINEIDTNDITTCDYYNIKFIRYYY",
      "product": ""
     },
     {
      "start": 5178,
      "end": 6077,
      "strand": 1,
      "locus_tag": "ctg24_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,178 - 6,077,\n (total: 900 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTCTGTAAATATTGCGGAGCACAGCTTGAAGACAATGCTGTTTGCAACTGCGAAAAGTCAAGAGCCGCTCAAGCACAGGCTCAGCAGGCAAATGCACAGGCACAGCCTCAGTATCAGCAGCCTGTTCAGCCACAACAGCCACAGTATCAGAACCCTGTTCAGCAACAGTATGCACAGCCGCAAAACCCTCAGACACAGCAGTCGCCTTATGCCGTAAATAACACAGCACCTATTGGGGAAAATGCTTTTGTTAAGGCTTTAAAGAACATTCCTGTTGTGTTCACTTCATTCTTTAAGGATTCCAAAACTGTTATCAAAACAGCAAAGGCTGAAAAAGACATCATTCTCGGCGCTCTTTTCTCGGCAATTTTCTTTATTGCACTCATTCTTGGCAATATGTTTCTTATGCTTTCTATGAGCGCACTTGATTTTCCGAAAACACTTCTTGTAAGTCTTGTTACTGCTGTCCTTATCGGCGGCTTCTATTCTGTTATTCTCTTTGCATATGTAAAGAAATACAAAACCGAAGAAAATACAGCCAAAGCATTTATTGATTCATTCATCACATTTTCAATTGAATCTATTCCGGCATCAATCGGTTGGATTCTGGCAGGTCTTTGCGCATTAATCAGCGTATATATGTTCCTGTTTTTCTTCGTAATCGTTATGCTTTACCTTGTTATTTCACTTGTAAATCAGGTAAAAGCTAATGTTCCCGAAGCAAAGAACTCTGCATTATTCACTTTAATTCTCACACTCATCGTTGCCGTTGCATTTATGATTGTATTCTTCATCGGCGCAGAACTTACTATGTGGTCATTTAACACAAGTACATTTGCAACAAGTGTTCTTACATCGCTTATTGGCGGTGGTTCATACCCTTCATGGTATTAA",
      "translation": "MKFCKYCGAQLEDNAVCNCEKSRAAQAQAQQANAQAQPQYQQPVQPQQPQYQNPVQQQYAQPQNPQTQQSPYAVNNTAPIGENAFVKALKNIPVVFTSFFKDSKTVIKTAKAEKDIILGALFSAIFFIALILGNMFLMLSMSALDFPKTLLVSLVTAVLIGGFYSVILFAYVKKYKTEENTAKAFIDSFITFSIESIPASIGWILAGLCALISVYMFLFFFVIVMLYLVISLVNQVKANVPEAKNSALFTLILTLIVAVAFMIVFFIGAELTMWSFNTSTFATSVLTSLIGGGSYPSWY",
      "product": ""
     },
     {
      "start": 6137,
      "end": 7321,
      "strand": -1,
      "locus_tag": "ctg24_9",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,137 - 7,321,\n (total: 1185 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATTTTTCCTATTTTTTCATATACCTTCCAAATCGAGGCAGAAACTTGTGTTTCTGCCTCAAAATCATTTATGAGGTTTTTTATGAGTAATTCTATCGGTCTTTACATTCACATACCGTTTTGTAAGCACAAATGTCCGTATTGTGATTTTTTCAGCGGCAATGCAGATGAAAACGCTTTTGATAATTATGTGATTGAATTAAAAGATAAAATAAAATACTGGTCTGAAAAAGCCAAAAGAGATGTTGCAACCGTATATTTCGGCGGCGGTACGCCGAGTATTTTGGGTGCAGACAGACTTTGTGATATTCTTGATTTTATCAAGTTCAATTTTAATATTCAAAATAATGCCGAGATTACAGTTGAAGTCAATCCCGACTCCGCCAAAACTATTGATTTTGAAAAAATGTATGCCTGCGGATTTAATCGCATTTCAATGGGAATGCAGACTGCTGTTGAAGATGAATTAAGGCTGCTTGGGAGAATTCACAGCATTGATGATGCAAAAACTTCTGTTGAAAGGGCTAAAAGTGCGGGATTTAATAATATTTCACTTGATTTGATGATGGGAATTCCTAATCAGACAATTGAAAGCCTTGAAAAATCAATCAGTTTCTGTGCCGATTGCAAAGTTACTCATATTTCATCATACATTTTGAAAATCGAGGAGAATACTCCGTTTTATAAGGTGCAAAATAAACTTAAGCTTGCCGATGATGATATGCAGGCTGAAATGTATCTGAAAGCTGTTGAAATGCTTGATTCTCTCGGATACAAACAATATGAAATTTCTAATTTTGCAAAACAGGGTTATGAAAGCCGACATAATACCAATTACTGGAGATGCGGTGAATATATCGGAATAGGTCCGTCTGCACACTCATTTTTTGAGGGCAAAAGGTTTTTTTATTCGAGAAGCATGGACGATTTTAATAACAATAAGCTGTCTTTTGAAGGTACGGGCGGAGATGAGGAAGAATTTATTATGCTCTCTCTCAGGCTGAAAAGCGGTCTTAATTATTCTGAATTTGGGGAAAAATTCGGGTACACCCTCCCCTCTTACATTATCAAAAAAGCTAAAGAGTATGAAAAATACGGGTATACAAATGTTACGGACAAGTCGATCAGCTTTACACCGAAAGGTTTTCTTGTTTCAAATTCAATAATCAGTGAACTGATATAA",
      "translation": "MIFPIFSYTFQIEAETCVSASKSFMRFFMSNSIGLYIHIPFCKHKCPYCDFFSGNADENAFDNYVIELKDKIKYWSEKAKRDVATVYFGGGTPSILGADRLCDILDFIKFNFNIQNNAEITVEVNPDSAKTIDFEKMYACGFNRISMGMQTAVEDELRLLGRIHSIDDAKTSVERAKSAGFNNISLDLMMGIPNQTIESLEKSISFCADCKVTHISSYILKIEENTPFYKVQNKLKLADDDMQAEMYLKAVEMLDSLGYKQYEISNFAKQGYESRHNTNYWRCGEYIGIGPSAHSFFEGKRFFYSRSMDDFNNNKLSFEGTGGDEEEFIMLSLRLKSGLNYSEFGEKFGYTLPSYIIKKAKEYEKYGYTNVTDKSISFTPKGFLVSNSIISELI",
      "product": ""
     },
     {
      "start": 7487,
      "end": 9073,
      "strand": 1,
      "locus_tag": "ctg24_10",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,487 - 9,073,\n (total: 1587 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 109.2; E-value: 4e-33)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTTCATTTAAAGAAGAAATCAGCAAGCGCAGAACCTTTGCGATTATTTCGCATCCTGATGCGGGTAAAACAACACTTACGGAAAAGCTCTTGCTCTACGGCGGAGCAATTAACCTTGCGGGTTCGGTAAAAGGCAAAAGAACCGCAAAGCATGCTGTGTCCGACTGGATGGAAATTGAAAAACAGCGTGGTATTTCTGTTACATCATCGGTTTTGCAGTTTAAATATAACGGTTATTGCATAAATATTCTTGATACACCGGGACATGAGGATTTCTCGGAAGATACCTACCGTACACTTATGGCGGCAGACTCTGCCGTAATGGTAATTGACGGTTCAAAGGGTGTTGAGAAACAGACTATCAAACTTTTCAAGGTCTGTGTAATGCGTAATATTCCTATCATTACATTCATCAACAAGATGGACAGAGATGCAAAAAATTCTTTTGACCTTCTTGAAGACATTGAAAATGTTCTCGGAATTCACACCTATCCCGTAAACTGGCCAATCGGTTCAGGTAAAGAATTCAAGGGTGTTTATGACAGAAATTCTAAGAAAATCCTTGCTTTCACCGCTAATAACGGTCAGAAAGAAGTTGAAAAGAAAGAACTTACGCTTGACGATCCTGCCCTTGAAGATACAATAGGCTACTATCATAAGCAGGATTTATTTGATGAAATAGAACTTCTTGACGGTGCAGGCGATGAATTTGACCTTGAAGCAGTCCGCAATGGTCAGCTTACTCCTGTATTCTTCGGTTCGGCTCTTACAAACTTTGGTGTTGAGCCATTCCTTGAACAGTTCTTACAGCTCACAACTCCACCTCTGCCAAGAGAAACAGTTGATGAAAAGGTTGAGCCTATGTCAGACTTTTTCTCTGCATTTGTTTTCAAAATTCAGGCAAACATGAATAAGGCTCACCGTGACAGAGTTGCATTTATGCGCATCTGCAGCGGCAAGTTTGAAAAGAATATGGAAGTGTTCCATGTTCAGGGCAACAAAAAAATGCGTCTTTCACAGCCACAGCAGATTATGGCTCAGGAAAGAGAAATTGTTGACGAGGCATATGCGGGCGACATCATCGGTGTGTTTGATCCGGGCATTTTCTCAATCGGTGACACAATCTGTTCACCGGGACACAAGGTACAGTTCAGGGGAATTCCTACATTTGCTCCCGAACACTTTGCACTTGTCCGTCAGAAAGACACAATGAAGCGCAAACAGTTCATCAAGGGTACAAGTCAGATTGCACAGGAAGGTGCAATTCAGATTTTCCAGGAGCTTGACGCAGGTATGGAGGAAGTTATCGTTGGTGTTGTAGGCGTACTTCAGTTTGATGTTCTTAAATACAGACTTCAAAACGAGTACAACTGTGATATCATTATGGAAACACTCCCATATGAATTTATCCGTTGGATTGTAAACGATGACCTTGATCCGAAAACTCTCGACCTTGCGTCCGATACTAAGAAAATTCAGGATCTTAAAGGCAATCATCTTTTGCTCTTTACAAGCTACTGGAGCATAAACTGGGCGCTTGAACACAACAAGGGACTTGAACTCGCTGAGTTCGGTACAAACTAA",
      "translation": "MSSFKEEISKRRTFAIISHPDAGKTTLTEKLLLYGGAINLAGSVKGKRTAKHAVSDWMEIEKQRGISVTSSVLQFKYNGYCINILDTPGHEDFSEDTYRTLMAADSAVMVIDGSKGVEKQTIKLFKVCVMRNIPIITFINKMDRDAKNSFDLLEDIENVLGIHTYPVNWPIGSGKEFKGVYDRNSKKILAFTANNGQKEVEKKELTLDDPALEDTIGYYHKQDLFDEIELLDGAGDEFDLEAVRNGQLTPVFFGSALTNFGVEPFLEQFLQLTTPPLPRETVDEKVEPMSDFFSAFVFKIQANMNKAHRDRVAFMRICSGKFEKNMEVFHVQGNKKMRLSQPQQIMAQEREIVDEAYAGDIIGVFDPGIFSIGDTICSPGHKVQFRGIPTFAPEHFALVRQKDTMKRKQFIKGTSQIAQEGAIQIFQELDAGMEEVIVGVVGVLQFDVLKYRLQNEYNCDIIMETLPYEFIRWIVNDDLDPKTLDLASDTKKIQDLKGNHLLLFTSYWSINWALEHNKGLELAEFGTN",
      "product": ""
     },
     {
      "start": 9097,
      "end": 10500,
      "strand": 1,
      "locus_tag": "ctg24_11",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,097 - 10,500,\n (total: 1404 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGTACGACAAGCTTAAAAATTATTCAAAAAGCGGCATATATCCTTTTCATATGCCCGGACACAAAAGAACGGACATTACAGAAGAGGGTATAATACCGTATAATATCGACATAACCGAAATTCATGATTTTGACAATCTCCATTCACCAAACGGAGTTATTGATGAAATTCAGGAAAAGGCTGCAAAGCTTTACAATGCAAAAAATGCTTTCATTCTGATTAACGGTTCAACAGGCGGAATACTTTCAGCAATTCGCTCAATGACAAATCAAGGCGACAAGATCTTAATGGCTCGTAACTGCCACAAATCTGTATATAATTCAGCAGAACTGTTTAATCTCAATGTCGATTACATTTTTCCTGATACAGACAGCAGATACAATATTCTTACATCGGTTTTACCTTGCGATATAGAAGATAAACTTACAAAACACAATGATGAAATCAGACTTGTAATCATAACTTCGCCTACATATGAAGGAGTTGTTTCGGATATAAAGTCAATTTCCGAAATCTGTCACAAACACGGAGCAAAATTACTTGTTGACGAAGCTCACGGAGCGCATTTTCCGTTTTCGGACAGTTTTCCCGATGAAGCACTTAACTGCGGTGCAGACGCCGCAGTATTGAGTCTGCACAAAACTTTGCCGTCATTAACTCAAACTGCATTGCTCATAGCAAATGACAGCGAGCTTTCTGAAATTCTTGCCGAAAATTTAGCTGTATTTGAAACAAGCAGTCCGTCATATATTTTAATGAGTTCAATCGAAAAATGTCTTGATTTCTGCGAAAACAGCAAAGATAAATTCAAGGAATATTGTTGCAATCTTAAAACGGTCAGAAAAAAACTTGAAAATCTAAAATATCTGAAAATTTATGATAAAAGCGATACTGATTTTGATTATGATATCAGCAAAATTGTAATTTCAACAGCGAACGCAAATATTTCGGGAACAAAGCTTGCCGAAATACTGCGAAATAATTATCAGATTGAAACCGAAATGGCATATTCGGACTATGTAATTGCCATGACATCTGTTTGTGACACTGAAAAAGCTTTTGATATGCTTTCAGACGCTCTGATTTCAATTGACAGCGAACTTTCAAAAGGAGCCGACACCGAGCGTGTTCCGTTAAAAAATCTCTACACAGGCAAAAATTTCAACGCCTACGAGTTGTACAAATTCAACAAAGAAACTATTCCGTTTCAAAATTCGGAATTCAGAACTTCTGCCGAGTATATCTGGGCATATCCACCCGGAATTCCCCTCATCATACCCGGTGAAATTATAAGCAAGGAACTTATAAATTACATTGAATATCTTTCAGCCTGCAAGGTTGAGATTATGTCAACAAAAGGCGGTATGACGGACAACATAAGCGTAGTTAAAAAAGATTGA",
      "translation": "MLYDKLKNYSKSGIYPFHMPGHKRTDITEEGIIPYNIDITEIHDFDNLHSPNGVIDEIQEKAAKLYNAKNAFILINGSTGGILSAIRSMTNQGDKILMARNCHKSVYNSAELFNLNVDYIFPDTDSRYNILTSVLPCDIEDKLTKHNDEIRLVIITSPTYEGVVSDIKSISEICHKHGAKLLVDEAHGAHFPFSDSFPDEALNCGADAAVLSLHKTLPSLTQTALLIANDSELSEILAENLAVFETSSPSYILMSSIEKCLDFCENSKDKFKEYCCNLKTVRKKLENLKYLKIYDKSDTDFDYDISKIVISTANANISGTKLAEILRNNYQIETEMAYSDYVIAMTSVCDTEKAFDMLSDALISIDSELSKGADTERVPLKNLYTGKNFNAYELYKFNKETIPFQNSEFRTSAEYIWAYPPGIPLIIPGEIISKELINYIEYLSACKVEIMSTKGGMTDNISVVKKD",
      "product": ""
     },
     {
      "start": 10540,
      "end": 10701,
      "strand": -1,
      "locus_tag": "ctg24_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,540 - 10,701,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACTTTTCGCACTGCTGGTTAGCAACGCCGCAAGATGTCTTACAAGCTGACTGGCATGAAGTCTGGCACTCGCCGCAACCGCCTGTCTTAACGCTCTTCTTGAGGTCACGAGTTTCGATAGTTTTAATTCTCTTCATAATAAATCAAACTCCTTGTTAG",
      "translation": "MHFSHCWLATPQDVLQADWHEVWHSPQPPVLTLFLRSRVSIVLILFIINQTPC",
      "product": ""
     },
     {
      "start": 10796,
      "end": 12169,
      "strand": 1,
      "locus_tag": "ctg24_13",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,796 - 12,169,\n (total: 1374 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTCATCAGTATAAACTTAACGGATACAACATAGTTCTTGATGTTTACAGCGGCAGTGTACACGCAGTCGATGACCTTGCTTATGATGTTATTGCAATGTACAAAAACGCAACAAAAGAACAGATAATCAACGAAATGCTTTCAAAATATGCAGACAATCCTGAGATTACAAAAGAAGAAATCTCCGACTGCATTGATGATGTAAAAGAGCTTGAGGAACAAGGAAAGCTCTTTACAGACGACAAATACGAAAACCTTGCATTTGACTTTAAAAAGAGAAACACAGTAATCAAAGCGCTTTGTCTGCACATTGCTCACACCTGTAACCTTAACTGCGAATACTGCTTTGCAAGTCAGGGCAAATACCACGGCGAGAGAGCGCTGATGAGCTTTGAAGTGGGCAAGAGAGCAATTGACTTTCTAATTGAAAATTCAGGCAGCAGAGTAAACCTTGAGGTTGACTTCTTCGGCGGAGAACCTCTTATGAACTTTGATGTTGTAAAGCAGATTGTTGCCTATGCAAGAAGCATTGAAAAGGAACACAACAAAAACTTCCGTTTTACACTTACAACAAACGGTATGCTTGTTGATGACGATGTAATTGAATTTGCAAACAAAGAATGTCATAATGTAGTTCTCAGCCTTGACGGCAGAAAAGAAGTGCATGACCATCTTCGCAAAACTGTAAACGGCAAGGGCAGTTATGACATTATCGTTCCGAAATTTCAGGAATTTGTCAAAAAAAGAGGTAACAAGGGTTACTATGTAAGAGGCACTTATACACATAATAACACAGACTTCACAAACGATATTTTCCATATGGCGGATTTGGGATTTACAGAGCTTTCAATGGAGCCGGTTGTATGTGCTCCCGATGACCCATATGCACTTACATATGACGATTTGCCTATCCTTTTTGAACAGTACGAAATTCTTGCAAAGGAAATGCTCAAGCGTGAAAAAGAGGGCAGACCGCTCACCTTCTATCACTATATGATTGACCTTACAGGCGGTCCGTGCATTTATAAGAGAATCTCGGGTTGCGGTTCGGGTACAGAGTATATGGCTGTAACACCTTGGGGCGACCTTTATCCCTGTCATCAGTTTGTAGGCGATGAAAAGTACAAGCTCGGCGATATCTTTAACGGTGTTTCAAACACGAAAATTCAGGACGAATTTAAGCTTTGTAACGCATACGCCCGTCCCGACTGCAAAGACTGCTGGGCAAGACTTTATTGCAGCGGCGGTTGTGCCGCAAACGCTTATCATGCAACAGGCTCAATCACAGGTATTTACGAATATGGCTGTGAGCTTTTCAGAAAAAGAATGGAATGTGCCATTATGATGAAGGTTGCAGAAGCAGAAGAATAA",
      "translation": "MIHQYKLNGYNIVLDVYSGSVHAVDDLAYDVIAMYKNATKEQIINEMLSKYADNPEITKEEISDCIDDVKELEEQGKLFTDDKYENLAFDFKKRNTVIKALCLHIAHTCNLNCEYCFASQGKYHGERALMSFEVGKRAIDFLIENSGSRVNLEVDFFGGEPLMNFDVVKQIVAYARSIEKEHNKNFRFTLTTNGMLVDDDVIEFANKECHNVVLSLDGRKEVHDHLRKTVNGKGSYDIIVPKFQEFVKKRGNKGYYVRGTYTHNNTDFTNDIFHMADLGFTELSMEPVVCAPDDPYALTYDDLPILFEQYEILAKEMLKREKEGRPLTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDEKYKLGDIFNGVSNTKIQDEFKLCNAYARPDCKDCWARLYCSGGCAANAYHATGSITGIYEYGCELFRKRMECAIMMKVAEAEE",
      "product": ""
     },
     {
      "start": 12235,
      "end": 13044,
      "strand": 1,
      "locus_tag": "ctg24_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,235 - 13,044,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACGAAAAAATTATTATGCTCGGCACAGGAAGTGCGATGGTTACCGACTGTTATAATACCTGTTTTCTTCTGAAATCCGAAAACGACTGTCTTCTTGTTGACGCAGGCGGCGGAAACGGAATTTTATCCGCAATTAAGAAATCCGGAATAGCTTGGAACAGCATAAAGACAATGTTTATTACTCATTCTCACACCGACCATATATTAGGTGCCGTGTGGGTAATAAGGCAAATAAGCGCTCTTATGAATTCAGGCAAATATGACGGTAATTTTAATATTTACTGCCACGATGAATGTGTTGATTCAATCACGGCAATTTGCAACCACACACTTGCACCGAAATTTCTCAAAAATATCAATACAAAAATTTTCATCAATGAAGTAAAAGACGGTGAAATGCAAAACGCCGGCAGTATCCGACTCACTTTCTTTGATATATTTTCAGACAAAACAAAGCAATTCGGATTCAAGGCTGTTTTTCCGTCAGGAAAAGTTCTCGCCTGTCTCGGTGATGAACCGTTCAATGAAAAATGCAGAAATTTTGTTCAAAACTGTGATTATCTTATGTGTGAAGCTTTTTGTCTTTACAGTCAAAAAGATATTTTTAAGCCCTACGAAAAATTCCACAGCACAGCGCTTGATGCAGGAAAACTTGCAGAGAGTCTTTTTGCAAAAAATCTTATCCTGTATCACACCGAGGACGAAACACTTCAAACACGCAAAAGTACATATACTTCAGAGGCAAGAACAGTTTTTAACGGAAATATATTTGTTCCCGATGATTTTGAAGTTATTGACTTAAAATAA",
      "translation": "MNEKIIMLGTGSAMVTDCYNTCFLLKSENDCLLVDAGGGNGILSAIKKSGIAWNSIKTMFITHSHTDHILGAVWVIRQISALMNSGKYDGNFNIYCHDECVDSITAICNHTLAPKFLKNINTKIFINEVKDGEMQNAGSIRLTFFDIFSDKTKQFGFKAVFPSGKVLACLGDEPFNEKCRNFVQNCDYLMCEAFCLYSQKDIFKPYEKFHSTALDAGKLAESLFAKNLILYHTEDETLQTRKSTYTSEARTVFNGNIFVPDDFEVIDLK",
      "product": ""
     },
     {
      "start": 13036,
      "end": 14949,
      "strand": -1,
      "locus_tag": "ctg24_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,036 - 14,949,\n (total: 1914 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTTTTCTACGGATAAATCATCTTTTAATAAAAAGGATGTCTCGGATTGTGATTACAAAATTTCACTTGCCGGTAATCCTAATGTCGGCAAGAGTACAATTTTTAACGAACTGACGGGATTAAGGCAGCACACGGGAAATTGGACGGGTAAAACAGTTGAGTTTGCCAGAGGTTGTTGCAAAATCAAAGACGCAAGATTTTGTATTACGGACTTACCCGGATGCTATTCCCTGCTTTCATTTTCGGGCGAAGAGGAGGTAACAAGGGAGTGTCTTATACAAAATCAAAATGACTGCGTTGTAATAGTTGTTGACTGCGGAGTTATTGAAAGAAATCTTTCATTTGCATTGCAGGTGTTATCTGTCACAAAGAATGCTGTTCTTTGTCTTAATCTTTGTGATGAGGCTGAAAAAAACGGTATAAAAATCGACTGCGACGAGTTATCGCTAAATCTTGGAATACCTGTTGTAAAAACCTGTGCAACAGACAAAAAAGGTTTGGATGAGTTAAAAAAAGCGATCTATAATGTATGCACCGGAAAGACAAAATGTTTTAGGGTAGAAAGAAATTTTGAAGGTGTTGATATACTATCCGAAAAAAACTACAAACAGAATATTGAAAAGCTTTCGCAAATTGGTAACAAAATTTCATGTGACTGCGTAAAATATGAAAAATCAGAGTTAAATGCTTGTACAAGAAAGCTTGATAAAATACTTACAAGCAAAACCACGGGAATACCGATTATGCTTGCAATGCTTGGTATATTGTTCTGGATAACAGTTGTCGGTGCAAATTATCCGAGTGAATGGTTAAGCAATTTGTTTGGTTTTATAAAAGAGAAGCTGTATATTCTTTTTGATTTTTTACACGCTCCCGATGTTGTAACGGGACTTTTGATTGACGGAGTTTATACAACTCTGTCATGGGTGGTATCTGTAATGCTGCCGCCTATGGCTATATTCTTTCCGTTGTTTTCGCTTGTTGAGGATTCGGGATATCTGCCGAGAATTGCATTTAATCTTGATAGGTATTTTTCAAAGTGCGGTGCACACGGAAAGCAAAGTCTTGCTATGGCAATGGGTCTTGGCTGTAATGCCTGCGGAGTTACGGGATGCAGAATCATTGAGTCGCCAAAGGAACGACTGATTGCAATTCTTACAAATAATTTTATGCCGTGTAACGGACGGTTTCCCACAATAATTGCATTACTGCTCATGTTCTTTGCAGGTACGGCATTTACGCTGAGCAGTTCGCTTGAGGTAGCGGCATTGTTGATTGGAATAATAGTTTTCTGTGTTTTTATAACACTTGTTATATCTAAGGTACTTTCAGTCACAATATTGAAAGGTGAACAGTCCGGATTTGTGCTTGAACTTCCGCCGTACAGAAAGCCGCAGATTTTAAAAACTATTGTCCGTTCGCTGTTGGACAGAACTTTATTTGTTTTAGGAAGGGCTGTTGCGGTTGCCGCTCCGGCAGGTGCGATAATCTGGATTCTTGCAAATGTGCATATAAGCGATGTTTCACTTTTAAAATATTGTACTGATTTTTTAGATCCGTTCGGCAGATTTATCGGGGTTGACGGCGTTATAATAATGGCATTTATACTTGGATTTCCTGCGAATGAAACCGTTATTCCGATTATAATTATGTCATATATGGCAAGCGGTACTCTTGTTGATTATTCAAGCTACGATCAGCTGTTTCAACTTCTCAGCATGAACGGCTGGACAATTACAACGGCTGTATGTACGATTATTCTTTGCATTCTTCATTATCCGTGTTCAACAACCTGTCTGACAATAAAAAAAGAAACAGGCAGCCTTAAATGGACGCTTGTTTCTATGGCATTGCCTACTGCAATGGGAATTGTACTTTGTATGATTACAGCAGGTGTTATGAGATTATTTTAA",
      "translation": "MFSTDKSSFNKKDVSDCDYKISLAGNPNVGKSTIFNELTGLRQHTGNWTGKTVEFARGCCKIKDARFCITDLPGCYSLLSFSGEEEVTRECLIQNQNDCVVIVVDCGVIERNLSFALQVLSVTKNAVLCLNLCDEAEKNGIKIDCDELSLNLGIPVVKTCATDKKGLDELKKAIYNVCTGKTKCFRVERNFEGVDILSEKNYKQNIEKLSQIGNKISCDCVKYEKSELNACTRKLDKILTSKTTGIPIMLAMLGILFWITVVGANYPSEWLSNLFGFIKEKLYILFDFLHAPDVVTGLLIDGVYTTLSWVVSVMLPPMAIFFPLFSLVEDSGYLPRIAFNLDRYFSKCGAHGKQSLAMAMGLGCNACGVTGCRIIESPKERLIAILTNNFMPCNGRFPTIIALLLMFFAGTAFTLSSSLEVAALLIGIIVFCVFITLVISKVLSVTILKGEQSGFVLELPPYRKPQILKTIVRSLLDRTLFVLGRAVAVAAPAGAIIWILANVHISDVSLLKYCTDFLDPFGRFIGVDGVIIMAFILGFPANETVIPIIIMSYMASGTLVDYSSYDQLFQLLSMNGWTITTAVCTIILCILHYPCSTTCLTIKKETGSLKWTLVSMALPTAMGIVLCMITAGVMRLF",
      "product": ""
     },
     {
      "start": 14965,
      "end": 15201,
      "strand": -1,
      "locus_tag": "ctg24_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,965 - 15,201,\n (total: 237 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGAAAAATGTTCGCTTGACAAGTTACCGCTTGGAGTTACGGGGATTGTCTATCGTGTGAACTGTAATGAAAATATCAAAAACAGAATATTTGATTTCGGTATTATGGAGAACAGTTCTGTTATCCCCTTGTTTACAAGTCCGTTCGGTGATCCGTCTGCGTATCTTGTTAAAAATGCCGTTGTGGCACTGAGAAATAACGATTGCAAAGATATCATTGTTACTCCTGAATAA",
      "translation": "MKEKCSLDKLPLGVTGIVYRVNCNENIKNRIFDFGIMENSSVIPLFTSPFGDPSAYLVKNAVVALRNNDCKDIIVTPE",
      "product": ""
     },
     {
      "start": 15669,
      "end": 17558,
      "strand": 1,
      "locus_tag": "ctg24_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,669 - 17,558,\n (total: 1890 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAAATCTTTTAAAAAAATCCTCTCAATTGTACTTTCTGTAATGATGATTTCGTCACTTATGACGGTTTCACTTTCAGTAAGCGCAGTTGAAGACGGAAAAGTAAGAGTAATTGTCAGAAATGATACATACTCAGTAGAAAACGGCGCTCCGTGGGACGGCGTTCTCGTTGATGAGTGGGTAAGCATTAATAATGACACTACTATGATGTCAGCCGTTGTTGATGCACTCAACAATCACGGCTACACACAGGAAGGTGCTGAGAACAATTACATCTCATCAATTAATGGACTTGCTGCATTTGACGGCGGTACAATGAGCGGTTGGATGGGAACTCTCAATGACTGGTTCACAAATTCAGGTTATGCATCCTATACAGTAGCAGACGGCACACTTGAGAGTGGTGATGAAATCGCTATTATGTATACTTCAAACGGTTACGGCGAGGATATCGGCGGTACATGGGCAAATAACGATACAACTGTTAAATCGGTTGAGATCACAGGTGCCGAGCTTTCGGGCGAATTCGATCCGTCAGTTACAGACTACACACTCACAATCGACACTCCGTCAGCTGATGTAAATGTAGTTCCTACTGCAACTAACAAAAACTTCCAGACAAGAAAATATAAGAATGAATATCATCCTTCTGACGACAGTGCGTTTTACAAGAGAAGTCAGGCTGTTAATGTTTCTGACGGTGACAAAATTATCATAGGTTGCGGTGATACTGCATGGCCGTCAATGAACACAAGTGAAGGCGGTACTGTATATACATTCACAGTTAAATATGCTCCTTCCGCAGCTGACACAGTTTCAAACAAGATTGACGAGGTTGCAAAATATCTCGCATCACAGGATGCCCCCACAGTTTCTTCGGTAGGCGGTGAGTGGACAGTCCTCGGTCTTGCAAGAGCAGGTAAAATCACAGACGAAATTGCAGACAGTTACTATCAGAATGCAGTTAAGTATGTTGAAGAAAAGGGTTCTGCAAAGCTTCACAATACTAAATCAACAGACAATTCAAGAGTAATTCTTGCCCTTACGGCAATCGGTAAGGATGTTACAGATGTTGCATCATATAACCTTCTTGAACCGCTTGCAGATATGGATTATGTTAAGAAGCAGGGTATCAACGGTCCTGTCTTTGCACTCATTGCACTTGATACGGGCGATTATGAAATTCCGCAGACTGACGCCGCAAATCCCACAACAAGAGAAAAGCTCGTACAGACAATTCTTGATGCACAGGTAGCAAACGGTGGCTGGACATTTTTCGGCTCAACTGCAGATCCTGATATGACAGGTATGGCAATTCAGGCACTTGCTCCTTACTACTCAACAAACAGCGATGTTAAAGAGGCAATTGATAAAGCACTCACAGCAATGTCAAACGCACAGAACGAAAACGGCGGATTTGCATCATGGGGTTCTGTAAACAGCGAAAGCTGTGCACAGGTACTCGTTGCACTTACAAGCCTTGGAATTGATCCTACAAATGATGAAAGATTCATCAAAAACGGCAACACACTCATCGATGCTATGATGAGTTTCTCCGCTGAAAACGGATTCGGTCATACAGATACAACATACAATCAGATGGCAACCGAACAGGGTTTCTATGCTTTTGTTTCATTTGACCGTCTTGTAAACGGCAAAACTTCACTCTACAATATGACTGACCGACTTGCAGAAAATTATGCCGTAGGTGATGTTAATCTTGATAACACAGTTTCTGTAATTGACGCAACACTTGTTCAGAAGCAGATTGTAAACCTTGAACAGCTTTCAAAGGTTTCACTTATCAAAGCTGATGTAAATCATGACGGTGTTATCGATGTTGTTGATGCAACAGAAATTCAGAAAATCATCGTTAAGCTCGTTTGA",
      "translation": "MNKSFKKILSIVLSVMMISSLMTVSLSVSAVEDGKVRVIVRNDTYSVENGAPWDGVLVDEWVSINNDTTMMSAVVDALNNHGYTQEGAENNYISSINGLAAFDGGTMSGWMGTLNDWFTNSGYASYTVADGTLESGDEIAIMYTSNGYGEDIGGTWANNDTTVKSVEITGAELSGEFDPSVTDYTLTIDTPSADVNVVPTATNKNFQTRKYKNEYHPSDDSAFYKRSQAVNVSDGDKIIIGCGDTAWPSMNTSEGGTVYTFTVKYAPSAADTVSNKIDEVAKYLASQDAPTVSSVGGEWTVLGLARAGKITDEIADSYYQNAVKYVEEKGSAKLHNTKSTDNSRVILALTAIGKDVTDVASYNLLEPLADMDYVKKQGINGPVFALIALDTGDYEIPQTDAANPTTREKLVQTILDAQVANGGWTFFGSTADPDMTGMAIQALAPYYSTNSDVKEAIDKALTAMSNAQNENGGFASWGSVNSESCAQVLVALTSLGIDPTNDERFIKNGNTLIDAMMSFSAENGFGHTDTTYNQMATEQGFYAFVSFDRLVNGKTSLYNMTDRLAENYAVGDVNLDNTVSVIDATLVQKQIVNLEQLSKVSLIKADVNHDGVIDVVDATEIQKIIVKLV",
      "product": ""
     },
     {
      "start": 17585,
      "end": 18514,
      "strand": 1,
      "locus_tag": "ctg24_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,585 - 18,514,\n (total: 930 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAAAGATAAAAAAGTTTGTTAAAAAAAATCAAATACTTTTAATTGCGGTGTGCGTTTGTATTGCCGCACTTACAGTAGCATTTTTTGCAGGCGGCAACCGATCGGAAAATAAAGTTCAAACTGCATCAACTGCCTCCTCGCTATCGACAACAAATGCAGACACAGAAACAACTTCTGTGTCTGCAACAGAGAAAACCACTCAAAATCCTACCGATTCCACTAAATCAAACAAAGATAAAAAGGACAGGAAAAATTCCGAAGATAAAAAGAACAGTAAGGATAATTCGCAGAACAGTAACGGTTCAGCCGTTGAAAAAAGTGAAAAATCCGAGCAGAGTTCAAACAACAGTTCTTCGGATAAGAAAAAAACGTCTTCTTCATCAAACAGTTCTTCAAAGCCGAACAAAAAGAATGATGTTCAGCCGACAACACAGGATAAGTACAAAACCGATCCCGTACCGTCGGGAAAGCCAAAGCCGGTTGAACCGGAAGAACAGGAAACAAAAGATACAAATCTTTATTGTACCTTTACAATCACCTGTTCAACAATTCTTGACAATATAGATGACCTTGATCCCGAAAAAATTGAACTTGTTCCAAAGGACGGTATAATCCTCAAAAAACAGAAGGTTCAATTCAAAGAGGGTGAATCTGTATATGATGTCCTTGTAAAAGTTTGTAAGGACAACAATATTCATATGGAATCAAGCTGGACTCCTATGTATAATTCCGCTTATATTGAAGGAATTAACAACCTCTACGAATTTGACTGCGGTTCTCTCTCGGGCTGGATGTACAAAGTCAATGAATGGTTTCCAAACTACGGCTGTTCACGATATGTACTCAAGAACGGCGACGATGTGGTCTGGTGCTACACTTGTAACTTAGGCTATGATGTCGGCGGAGGATACGCAACAGGAGAATAA",
      "translation": "MEKIKKFVKKNQILLIAVCVCIAALTVAFFAGGNRSENKVQTASTASSLSTTNADTETTSVSATEKTTQNPTDSTKSNKDKKDRKNSEDKKNSKDNSQNSNGSAVEKSEKSEQSSNNSSSDKKKTSSSSNSSSKPNKKNDVQPTTQDKYKTDPVPSGKPKPVEPEEQETKDTNLYCTFTITCSTILDNIDDLDPEKIELVPKDGIILKKQKVQFKEGESVYDVLVKVCKDNNIHMESSWTPMYNSAYIEGINNLYEFDCGSLSGWMYKVNEWFPNYGCSRYVLKNGDDVVWCYTCNLGYDVGGGYATGE",
      "product": ""
     },
     {
      "start": 18517,
      "end": 19407,
      "strand": 1,
      "locus_tag": "ctg24_19",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,517 - 19,407,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGATACTTTTTCAAATATGCACCCCTTTATCAATTTTATATTTTTTGCACTTACAATAGGGTTCACGATGTTTATCATGAACCCTGTTTGTCTTGCTGTCAGTTTTTTATGTGCGCTTGTAACCGCTTTATACCTTAACGGCAAAAAAGCTGTGAGATTGTCACTTGTTTTTCTTTTACCTATGATACTCTTGATAGTTCTCGTAAATCCTGTTTTTAATCATGAAGGAATGACTATACTCACATATTTTCCGTGGGATAACCCACTAACCCTCGAATCAATCGTTTACGGTATTGCAAGTGCATTTTTGCTTTCGTCAACAGTTTTATGGTTTTCTTCATTCAATGCAGTAATCACTTCCGACAAGGTAGTTTTCCTGTTTGGCAGAATAATGCCGTCATTGAGTCTGGTGATTTCAATGGCATTGCGTTTTGTTCCAAAGTTTTCGGCACAAATGAAGCTTGTGCGTAATGCACAACACACAATAGGCAGAGATATAAACGAGGGAACATTGTTTCAAAGAATAAGAAATGCTGTAAAAATCCTTTCGATTATGATAACATGGTCACTTGAAAATGCAATTGAAACAGCCGATTCAATGAAAAGCAGAGGTCACGGTCTTAAAGGCAGAACATCCTATTCACTTTATAAATTTGACAAAAGAGACGCATTTATGCTTTGCACAATCCTTTTTACCGGATTTGTACTTATGATTTTGCTTTTTACAAACGCAATAAAATTCAGATACTATCCGTCAATCAAGGGCGATTTGTTTACGGTGCAAAGTGTTATTTTTTATATATTCTACACATTTTTAATGTTGATTCCGCTATCGGTAAATATAGGAGAGGGGATAAAATGGAAACATATGCAATCAAGAATCTGA",
      "translation": "MKDTFSNMHPFINFIFFALTIGFTMFIMNPVCLAVSFLCALVTALYLNGKKAVRLSLVFLLPMILLIVLVNPVFNHEGMTILTYFPWDNPLTLESIVYGIASAFLLSSTVLWFSSFNAVITSDKVVFLFGRIMPSLSLVISMALRFVPKFSAQMKLVRNAQHTIGRDINEGTLFQRIRNAVKILSIMITWSLENAIETADSMKSRGHGLKGRTSYSLYKFDKRDAFMLCTILFTGFVLMILLFTNAIKFRYYPSIKGDLFTVQSVIFYIFYTFLMLIPLSVNIGEGIKWKHMQSRI",
      "product": ""
     },
     {
      "start": 19380,
      "end": 20597,
      "strand": 1,
      "locus_tag": "ctg24_20",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,380 - 20,597,\n (total: 1218 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 79.9; E-value: 2.8e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMETYAIKNLSFRYPETGIDVLKDITFSVNEGEFITVCGPSGCGKSTLLRHLKPDLSPHGVLSGEILFEEKPISDLSHREQSSKIGFVMQSPENQIVTDKVWHELAFGLESLGYDNNTIRKRVAETASFFGIQNYFEKSVLELSGGQKQILNLASIMAMQPSVLILDEPTSQLDPIAASEFLHCVSRINHELGTTVIITEHRLDEVLPLSDRVLVIENNGISAFDSPQKVGKILKEKVSKTFLSMPAPMQIWQAVTENDNTDCPVTVPSGKKWLSEYAQNHKMYELKPESIQKHSDKEAVSLNDIWFRYEKSGADVLKGLSLKIYQGEFAAILGGNGMGKSTALSIICSLNKPYRGKVEISPLNKNSFDTLVAVLPQNPQTLFLKKTVLEDLYEVFDGRKISKEEKE\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAACATATGCAATCAAGAATCTGAGTTTTCGATACCCCGAAACCGGTATTGATGTACTTAAAGATATTACTTTCAGCGTAAATGAAGGCGAGTTTATCACGGTCTGCGGTCCGTCAGGCTGCGGAAAAAGCACACTTCTCAGACATCTGAAACCCGATCTTTCACCGCACGGTGTTCTTTCGGGAGAAATATTATTTGAAGAAAAACCTATATCAGACCTTTCTCACAGGGAGCAAAGCAGTAAAATCGGCTTTGTTATGCAATCACCTGAAAATCAGATTGTTACCGATAAGGTATGGCACGAACTTGCTTTCGGACTTGAAAGTCTTGGTTATGACAACAATACAATCCGAAAAAGAGTTGCCGAAACAGCTTCATTTTTCGGAATCCAAAATTATTTTGAAAAAAGTGTTCTCGAACTTTCGGGCGGACAAAAGCAAATTTTAAACCTTGCTTCAATTATGGCAATGCAACCGTCCGTTCTCATTTTGGATGAACCGACAAGCCAACTCGATCCGATTGCGGCAAGCGAATTTTTGCACTGCGTTTCACGCATAAATCACGAACTGGGGACAACGGTGATAATAACGGAACACAGACTTGATGAGGTGCTTCCGCTTTCAGACAGGGTGCTTGTCATCGAAAACAACGGAATTTCAGCTTTTGACTCTCCTCAAAAGGTCGGAAAAATTCTTAAAGAAAAAGTCAGTAAAACATTTCTTTCTATGCCTGCTCCGATGCAGATATGGCAGGCTGTTACAGAAAATGACAATACCGACTGTCCCGTAACTGTCCCAAGCGGCAAAAAGTGGCTTTCGGAATATGCCCAAAATCATAAAATGTATGAGCTCAAACCCGAAAGCATTCAGAAACATTCTGATAAAGAAGCAGTAAGTCTTAATGATATTTGGTTCAGGTACGAAAAGTCGGGTGCAGATGTACTAAAAGGTCTTTCACTAAAAATATATCAGGGGGAATTTGCGGCTATACTCGGCGGTAACGGAATGGGAAAATCAACCGCTTTGTCAATTATCTGTTCACTTAACAAGCCATACAGAGGCAAAGTTGAAATCTCTCCGCTTAACAAAAATTCTTTTGACACGCTCGTAGCAGTATTACCCCAAAATCCGCAGACACTGTTTTTGAAAAAAACTGTACTTGAAGATTTGTACGAAGTATTTGACGGCAGAAAAATCAGCAAGGAGGAAAAAGAA",
      "translation": "METYAIKNLSFRYPETGIDVLKDITFSVNEGEFITVCGPSGCGKSTLLRHLKPDLSPHGVLSGEILFEEKPISDLSHREQSSKIGFVMQSPENQIVTDKVWHELAFGLESLGYDNNTIRKRVAETASFFGIQNYFEKSVLELSGGQKQILNLASIMAMQPSVLILDEPTSQLDPIAASEFLHCVSRINHELGTTVIITEHRLDEVLPLSDRVLVIENNGISAFDSPQKVGKILKEKVSKTFLSMPAPMQIWQAVTENDNTDCPVTVPSGKKWLSEYAQNHKMYELKPESIQKHSDKEAVSLNDIWFRYEKSGADVLKGLSLKIYQGEFAAILGGNGMGKSTALSIICSLNKPYRGKVEISPLNKNSFDTLVAVLPQNPQTLFLKKTVLEDLYEVFDGRKISKEEKE",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 10795,
      "end": 12169,
      "tool": "rule-based-clusters",
      "neighbouring_start": 795,
      "neighbouring_end": 20597,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r24c1"
   }
  ]
 },
 {
  "length": 20077,
  "seq_id": "NZ_WHCC01000031.1",
  "regions": []
 },
 {
  "length": 19919,
  "seq_id": "NZ_WHCC01000032.1",
  "regions": []
 },
 {
  "length": 19411,
  "seq_id": "NZ_WHCC01000033.1",
  "regions": []
 },
 {
  "length": 18902,
  "seq_id": "NZ_WHCC01000034.1",
  "regions": []
 },
 {
  "length": 18632,
  "seq_id": "NZ_WHCC01000035.1",
  "regions": []
 },
 {
  "length": 18440,
  "seq_id": "NZ_WHCC01000036.1",
  "regions": []
 },
 {
  "length": 17887,
  "seq_id": "NZ_WHCC01000037.1",
  "regions": []
 },
 {
  "length": 16747,
  "seq_id": "NZ_WHCC01000038.1",
  "regions": []
 },
 {
  "length": 16285,
  "seq_id": "NZ_WHCC01000039.1",
  "regions": []
 },
 {
  "length": 69798,
  "seq_id": "NZ_WHCC01000004.1",
  "regions": []
 },
 {
  "length": 15774,
  "seq_id": "NZ_WHCC01000040.1",
  "regions": []
 },
 {
  "length": 15560,
  "seq_id": "NZ_WHCC01000041.1",
  "regions": []
 },
 {
  "length": 14994,
  "seq_id": "NZ_WHCC01000042.1",
  "regions": []
 },
 {
  "length": 14921,
  "seq_id": "NZ_WHCC01000043.1",
  "regions": []
 },
 {
  "length": 14587,
  "seq_id": "NZ_WHCC01000044.1",
  "regions": []
 },
 {
  "length": 14016,
  "seq_id": "NZ_WHCC01000045.1",
  "regions": []
 },
 {
  "length": 13949,
  "seq_id": "NZ_WHCC01000046.1",
  "regions": []
 },
 {
  "length": 13869,
  "seq_id": "NZ_WHCC01000047.1",
  "regions": []
 },
 {
  "length": 13799,
  "seq_id": "NZ_WHCC01000048.1",
  "regions": []
 },
 {
  "length": 13768,
  "seq_id": "NZ_WHCC01000049.1",
  "regions": []
 },
 {
  "length": 67317,
  "seq_id": "NZ_WHCC01000005.1",
  "regions": []
 },
 {
  "length": 13744,
  "seq_id": "NZ_WHCC01000050.1",
  "regions": []
 },
 {
  "length": 13731,
  "seq_id": "NZ_WHCC01000051.1",
  "regions": []
 },
 {
  "length": 12860,
  "seq_id": "NZ_WHCC01000052.1",
  "regions": []
 },
 {
  "length": 12420,
  "seq_id": "NZ_WHCC01000053.1",
  "regions": [
   {
    "start": 1,
    "end": 12420,
    "idx": 1,
    "orfs": [
     {
      "start": 1,
      "end": 870,
      "strand": -1,
      "locus_tag": "ctg49_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 870,\n (total: 870 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTATTTTACAGCTATGCGGAGTTTGTAATAGGGCTTGTGGCAATTTTCTATTTTACTTCAAAAATATTTTCCATTACCAAGTACAAACTGTATTTTGCCCTGTCATTGATTTTTATAATTTCAACGGCATCGTTTGCCTGCTTTATAAAAAGCGACCAACGGTATGTAATTCTGCCGGTTTTGCATTTCGTTACATTGACATTTCTTCCGATTTCACTTGGATACAATAAGAAAATGATGTTGCTGTTCTCTTCGCTCTTCTTTTCGGGATTAACATTTTTTATATCCGAAATCTATCAATTGTTGTGTTCAATCTATTCAACCGAATTTGCGAGCAGCACCAGTGTGTTTTTTAATCTGATTTCAAATCTTATTGTTTTGGGAATATTCATACTGCTGTCAAGTCCGCTGAAAATCAAGACCAAGCTTGTGGTTGAGTCAATTACCAAACCGACAATAATTATGATATTGATTTTCCTTTATCTCGGCGGAAGTATGGCGACCTTCGGGGCATATTACATAATTCCGTCATCGGATTACAGAACAGCTGCACTTAAAATTTTGACAATGATTGTGTCGATTGTATTCTCGTTTTCAATACCTATTCTTTTGTACAATCAGATTAAAAAGAGCCAATATATGCACGAAAACGATATCTACGAAAGACAGCTTAACGCACAGATTAATTATTACAAGAGCATTACGACTTCGGGATATGAACTGAGAAAAATCAGGCATGATTATAATGATCTTTCTATCGGGTTGAAGTCGCTTATCAACAGTCGGAAATATGATGAGGTTCTTCCCCTCCTGCAAAAATATGACAGCGAGATTATAAGCTCATTTCAGATTTTGTACAACACGGGC",
      "translation": "MLFYSYAEFVIGLVAIFYFTSKIFSITKYKLYFALSLIFIISTASFACFIKSDQRYVILPVLHFVTLTFLPISLGYNKKMMLLFSSLFFSGLTFFISEIYQLLCSIYSTEFASSTSVFFNLISNLIVLGIFILLSSPLKIKTKLVVESITKPTIIMILIFLYLGGSMATFGAYYIIPSSDYRTAALKILTMIVSIVFSFSIPILLYNQIKKSQYMHENDIYERQLNAQINYYKSITTSGYELRKIRHDYNDLSIGLKSLINSRKYDEVLPLLQKYDSEIISSFQILYNTG",
      "product": ""
     },
     {
      "start": 874,
      "end": 1581,
      "strand": -1,
      "locus_tag": "ctg49_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 874 - 1,581,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTTTGCGGCTTTATGTGATGATGATAAACACATAACCGAAGAGGTTAAAAAACTGCTTTTAGAATATGCAAAGGATAATCGTGTAACTATTGATATTGATGAATTTGAAAGCGGTGAAAAGCTTTTGAATTCCGAGAATAATTACGATATAATCGTGCTTGATTTTCAGCTTGGCAGTACAGACGGACTGACTGTTGCAAAGGAGCTCAGAAAACGCAATGTGCTTTCCTGCATAATTTTTCTGACATCTTACCCCAACTTTATGATTGATGCGTTTGAAGTGAACACATTCAGATTTCTTCTGAAACCGATTGACAAATCAAAATTTTTCAAGGCAATTGATGACTATGTAAAAATTGTAGATGCAAATTATCCGATAACTCTTATTCAAAATAAGGAATTGAAAAAAATTAACTCAAATGAAATTTGCTTTATTGAGGCAGACGGAAAGTACTCAAACATTCATTTAAACACCAAGGTCATGCACTGTTCAAAAACTCTTTCGGGAGTTACAAATCTTCTCCCAAAGTATTGTTTTGTAAAAACTCATCGTTCTTTCGTGGTAAATCTTCACTATATAAAATCATACTCATCAGATACGGTGTATCTGAGTAACGGCGAATCGGCTTATCTCAGTAAAAATTATCAAAAATCCTTTCGGACATCATATATGAATTTTCTTGAAAAAAATTATGTGAGGTTATAA",
      "translation": "MFAALCDDDKHITEEVKKLLLEYAKDNRVTIDIDEFESGEKLLNSENNYDIIVLDFQLGSTDGLTVAKELRKRNVLSCIIFLTSYPNFMIDAFEVNTFRFLLKPIDKSKFFKAIDDYVKIVDANYPITLIQNKELKKINSNEICFIEADGKYSNIHLNTKVMHCSKTLSGVTNLLPKYCFVKTHRSFVVNLHYIKSYSSDTVYLSNGESAYLSKNYQKSFRTSYMNFLEKNYVRL",
      "product": ""
     },
     {
      "start": 2202,
      "end": 9533,
      "strand": -1,
      "locus_tag": "ctg49_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,202 - 9,533,\n (total: 7332 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (rule-based-clusters) NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 148.6; E-value: 5.2e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTAATTTAATCAACTTGCTTGATACATACAAAGGTGAAAAGCGAGAGCTTTATCCGCTTACACCGAGCCAGATGGGTGTTTATCTTTCGTGTATGCACAACCCAAAAGGCACAATGTACAACATTCCCTGCACCTATGTTTTTGACAAGGGCAGTCTTGATACCGACAGGCTGATAAATGCCGTAAGAAAAGCTGTTGACAATCACCCTGTTATGAAAATTTTTATTGACAGTTCAACAGGAAGCCCGATGATGAAGCCTCGTGACAGCGTTGATTTTGACATTCCTGTCGTACAGGTTGACAATCTTGAACAGGCAGGCAAAGATTTTGTTAAGCCGTTTGACCTTGAAAAAGACATTCTGTTCAGATTTGCAATTTTTGAATGCGGTGACAAATCTATGTTTGCAATGGACTTTCACCATATAATCTCTGACGGCACATCTGTTTCGGTTATCTGCAATGACATTGCGCTTGCATATGACGGAAAAGAGCTTGAACCCGAAAAGTTTTCTCAGCTTGATCTTTCTGTTTTTGAGGAAAAGCTTGAAGAAACCGAAGAATATCAAAAATCAAAGAACTACTATGACAGCATTTTTTCGGCTGTTGAGTCAAAGTCGGAAATAACGGAAGATTTTGCAGAGAATTCAGAGGTTGAGGATAAACCGAACGGTTCTTTTGAATTATCCACGAACGGCAAATTCTCCGTTGAGGAAGTTCGCAATTTTGCCTTAGCAAACCAAATTACGCCGTACACTGTTTTCCTCGGTGCATATGAATACGCAGTTGCAAAGTTTACAAATCAGAGCGAAACAACGGTTTGCACGGTTACTCACGGAAGATTTAACAAACAGCTTAAAAATACGGTCGGCATGATGGTTCGCACACTTCCTATCCACGCAAATATTGATGAAGAAGATACAGTTTCGGACTACCTCAAAAAAATACGCAGGAATATAAAGGAAACAGTTGCAAACGATTGGTTTCCGTTTATGAAACTTGCGTCTGACTATGACCTCTCTGCCGACATTATGCTTGCCTATCAGGCTGACATATTCAACACCTTTAAAATAGGCGGTCAGGCTCTAAAATTAAAACTTGTTCCGTTAAAAAGTGCCATTTCAAAATTGAATGTTATGGTATTTGAATCAGAAACAGATTTTGAATTGCGTTTTGAATACAGAAACGATTTATTCAAAGAGGAAACTATTCGTTCGTTTGCCGACAGCTTTTTAAAGATTGTTGAGCAGTTTCTTAAAAAATCCAAGCTCTGCGAAGTTGAGCTTGTAAACGAAAATCAGCTTGCAGAGCTTGATAACTTCAACAAAACGGAATTTCCGTTTGACGACAGCAAAACCGTTGTTGATTTGTTTGAGGAGCAATGCAAAAAAACTCCTGACAAAACAGCGGTTGTATATAAAGAAAAGAAGTTCACCTACGCTGAAATTGATGAGATTACAAACCGAATTGCAGGTTATGTTCACTCAAAGGGTATCGGTAAAGAAGAGGTTGTTTCAATTCTGATTCCGAGATGCGAATATATGCCGATTGCGTCAATCGGTGTGCTGAAATCGGGTGCGGCATATCAACCGCTTGATCCGTCATATCCGCCCGAAAGACTTCAGTTTATGATTAAGGACGCAAACGCAAAGCTGCTTATTGCGGACGAAAATCTGCTTGAACTTTTGCCCGATTACAGCGGTGATATTCTTCTTACAAAGGATATTCCGAATCTTCCGAAATCAGATGCAGTTTTTACAAAACCCTCACCCGATGATTTGTTTATACTTATCTATACATCGGGTTCAACAGGCACTCCAAAGGGTGCTATGCTTGAACACAAAAATGTGCGTTCATTCTGCGATTTTCATATCAGAAACTCTGACATTGACGAACACAGCGTTGTTTCGGCATATGCAAGCTACGGTTTTGACGCCTGTCTCAGTGAAATGTATCCTGCGCTTATCGGCGGTGCCGAGCTTCACATTATTGAGGAGGACATCAGACTTGACCTTGTAAGGCTGAACAGATATTTTGAAGATAACGGAATCACCCACGCATTTATGACAACACAGGTTGCAAGACAGTTTGCAACCGAAATTGACAACCACTCGCTCAAATATCTTCTTACGGGCGGTGAACGGCTTGTTCCCCTTGAACCGCCAAAGAATTTTGAACTCATAAACGGTTACGGTCCGACAGAATGTACGGTTTACATCACAACACAGCCCGTTGACAAGCTCTACCACAGAATTCCTGTCGGCAAGGCTCTTGACAATATCAAGCTTTATGTAACAGACAAATACGGCAGACGGCTTCCGACAGGGGCTTTGGGCGAGCTCTGTGTATCAGGTCAGCAGGTTTCAAGAGGGTATCTTAACCGTCCCGAACAGACTGCAAAGGCATACGAAAAGAACCCATATTGCAATAAAAACGGTTACGAAAGGCTTTATCACACAGGTGACATTGTTCGCCTTACAGATGAGGGCAAGGTTGATTTTATCGGACGAAATGACGGTCAGGTTAAAATCAGAGGATTCCGCATTGAGCTTTCCGAGGTTGACAAGATTATCCGCAAATATGACGGCATTACAAACACAGCTGTAATCGCAAGAAAGCTTGATGGCGGCGGACAATGCATTAACGCATATATTGTTGCCGACAGAAAAATTGACATTCAAAAGCTCAACGAATTTATTCTTGAACACAAGCCGCCGTATATGGTACCCGCCGCTACAATGCAGATTGACAAAATTCCGCTCAATGTAAACGGCAAGGTTGACAAGCGCAAGCTTCCCGAAATCAAGGCAGAATCTTCAAAAAAGAAAAATTCCGCTCCGAGGGAACTAACATTCCTTGAAAAGAAAATTTCCGCAATTATCGAAAAGATTATCGGACACAGCGATTTTGATATTTCCGAAAATCTCATCAACGCAGGTATGACCTCGCTTTCGGTTATCAAGCTTGCAGTTGAACTCAACAAGGCATTCGGCTTTGAGGCACAGGTTAAAAAGATGATGAAGGGCTGTTCGCTTCTTTCGATTGAGGACGAACTTCAGGAGTTTATGTTCAGCGGTACGGCAAATCAGCAAACTGTCAAAAAAGAAGAAAAGAAAGAACATAAGGCTCTCTATCCTCTTTCAAAAACTCAGCTCGGCGTGTATATTGACTGTATGAAAAATCCGTACAGCACACTTTACAATATTCCGTCAATTCTCACATTTTCAAAATCAGTCGATGCACAAAAGCTTGCCGACTGCGTTGTAAAGGTAATCAAGGCTCACCCATATATTATGACTCACCTTTCACTTGAAAACGATGATATTGAGCAGGCATATGTTGACTCTGCAAAACCGAATGTTCCCGTTGAAAAGCTTACGGAAGAACAGCTTGAAGCCTACAAAAAGGATTTTGTAAAACCGCACAATCTTATGAAAGCGCCGCTGTTCAGAATCTCGGTTGCAGAAACCGAAAAGGCGGTATATCTGCTTTCGGATTTCCACCACCTTATCTTTGACGGTGCGTCCGTTGCACTCTTCTTTGAACAGCTTAAAACGCTGTATGAGGGAGGTAATATTGAGCCTGAAAGCTACACCTACTTTGATTATGCAGAGAATGAAATTAAGGCTGAAAGCAGTGATGAATTTAGAAATGCTGAAAAGTTCTTCGACAATATGATGAAAAATTTTGAATCTGCAAGCGAAATCACGGCTGACCTCAGAGGTCATGCAGAGGACGGTGCTCTTGCATCTCAGGCAGTCCCCGTTGATATGGCAAGGGTTGAAAACTTCTGTTCACAGCACGGAATCACTCCCGCCCACCTTTTCCTTGCCGGCACATTCTACGCTGTTTCAAGATTTGTAAACAGCAGAAATGTTTACATCAGCACAATCAGCAACGGCAGAAGCGATATGCGGCTTACAAACTGCTTTGGTATGTTTGTAAAAACTCTTGCGCTCGGCATTGAAATTGAGGACATCACCTCACTTGAATTTGTTGAAAAAAGCAAGGCTGTTTTCACGGATTCAATTGAAAATGAAATTTACCCCTACGCACAGCTTTGTGCAAAATACGGCTATGCACCGAACATTATGTACGAATATCAGCTTGGTGTTGTTGATAACCTTGAAATTGACGGCAAAGCCGTTGTCCGTGATTACCTTGAAATGAATACTGCAAAGTTCAAAACAGCCATTCACATTGAAGATTACAGGGGCAAGCCGAGCGTTGTGGTTCAGTACAATGACGCACTTTACAGCGGTGAGCTTATGAGAACGCTTGCAAAATCCGTTCTCTGTGCTGTTGAACATATTATCGAAAATCCAAACGGCAAAATCAGAAAGGTTTCACTCCTTGACAACGCCGCAATTGCTCAGCTTGAAAGCTTTAAGTCAACAGAAATTGCTCCCGTTAAGACAAAACTTCTTCACAAAATGTTTGAGGAGCAGGTTGCAAAAACTCCCGACAGAATTGCTCTTTCGGCTTGTGACGGCAAACTGACCTATAAAGAGCTTGACCGTCTTGCAAATATCACGGCAAACTCACTCATTGAAAAAGGTCTTGAAAAGGGCGGAAAGGTTCTTATTCTGCTTGAAAGAACCTCAAAATTCTTCATATCACTTTTCGGTATTCTCAAGGCAGGCGGTGCGTTTATTCCGTCATGTCCCGACTATCCGAAGGAGCGAATCGACAGTATTATTGAGGACAGTGACGCAGACTTTGTAATTACCGAGGGCGAACTGCTCAATAAATATGACCGCACGGTTGATGTTTCAAAACTTCTTTCAGGCAATAATGATGAAGACCCGAATGTTCATGTACAGCCTGACGACCTTGCGTACCTCATCTACACCTCGGGTTCAACAGGCAAGCCAAAGGGCGTTATGCTCCGCCACATTGGCATTGCAAACTACCTTGCATACAGCGACTCAAACATTCAGGTTAAAGAGGTTGTTGACAACTGTCACGCATACGGCTCTGTAACTACAATCAGCTTTGATATGTCGCTAAAGGAAACCATGCTGTCGCTCTGCAACGGTCTTACCCTCGTTTTTGCAAGTGATGAACAGGTGGTAAACCCGATGTTACTTGCAGAATTCTTTAAAGAAAACAATGTTGATGCGTTCAACTCTACACCGTCAAGACTTTTGCAGTATATGGAGCTTGACGAATTTGCAGAAGCAATGGCAAACTGCAAGGTTATTCTCTCGGGCGGTGAAAAATATCCCGACAAGCTATTAAGGATACTGCGTGAAAAAACGAACGCAACAATAATCAACACCTACGGTCCGACTGAAATCACGGTTTCTTCAAACGCAAAAAATCTTACGAATGCAGACGAAATTTCAATCGGCAGGCCGTTACGCAACTACACGGAATATATTGTTGACTCAGACAACAATCTCCTTCCAATCGGAGTTGTGGGTGAGCTTCTCATTCAGGGATACGGTGTGGCGCTCGGCTATAATAAACTTCCCGAACAAACTGCAAAGGCTTTCATCGAATTCAACGGTGAACGCACCTACCGTTCGGGTGACTACGCAAAATGGACTACAGACGGCGATGTTATTATTCTCGGCAGAACAGACAATCAGGTTAAGCTGAGAGGATTAAGAATTGAACTCGGCGAAATTGAAAAGTGTCTGACCGCAGTTGACGGAATCAAGAGCGGAATTGCTCTCATCAGAAAGGTCGGCAAGGCTGACGCAATCTGCGTTTACTACACAGCCGACAGACAGCTTGATCCCGATGAAATCAAGTCAGAGCTTGCAAAAACTCTCACAGATTATATGGTTCCGAGTGCGTATGTTCAGCTTGACGAAATGCCTCTCACACCAAACGGCAAGGTCAACACAAAGGTTCTTCCCGAACCTAAGAGCAACAAATCCGAAAGAGGTCGGTTGCCGAAGAATGAACTTGAAAAAACATTCTGCGACATCTTTGCAGAAATTCTTGAACTTGACAATGTTTTTGCAGACGATAACTTCTTTGACCTCGGCGGAACATCGCTTACAGCAACAAGAATTGTAATCTCCGCATCAAAGAAAAACATTGAGGTTGCATACAGCGACATATTTGCAAATCCTACTCCGCAGACTCTTGCAAAATTTGTGAGCAAGGATGATTCAGCCGAAGACGACCTTGAAAATCTTTCGGACTACGATTATACAAATATCAATAAAGTTCTTGAAAAGAATAATATTGATACATTTAAAAACGGTGAGCTTCAAAAACTCGGCAATGTTCTTCTGACAGGCTCTGCCGGCTTCCTCGGAGTACACATTCTCTACGAACTTCTTCACAAGTATAACGGCAAGGTTTACTGCATGATTCGTGACAAAAACAATAATCCTGCCGAAAACAGAATGAACTCAATCTACTATTACTACTTTGAAGAAAGTCTGAAAGAAAGATATCCCGACAGAGTTACCGTTATCAGCGGTGATGTTACAAACCGTGAATCATTCGATAAATTTATTGACGAGGACATTAACACGGTCATCAACTGTGCCGCAAATGTTAAGCACTTCTCAAAGGGTACAGACATTGAAGATGTAAACCTTTACGGTACTCTCAATGTGCTTGACTTCTGCAAAAAGGCTAATGCAAGGCTTGTTCATGTGTCAACAATGAGCGTTGGCGGTATGTTTGTGGGCGAACAAGGTTCTGTTGACAAGCTCAAAGAAAATCAACTTTACTTTGGTCAGCATGAGGGTTCAAAGTACACCCTGTCAAAGTTCCTTGCGGAAAGGGCGATTCTTGAAGAGGTTTCAAAGGGCTTTAACGCAAAGATTATGCGTGTAGGCACACTTGCCGCAAGAAACAGCGACGGTGAATATCAGATTAATTTCACCACCAACACATTTATGGGCAGACTCAAATCTACGCTTCTTATCGGCAAATATCCGTATGAGGCAATGGAAATGCCGTTTGAGCTTTCTCCGATTGATTTTGTGGCAAAGGCAATTCTTCTGCTTGCACAGGCTCCGAAGGATTGTACCGTGTTCCACCCGTTCAACAACCATACTCTCATTATGGGCGACCTCTATACCGAGATGAACAAAATCGGACTTCATTCACAGGGTGCAGAATATGAGGAATATATGATTGCACTTGACAGAGCCGAGCAGGATCCCGAAAAAGCAAAGATTCTTTCAAGTATGATTGCATATCAGAACATGGCTCACGGTCAAAAGACATTTACAGTCGGCAAGAGCAACACATATACAATGCAGGTTCTTTACAGAATGGGATTTGTGTGGCCCGTTACCTCGCTTGACTATATGAAACGATTCATCAACGCATTAAGAGGTCTTGGTTTCTTCGATTAA",
      "translation": "MSNLINLLDTYKGEKRELYPLTPSQMGVYLSCMHNPKGTMYNIPCTYVFDKGSLDTDRLINAVRKAVDNHPVMKIFIDSSTGSPMMKPRDSVDFDIPVVQVDNLEQAGKDFVKPFDLEKDILFRFAIFECGDKSMFAMDFHHIISDGTSVSVICNDIALAYDGKELEPEKFSQLDLSVFEEKLEETEEYQKSKNYYDSIFSAVESKSEITEDFAENSEVEDKPNGSFELSTNGKFSVEEVRNFALANQITPYTVFLGAYEYAVAKFTNQSETTVCTVTHGRFNKQLKNTVGMMVRTLPIHANIDEEDTVSDYLKKIRRNIKETVANDWFPFMKLASDYDLSADIMLAYQADIFNTFKIGGQALKLKLVPLKSAISKLNVMVFESETDFELRFEYRNDLFKEETIRSFADSFLKIVEQFLKKSKLCEVELVNENQLAELDNFNKTEFPFDDSKTVVDLFEEQCKKTPDKTAVVYKEKKFTYAEIDEITNRIAGYVHSKGIGKEEVVSILIPRCEYMPIASIGVLKSGAAYQPLDPSYPPERLQFMIKDANAKLLIADENLLELLPDYSGDILLTKDIPNLPKSDAVFTKPSPDDLFILIYTSGSTGTPKGAMLEHKNVRSFCDFHIRNSDIDEHSVVSAYASYGFDACLSEMYPALIGGAELHIIEEDIRLDLVRLNRYFEDNGITHAFMTTQVARQFATEIDNHSLKYLLTGGERLVPLEPPKNFELINGYGPTECTVYITTQPVDKLYHRIPVGKALDNIKLYVTDKYGRRLPTGALGELCVSGQQVSRGYLNRPEQTAKAYEKNPYCNKNGYERLYHTGDIVRLTDEGKVDFIGRNDGQVKIRGFRIELSEVDKIIRKYDGITNTAVIARKLDGGGQCINAYIVADRKIDIQKLNEFILEHKPPYMVPAATMQIDKIPLNVNGKVDKRKLPEIKAESSKKKNSAPRELTFLEKKISAIIEKIIGHSDFDISENLINAGMTSLSVIKLAVELNKAFGFEAQVKKMMKGCSLLSIEDELQEFMFSGTANQQTVKKEEKKEHKALYPLSKTQLGVYIDCMKNPYSTLYNIPSILTFSKSVDAQKLADCVVKVIKAHPYIMTHLSLENDDIEQAYVDSAKPNVPVEKLTEEQLEAYKKDFVKPHNLMKAPLFRISVAETEKAVYLLSDFHHLIFDGASVALFFEQLKTLYEGGNIEPESYTYFDYAENEIKAESSDEFRNAEKFFDNMMKNFESASEITADLRGHAEDGALASQAVPVDMARVENFCSQHGITPAHLFLAGTFYAVSRFVNSRNVYISTISNGRSDMRLTNCFGMFVKTLALGIEIEDITSLEFVEKSKAVFTDSIENEIYPYAQLCAKYGYAPNIMYEYQLGVVDNLEIDGKAVVRDYLEMNTAKFKTAIHIEDYRGKPSVVVQYNDALYSGELMRTLAKSVLCAVEHIIENPNGKIRKVSLLDNAAIAQLESFKSTEIAPVKTKLLHKMFEEQVAKTPDRIALSACDGKLTYKELDRLANITANSLIEKGLEKGGKVLILLERTSKFFISLFGILKAGGAFIPSCPDYPKERIDSIIEDSDADFVITEGELLNKYDRTVDVSKLLSGNNDEDPNVHVQPDDLAYLIYTSGSTGKPKGVMLRHIGIANYLAYSDSNIQVKEVVDNCHAYGSVTTISFDMSLKETMLSLCNGLTLVFASDEQVVNPMLLAEFFKENNVDAFNSTPSRLLQYMELDEFAEAMANCKVILSGGEKYPDKLLRILREKTNATIINTYGPTEITVSSNAKNLTNADEISIGRPLRNYTEYIVDSDNNLLPIGVVGELLIQGYGVALGYNKLPEQTAKAFIEFNGERTYRSGDYAKWTTDGDVIILGRTDNQVKLRGLRIELGEIEKCLTAVDGIKSGIALIRKVGKADAICVYYTADRQLDPDEIKSELAKTLTDYMVPSAYVQLDEMPLTPNGKVNTKVLPEPKSNKSERGRLPKNELEKTFCDIFAEILELDNVFADDNFFDLGGTSLTATRIVISASKKNIEVAYSDIFANPTPQTLAKFVSKDDSAEDDLENLSDYDYTNINKVLEKNNIDTFKNGELQKLGNVLLTGSAGFLGVHILYELLHKYNGKVYCMIRDKNNNPAENRMNSIYYYYFEESLKERYPDRVTVISGDVTNRESFDKFIDEDINTVINCAANVKHFSKGTDIEDVNLYGTLNVLDFCKKANARLVHVSTMSVGGMFVGEQGSVDKLKENQLYFGQHEGSKYTLSKFLAERAILEEVSKGFNAKIMRVGTLAARNSDGEYQINFTTNTFMGRLKSTLLIGKYPYEAMEMPFELSPIDFVAKAILLLAQAPKDCTVFHPFNNHTLIMGDLYTEMNKIGLHSQGAEYEEYMIALDRAEQDPEKAKILSSMIAYQNMAHGQKTFTVGKSNTYTMQVLYRMGFVWPVTSLDYMKRFINALRGLGFFD",
      "product": ""
     },
     {
      "start": 9552,
      "end": 11312,
      "strand": -1,
      "locus_tag": "ctg49_4",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,552 - 11,312,\n (total: 1761 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1086:MATE efflux family protein (Score: 291.1; E-value: 2.1e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSSTVLGRNAVTVNKKYTEYFLPTVLTAMATNIAMIVDSIIAGNLLGQNSLAAINLMSPISQFYFSITILFGLGASSIISFAKGRRDEKQANRVFTSTFIVLIALSVIFIAIQLPLADSISSLLTKDAELKSLLYQYYVPFIIGTPIYLLLMCSIHFVRADARPAFASNIVIVANAVNLGLDFLFMGAFKMGIAGSSIATVTGYAVGFVMMSTHFIMKKSTLHFDFSILRNPVQFFKFLGKMVTIGLSGALGTMLITVKMLFLNTIIQSIGGSAGMVSYSVCSSSQIFMSMFITGASQTMIPIIGVCLGEKDYDGVRYAFRRAARVLAVSSVVIMLFICIEPEPIIKFFGITSPTDIANTVPAMRINALSFPGLSFSFLLLYYYMATQKRAISTAISIINGIVILIPSALILGKFFGITGVWYSLVVAQVGTLVVVYFIDLAEKRKSGGKYKNFYLLEETEDNELLALSFKGTKENAAGVSLYLSSFLSKNGIEESRANRIAVAVEEMAASCAERMEGKKKFADIDIRIFADKNETIISVRDNGDEFDPLNDDKEFEMSPLTVVKAISDKVEYSRVLGFNRTIIKL\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAGTACCGTACTTGGCAGAAATGCCGTTACCGTCAACAAAAAATACACGGAATATTTTCTTCCGACAGTTCTGACGGCTATGGCAACAAACATTGCGATGATTGTGGACTCAATTATTGCAGGCAATCTTCTGGGGCAAAACTCACTTGCGGCAATCAACCTTATGTCCCCTATTTCGCAGTTTTATTTTTCGATTACTATTCTTTTCGGACTCGGTGCATCCTCGATAATTTCATTTGCAAAGGGCAGGCGTGACGAAAAGCAGGCTAACCGTGTTTTCACTTCAACATTTATCGTACTTATCGCACTCAGCGTAATTTTTATTGCAATTCAGCTGCCGCTTGCCGACTCGATAAGCTCGTTGCTTACAAAGGACGCAGAGCTTAAATCGCTGTTGTATCAATACTATGTTCCGTTCATAATCGGCACACCGATTTACCTTTTGCTCATGTGTTCAATTCACTTTGTAAGAGCAGACGCAAGACCTGCGTTTGCATCAAACATTGTAATTGTGGCAAATGCCGTAAATCTCGGACTTGACTTTCTGTTTATGGGTGCTTTCAAAATGGGCATTGCAGGCTCGTCAATTGCGACCGTAACAGGCTATGCGGTAGGGTTTGTGATGATGTCAACACACTTCATCATGAAGAAAAGCACATTGCACTTTGACTTTTCAATTCTCAGAAATCCCGTTCAATTCTTTAAATTTCTCGGAAAAATGGTTACAATCGGACTTTCGGGAGCATTAGGTACAATGCTGATAACAGTTAAAATGCTGTTTTTAAACACAATTATTCAGAGCATAGGCGGAAGTGCGGGTATGGTTTCATATTCGGTATGCTCGTCAAGCCAAATTTTTATGTCAATGTTCATCACGGGTGCAAGTCAGACAATGATTCCGATTATCGGGGTTTGTCTTGGTGAAAAGGACTATGACGGTGTGCGCTATGCATTCCGCAGAGCCGCAAGGGTGCTTGCTGTTTCAAGCGTTGTAATTATGCTTTTCATCTGTATCGAGCCTGAACCGATAATTAAATTTTTCGGAATTACTTCACCCACAGACATTGCAAACACAGTTCCGGCAATGAGAATCAACGCACTGTCATTCCCCGGACTTTCATTCTCGTTTTTGTTGCTTTACTACTATATGGCAACGCAGAAAAGGGCTATTTCTACTGCAATTTCAATCATCAACGGAATCGTCATACTCATTCCGTCAGCTTTAATTCTCGGCAAATTTTTCGGCATCACAGGTGTATGGTATTCACTCGTGGTTGCACAGGTGGGAACACTTGTAGTTGTGTATTTTATTGACCTTGCCGAAAAGAGAAAATCGGGCGGAAAGTATAAAAACTTTTACCTTCTTGAAGAAACCGAGGACAACGAGCTTCTTGCCCTTTCGTTCAAAGGAACAAAAGAAAATGCGGCAGGCGTTTCGCTCTACCTTTCCTCTTTTCTTTCAAAAAACGGAATTGAAGAAAGCCGTGCAAACAGGATTGCAGTTGCCGTTGAAGAAATGGCTGCAAGCTGTGCCGAAAGAATGGAAGGCAAAAAGAAATTTGCAGACATCGACATCAGAATTTTTGCCGATAAAAACGAAACAATAATTTCCGTTCGTGACAACGGTGACGAATTTGATCCGCTCAATGACGATAAGGAATTTGAGATGAGTCCTCTCACAGTTGTGAAGGCGATTTCGGATAAGGTTGAATATTCAAGAGTGCTTGGTTTCAACCGCACAATAATTAAACTTTAA",
      "translation": "MSSTVLGRNAVTVNKKYTEYFLPTVLTAMATNIAMIVDSIIAGNLLGQNSLAAINLMSPISQFYFSITILFGLGASSIISFAKGRRDEKQANRVFTSTFIVLIALSVIFIAIQLPLADSISSLLTKDAELKSLLYQYYVPFIIGTPIYLLLMCSIHFVRADARPAFASNIVIVANAVNLGLDFLFMGAFKMGIAGSSIATVTGYAVGFVMMSTHFIMKKSTLHFDFSILRNPVQFFKFLGKMVTIGLSGALGTMLITVKMLFLNTIIQSIGGSAGMVSYSVCSSSQIFMSMFITGASQTMIPIIGVCLGEKDYDGVRYAFRRAARVLAVSSVVIMLFICIEPEPIIKFFGITSPTDIANTVPAMRINALSFPGLSFSFLLLYYYMATQKRAISTAISIINGIVILIPSALILGKFFGITGVWYSLVVAQVGTLVVVYFIDLAEKRKSGGKYKNFYLLEETEDNELLALSFKGTKENAAGVSLYLSSFLSKNGIEESRANRIAVAVEEMAASCAERMEGKKKFADIDIRIFADKNETIISVRDNGDEFDPLNDDKEFEMSPLTVVKAISDKVEYSRVLGFNRTIIKL",
      "product": ""
     },
     {
      "start": 11322,
      "end": 11630,
      "strand": -1,
      "locus_tag": "ctg49_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,322 - 11,630,\n (total: 309 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAATCAATAAGGCTATAAGCAATCAGAATGTTATTATCACACTCAAGGGCCGTCTTGACACAATGACAGCACCGCAGCTTGATGACGAGGCAAAGAGCATTGATTTTGACGAGGTTGAAACCGTAACTCTCAACCTTAAAGACCTTGAGTACATTTCAAGCTTGGGACTGAGGGTTATTCTTGCACTTTATAAAAGCCTAAAAAGCAAAGGCGGAAATCTTAAAATTGTCAATGTAAGCAACACAATTATGGAGCTGTTCTCAATGACAGGGATGGCTGACTACCTTGACATTGAGCAGGGATAA",
      "translation": "MKINKAISNQNVIITLKGRLDTMTAPQLDDEAKSIDFDEVETVTLNLKDLEYISSLGLRVILALYKSLKSKGGNLKIVNVSNTIMELFSMTGMADYLDIEQG",
      "product": ""
     },
     {
      "start": 11797,
      "end": 12195,
      "strand": -1,
      "locus_tag": "ctg49_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,797 - 12,195,\n (total: 399 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAATCGTTTGCGTTGATGCCGTTAAGGAAAATCTGCCGAATGTTATAGAATTTGTGACAAAAATGCTTGGTGAAAATGCAGACGGTAAGCTTGTTTTTGAGCTTGAACTGATTTGCGAGGAAGTGTTTGTAAACATCTGCAACTATGCTTACGGTGAAAATGTCGGCAAGACTGAAATTGAAGTTAGCAAATTTTCAGACTGCATTGTTGTAAAATTCATTGACAGAGGAAAAAAATTCAATCCGCTTGAAATTGCAGAGCCGAACATTCACGCTCCGCTTGAGGAACGAAGCATCGGCGGTCTGGGAATTTTCATGACAAAGAAACTTTCCGACACTCTTTTCTATGAAAGATCTAACGGCAAAAACATTTTTACAATTACAAAGAATTTCTAA",
      "translation": "MPIVCVDAVKENLPNVIEFVTKMLGENADGKLVFELELICEEVFVNICNYAYGENVGKTEIEVSKFSDCIVVKFIDRGKKFNPLEIAEPNIHAPLEERSIGGLGIFMTKKLSDTLFYERSNGKNIFTITKNF",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 2201,
      "end": 9533,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 12420,
      "product": "NRPS",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS",
    "products": [
     "NRPS"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS",
    "anchor": "r49c1"
   }
  ]
 },
 {
  "length": 12108,
  "seq_id": "NZ_WHCC01000054.1",
  "regions": []
 },
 {
  "length": 12060,
  "seq_id": "NZ_WHCC01000055.1",
  "regions": []
 },
 {
  "length": 11831,
  "seq_id": "NZ_WHCC01000056.1",
  "regions": []
 },
 {
  "length": 11745,
  "seq_id": "NZ_WHCC01000057.1",
  "regions": []
 },
 {
  "length": 11435,
  "seq_id": "NZ_WHCC01000058.1",
  "regions": []
 },
 {
  "length": 10386,
  "seq_id": "NZ_WHCC01000059.1",
  "regions": []
 },
 {
  "length": 66000,
  "seq_id": "NZ_WHCC01000006.1",
  "regions": []
 },
 {
  "length": 9852,
  "seq_id": "NZ_WHCC01000060.1",
  "regions": []
 },
 {
  "length": 9658,
  "seq_id": "NZ_WHCC01000061.1",
  "regions": []
 },
 {
  "length": 9383,
  "seq_id": "NZ_WHCC01000062.1",
  "regions": []
 },
 {
  "length": 9044,
  "seq_id": "NZ_WHCC01000063.1",
  "regions": []
 },
 {
  "length": 8475,
  "seq_id": "NZ_WHCC01000064.1",
  "regions": []
 },
 {
  "length": 7805,
  "seq_id": "NZ_WHCC01000065.1",
  "regions": []
 },
 {
  "length": 7147,
  "seq_id": "NZ_WHCC01000066.1",
  "regions": []
 },
 {
  "length": 6333,
  "seq_id": "NZ_WHCC01000067.1",
  "regions": []
 },
 {
  "length": 5058,
  "seq_id": "NZ_WHCC01000068.1",
  "regions": []
 },
 {
  "length": 4457,
  "seq_id": "NZ_WHCC01000069.1",
  "regions": []
 },
 {
  "length": 59925,
  "seq_id": "NZ_WHCC01000007.1",
  "regions": [
   {
    "start": 10441,
    "end": 52639,
    "idx": 1,
    "orfs": [
     {
      "start": 11048,
      "end": 11302,
      "strand": -1,
      "locus_tag": "ctg67_11",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,048 - 11,302,\n (total: 255 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1058:ArsR family transcriptional regulator (Score: 66.6; E-value: 2.3e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTCACTGAACGGTACACTTAAAGCACTTTCAGATCCGATAAGAAGAAATATTCTGACAATGCTGAAAGGCAAAAAAATGATTGCAGGCGACATTGCCGAAGAACTTGGAATTTCACCTGCATCGCTTTCATATCACCTCAATCTGTTGAAGAAAAACGACCTGGTGATTGAATCAAAAGAAAAAAATTATGTTTATTATGAGCTTAACACAACCCTGTTTGACGAACTCATAATGTGGCTTAAACAATTTTAG",
      "translation": "MSLNGTLKALSDPIRRNILTMLKGKKMIAGDIAEELGISPASLSYHLNLLKKNDLVIESKEKNYVYYELNTTLFDELIMWLKQF",
      "product": ""
     },
     {
      "start": 11519,
      "end": 11680,
      "strand": 1,
      "locus_tag": "ctg67_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,519 - 11,680,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAATAAATCATGTGGACTTCCCTTGCGGGTACCGAAAGCCTTTACTCGGGAGGATGTGCTTACCTCCCGACAGGGTGTTTCAAAATCAGTTGAAAGTATTAATACAGTAATTAACGATACAGCAGTCGGTACGGACGCTTTCAATGTTAAAAAAGATTGA",
      "translation": "MNKSCGLPLRVPKAFTREDVLTSRQGVSKSVESINTVINDTAVGTDAFNVKKD",
      "product": ""
     },
     {
      "start": 12245,
      "end": 13609,
      "strand": 1,
      "locus_tag": "ctg67_13",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,245 - 13,609,\n (total: 1365 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1086:MATE efflux family protein (Score: 359.7; E-value: 3.2e-109)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNGSKSVRNLTQGKISSQILFFAIPVIIGNLLQELYNVVDTLIVGQTLGEIKLAAVGSTSSLNFFALGFFIGLSAGCSVITSQHFGANDMERVKKSVAAHIIIGVVSAVVLTVSFVLLVNPLLTMLGTTSDTFEYASRYLTIIYLGIPATMLYNLTASLLRSVGDSKTPLYLLLFSSVMNVGLDLLFIIVFRWDVSGAAIATVISQLVSAVLCCVYIFFKVKMLLPNKNSFKNLTSTVRDELKVGFPMGLQNSVISIGMMVLQYFVNQFGSYAVAAYTIGNRVQLLIQNPMNSMSTVIATFAGQNEGAGRYDRIKKGVNFCLLICIVYSIVIGAVSMIFAQPITGIFTSGSSQQTIDYSVQFMFWNCPFEWSLAMLFIYRGTIQGLKNGIVPMIGSLIEVVMRIMTPVIFSSVIGYASICVAGPAAWTGSMLLMIAVYYVKIRKLSKTKTVVAN\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATGGTTCAAAATCTGTTAGAAATCTGACTCAGGGAAAAATTTCAAGTCAGATTTTATTTTTTGCAATTCCCGTAATAATCGGCAACCTTTTACAGGAGCTTTACAATGTTGTCGATACGCTGATTGTCGGTCAGACTCTCGGTGAAATCAAGCTTGCGGCTGTCGGTTCAACGAGTTCGCTCAACTTTTTTGCACTCGGATTTTTCATAGGACTTTCCGCCGGCTGTTCGGTAATCACTTCACAGCATTTCGGTGCAAACGATATGGAACGGGTGAAAAAGAGCGTTGCCGCCCACATAATAATTGGCGTTGTGTCGGCTGTTGTGCTTACTGTTTCGTTTGTACTTCTTGTTAATCCGCTGCTTACAATGCTCGGAACAACCTCGGATACATTCGAGTACGCAAGCAGATATCTTACAATAATTTACCTCGGAATCCCCGCAACCATGCTCTACAACCTTACGGCATCACTTCTGCGTTCGGTTGGTGACAGCAAAACTCCGCTTTATCTGTTGCTCTTTTCATCCGTAATGAATGTGGGACTTGACCTGTTATTTATCATAGTGTTCAGGTGGGATGTTTCGGGTGCGGCAATTGCAACGGTAATCTCTCAGCTTGTGTCGGCAGTTCTCTGTTGCGTGTACATTTTTTTTAAGGTGAAAATGCTCTTGCCGAACAAAAACAGCTTTAAAAATTTGACTTCAACTGTACGGGACGAGCTAAAAGTCGGTTTCCCGATGGGACTTCAAAACTCAGTAATTTCAATCGGCATGATGGTTTTGCAGTATTTCGTAAATCAGTTCGGTTCATATGCCGTTGCCGCCTACACAATCGGCAACCGTGTTCAGCTTCTCATCCAGAATCCGATGAACTCAATGAGTACGGTTATCGCAACATTTGCAGGTCAGAACGAGGGCGCAGGAAGATATGACAGAATCAAAAAAGGCGTCAATTTCTGCCTGTTAATTTGCATTGTATATTCAATTGTAATCGGTGCGGTTTCAATGATTTTTGCTCAGCCGATAACAGGAATCTTCACAAGCGGAAGCTCACAGCAGACTATTGATTATTCCGTTCAGTTTATGTTCTGGAACTGCCCGTTTGAGTGGTCGCTTGCAATGCTGTTTATATACCGTGGAACAATTCAGGGACTTAAAAACGGCATTGTGCCTATGATTGGTTCGCTTATCGAAGTTGTTATGCGAATTATGACGCCCGTCATTTTCAGTTCTGTAATAGGTTACGCATCAATCTGTGTTGCCGGTCCTGCCGCATGGACAGGAAGTATGCTCCTTATGATTGCGGTTTATTATGTTAAAATAAGAAAACTTTCAAAGACGAAAACTGTTGTGGCAAATTAA",
      "translation": "MNGSKSVRNLTQGKISSQILFFAIPVIIGNLLQELYNVVDTLIVGQTLGEIKLAAVGSTSSLNFFALGFFIGLSAGCSVITSQHFGANDMERVKKSVAAHIIIGVVSAVVLTVSFVLLVNPLLTMLGTTSDTFEYASRYLTIIYLGIPATMLYNLTASLLRSVGDSKTPLYLLLFSSVMNVGLDLLFIIVFRWDVSGAAIATVISQLVSAVLCCVYIFFKVKMLLPNKNSFKNLTSTVRDELKVGFPMGLQNSVISIGMMVLQYFVNQFGSYAVAAYTIGNRVQLLIQNPMNSMSTVIATFAGQNEGAGRYDRIKKGVNFCLLICIVYSIVIGAVSMIFAQPITGIFTSGSSQQTIDYSVQFMFWNCPFEWSLAMLFIYRGTIQGLKNGIVPMIGSLIEVVMRIMTPVIFSSVIGYASICVAGPAAWTGSMLLMIAVYYVKIRKLSKTKTVVAN",
      "product": ""
     },
     {
      "start": 13662,
      "end": 14228,
      "strand": 1,
      "locus_tag": "ctg67_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,662 - 14,228,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTTGCTTTAAAAAAGTCACAAAACAACTTGATGATTATAAATCTGTAAAAGAATTATACCTTTCCGCATTTCCGTCCGTTGAGAGAGTACCGTTTTGGCTTTTGATGAAAAAATCAAAGAATGACGGTGCAGATTTCTACGCAATTTATGATGAAGAAAAGTGGATTGGACTTATCTATGCAATCACGGACGGCGAAGTTGTCTATGTGTACTACTATGCAATTTCCGAAAAGGAGAGGGGACACGGAATCGGAGTTGCCGTGCTTGATGAATTTAAAAATTTGTATAAGGGCAAAAAGATTTTCCTTGCAATTGAACAGCTTGAAGAAGAAAATGCTCCCAATCAAAAACAGCGAATGAGCCGTTATAAATTCTATCAGCGTTGCGGATTTTTAAGGCTGAATGCAAAGATTGTTGAGGCGAAAATAACATTTGATGTTATGGCATACGGCGGTGAAGTCAATCCCGAAAGCTATAACAAAATGATGAAAAAATATCTCGGCAAAATTATATCGCCCTTCATCAAAACAGAAATGAAGGGCAGCGGTAAATATTTTGAATAA",
      "translation": "MICFKKVTKQLDDYKSVKELYLSAFPSVERVPFWLLMKKSKNDGADFYAIYDEEKWIGLIYAITDGEVVYVYYYAISEKERGHGIGVAVLDEFKNLYKGKKIFLAIEQLEEENAPNQKQRMSRYKFYQRCGFLRLNAKIVEAKITFDVMAYGGEVNPESYNKMMKKYLGKIISPFIKTEMKGSGKYFE",
      "product": ""
     },
     {
      "start": 14291,
      "end": 15394,
      "strand": -1,
      "locus_tag": "ctg67_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,291 - 15,394,\n (total: 1104 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAAAACCAAACGACAGTCCGGTATTGAGTTACTGCGAATTATTGCAATGATACAGATAATTTTTTTGCATGCGTATCAGTACGGATTACTTCATGACGCATCAAAGGCCGCAGGCGATATTGACGGTATATTGGTGACATTTGTATGGTCATTCTGCAGAACACCTGTTGATGTGTTTATTATGATAAGCGGCTACTTTATGATAACCTCGCAGTTTGATATAAAAAAGACCATACGGCGTGGCGGAAAAATCTACGGTGCAATGATTTTTTACTCGATTATACTTTCGATAATTTTCTTCATAAGCGATCCGTCGCTCATAAATATAAATTCAGTTATAAAGGCGTTCACTCCGCTAATGTCACGAACTTGGTATTTTCTGAGCAATTATTTGATTATTCTTCTGCTCAGCCCATTTCTCAACAAAATGCTTGCGTCACTTTCTAAAAAACATTACCTCTACTTTATGGGAATTGTTTTTGTGGCAGTAAGTCTATGGTCAACGCTTGCGGAAATTCACGGAATAAACAATGTGATCAGCGTCAACAAAATACTTGATCCTTATATGGGCAAGAGTCTTGGCGGATTCCTTTTGATGTACATAATCGGCGGTTATCTGAGGTTGTTTGTAAAGCAGAAACCGCTTGAGGAAAGAAAACCGAATTTCCGCTATCTCGGCATTTTCGTCGGCCTTTGCGTATTAGATTTTGTATTGGCATCTGTTTTTCCACAGTACAAGCCGGCATTCGGTATGTTCAACAACCCGATTGTCCTCGCCGAATCGGCGATGTTGGTTCTCTTTTTCAGAGATTTCAATTTCAGCTCAAAATTTGTCAATACAGTAGCCGGCACAACGCTCGGTATATATGCAATCCACGAAAATCCGTATGTTCGTGATTGTCTGTGGAATGTTGCAAACTTCAGCAATAAGCACCTCTATGACACCCTGATTTACATTCCGATTGTATTTATAACAATCCTCCTCATATTCGCAGGCTGTTGCGTAATTGAGCTTTTAAGACTTAAACTCTTCGAATTTGTCGGCAATAAAATAAACGCCCGCAAATCCATAACATCCGGCAACCGCTGTACAAAATAA",
      "translation": "MSKTKRQSGIELLRIIAMIQIIFLHAYQYGLLHDASKAAGDIDGILVTFVWSFCRTPVDVFIMISGYFMITSQFDIKKTIRRGGKIYGAMIFYSIILSIIFFISDPSLININSVIKAFTPLMSRTWYFLSNYLIILLLSPFLNKMLASLSKKHYLYFMGIVFVAVSLWSTLAEIHGINNVISVNKILDPYMGKSLGGFLLMYIIGGYLRLFVKQKPLEERKPNFRYLGIFVGLCVLDFVLASVFPQYKPAFGMFNNPIVLAESAMLVLFFRDFNFSSKFVNTVAGTTLGIYAIHENPYVRDCLWNVANFSNKHLYDTLIYIPIVFITILLIFAGCCVIELLRLKLFEFVGNKINARKSITSGNRCTK",
      "product": ""
     },
     {
      "start": 15698,
      "end": 18412,
      "strand": -1,
      "locus_tag": "ctg67_16",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,698 - 18,412,\n (total: 2715 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGGTATAATTGTTTCTGTTATTGTCCCCTTTCTTGAGAGCAATAACAAATTAATAGATACTCTGTCATCAATATCCGAGCAAAAGAATATTAATCAAGAGAACATTGAAGTGCTTATTGTTGACGCAACAGACAAAACTTCAGGCAAAATTGCAAACGGCAATATGTCAATGTGCAAGGTGATTTATGCAAAGTCGGTTAAAAGCTTTGCCGATGCCTGCAACCTTGCTGCGTCAAAAGCAACAGGCAAATATATCACGGTGTGCAATTGCGGCGACACTTTCAGCTATAACTATTTTGAAAGCTGCATTAAGGTGTTCAATAAAAAGGAAAAAATTCCTTTTGTTGCCGGTCACAGATTTTGCGTAAACCCTGTTTTCAGAGAGAAAAAGGAATTCAGACTTAACAAAGGGCAGCTTGAATCAAGCGTTGTCAACCTTTTTGATAATCCCAACCTCATCAATCTTGAGCTTACGGGTACTTTTTACAGAACTGAAATTTTCAAATCATACAAAATGAACAACAAGCTCAAGTACGAAAGTGCAGACGATTTTGCACTCAGAATTCAGCTTGATTATCCGGAGTATGTATATCTTGATGAGATTGAATTTGACTACTTTATGCCTGTAAGCGATGACTTTATGTACTATGTTCCCACAAACTACAAGGACTGGTACACAGATTCGCTTAACAACTTCTTAAAGCCTCTCATCAATGACAGCAAGGACAGGGACGGAAATATTCCGCTGTTTATTCAGTTCTATATTGTTTTCAATATTACAACAAAGTTCCTCGCAAATATGAACAACCGCAACAAGCGTAATATGAACGATGAAGAGCTTGCGGTTTTCTTTGAAACAGCAAGAGAATGTTTTAAGTTTGCAAATGACGGTTTTGTTCTTAACAAAGACAAGTATGTTTCTCTCGGCTACAGCGAGGAAGCCGCCGAGATGTTCTATATGATAAAGCACAATTGTGTTTTCAAGGATATGCCTTTTGAATATTCCGAGGGCAAAAAAGAGGTTTACCTCAACTGCAACAATGTCTATATTTCTAAGCTTACAGACCAGAGAGTCGGTATGCATGTTATGGACTACCGCGACGGCAAGCTTGTTATTGACGGCTCGTTCAGACAGGTTTTTGACCTTGAAGATTTTGAGCTTTATGTTCAGTTTGGCGACAAAAAACAGGTTCTTACAAACACAGACCGTTATTCTCTGACAAAATATTTCGGCATCAGTGCGTACAAGAAATTCACCTTCCACCTTGAGCTTGAGCTTGATCCCGAAAAGCCTCAGCAAACGGTTGCATTCTTTGCAAGATACAAGGATTCAATTATTCCGCTCAAGCTTTCATTCCTGCACCATTGGTCTAAGTTTACAATCAAGCCAAAGAACTCCTACTGGAGATTCAACAAGTATGTTGCCTATATTGACAACTCAAGCACAATTGTAATCTGTCACGCATCTGCTATGGATACATTCAAGAGAGAACTCAAGTTTCTCCCATATGTTTTCATGGAGAGTAAACGCAGCTTCATTACAAGAATTCAGTATTGGCTTACAAGACCTTTCTTCAAGAACAAGAAAATCTGGCTCATGTACGATAAGCTGTACAAGGGCGGTGACAGCTGTGAATATCTTTACAGATATTGTGCAGACAAAAAGGACGGCATTTCAAGATACTATATCATTGATAAAAACACTTCCGATTACAAGCGACTAAAGGCTGACGGACTCAAGCCTGTCAAGAACCGTTCATTCAAGCACAAAATGCTGTTTCTCAATACCGATATTGCGCTCATTACAAACTCAAATGTATTCCCGTTCAACGGCTACAGTATGGATCGTTCAAGATTCATCAGAGGTTTGTGCAACTTCCCTTCAATGTGCTTACAGCACGGACTTTCGGTTCAAAAGTGCGCAATGGCTCAGCAGAGAATTGTTGACAACACACAGATGTACTTCCTTGCGTCAAAGTATGAGTACAAAAACCTGAGCAACCATGTTTACAACTATCAGGATTTTGATATTCTCAAGATGACAGGCATCGGCAGATATGACGGACTTATCAATAACGATAAAAAGCAGATTCTGCTTTCACCCACCTGGCGTATGTACAATGCAATGCCTGTTACAACAAGCGAGGGTGAACAGAGAGCTTACAATCCCGAATTCAAGCACACAACCTATTATAAAATCTACAACGACCTTATCAATAATAAAAAGTTGATTGATACGGCAAAGCGTACAGGCTATAAGATTAAGTATGTTCTTCATCCGATTTTAAGCTCACAGGTTAACGACTTTATCCCCGATCCGTATGTTGAGGTTGTTTCATCGGTTGGCGATTTCAACTACGAAACAGCTTTTCAGGAGTCAAGCCTTATGGTAACAGACTATTCGGGCGTTCAGTTTGACTTTGCTTATATGAAGAAACCGCTTGTATATTTCCATCCGTCACAGCTTCCTGCACACTATGATGACGGCGGATTCTTCTATGATACAATGGGATTCGGAGAAATTTGTACCGAAAGCGACCAGCTTGTTGACCTGCTCTGCGAGTATATGGAAAACGGCTGTAAAATGAAGCCAAAGTATGTTGAAAGAGTTGAAGATTTCTATCAGTTTGACGATCACAACAACTGTGAAAGAATTTACAACGAAATCATCAAGTATCAGCAACAGGTTAACAAAGACAAATTAAAATAA",
      "translation": "MSGIIVSVIVPFLESNNKLIDTLSSISEQKNINQENIEVLIVDATDKTSGKIANGNMSMCKVIYAKSVKSFADACNLAASKATGKYITVCNCGDTFSYNYFESCIKVFNKKEKIPFVAGHRFCVNPVFREKKEFRLNKGQLESSVVNLFDNPNLINLELTGTFYRTEIFKSYKMNNKLKYESADDFALRIQLDYPEYVYLDEIEFDYFMPVSDDFMYYVPTNYKDWYTDSLNNFLKPLINDSKDRDGNIPLFIQFYIVFNITTKFLANMNNRNKRNMNDEELAVFFETARECFKFANDGFVLNKDKYVSLGYSEEAAEMFYMIKHNCVFKDMPFEYSEGKKEVYLNCNNVYISKLTDQRVGMHVMDYRDGKLVIDGSFRQVFDLEDFELYVQFGDKKQVLTNTDRYSLTKYFGISAYKKFTFHLELELDPEKPQQTVAFFARYKDSIIPLKLSFLHHWSKFTIKPKNSYWRFNKYVAYIDNSSTIVICHASAMDTFKRELKFLPYVFMESKRSFITRIQYWLTRPFFKNKKIWLMYDKLYKGGDSCEYLYRYCADKKDGISRYYIIDKNTSDYKRLKADGLKPVKNRSFKHKMLFLNTDIALITNSNVFPFNGYSMDRSRFIRGLCNFPSMCLQHGLSVQKCAMAQQRIVDNTQMYFLASKYEYKNLSNHVYNYQDFDILKMTGIGRYDGLINNDKKQILLSPTWRMYNAMPVTTSEGEQRAYNPEFKHTTYYKIYNDLINNKKLIDTAKRTGYKIKYVLHPILSSQVNDFIPDPYVEVVSSVGDFNYETAFQESSLMVTDYSGVQFDFAYMKKPLVYFHPSQLPAHYDDGGFFYDTMGFGEICTESDQLVDLLCEYMENGCKMKPKYVERVEDFYQFDDHNNCERIYNEIIKYQQQVNKDKLK",
      "product": ""
     },
     {
      "start": 18594,
      "end": 19136,
      "strand": -1,
      "locus_tag": "ctg67_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,594 - 19,136,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTATGAAGAAATTTATGCTCAGGCAAAACAGGCTTGTAATGAGCTTTGCGATGTTGCCAAGCTTAAAGAGGGCAGTATTGTTGTAATCGGCTGTTCTTCAAGCGAGGTTGCAGGCGGAACTATCGGACACAATTCAAGTCTTGAAACCGCTCAGGCTGTTTTCAAGGGTATATACGAAGTGCTTTGCGAAAGAAAAATTTACCTTGCCGCACAATGCTGTGAACACCTCAATCGTGCAATCATCGTTGAGCGAGAGGCTGTTCCGAACGCTGAAATCGTGAATGTTGTTCCACAGCCAAAGGCAGGCGGTTCGTTTGCCACAACAGCATACAAAACATTCAAAGATCCCGTTGCGCTTGAAGAAATCAAGGCTGACGCAGGTCTTGACATCGGCGGAACACTTATCGGCATGCACCTTAAAAGAGTTGCCGTACCCGTAAGACTCGGCATTGACCATATCGGACAGGCAATTCTGCTTGCCGCAAGAACCCGTCCTAAATTCATCGGCGGTTGCCGTGCCGTTTATGACGACAGCTTTTAA",
      "translation": "MYEEIYAQAKQACNELCDVAKLKEGSIVVIGCSSSEVAGGTIGHNSSLETAQAVFKGIYEVLCERKIYLAAQCCEHLNRAIIVEREAVPNAEIVNVVPQPKAGGSFATTAYKTFKDPVALEEIKADAGLDIGGTLIGMHLKRVAVPVRLGIDHIGQAILLAARTRPKFIGGCRAVYDDSF",
      "product": ""
     },
     {
      "start": 19529,
      "end": 20005,
      "strand": 1,
      "locus_tag": "ctg67_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,529 - 20,005,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTGTGAAGTAACAATAAGACGGGCAAAATTTAAAGACATACCGCAGCTTGACAAGCTCCTTTTTGAGGTTCACAAGATTCACAGCGATATCCGCCCCGACCTTTTTACAGTCGGTGAGAAGAAATACACAGACGAGGAGCTTGAGCGAATAATTGTTGATGAGCAAAAGCCGATTTTTGTTGCAGAACATAACGGAAAAGTAAAAGGATATGCTTTTTGTATTTTCAAGCAGGATCTTGAAAGCAAGTCGGTCACAAATATAAAAACACTGTATATTGATGATTTGTGTGTTGACGAGGATACAAGAGGGATGCATATCGGCACAAAGCTGTATAACCATGTTATTGATTTTGCCCGAAAAAGCGGTTGCTATAATGTTACGCTAAATGTGTGGGCAGGCAATGACGGTGCAATGAAATTTTACGAGCGTATCGGTTTTAAGGTTCAAAAAATCGGTATGGAAACAATTCTCTAA",
      "translation": "MCEVTIRRAKFKDIPQLDKLLFEVHKIHSDIRPDLFTVGEKKYTDEELERIIVDEQKPIFVAEHNGKVKGYAFCIFKQDLESKSVTNIKTLYIDDLCVDEDTRGMHIGTKLYNHVIDFARKSGCYNVTLNVWAGNDGAMKFYERIGFKVQKIGMETIL",
      "product": ""
     },
     {
      "start": 20040,
      "end": 22649,
      "strand": 1,
      "locus_tag": "ctg67_19",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,040 - 22,649,\n (total: 2610 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 145.7; E-value: 3.5e-44)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAAATTGCAGTCGGTATTCTGGCTCATGTCGATTCGGGAAAGACTACGCTTTCAGAGGCTCTGATGTACTCCTCAGGCAACATAACAAAGCTTGGTCGGGTTGACCACAGGGATTCGTTTCTTGACACTTTTTCGCTTGAGCGTGACCGTGGAATTACAATTTTTTCAAAACAGGCGGTTATGAAGTACAACAACACGGAATTTACTCTGCTTGACACACCCGGTCATGTTGATTTTTCGGCAGAAGCAGAGCGTACACTTCAGGTGCTTGACTACGCAATTCTTGTAATCAGCGGAACTGACGGTGTTCAGAGTCACACCTGCACACTTTGGAAGCTGCTCAAAAAGTACAATGTGCCGTGTTTTATCTTCGTCAACAAAATGGATCTTGACGGTGCGGACAAGCTTTCCGTTATGACACAGCTGCGTACAGGGCTTGACGAAAACTGCGTTGATTTTACCTATCCGAACTCCGACGGCTTTCGTGAAAGTGTTGCCGTATGTGATGAAAAAATTCTTGAAAAATATTATGAAACAGATTCCGTTGAAAAGACCGACATAACAGGTGCGATTAAGGAACGCAAAATTTTTCCGTGTATGTTCGGTTCGGCACTCAAACTTGACGGTGTAAAGGCATTTTTGAATCTGCTTGACGAATACACGGTTATGCCCTCTTACGGTGCTGAGTTTGGTGCAAAGGTCTATAAAATTGCAGAGGACAATCAGGGCAACCGCCTTACATTTATGAAAATTACGGGCGGAAGTCTTAAAGTGCGTGAAATTCTCCAAAGCGAAAAAAATACCAATGCCGAAAAGGTAAACAGAATAAGAATTTATTCGGGCGAGAAATTCACAGCCGTTGAGGAGGCTGTTGCAGGAACCGTTTGTGCGGTAACAGGAATAACATTCACTTCATCGGGTGACGGCTTGGGTGTTGAGAAAAATTCCGGAGTTCCCGTACTCGAACCTGTTCTGACTTACAAGGTTGAATTAGAGGATGGGACAGACGCCCACACGGCTCTCACAAAGCTGAAAACGCTTGAAAACGAAGATCCTCAGCTAAATGTTGTGTGGAACAGCAGACTCGGTGAAATCCACATCCGCCTTATGGGTGAAATTCAGCTTGAGGTGCTGAGGTGCATAATAAAAGAGCGTTTCGGTATGAATGTATCGTTCAGTACAGGCAGTATAATCTATAAAGAAACAATCGAAAATACGGTTGAGGGTGTCGGTCATTTTGAGCCGTTAAGACACTATGCAGAGGTTCATCTCCTTTTGAAACCTGCAAAGCGTGGCAGCGGAATTACAATAAATTCCCGTTGCAAAGAGGACTTGCTCGACCGAAACTGGCAAAGGCTGATTCTTACTCACCTCTGCGAAAAAACACATCTCGGTGTGCTGACAGGCTCGCCGATTACAGATATTGAAATCACACTTGTTTCGGGAAAAGCTCACGCAAAGCATACCGAGGGCGGAGATTTCAGACAAGCAACCTACCGTGCCGTAAGACAGGGACTGCGTTGTGCAAAGAGCATTCTGCTTGAGCCTGTTTATGATTTCACGCTTGAAGTGCCTAACGAAAATGTGGGACGGGCAATGTCAGATATTCAGCGGATGAGCGGTACTTTCAATTCTCCCGAAGCCAAAGGCGAGAATTCCGTTCTCACGGGTACTGCACCCGTGTCCGAAATGGGCAACTACACAAAAGAAGTTATGCAGTACACTCACGGCAGAGGCAGACTTTCGTGCAGTCTTAAAGGCTATGAGCCGTGTCACAACAGTGATGAAGTTATTGCACAAATCGGCTACGATTGTGATGCCGATGTTGACAATCCGTGCGGTTCTGTGTTCTGTTCTCACGGAGCAGGCTACAATGTGCCGTGGAATGAGGTCGGCGAGCATATGCATCTGCCGAGTATTCTCGATGCTCCGAAAGACGATGAAATCGGCACAAACAGCGAAAATGCTTTTGCAAAGTGCAAAACTCAGGACGATATTTTTGCTCTCGACAAGGAGCTTATGCAGATTTTTGAACAGACCTACGGTCCTGTGACACGCAGAAAACACGCTCCCGAAAAGCGTCATGTCAAGGCGGTTTCGTCAATTGACAAGGCGGCTGAAAAGTATAAAAAATCCCCCGTGTATGACGGCACGGAGTATCTGCTTGTTGACGGCTACAATGTTATTTTTGCGTGGGAACACCTCAAAGAGCTTTCCGAAAGAAGTCTTGACGGTGCAAGGCACGCTCTGATAAACATTCTCTGCAACTATCAGGGCTACAGCAAGTGCAACCTTATTCTCGTGTTTGATGCGTACAAGGTAAAGGGCGAACACAGAGAGGTTGAAACCGTGAATAATATCAGTATTGTATATACCAAAGAGGCAGAAACCGCCGATATGTTCATTGAGAAAACTTCTCACAAGCTTGCCAAAACCAACAAGGTGCGTGTTGTAACATCCGATGCACTCGAACAGATGATAATTCTGGGCAACGGTGCGTTGCGTGTTTCATCAAGAGCATTTTTAGAAGAAGTCAGACAAGCCGAAAATGAAATCAGAGAAATAATAAATTCTTCAAACGAATTAAACAATAATATGAATTAG",
      "translation": "MKKIAVGILAHVDSGKTTLSEALMYSSGNITKLGRVDHRDSFLDTFSLERDRGITIFSKQAVMKYNNTEFTLLDTPGHVDFSAEAERTLQVLDYAILVISGTDGVQSHTCTLWKLLKKYNVPCFIFVNKMDLDGADKLSVMTQLRTGLDENCVDFTYPNSDGFRESVAVCDEKILEKYYETDSVEKTDITGAIKERKIFPCMFGSALKLDGVKAFLNLLDEYTVMPSYGAEFGAKVYKIAEDNQGNRLTFMKITGGSLKVREILQSEKNTNAEKVNRIRIYSGEKFTAVEEAVAGTVCAVTGITFTSSGDGLGVEKNSGVPVLEPVLTYKVELEDGTDAHTALTKLKTLENEDPQLNVVWNSRLGEIHIRLMGEIQLEVLRCIIKERFGMNVSFSTGSIIYKETIENTVEGVGHFEPLRHYAEVHLLLKPAKRGSGITINSRCKEDLLDRNWQRLILTHLCEKTHLGVLTGSPITDIEITLVSGKAHAKHTEGGDFRQATYRAVRQGLRCAKSILLEPVYDFTLEVPNENVGRAMSDIQRMSGTFNSPEAKGENSVLTGTAPVSEMGNYTKEVMQYTHGRGRLSCSLKGYEPCHNSDEVIAQIGYDCDADVDNPCGSVFCSHGAGYNVPWNEVGEHMHLPSILDAPKDDEIGTNSENAFAKCKTQDDIFALDKELMQIFEQTYGPVTRRKHAPEKRHVKAVSSIDKAAEKYKKSPVYDGTEYLLVDGYNVIFAWEHLKELSERSLDGARHALINILCNYQGYSKCNLILVFDAYKVKGEHREVETVNNISIVYTKEAETADMFIEKTSHKLAKTNKVRVVTSDALEQMIILGNGALRVSSRAFLEEVRQAENEIREIINSSNELNNNMN",
      "product": ""
     },
     {
      "start": 22727,
      "end": 22981,
      "strand": -1,
      "locus_tag": "ctg67_20",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,727 - 22,981,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAAAAATTTGTATCGTTTTTGCTTGCTCTTATGATGATTTTCTGGAGCAGTACCCTTGCTTTTGCAACTGACAAAACAGACACACAAAATAGCTCCACCTCCGATGAATCGGACGGCGGTTCAATGCCTACGGATTTTGCGATAATTCTTCTGCTTATCGCCGGCGGTACGGCAGTCGCAAGCTTTAAACGCCACAGAAATGACCGTGACGATTACGATGAACCCGATGATGACACGGAAGAAGAAATTTGA",
      "translation": "MKKFVSFLLALMMIFWSSTLAFATDKTDTQNSSTSDESDGGSMPTDFAIILLLIAGGTAVASFKRHRNDRDDYDEPDDDTEEEI",
      "product": ""
     },
     {
      "start": 23187,
      "end": 23723,
      "strand": -1,
      "locus_tag": "ctg67_21",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,187 - 23,723,\n (total: 537 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAACAAATAACATGCTTAAAGTTACGGGAATTATTCAGAGTGTTCTCATCGGCATATTGCTGTTGTTTGCGATTTGCATTGAGGTAATGAGCCGTATGAATTTTTATACATACGACTATTCACTCAATTTTGATTATTCTTCTTTTTGGGCAATCCACGGCGACTACCCGTTCCTATTCATTTTCAACACTCTTTTTACAACCTTTGCATCTTTCTCAAGCTTGTTAGAAAATTATGTTTTATATGTTATTTTTGAAATTATGGATATTGCATCGTTGGTATTGCCCGTATATCTCGTTTACAAATCCATACGCAGTAAAAGCACGATGGCAAACGGATTGATTATTATATCATCTGCTGTTACTTTTATGATTATGGTTGCTTACGGAGTTTATACCCTTCTTGACATAATTCGCGGTGCTGAAACATTCAATATTTACAGCATAATTTTCATCTTCATAATGTTGATAAAAGTTACTCTGTGCATTGTTTCACCGCTCAGAATAAGGGCAATTAACAACGCAGTCGAATAG",
      "translation": "MKTNNMLKVTGIIQSVLIGILLLFAICIEVMSRMNFYTYDYSLNFDYSSFWAIHGDYPFLFIFNTLFTTFASFSSLLENYVLYVIFEIMDIASLVLPVYLVYKSIRSKSTMANGLIIISSAVTFMIMVAYGVYTLLDIIRGAETFNIYSIIFIFIMLIKVTLCIVSPLRIRAINNAVE",
      "product": ""
     },
     {
      "start": 23743,
      "end": 24297,
      "strand": -1,
      "locus_tag": "ctg67_22",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,743 - 24,297,\n (total: 555 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAACAATAAAACTCTCAAGTACACAGGAATTATACAAGGTGTACTCATTGCAACTCTGTTACTGCTTGCCATTTGGATTCAAGTGACATTTTTATATAACACATACTATTGTGAAGATTATACTTTTGATTTTCTTAGAAATATGGGCATTGGTTATTGGGATTTACGGAATAATTCTTCAGCGTTTTTCCTCATAAATTCCATTGCGGAAACTATAGCTTATTTTTTAGGTTTGATGCGTCTTTATGTTCTTAAAATAATTTTTCAGATTATTGCCGCTGCAGCGTTAACCTTGCCTGTTATTTTAGGCTATCTGTCAATATTCCGCAAAAACATAGTTGCAAACGGATTGATTATTGCAGGATCGGCATTGACTTTGTTATCCGCATGTCGGAGTCTTTTCTCTACCCTATTTGAACTTGCCCGTGGATTTGGCGAATTTACTTTGGTTCAAGTAGTTTTAATAATTGTGATACTGATAAAAATAGAATTGATTGCCGTTTCAATACTGCGGATAAAACAGATTAAAAAATCAAATCAGTTACAGTAA",
      "translation": "MKNNKTLKYTGIIQGVLIATLLLLAIWIQVTFLYNTYYCEDYTFDFLRNMGIGYWDLRNNSSAFFLINSIAETIAYFLGLMRLYVLKIIFQIIAAAALTLPVILGYLSIFRKNIVANGLIIAGSALTLLSACRSLFSTLFELARGFGEFTLVQVVLIIVILIKIELIAVSILRIKQIKKSNQLQ",
      "product": ""
     },
     {
      "start": 24313,
      "end": 24804,
      "strand": -1,
      "locus_tag": "ctg67_23",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,313 - 24,804,\n (total: 492 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAAAAGTTCAAAAATAATTGCCGCAATTTTTATTACTCTCCTCTCCCTTATTCTGATTGTGTCGGCATTTTTGCTCCTGTTTGAGGGAATAAAATTAAGCTACGATCCGTCCGATGAAAGCAAATCGTTGGATTACTATGACATTGACGATGTAAAATACTATGTTTATCAGCAGAAAGTTGCCGTCACTATGAACGGTGACAACGACAGTCTTGATGTGAGAACGGGAAAATATCGTGACAACTGGCTGAATGACAGTTCCGAAAATGTGCTTAAAGGCAAGTTTGAAAAGGTCGGCTGGAATGACGATAAGCTCTATATTTTATCGGATGATAAGTATTATGAGTTTGACATCAACAGCTACGAAATTCCGAAAAATTATAACGGCAGTTCGTTAGAAACTGCCTATTCGTTAAAAGAACGTTCAAAATCACAGTTTGAGAAAAACTTTAAAAATTTCGATTCATTTGATTGGTATGACAATTAA",
      "translation": "MKKSSKIIAAIFITLLSLILIVSAFLLLFEGIKLSYDPSDESKSLDYYDIDDVKYYVYQQKVAVTMNGDNDSLDVRTGKYRDNWLNDSSENVLKGKFEKVGWNDDKLYILSDDKYYEFDINSYEIPKNYNGSSLETAYSLKERSKSQFEKNFKNFDSFDWYDN",
      "product": ""
     },
     {
      "start": 24818,
      "end": 25399,
      "strand": -1,
      "locus_tag": "ctg67_24",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,818 - 25,399,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTAAGAAAAGCTCAAAAATTATTATGATTGTTTCAATAACACTTGCAAGCATAATGCTTTTAACGGCAATTGCATTTATAGCACAAAGGATTTACATAAACAAAGACATACTTTCAGAATCTCCCGAAAAAATAATTGACATAATTATGGACGGTGATGAATACCATGACGGAATTCGTTCGAGTTCAGCCATTGACGGTACAGACTATACCTGTTTTGACAAAGTCTATATTTCCATAGCACTTGCCGACCGTTATCAAGACAGCGTTTACATGAAAGTTCCCTACAATGAGGGCGACGATTCTTTCTATATCGGTGATGAAAACAAAATAATCACGGGCAAAATCAACGCACTTTATAAATTTGACAAAACGGTTATTGTAATGTGTGACGATGTGTACTATGTGATTGACACGGACGAATACACAGTTCCTCAGAATTTTGAGGAAGGTAAAAATATTGATTACAAGCCCGATCAATATTCCGAAAAAGAATTTAGAAATAAATATCCGAACTATAAAAGTTTTGAATGTTTTTACAGCCGTTTGTGTCAGCCTGTTGCCGATGATTTCGATTGA",
      "translation": "MIKKSSKIIMIVSITLASIMLLTAIAFIAQRIYINKDILSESPEKIIDIIMDGDEYHDGIRSSSAIDGTDYTCFDKVYISIALADRYQDSVYMKVPYNEGDDSFYIGDENKIITGKINALYKFDKTVIVMCDDVYYVIDTDEYTVPQNFEEGKNIDYKPDQYSEKEFRNKYPNYKSFECFYSRLCQPVADDFD",
      "product": ""
     },
     {
      "start": 25646,
      "end": 26056,
      "strand": -1,
      "locus_tag": "ctg67_25",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,646 - 26,056,\n (total: 411 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1275:peptide deformylase (Score: 127.6; E-value: 5.4e-39)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAAGAGAAATTGTACATGATCCTATGTTTTTACAGAGAAAGTCGGAGGACGCAACACAGGCAGATTTGCAGACGGCACAGGATTTGCTTGACACACTCAGGGCAAATTTTGACCGTTGCGTGGGCATGGCGGCTAACATGATAGGGGTTGCAAAGAGGATAATCGCAATTAATGACAACGGAAAATATCTTGTTATGTTCAATCCCGAAATCATTAGCAAATTCGGTGAATTTGAAACCGAGGAGGGCTGTCTTTCGCTTGACGGCGAACGCAAAACAGTTCGTTACAAAACGATAAAAGTAAAATATTTCAACGAAAATTTCAAGCAGATAAAACGCAGTTTTTCAGACTTTACCGCACAGATTATTCAACATGAAATTGACCATTGCAACGGGATTCTGATTTAA",
      "translation": "MVREIVHDPMFLQRKSEDATQADLQTAQDLLDTLRANFDRCVGMAANMIGVAKRIIAINDNGKYLVMFNPEIISKFGEFETEEGCLSLDGERKTVRYKTIKVKYFNENFKQIKRSFSDFTAQIIQHEIDHCNGILI",
      "product": ""
     },
     {
      "start": 26160,
      "end": 26351,
      "strand": 1,
      "locus_tag": "ctg67_26",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,160 - 26,351,\n (total: 192 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAATATCCGGAGTTATCGTGCAATTTTTATGCTGAGGTTGACGGTGAGAATGTTTTGCTGATTGAAATTGACAGAGAGGGCAGAGCAAAGGTTTATCATGAAAATTTAAGAATTGACGGGGTGAAGAAAATTTTTGAAGAAATCAACGGAAATATTGAAAGCTACATAAAATATTTCGGAACAAAATAA",
      "translation": "MKYPELSCNFYAEVDGENVLLIEIDREGRAKVYHENLRIDGVKKIFEEINGNIESYIKYFGTK",
      "product": ""
     },
     {
      "start": 26424,
      "end": 26867,
      "strand": -1,
      "locus_tag": "ctg67_27",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,424 - 26,867,\n (total: 444 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1171:transcriptional regulator, MerR family (Score: 81.4; E-value: 1.7e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTACACAATCGGTCAGGTATCTCAGATGTGCGGTATTCCTGTTTCAACCCTGCGTTACTACGATAAAGAGGGACTTTTTCCGCATATGGAGAGGGTGTCGGGTATCCGCAGATTTTCCGACAGAGAGCTTGAAACACTCCGCATAATTGACTGTCTCAAAAAATCGGGACTTGAAATCAGGGAAATAAGAAAATTTATGCAATGGTGCGCCGAGGGCAGTTCGTCCTATCCGCAAAGGCGAGAGCTTTTTGAAAATCAGAAAAAAACCGTAGAAAAGGAAATTGAGCGTCTTCAAAAGGCGCTTGATATGCTCCGCTTTAAGTGCTGGTACTACGATACTGCCATTGCTGACGGCAACGAGGACAGAATCAACGAAATGCTCCCGAACAATCTTCCCGATGATATTCAAAAGCTGTATGACCATGCCCACAGCGATGACTAA",
      "translation": "MYTIGQVSQMCGIPVSTLRYYDKEGLFPHMERVSGIRRFSDRELETLRIIDCLKKSGLEIREIRKFMQWCAEGSSSYPQRRELFENQKKTVEKEIERLQKALDMLRFKCWYYDTAIADGNEDRINEMLPNNLPDDIQKLYDHAHSDD",
      "product": ""
     },
     {
      "start": 27045,
      "end": 27884,
      "strand": -1,
      "locus_tag": "ctg67_28",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,045 - 27,884,\n (total: 840 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAGGTCTGATAATTGAAGGCGGAGCAAGGCGAGGAATTTTTACCGCCGGTATAACCGACTGTCTGCTTGAAAACAAAATACACTTTGACTATGTTGCAGGAGTTTCGGCGGGAGCTGAGGTTGCCCTTGATTTTACCGCAAAACAGGAAGGTCGTTCCCGCAGGGTTATTATGCCCCACAGAACAGGCGATTTTTCAGTTCTCGGTTTTCTTTCAATGGATCTTGACAATATGATTTACAGATTTCCTTATCAGGACTATCCGTTCGATTTTGATACATTTTTTGCGTCAGATACAAACTGCGAATTTGTGGCAACCGACTGCGTAACAGGCAAGGCAAAATATTTTTCCGAGAACAAAAGCGAACAGCGATTGCTTGACTCCGTAAGAGCGTCCTGCACAGTTCCTATTCTCTATCAGATAAGCGAATTTGAGGGCGGAAAGTATGTTGACGGCAGTATTGCCGACGCTGTTCCCTTTGACCGTGCGTTTGAACAGGGCTGTTCCCGTGTGCTTGTGCTTTTGACAAAGCCCGAAAATGAGCCTTGCACGGACTATCGCAAGTTTGAATTTTTAATCAACAAAAAATACAAGGACTATCCGAACCTCATCAACGCTCTTATGACGAGATTTGACCGCTATAATGAGCAATGCAAAAGAATGAAACAGCTTGAGGAGGACGGCATACTTATGGTACTCCGCCCGTCACACAAGTATGTAAAATCATTTGAGATGAACACGGATGTGCTTGACGAGGCATATAACGCCGGCAAGAATCTTGCCAAAGAAAAGCTTGCCGAAATTGAAGATTTTCTCAATGTTCTCGAAAAGAAATAA",
      "translation": "MTGLIIEGGARRGIFTAGITDCLLENKIHFDYVAGVSAGAEVALDFTAKQEGRSRRVIMPHRTGDFSVLGFLSMDLDNMIYRFPYQDYPFDFDTFFASDTNCEFVATDCVTGKAKYFSENKSEQRLLDSVRASCTVPILYQISEFEGGKYVDGSIADAVPFDRAFEQGCSRVLVLLTKPENEPCTDYRKFEFLINKKYKDYPNLINALMTRFDRYNEQCKRMKQLEEDGILMVLRPSHKYVKSFEMNTDVLDEAYNAGKNLAKEKLAEIEDFLNVLEKK",
      "product": ""
     },
     {
      "start": 28075,
      "end": 28557,
      "strand": 1,
      "locus_tag": "ctg67_29",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,075 - 28,557,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTAACCGCAAAACCTTTTACCGTCACTACAACACGGTTCAGGATGTTGTCGATGATATCAACTACGATATAATCAACGATGTTATCAGCCATGCGAAAAAATCCGACCGTGACGGCAACAATCTTGTGAATCAGCTGAATTTTATCGGTCTTTCCATTGTTGAAAATAAAGAACAGATTAATAAAATTCTGAAAAATTCTCCCGAGGTGTTCGGCTCTGGACGCTCTGTTGAGCTTTTGAAAAGATTTATCGAGGTTTCAATAAGACCTGTGCTTAATTTTAAAAATGAAACAAAACTCAAATACCTTGTTGAGTTTGTCGTTTCGGGATTTATCTCGGTTTATGTCCGTTGGTTCAATGACGGCTGTGCAGAAAGCTCCGAAAAACTTGCAGACGCTGTCAACGAGTTCGTTCTCGGAGCATTGTCCGAATATGTTCCACCCAAAAAGCTGATTAACTCATTTTCCAATGAGCCTTAG",
      "translation": "MINRKTFYRHYNTVQDVVDDINYDIINDVISHAKKSDRDGNNLVNQLNFIGLSIVENKEQINKILKNSPEVFGSGRSVELLKRFIEVSIRPVLNFKNETKLKYLVEFVVSGFISVYVRWFNDGCAESSEKLADAVNEFVLGALSEYVPPKKLINSFSNEP",
      "product": ""
     },
     {
      "start": 28532,
      "end": 29236,
      "strand": -1,
      "locus_tag": "ctg67_30",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,532 - 29,236,\n (total: 705 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGTTCTCGTATTAAACGGTAGTCCAAAGGGCGAAAAAAGCAATACTCTCAACATTACAAAAGCATTTCTTGACGGCTTTTCAGCCGATACGGAAGTTGAATATATCACGGTTAAAAAGGAAACAATCAAGCCGTGTATGGGTTGCTTTTCGTGTTGGAGCAGAACACCCGGCAAATGTGTTATAAAGGACGATATGCAGAAAATCTACGAAAAGATTAATTCTGCCGATATTATCATTGAGAGCTTTCCGCTCTACTTTTTCGGTATGCCGTCACAGATGAAAGCATTAACCGACAGATGTCTGCCGTATATGCTCCCCTATTCGGGAAATGTTGCCGAGGACAAAGAAGCCTCTTTCCATGAACTGCGTGATGAAGCAATGCACGAAAAGAGACTTTTGGTTATTACAACTTGTGGCTATGTGAGTGCCGAACCGATGTATCCCGCACTTATAAAACAGCTTGATTTGATTTGCGGTAACGGCAATTACACGATGATAAAATGTCCCGAGGGCGAGCTTTTTATTGCAGAAAAAGCTGAAAGGCAGAGAAAAGCATACCTTGATTCAATCACGGAGGCAGGCAGGGAATTCTGCGAAAACCGTTGTCTTTGCGATGAAACAATGAAAAAAATTTCAAAGCCTATTCTCTCCCCCAAAGGATTCGAGGCAATTACTAAGGCTCATTGGAAAATGAGTTAA",
      "translation": "MKVLVLNGSPKGEKSNTLNITKAFLDGFSADTEVEYITVKKETIKPCMGCFSCWSRTPGKCVIKDDMQKIYEKINSADIIIESFPLYFFGMPSQMKALTDRCLPYMLPYSGNVAEDKEASFHELRDEAMHEKRLLVITTCGYVSAEPMYPALIKQLDLICGNGNYTMIKCPEGELFIAEKAERQRKAYLDSITEAGREFCENRCLCDETMKKISKPILSPKGFEAITKAHWKMS",
      "product": ""
     },
     {
      "start": 29239,
      "end": 29694,
      "strand": -1,
      "locus_tag": "ctg67_31",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,239 - 29,694,\n (total: 456 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1270:UDP-3-O-[3-hydroxymyristoyl] N-acetylglucosamine (Score: 94.1; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGAATCTGCTTGAAATCAATCAAAGAATAAAACAAAGACCACCCTTTCAGATGATTGAGAGGGTGACCGAGCTTGAGCCGAATGTTTCGGCAACAGGTATAAAAAATGTGTCGGTGAACGAGCCGTATTTTGCAGGTCATTTTCCCGACACACCGATTATGCCGGGAGTATTGCTCATTGAATCTGCGGCACAGCTTTGCAGTCTTGTATTTGCTCCCGAAAGCGTTGAGGAGGACAAGCTGTATGTTCTTCTAAAAGTCAAGGATTTCAAAATGCTCCGCCCCGTTATTCCGGGTGATACGCTTATTATCAGCGTAAATGTTACAATGTCAACAAAGTCGGCATTTGAATTTGCGTGTGTCATCAAGGTTGACGGTGAAGTGAGGGCAAAGGGAAGTCTTTTGTTTACCACAATGGATAAAAATGCGGTTTACAAGCCGTCACAGGAGTGA",
      "translation": "MMNLLEINQRIKQRPPFQMIERVTELEPNVSATGIKNVSVNEPYFAGHFPDTPIMPGVLLIESAAQLCSLVFAPESVEEDKLYVLLKVKDFKMLRPVIPGDTLIISVNVTMSTKSAFEFACVIKVDGEVRAKGSLLFTTMDKNAVYKPSQE",
      "product": ""
     },
     {
      "start": 29691,
      "end": 30425,
      "strand": -1,
      "locus_tag": "ctg67_32",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,691 - 30,425,\n (total: 735 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 227.2; E-value: 3.6e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAAAACCGCTCTTGTAACAGGTTCATCAAGGGGCATTGGCAAGGCTTGCGCTTTAAAGCTTGCAGAGCTTGGATATGACATTGCCGTGAACTGCAATTCAAATTTGGAAATGGCTCAAAAGGCTGTTGACGAAATTACATCACTCGGCAGAAAAGCCGTTGCCTACAAGGCAAACACGGCAGATATTGACGAAGTAAAGGATATGTTCCGCAGTATTCAGCAGGACTTCGGCGGAATTGATGTGCTTGTCAACAACGCAGGTGTGGTTGACGACGCTTACCTTTTGATGATTAAGGACGAGTCGCTTGAAAGAAGTCTTGACATTAATATCAAAGGATATTTCAATTGTGCAAGACAGGCATCGCTTAAAATGCTCCGCAAAAAGAGCGGAATCATCATCAACATTTCTTCCGTAAGCTCTGTTCTTGCAGTTGAAGGTCAGTCGGTTTACAGTGCAACAAAGGGTGCGGTAAACGCTATGACTCACACGCTTGCAAAGGAACTTGCAAAGTACGGAATCAGAGTAAACGCAGTTGCACCCGGTTTTATCGAAACCGAAATGATGAACGGCATTCCCGAAGAGTTGCAAAAAAAGTATCTTGAGGCTATTCCCGAAAAGAGATTCGGCACAGTTCAGGATGTCGCAAATGTAGTCGGACAGCTTTGCAGTGACGATTTTTCATATATGACAGGTCAGGTGCTTGTGCTTGACGGAGGACTCAGCTTATGA",
      "translation": "MSKTALVTGSSRGIGKACALKLAELGYDIAVNCNSNLEMAQKAVDEITSLGRKAVAYKANTADIDEVKDMFRSIQQDFGGIDVLVNNAGVVDDAYLLMIKDESLERSLDINIKGYFNCARQASLKMLRKKSGIIINISSVSSVLAVEGQSVYSATKGAVNAMTHTLAKELAKYGIRVNAVAPGFIETEMMNGIPEELQKKYLEAIPEKRFGTVQDVANVVGQLCSDDFSYMTGQVLVLDGGLSL",
      "product": ""
     },
     {
      "start": 30441,
      "end": 32639,
      "strand": -1,
      "locus_tag": "ctg67_33",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,441 - 32,639,\n (total: 2199 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) HR-T2PKS: t2fas<br>\n \n  biosynthetic (rule-based-clusters) HR-T2PKS: hr-t2pks-ksa<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 78.6; E-value: 7.8e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGACAAAAAGAGATGTGTTGTCACAGGACTCGGACTTATCTGCGGCGTCGGTGACAATGTAAAGGATTGCTGGGATGCCGTAACACTCGGTCACTCCGGCATTGATGAGGTTAAGTCGGTTGACACCTCAAACTGTTATGCACACAAGGGTGCAGAGGTTGACAAGGCATCGTCAGAGCTTTCTCCCGAAAACTATGACCGTTCTTCCCTTCTCTGTATTCATGCCGCAAACGAGGCTTTTGAAGATGCAAACATTGACGCATCCGAAAAGAACATCGGTGTTATTCTTGGCAGTTGTGTAGGCGGTGCGGCAAGCATTGACAAATATTACACAGACGAAATCAAGGGTGACGGCGGTAAAAAAGAAGATATTTTCAAAATGGGTGCTTCGGCAATTGCCAACAATGTTTCCGCTCATTTCGGACTTGAGGGCATTACCGCAAACATCGTCAACGCTTGTGCGGCAGGCACAATGAGCATCGGCTATGCCTGTGACCTTATCCGTGAGGGCAAGGGGGATGTGTTCATTGCAGGCGGTTCGGACAGTTTTTCTTCACTTGCATTCAGCGGTTTCCACGCTCTCCATGCGCTTGACGAAAACGCCTGTTCCCCGTTCAATCACAGCACAGGTATCACGCTCGGCGAGGGTTCGGGTATTCTTGTAATCGAAAGCTACGAACACGCTGTTGAACGAGGTGCAAAGATTTACTGTGAAATTCTCGGTTCGGGTGTAAGCAGTGACGCTTACCACATTACCGCTCCCCGTCCCGACGGTGAAGGTCAGATGAGTGCAATCAGAAGGGCTGTTGAAAGCTCTGCTCTTAGTTTTGACGATATCGACTACATAAACGCACACGGAACGGGTACTGCCAAAAATGACGAGGCTGAATTTCTTTCACTTCACACACTTTTTGACGGCAACGACCACCTTTCTGTCAGCTCAACAAAATCTATGACAGGTCATTGCCTCGGTGCGGCAGGCTCAATTGAGGCTGTATTTTCCGTAAAAGCAATAAAAGAGAACCTCGTTCCGCCTACAATCGGCTACTCCGATGAGGATTTGAAGGTGCTTTCCGAAAAGGCTGGCAACATTGACTTTATTCCGAACAAGAGCCACACAAAAGATGTTCACTATGCAATGTCAAACTCATTTGCATTCGGCGGCAACAACGCAAGCATCATTTTCTCGGACAACGAGCATGATATTCCCGACAACAGTAAAAATGAAAAAATTTACATTACGGGCATTTCAAAGCTTACAGGCACAAGGACTGACGAACACAGCCTTAACTGCAATCTTACCTCCGAGGATTATGACAAACACGGAATCAAGGTTGCATTTTACAGAAAGCTTGACCGTTTCAGCCAGCTCCAGCTTTTGAGCGGTATGGACGCACTTGCAGACGCTGACATTAAAATTGACAAAGACAACGAATATAAAACAGGTATTGTAATCGGCACGGCTGACGGTCCTATGACCGAAATTGTTGATTTCCAGAAAAAGGCAATCACAAGAGGTACCGAAAAGGGCAGTGCTTTTTCATTCCCGAATACGGTTTACAATGCCGCAGGCGGTTATCTGAGCATTTTCTCAGGTATCAAGGGCTACAACGCAACTGTTGCAAACGGCAATCAGGCAGGACTGCAAAGTATTTGCTATGCCGCTGATATTCTTGCAGACGGCAACGAAAGCGTTATGCTTGCCGCAGGTACCGATGAAAATACAAAGACAAACCTTGAACTCTATACAAAGGCCGAATTGCTTGAAAAACCACTCGGTGAGGGCTCTGTAACTCTCGTTCTTGAAACAGAGGAAAGTGCAAACGGCAGAAATGCACGCAAGTATGCAGAAATTAAGGGCTATGCACAGGCTCACCGCCCTGTATCTTATGACAACTCAGAGGTTGACAGCAAGGCTGTTGTTGAGGTTATCGAAAAGGCTTGTGTGAATGCCGACATTGAGGCAGACAATATCGACTTTGTATGCTGTGATGACAGGAAGATTATCAAGACGCTTATGCCCTGCTATGATGTATCGCAGGAAATCGGCAATGCAAGAGCCGCAGCAAGCGCAATGACAGCGGCATATGCGGCTGAGATTCTTTCTGACAGCGAGAAAAATTACGAATACGGACTTGCTCTTTCAATGGGTGCGGGCGGAACATACTCTGCCGTAATCCTGAAGAAAGCGTAA",
      "translation": "MADKKRCVVTGLGLICGVGDNVKDCWDAVTLGHSGIDEVKSVDTSNCYAHKGAEVDKASSELSPENYDRSSLLCIHAANEAFEDANIDASEKNIGVILGSCVGGAASIDKYYTDEIKGDGGKKEDIFKMGASAIANNVSAHFGLEGITANIVNACAAGTMSIGYACDLIREGKGDVFIAGGSDSFSSLAFSGFHALHALDENACSPFNHSTGITLGEGSGILVIESYEHAVERGAKIYCEILGSGVSSDAYHITAPRPDGEGQMSAIRRAVESSALSFDDIDYINAHGTGTAKNDEAEFLSLHTLFDGNDHLSVSSTKSMTGHCLGAAGSIEAVFSVKAIKENLVPPTIGYSDEDLKVLSEKAGNIDFIPNKSHTKDVHYAMSNSFAFGGNNASIIFSDNEHDIPDNSKNEKIYITGISKLTGTRTDEHSLNCNLTSEDYDKHGIKVAFYRKLDRFSQLQLLSGMDALADADIKIDKDNEYKTGIVIGTADGPMTEIVDFQKKAITRGTEKGSAFSFPNTVYNAAGGYLSIFSGIKGYNATVANGNQAGLQSICYAADILADGNESVMLAAGTDENTKTNLELYTKAELLEKPLGEGSVTLVLETEESANGRNARKYAEIKGYAQAHRPVSYDNSEVDSKAVVEVIEKACVNADIEADNIDFVCCDDRKIIKTLMPCYDVSQEIGNARAAASAMTAAYAAEILSDSEKNYEYGLALSMGAGGTYSAVILKKA",
      "product": ""
     },
     {
      "start": 32641,
      "end": 32883,
      "strand": -1,
      "locus_tag": "ctg67_34",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,641 - 32,883,\n (total: 243 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAATGCTATTGCAGATCAGATTAAGGAAATGCTCGTAGAAAACCTTAGAATTCCCGAAAACATTCTTACATACGATTCAGAACTTTTCGGTGACGAAATCGGTCTTGACTCAATCGACTCAATCGAAATCGTTGCAGGCATCGACACACTTTTCGGTATTGATATGACAGGTGCAGACCGTGAGCACTTCCAATCAATCAGAGCACTTACAGAATATGTAGAAAGCAAGCAGGGTTAA",
      "translation": "MNNAIADQIKEMLVENLRIPENILTYDSELFGDEIGLDSIDSIEIVAGIDTLFGIDMTGADREHFQSIRALTEYVESKQG",
      "product": ""
     },
     {
      "start": 32924,
      "end": 33610,
      "strand": -1,
      "locus_tag": "ctg67_35",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,924 - 33,610,\n (total: 687 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 84.3; E-value: 1.3e-25)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGTACAATTATCATAAAAATGCAGGACAGCTTGCATTCATAAAATTTGTAAAAGGTCTTGTGCATCTTCTTATTCGCCCTAAGGTTGAATGGAAGGACAAGAGCCTTAAAAAGAACCTCAAGGGCAAGCCTGTTGTGTTTGTATGCAACCACACTCACCACTTTGACGGAGTTGTGATAAGCTCTGTACTCAGCAGATACAAGCCGTATATGCTTGTTAAAAAAAGCTGGTACGACAAGAGCGGGACAGGCTCGTTTATCCGAATTTGCCGCAGTATTCCCGTTGACTTTGACACCATGGACACAAACTGGTATGCACAAAGTGAGGGTGCGGTTGAAAACGGATATTCAATGCTTATCTTCCCCGAGGGCGGAATTGCAAGAGATGGCAAAATGCTCCCGTTCAAGCCCGGTGCGGCATTGCTTGCGGCAAAAAAAGGTCTTGACATAATCCCGATTGCATCTTTGGGTGAGTATAAAATTCTTTTCGGAAAAAGGCAGAAAATTTTAATCGGCAATCCGATAAAATCCGAATGTCCCGAAAATGTTCGCTACTCAAAATATGCAAAAGAAATAAGTGCCGAAGCCGAAAAGCAGGTTAAAAAGCTTTATCTTGAGCTTGAAGAAAAATACGGCAAAGGCAAGGTTTATTACAAAGAAGATTTTTCTTCGGAAAATTTATAA",
      "translation": "MEYNYHKNAGQLAFIKFVKGLVHLLIRPKVEWKDKSLKKNLKGKPVVFVCNHTHHFDGVVISSVLSRYKPYMLVKKSWYDKSGTGSFIRICRSIPVDFDTMDTNWYAQSEGAVENGYSMLIFPEGGIARDGKMLPFKPGAALLAAKKGLDIIPIASLGEYKILFGKRQKILIGNPIKSECPENVRYSKYAKEISAEAEKQVKKLYLELEEKYGKGKVYYKEDFSSENL",
      "product": ""
     },
     {
      "start": 33852,
      "end": 34913,
      "strand": 1,
      "locus_tag": "ctg67_36",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,852 - 34,913,\n (total: 1062 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAAGTAATTTTAACAGGTGACCGTCCTACGGGCAGACTTCATGTCGGTCACTATGCAGGTTCGCTCAAGGAGAGAGTAAAGCTCCAGAATTCGGGCGAATATGATGATATATACCTTATGATTGCAGACGCTCAGGCTCTTACCGACAATGCCGAGCATCCCGAAAAGGTAAGACAGAATATTTTGCAGGTTGCGCTCGACTACCTTGCCTGCGGAATAGATCCGAACAAGTCAACAATTTTTGTTCAGTCAATGATTCCTGAGCTTACAGAGCTTACTTTCTATTATATGAACCTCGTAACCGTGTCTCGTGTTCAGCGTAACCCCACCGTTAAGGCAGAAATTCAGATGCGTAATTTTGAGGCAAGCATTCCTGTGGGATTTTTCTGTTATCCAATCAGTCAGGCGGCTGATATCACGGCATTCCGTGCAACTGCCGTTCCTGTCGGCGAGGATCAGCTTCCGATGCTTGAACAATGCAAGGAGATTGTTCACAAGTTCAATTCCGTTTACGGCGAAACTCTTACGGAACCGCAGATTATTCTTCCGAGCAACAAGGCTTGTCTGCGACTGCCCGGTATTGACGGCAAGGCAAAGATGAGCAAATCCCTCGGCAACTGCATTTATCTTGCAGAAGAACCCGAGGATATCAAGAAAAAGGTTATGTCAATGTTTACCGACCCGAATCATCTTCGTGTTGAGGATCCGGGCAAGGTTGAGGGCAATCCCGTGTTTATCTACCTTGACGCATTCTGCCGTGATGAGCATTTTGCGGAATTTTGGAATGATTACAGCTGTCTTGACGAACTCAAGGCTCATTATCAGCGTGGCGGACTCGGTGATGTCAAGGTTAAGAAATTCCTTAACAATGTTATGCAGGAGGAGCTTCGTCCTATTCGTGAACGCAGAAAAGAATGGGAAAATCATCTTCCCGATGTTCTCGATATTCTCAAAGAGGGCAGTAAGGTTGCAAAGGAAACTGCCGCAAAAACACTTGAGGATGTCCGTCATTCTATGAGAATCGATTATTTTACAGACAATAATCTTCTTAAATAA",
      "translation": "MKKVILTGDRPTGRLHVGHYAGSLKERVKLQNSGEYDDIYLMIADAQALTDNAEHPEKVRQNILQVALDYLACGIDPNKSTIFVQSMIPELTELTFYYMNLVTVSRVQRNPTVKAEIQMRNFEASIPVGFFCYPISQAADITAFRATAVPVGEDQLPMLEQCKEIVHKFNSVYGETLTEPQIILPSNKACLRLPGIDGKAKMSKSLGNCIYLAEEPEDIKKKVMSMFTDPNHLRVEDPGKVEGNPVFIYLDAFCRDEHFAEFWNDYSCLDELKAHYQRGGLGDVKVKKFLNNVMQEELRPIRERRKEWENHLPDVLDILKEGSKVAKETAAKTLEDVRHSMRIDYFTDNNLLK",
      "product": ""
     },
     {
      "start": 35083,
      "end": 36105,
      "strand": 1,
      "locus_tag": "ctg67_37",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,083 - 36,105,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTGACGCAAGAAAGCATACGTTCGATTCTGTTAAAAAGCTGACCGATTACAGCGATTTTAACCTTTATAAAATGGATATATGCTACGATTACAGCATTGATAAAATCATTGACAGAGGGATTTTTGATGATGAGTCGGCTCTCGGTGCAATTTTGCAGGAGGTTCTGCCCGATTATCCCGTCAATCTTAAAATGCCGAATTTCGGGTGCAGTGCCTTTACAATGAAAAATCCCGACAGCGTAATGATGGGGCGAAACTATGATTTTAAGAACGACACCTCGTCAATGCTTGTATATTGTTCGCCAAAGGACGGCTACAGGTCGGTTGCGTTTGCGGCACTTGATAATGTAGGTGCAAACAACCCCGAGTTGAGTGATGAAACAAGGCTTGCAACCTTGCTCTCACCGTTTATCAGCCTTGACGGAATCAATGAAAAGGGCGTGTCAATCGCAGTTCTCACACTTGACAGCAAGCCGGTTCGTCAGCAAAGCGGAAAGCCTGTTATCGCCACAACGCTTGCAATCCGTCTTATACTTGACAGAGCTGCGTCAACCGAAGAGGCGGTTACACTTTTTGAAAAATACGATATGTTCGCCTCAAGCGGAAGAGATTATCACTTTTATGTTACCGATTCAAACGGTGACGGTCGTGTTATTGAGTACGATTGCAACAGCGATGACCGAAAGCTTGTTGTTACAAAATCGCCTGCCGTTACAAACTTTTTTGTGATGTACAAAAATTTTGTAAAGCCTTATCAGAAAAACGGTGTTTACGGTCACGGCAGAGAGCGGTATGATAAGATAATTAATGTTCTTGAAAAGAATAATAGTTACACAAAAGAAACAGCATGGGAGGCTCTTGTTTCGGCGTCACAAGCACCGAATCCGAACGATATAACAAGCAATACTCAATGGTCGATTGTTTATGACAACACAAACCTTACCGCTGATATTTCAATCCGCCGAGATTGGAACACGGTGACAAAATATTCGCTAAAAGAAAATAAAATTACGGAATAA",
      "translation": "MIDARKHTFDSVKKLTDYSDFNLYKMDICYDYSIDKIIDRGIFDDESALGAILQEVLPDYPVNLKMPNFGCSAFTMKNPDSVMMGRNYDFKNDTSSMLVYCSPKDGYRSVAFAALDNVGANNPELSDETRLATLLSPFISLDGINEKGVSIAVLTLDSKPVRQQSGKPVIATTLAIRLILDRAASTEEAVTLFEKYDMFASSGRDYHFYVTDSNGDGRVIEYDCNSDDRKLVVTKSPAVTNFFVMYKNFVKPYQKNGVYGHGRERYDKIINVLEKNNSYTKETAWEALVSASQAPNPNDITSNTQWSIVYDNTNLTADISIRRDWNTVTKYSLKENKITE",
      "product": ""
     },
     {
      "start": 36156,
      "end": 37469,
      "strand": -1,
      "locus_tag": "ctg67_38",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,156 - 37,469,\n (total: 1314 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGACAAATGTTTTCTGTCCGATGATTGAACTCGGTGCAATCATCCCCGGTGTTGTACTTGCATATTTTCCAATAAAAAAACATCTCAAACTATCAAAGCTCAGGCTGTTTCCTGTGATGATTTTATCACTTGCGTGCCTTTGTACATTGTGCGGTTTTGTTTGTTACAGATACAATCTGAAATCGTTTGTGCTTGCAATACCAATAGTGCTTGCTCTTTCGGCAGCATACTGTTGTTCACTCAAAACATCCATGTGGAAATCGGTGAGTGTGTTACTTGCGGTATGCGGAGTGTTTGCCTGCATTGCGAGCATTACACGGGCGTTTGATTCGATAACATTTCCGCAGAACACAACGCCGTGGTTTGAAATTAAATCGGCTGTGCTGTTCAATATTCTATGCTGGATGTTTGTAATTCTTGCATGGTATCCTGCAACACACGGTGTGAGTGAACTGCTCGATGATGAAAACATTGCCCAGACATGGTATATATTCTGGATTTTACCGATAATATTCATCTTGCTCAACTTTTTTATAATCCCATGGAATCCTAACATTCTACATACAGGAAGAATTATGCAGGGTTACATTGTTATCAGTGTATCACTTCTTGTGCTGTTGCTCATTTTCTACGCTTTGCTGTATTTTATTGCAAAAAGTCTGAACCGCAATAACAAACTTGCTCAGAAAAATCAATTTTTGAATATGCAGAGGGCACAGTATGACGCATTAAAAGTCGCTATTGAAGAAACCCGTCAGGCACGGCATGATATGCGACATCACTTTGCCGTACTTAATGCTCTTGCCGAGCAAAAGAACTGGGAAGAACTTGAAAAATACCTTTCGTCAGCATCGCAGAATATTCCCGACACAGAGCTTGTACTCTGTAAAAACCACGCTGTTAATGCGATTATCGGACATTATTATTCAAAATACAAGAGCAATGGTATTCCGTTTAAACTAAAAATTGACATTCCCGAAAAGTTGACAGTTTCGGAATCCGATATCTGTCTTGTAATCGCAAATTTGCTTGAAAATGCATTTGAGGCGAGCATGAAGCTTGACAGAGATAAACGGCAGATTAAAATGTATGCCCGTCCGCATTCCGAAAAGATATTGCTTATTTCCGTAGAGAATGCTTTCAATGGAGAGATTACCGAAAAGGATGGATTTTTCGGTTCGTCAAAGCGAAACGGTAACGGTATCGGTACGCAGTCGGTACGCAGAATTGCCGAAAAAGACGGCGGTTATTGCAGATTTTCTCACGAAAATGGGATTTTCACGGCGGATGTTATGCTGCACAGCAAAAACTGA",
      "translation": "MTNVFCPMIELGAIIPGVVLAYFPIKKHLKLSKLRLFPVMILSLACLCTLCGFVCYRYNLKSFVLAIPIVLALSAAYCCSLKTSMWKSVSVLLAVCGVFACIASITRAFDSITFPQNTTPWFEIKSAVLFNILCWMFVILAWYPATHGVSELLDDENIAQTWYIFWILPIIFILLNFFIIPWNPNILHTGRIMQGYIVISVSLLVLLLIFYALLYFIAKSLNRNNKLAQKNQFLNMQRAQYDALKVAIEETRQARHDMRHHFAVLNALAEQKNWEELEKYLSSASQNIPDTELVLCKNHAVNAIIGHYYSKYKSNGIPFKLKIDIPEKLTVSESDICLVIANLLENAFEASMKLDRDKRQIKMYARPHSEKILLISVENAFNGEITEKDGFFGSSKRNGNGIGTQSVRRIAEKDGGYCRFSHENGIFTADVMLHSKN",
      "product": ""
     },
     {
      "start": 37466,
      "end": 38188,
      "strand": -1,
      "locus_tag": "ctg67_39",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,466 - 38,188,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGGATTGCAATAGTTGATGATTGCGAAAATGAGCGAAATGAACTTTGCAAAAGACTTTCTCAAAGCTCATTTTCAAGGTCATATGATATTGAAATTTGCGGATACGGTAACGGAACGGATTTCCTGAATGAGGCAATGCAAAACAGATTTGACCTTGTTTTTATGGATATATATATGGAAAAGGAAAACGGAATTGATGCGGCACAAAAGCTGAGGAAGTTTGACAAAGATTGTCTGCTTGTTTTCACAACCACATCAACTGACCACGCACTTGAAGGTTTTAGGGTTCGGGCATTGCACTATCTTGTGAAGCCGTACAGCGATGACGAGCTTGATATGTTGCTTGATGAGATTTCGCAGAAAATTTCCGTTGAAGAAAAATACATTGAAATACCCTCTGCAAGTGACTCGTTGCGTATAAAGCTTTGCGACATTTTGTATGCCGAGCATTTTAAGCACTGCATACATATTCATTGTACGGACAAATCCGAAAAGTCTGTGCGCAGTACATTTGCCGAATTTGTAATGCTGTTTGATGACGGAGATAATTTCTTTGTGTGCAACCGAGGAATCATAGTAAATCTTGAACACATCAGGGATATGAACGGCAATGAATTTGTTCTTGACAACGGTGAAAGAATCTCCATAAGTCGAAGTCTTGTAAAAAGCGCAAAAAGCACCTTTGGCGAATATATTTTCGGCAGGAGGGATTTGCATTGA",
      "translation": "MRIAIVDDCENERNELCKRLSQSSFSRSYDIEICGYGNGTDFLNEAMQNRFDLVFMDIYMEKENGIDAAQKLRKFDKDCLLVFTTTSTDHALEGFRVRALHYLVKPYSDDELDMLLDEISQKISVEEKYIEIPSASDSLRIKLCDILYAEHFKHCIHIHCTDKSEKSVRSTFAEFVMLFDDGDNFFVCNRGIIVNLEHIRDMNGNEFVLDNGERISISRSLVKSAKSTFGEYIFGRRDLH",
      "product": ""
     },
     {
      "start": 38376,
      "end": 40406,
      "strand": 1,
      "locus_tag": "ctg67_40",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,376 - 40,406,\n (total: 2031 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTAACAAAAAGAAAACGGGACTTTGCCTTGCTTTGGCGGCAACATTGATTGCCTCGTCTGCACTTTGCGGATGTCAGCAGAGCGACAGCAGTACATCCGCAAAATTCAACAGCGATGTAAAGGATGCGTCAAAATATACGGCTGACGAAAACGCACAGGTGTATAAGACCCTTGACTTTTCCGATGAACAGGAAAAGGAATTTGCAAAAAAGGGCTTTATAACAGCACCCGACAAACTCGAAATCAAAACCGAGAATGGTACTGTTGCATGGAGCCAGACAGCATATGATTTTATCAGAAACTCGTCAACTCCCGACAGTGCAAACCCAAGCCTTTGGAGAAACACGGAGCTTAACTCGCTTTATGGACTTTTTGAAGTTGTTGATGGTGTTTATCAGGTCAGAGGCTACGATGTTGCCAATGTAACCTTTGTAAAGAGCGACAACGGCTGGATTGTTTTTGACTGTACAACAAGCTCCGAAACTGCAAAGGCGGCACTTGAACTTCTTGAATCAAAGTTCGGCAAGGCGCATATTGCCGCTGTTGTTGTAAGCCACGCCCACATTGACCACTACGGCGGTATCGGCGGACTTATTGACGAAAAGGATGTTGCCGATTCATCACTTCCGCTTGATGAACAGATTAAGTCCGGCAAAACGCTCATTATCGTTCCCGAAGGCTACGAAAAGGCTGTTATGGAAGAAAATGTTTTTGCAGGAAACGCAATGAAACGCAGAACCAACTTTCAGTACGGATCATTGCTTGATAAGGGCGGTAAGGGCAGTTTGTCGGTAGGTATCGGCCTTACCCCTTCAAGCGGCACAACAACATACATTTCACCGTCTTATGAGGTAAAGAAAGCTACCGAAACTATCAAGGTTGACGGTGTTGAAATGGTGTTCCAGCTTACTCCCAACACAGAATCGCCTGCCGAGATGAATACCTATATTCCAAAATACAAGGCGTTGTGGATGGCAGAAAACTGTTCCGGCACAATGCACAACCTCTACACACTCAGAGGCGCAGAGGTTCGTGACGGCAATGCGTGGGCGCAGTACATTATGGAGGCAAAGGAGCTTTTCGGAGATAAGGCCGAAGTAGTTTTCCAGGCTCACAACTGGCCGCATTGGGGCAACGATGTAATCAATGACTACATGGCAAACACAGCCTCTGTCTATAAGTACATATTCTCACAGACACTTATGTACATCAATCAGGGCTATACTTCAACCGAGATTGCAAATATGATTGAACTCCCCGATGAACTCAACAAGGTTTGGTACACACGCCAGTATTACGGAACTCTCAAGCACAATGTAAAGGCAGTTTATCAGAAGTATATGGGTTGGTATGACGAAAACCCCATTCACCTTGACGAGCTTGAACCGACAGAATATTCAAAGAAGCTTGTTGAGTATCTCGGCGATACAGACAAGGTTCTTGAAATGGCTAAAAAAGACTTTGACAAGGGAGAGTATCAGTGGGTTGCACAGATTACAAACACACTTGTATATGCAGATCCCGAAAATAAAGACGCCCGCTATCTTTGCGCAGACGCACTCGAACAGCTCGGCTATCAGGCTGAAAGTGGTGCATGGAGAAACGCTTATCTTACAGGTGCTTATGAGCTTCGTAACGGTACAAAAAATTATCCGAATTCCGAAGGTTCAGGTGCAACAGCTCTCGGTATGAGTACCGAAACAATGTTGGATTATCTCGGAATCTGTCTTGACGAAAAGAAGCTTGAAGATCAGAACCTTGTAATCAATCTTGAAGTGACCGATAAAAACGCAAAATATCTTCTTCGCATAAATCACGGTGTGCTTATCTATTCACAGGAAAAGTGGAGCGATAAGGCTGACGCAACAATCAAAACCAAGAGCGCAGGTATTCTCGGCATTGCACAGAACAATCAGAAACTTATGGACGCCGGCATTGAAAAGGTTGAGGGCAACAGTGACATCATCAAAACCCTTACATCAAGCGTTGCCGAATTCCCGCTGTATTTCAATATTATTGAACCCTAA",
      "translation": "MINKKKTGLCLALAATLIASSALCGCQQSDSSTSAKFNSDVKDASKYTADENAQVYKTLDFSDEQEKEFAKKGFITAPDKLEIKTENGTVAWSQTAYDFIRNSSTPDSANPSLWRNTELNSLYGLFEVVDGVYQVRGYDVANVTFVKSDNGWIVFDCTTSSETAKAALELLESKFGKAHIAAVVVSHAHIDHYGGIGGLIDEKDVADSSLPLDEQIKSGKTLIIVPEGYEKAVMEENVFAGNAMKRRTNFQYGSLLDKGGKGSLSVGIGLTPSSGTTTYISPSYEVKKATETIKVDGVEMVFQLTPNTESPAEMNTYIPKYKALWMAENCSGTMHNLYTLRGAEVRDGNAWAQYIMEAKELFGDKAEVVFQAHNWPHWGNDVINDYMANTASVYKYIFSQTLMYINQGYTSTEIANMIELPDELNKVWYTRQYYGTLKHNVKAVYQKYMGWYDENPIHLDELEPTEYSKKLVEYLGDTDKVLEMAKKDFDKGEYQWVAQITNTLVYADPENKDARYLCADALEQLGYQAESGAWRNAYLTGAYELRNGTKNYPNSEGSGATALGMSTETMLDYLGICLDEKKLEDQNLVINLEVTDKNAKYLLRINHGVLIYSQEKWSDKADATIKTKSAGILGIAQNNQKLMDAGIEKVEGNSDIIKTLTSSVAEFPLYFNIIEP",
      "product": ""
     },
     {
      "start": 40425,
      "end": 40970,
      "strand": 1,
      "locus_tag": "ctg67_41",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,425 - 40,970,\n (total: 546 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGTATTTAATTGTATTTTCGGCATATTGTCGATAATAGGCGCAATTTATTGTATGTTCTATCCGGGACTTACCTTCCTTAATACCGGTTGGATAGTGACAATCCTTCTCGGAGTATGGGGAATATGCTCCGTGATTGACTACTTTGCAAAACGCAAAAAGGCAAAGGCTGAACAGAGTGAAGCAATAATGGGAACACTCGGCCTTGTTGTCGGCATTGCAGCGGCAGTAATTTCAATTCTTGCTATGTTTATGCCGGGCATAAGACTTATGTTTGATGTTATCATTCTCTGCATTTTCTCAGGTTGGCTTGTAGTGGACGGTATCTCGTCCGTTGCAATGTCACTCAAGGTCAAAAAAGCATCTTCCTCAGGTGCATGGCTTATTCCGCTTTTCTGCGGAATACTCGTCATAATCGGCGGTATCTACGGATTTTTCCACCTTATATTTGCCGCACAGACAATCGGATTTATGATTGGTGTCCTTTTGTCAATCTACGGTGTAAAGCTTATTCTTTCGGCATTTGAAAAGCCGAGCGTGTAA",
      "translation": "MKVFNCIFGILSIIGAIYCMFYPGLTFLNTGWIVTILLGVWGICSVIDYFAKRKKAKAEQSEAIMGTLGLVVGIAAAVISILAMFMPGIRLMFDVIILCIFSGWLVVDGISSVAMSLKVKKASSSGAWLIPLFCGILVIIGGIYGFFHLIFAAQTIGFMIGVLLSIYGVKLILSAFEKPSV",
      "product": ""
     },
     {
      "start": 41608,
      "end": 42270,
      "strand": -1,
      "locus_tag": "ctg67_42",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,608 - 42,270,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGTTATGAATGTTAATCCCACCCGTATGCAGTTGACAAAGCTGAGAAAACAGCTTGCAACAGCTACCCGTGGTCATAAAATGTTAAAAGACAAGCGTGACGAACTGATGCGCCGATTTCTTGACCTTGTAAGAGAAAACAAGGAGCTTCGTGAGAAGATTGAAAGAGAGCTTGCAGAGTGCAACAACCACTTTGTGAACGCAAGTGCGGTTATGTCAAAAGAGGCTCTGGACGCCTCATTGATGTCACCGAAGCAGAGAATTGACCTTGAGCTTTCTTCAAAAAATGTTATGAGCGTTGATATTCCGCAGTTTTCATCAAGCACACGAACAAGCAACGAGGGCGATATTTTTCCCTACGGTTTTGCGTTTACTTCGTTTGAACTTGATGATGCGGTTATGTCGCTCAACGAGCTTTTGCCCGACCTGATAAGGCTTGCTGAAATTGAAAAAAGCTGTGAGCTTATGTCGGCAGAAATTGAAAAGACACGCCGCCGTGTTAATTCGCTTGAGCATGTTATGATTCCGAGATATCAGGAAACAATCAAGTATATCTCGATGAAACTTGAAGAAAATGACCGCAGCAGTCGTACAAGGCTGATGAAGGTTAAGGATATGCTTCTTGACAAGGCACATCATTATTCGGAACACTATAATTAA",
      "translation": "MAVMNVNPTRMQLTKLRKQLATATRGHKMLKDKRDELMRRFLDLVRENKELREKIERELAECNNHFVNASAVMSKEALDASLMSPKQRIDLELSSKNVMSVDIPQFSSSTRTSNEGDIFPYGFAFTSFELDDAVMSLNELLPDLIRLAEIEKSCELMSAEIEKTRRRVNSLEHVMIPRYQETIKYISMKLEENDRSSRTRLMKVKDMLLDKAHHYSEHYN",
      "product": ""
     },
     {
      "start": 42292,
      "end": 43665,
      "strand": -1,
      "locus_tag": "ctg67_43",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,292 - 43,665,\n (total: 1374 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAAAGGAATACCGCACAATACGAGAGGTTGCAGGTCCTCTTATGATGGTAAGTGATGTTGAGGGCGTAACATATGACGAACTCGGCGAAATTGAACTTCCGAACGGTGAAACACGCCGTTGCAAGGTTCTTGAGGTTGACGGCTCAAACGCACTTGTTCAGCTTTTTGAATCAGCCGCAGGCATTAACCTTGCAAATTCAAAGGTAAGATTTTTAGGTCGTTCAATGGAACTTCCCGTATCTCCCGATATGCTTTCACGAGTATTTGACGGTCTTGGAAATCCGATTGACGGCGGTCCTGCTCTTATTCCCGAAAAAAGACTTGACATCAACGGAACCCCTATGAACCCTGCCGCAAGAAACTATCCGCAGGAATTTATTCAGACAGGTATTTCAGCAATTGACGGACTTAACACACTTGTAAGGGGACAGAAGCTGCCTATCTTCTCGGCATCGGGTCTGCCCCATGCCCAGCTTGCCGCTCAGATTGCAAGACAGGCGGCTGTAAGAGGCAAGGACGAACAGTTTGCCGTTGTATTTGCCGCAATGGGTATTACATTTGAAGAGTCCGACTACTTTGTTCAGTCGTTTAAAGAAACAGGCGCTATTGACAGAACCGTAATGTTTGTAAACCTTGCAAACGATCCTGCCATTGAGCGTATTGCAACTCCTAAAATGGCACTCACGGCGGCTGAATATCTTGCATTTGACAGAGGAATGCATGTTCTCGTTATTATGACCGACATCACAAACTATGCCGATGCGCTCCGTGAGGTTTCTGCCGCAAGAAAAGAAGTTCCGGGCAGACGAGGCTATCCGGGTTATATGTACACAGACCTTGCAACATTGTATGAAAGAGCCGGCAGACTTAAAGGCAAAGAGGGTTCAATCACTCTTATTCCGATTCTTACAATGCCCGAAGATGACAAGACTCACCCGATTCCTGACCTTACAGGCTACATTACAGAAGGTCAGATTATCCTATCCCGTGAGCTTTACAGAAAGGGAATTACTCCGCCGATTGATGTTCTTCCGTCACTTTCAAGACTTAAAGACAAGGGTATCGGCCCTGACAGAACCCGTAAAGACCACGCCGCAACCATGAACCAGCTTTTTGCCGCTTATGCAAGAGGTAAAGACGCAAGAGAACTTATGATAATTCTCGGTGAGGCGGCTCTTACCGATATGGATAAAAAGTACGCTGAATTTGCCGAGGCATTTGAGCGTGAGTATGTTTCACAGGGTTATGACGCAAACCGTTCAATTGAAGAAACACTTGACATCGGCTGGAAGCTTTTGCATATTCTTCCCAGAAGTGAACTTAAACGAATTAAGGACGATATGCTTGACGAGTTTTACGGTAAAGAATAA",
      "translation": "MPKEYRTIREVAGPLMMVSDVEGVTYDELGEIELPNGETRRCKVLEVDGSNALVQLFESAAGINLANSKVRFLGRSMELPVSPDMLSRVFDGLGNPIDGGPALIPEKRLDINGTPMNPAARNYPQEFIQTGISAIDGLNTLVRGQKLPIFSASGLPHAQLAAQIARQAAVRGKDEQFAVVFAAMGITFEESDYFVQSFKETGAIDRTVMFVNLANDPAIERIATPKMALTAAEYLAFDRGMHVLVIMTDITNYADALREVSAARKEVPGRRGYPGYMYTDLATLYERAGRLKGKEGSITLIPILTMPEDDKTHPIPDLTGYITEGQIILSRELYRKGITPPIDVLPSLSRLKDKGIGPDRTRKDHAATMNQLFAAYARGKDARELMIILGEAALTDMDKKYAEFAEAFEREYVSQGYDANRSIEETLDIGWKLLHILPRSELKRIKDDMLDEFYGKE",
      "product": ""
     },
     {
      "start": 43665,
      "end": 45431,
      "strand": -1,
      "locus_tag": "ctg67_44",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,665 - 45,431,\n (total: 1767 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAAATCTGGAATTATAACTAAGGTAGCAGGCCCTCTGGTAATTGCCGAGGGTATGCGTGATGCCGATATGTTCGATGTTGTGCGTGTAAGCAGTCAGCGACTTATCGGTGAAATAATCGAGATGCACGGTGACAGGGCATCAATTCAGGTATATGAAGAAACTTCGGGACTCGGACCCGGTGAGATTGTTGAATCCACAGGCGCTCCGCTTTCCGTTGAACTCGGTCCGGGACTTATCGGTTCAATTTATGACGGTATTCAGCGACCGCTTAACGAGATTATGAAGGTTGCCGGCACAAACCTCAAAAGAGGTGTTGATGTTCCGTCACTTGACCACAAAAAGAAGTGGCACTTTACTCCCCTTGTTAAAAAGGGCGACACAGTTGCGGCAGGCGACACACTCGGTACTGTTCAGGAAACACACGCTGTTCTTCACAGGATCCTTGTTCCGAACAAAACAGGCGGTGTTGTTGAAAGCATCAGCGAGGGTGATTTTACAATTGACGAAACGGTTGCCGTTCTCAAAACAGACAAGGGCAATGTTGAGATTAATATGTGTACAAAATGGCCTGTTCGTGTTGGCAGACCGTACAAAAGAAAGCTCTCCCCCGACATTCTTCTTACCACAGGTCAAAGACCTATTGACACACTCTTTCCGCTTGCAAAGGGCGGTGTAGCCGCAGTTCCGGGACCGTTCGGTTCGGGCAAAACTGTTGTTCAGCATCAGCTTGCAAAGTGGGCGGCTGCCGATATTATCGTATATATCGGTTGCGGTGAGCGTGGCAACGAGATGACCGATGTTCTTAACGAGTTCCCCGAACTTAAAGATCCACGCACAGGCAACTCTCTTATGGAGAGAACCGTGCTTATTGCAAACACATCCGATATGCCTGTTGCCGCCCGTGAGGCATCTATCTACACAGGCATTACTATTGCCGAGTATTTCCGTGATATGGGTTACACGGTTGCACTTATGGCTGACTCAACATCCCGCTGGGCAGAGGCTCTCCGTGAAATGTCCGGCCGTCTTGAAGAAATGCCGGGTGAAGAGGGTTATCCCGCATACCTCGGCAGCCGACTTGCACAGTTCTATGAAAGAGCAGGCCGTGTTATCGTAAACGGCAGTGACGACACGGAAGGCGCACTCTCGGTTATAGGTGCTGTATCACCTCCGGGCGGTGATATTTCAGAGCCTGTATCACAGGCAACACTCAGAATCGTTAAGGTATTCTGGGGACTTGACGCAAACCTTGCTTACAAACGACACTTCCCTGCAATTAACTGGCTGACAAGTTATTCGCTTTATACAGACCGACTTGCAGATTGGTTCTCAAAGAATGCCGCTCCCGACTTTATGGAGCTTCGTGGCAAACTTATGACATTATTACAGGAAGAAAGCGAGCTTCAGGAAATCGTAAACCTTGTCGGTATGGACGCACTTTCCGCACCCGACAGACTTAAGCTTGAAACCTCCCGTTCAATCCGTGAGGATTATCTGCACCAAAACGCATTTGACCCGACAGACACATACACATCTCTCGGCAAGCAGGTGCTTATGATGCGTGCAATTCTTGTTTACTATGACAAAGCAAAAGAGGCTCTTGCAAACGGTGCAGACATTGAAATGCTTGTCAACCTTCCTGTTCGTGAACGCATAGGAAGATATAAATATGTACCCGAGGATAAGGTTCGGGACGAGTTCGAGTCAATCAAGGCTCTGCTTGATTCGGAAATTAAGGATGTACTTGAAAGGAGTGAGGACTGA",
      "translation": "MKSGIITKVAGPLVIAEGMRDADMFDVVRVSSQRLIGEIIEMHGDRASIQVYEETSGLGPGEIVESTGAPLSVELGPGLIGSIYDGIQRPLNEIMKVAGTNLKRGVDVPSLDHKKKWHFTPLVKKGDTVAAGDTLGTVQETHAVLHRILVPNKTGGVVESISEGDFTIDETVAVLKTDKGNVEINMCTKWPVRVGRPYKRKLSPDILLTTGQRPIDTLFPLAKGGVAAVPGPFGSGKTVVQHQLAKWAAADIIVYIGCGERGNEMTDVLNEFPELKDPRTGNSLMERTVLIANTSDMPVAAREASIYTGITIAEYFRDMGYTVALMADSTSRWAEALREMSGRLEEMPGEEGYPAYLGSRLAQFYERAGRVIVNGSDDTEGALSVIGAVSPPGGDISEPVSQATLRIVKVFWGLDANLAYKRHFPAINWLTSYSLYTDRLADWFSKNAAPDFMELRGKLMTLLQEESELQEIVNLVGMDALSAPDRLKLETSRSIREDYLHQNAFDPTDTYTSLGKQVLMMRAILVYYDKAKEALANGADIEMLVNLPVRERIGRYKYVPEDKVRDEFESIKALLDSEIKDVLERSED",
      "product": ""
     },
     {
      "start": 45443,
      "end": 45766,
      "strand": -1,
      "locus_tag": "ctg67_45",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,443 - 45,766,\n (total: 324 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTAAAAATATTGCCGTTATCGGCGACAGCGAAAGCATAAAGGGCTTTGCGGCAATCGGCATGGACATTTATCCGTGTGATGACAACGAAAACGCACCGCATCTTTTCAGAAAGATTGCTGACGGTGACAACTATGCGGTAATTTTTATTACCGAGGAAATGTTCGGACTTGTTGAAAAAGAGCGAAAAAGATATGAAGAAAGGCTCATTCCTGCCGTTATTCCTATCCCCGGAGTAAAAGGCAATACGGGAATCGGCATAAAAAGACTGTCGTCATTTGTTGAAAAGGCAGTCGGTTCGGACATTATCTTCAATGATTGA",
      "translation": "MAKNIAVIGDSESIKGFAAIGMDIYPCDDNENAPHLFRKIADGDNYAVIFITEEMFGLVEKERKRYEERLIPAVIPIPGVKGNTGIGIKRLSSFVEKAVGSDIIFND",
      "product": ""
     },
     {
      "start": 45759,
      "end": 46730,
      "strand": -1,
      "locus_tag": "ctg67_46",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,759 - 46,730,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCATTATCTTATGAATTTTCCATCGGCTCCGTCCGTGCTAAAGAAAAAAATCTGTTTACAAACAGCGACATTGAGCATATGCTCGGTTGTGAAAATGTGAACGAGCTTTGCAGATACCTCTCGGACAAGGGTTACGGCGAGGGTGATGACATTGAAGAGATTTTGAAATCACACAGCAAAAATGTGTGGGAATATCTTAAAAGAACCGCACCCGATTTTGCAATATTCACACCGTTCTTCTATCTTAACGACCTTCACAACCTTAAAGCTGTTTTAAAGGGAACGCTTTCAAACAGACCGTATTCACAGCTTTTGGTAAAGCCGTGTACTTTCTCTGAAGAAACGCTTAAACAGGCGGTTGAGAACAGAAAGTTTTCACTTTTAGGCGAAGAACTTTCCGCACCTTGTGACAAGGCATATGAAATTCTTGCACACACAGGTGACGCAAGACTCAGCGATGCGGTTCTTGACAGAGCTTTTATGGAGCTTGTTCTGAAAACATCCGAAAAATCCGACAGCGAATTTATGTCCGAATATTTTAAAGCTACAGTATTTTATAATAATGTAAAGACAGCCATAAGAGGTGCAAAAGCCGATTGCGACAGGGATTTTCTTGAAATTGCAATCTGTGATGTGCAGGACTTCCCCCGTTCAAGGGTTATTGAGGCAAGCGTAAAGGGACTTGAACCAACGCTTGATGTGCTGTCAAAAATCTCGGCATACGGCTGTAACAAGGCTGTTGAAGAGTACAAGGCTTCTCCGTCGGCATTTGAAAAATTTGTTGACAACAAGCTTATGAGCCTTGCAAAAGAAAAATGCAAAAGAAGCGGTGACGGTGCAGATCCGATTACAGGCTATCTGATTGCAAGTGAAACAGAGAAAAAAGTTATTCACATTATTGCAAGCGGAATCCGCACCAAGACAAATTATGAAACCGTAAAAGAAAGGTTGCGTGAAGTTTATGGCTAA",
      "translation": "MALSYEFSIGSVRAKEKNLFTNSDIEHMLGCENVNELCRYLSDKGYGEGDDIEEILKSHSKNVWEYLKRTAPDFAIFTPFFYLNDLHNLKAVLKGTLSNRPYSQLLVKPCTFSEETLKQAVENRKFSLLGEELSAPCDKAYEILAHTGDARLSDAVLDRAFMELVLKTSEKSDSEFMSEYFKATVFYNNVKTAIRGAKADCDRDFLEIAICDVQDFPRSRVIEASVKGLEPTLDVLSKISAYGCNKAVEEYKASPSAFEKFVDNKLMSLAKEKCKRSGDGADPITGYLIASETEKKVIHIIASGIRTKTNYETVKERLREVYG",
      "product": ""
     },
     {
      "start": 46742,
      "end": 47323,
      "strand": -1,
      "locus_tag": "ctg67_47",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,742 - 47,323,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAGCAGCGGTGATAAAATTTTAAATCGCATAAGTCTTGACTGTGACGAAAGAATCAGCCAAATAGGTGCTGAAACCGATGAAAAATGCGCACAGATTATGGCACAGGCAAAGCTTGATGCCGACAAGATTTCTGCCGAAATTGCCGACAGGGCACAGTCAAAGGTCAAGCAGATGCAGGCGGCTTCAAAGAGCCGTTGCGACCTTGAAACACGCAACGCTTTCCTGAAGAGAAGGCGTGAAGAAATTGACAAGACATACAGTGAAATTCTTAATAAAATGAAAAATCTTCCCGATGAAGATTACTTTGAACTGATTTACACATTTGCAAAAAAGTTAAACGGAATGAGCGGTGTTGTGCTTTTGAATGAAAAGGATATGAACCGACTTCCGAAGGATTTTCTTGCAAGGCTTGAAGAATGCGGTGTAAAAGCAGAGCTTTCAAAAACGCCGTGTGACATTGAAAGCGGATTTATTCTTAAATGCGGTGACATTGAAGAAAACATGGACTTCTCGGCAATATTGTCCGAAAAGTGTGACGCTATCGAGGATTTTATAAATCAGGAACTTTTTAAGGCATAG",
      "translation": "MSSGDKILNRISLDCDERISQIGAETDEKCAQIMAQAKLDADKISAEIADRAQSKVKQMQAASKSRCDLETRNAFLKRRREEIDKTYSEILNKMKNLPDEDYFELIYTFAKKLNGMSGVVLLNEKDMNRLPKDFLARLEECGVKAELSKTPCDIESGFILKCGDIEENMDFSAILSEKCDAIEDFINQELFKA",
      "product": ""
     },
     {
      "start": 47365,
      "end": 47838,
      "strand": -1,
      "locus_tag": "ctg67_48",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,365 - 47,838,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATGGAATATTTTTCGCACTTTTAGGCGCATCAATAGCAACAGCACTTGCAGGCGTAGGTTCTGCTCGAGGTGTAGGCTCTGCCGCACAGGCAGCTATGGGAGTTCTTTCCGAGGACTCATCAAAATTCGGTAAAATGCTCGTTCTCACACTTCTCCCGGGTACTCAGGGACTTTACGGATTTATCGTAGGCTTCCTTATTCTCGTAAGCGGCGGCGTTCTCGGCGGCACAGCTCCGACAATCGGACAGGGACTTGCATACTTTGCAGCATCGCTTGCTATCGGTATCGGCGGTATGATTTCAGGTTTTGCACAGGGCAAGGCAGCCGTTTCGGGTATTGCACTCAGCGCAAAGGATGATTCAAACTTCTCAAAGGCAATGGTTTCCGTAACTCTCGTTGAGATTTACGCTCTCCTTTCATTCATCGTTTCACTTCTCGTTGTTATCACAGTTCCAAACCTTAACATCTGA",
      "translation": "MNGIFFALLGASIATALAGVGSARGVGSAAQAAMGVLSEDSSKFGKMLVLTLLPGTQGLYGFIVGFLILVSGGVLGGTAPTIGQGLAYFAASLAIGIGGMISGFAQGKAAVSGIALSAKDDSNFSKAMVSVTLVEIYALLSFIVSLLVVITVPNLNI",
      "product": ""
     },
     {
      "start": 47835,
      "end": 49823,
      "strand": -1,
      "locus_tag": "ctg67_49",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,835 - 49,823,\n (total: 1989 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGGCAAAACTTAAAATGAAGTCGGTTCGGATTATTGCCCTAAGACAGGACAGAAAGCGACTTCTTGAACATTTGCAGGATTCGGGTTTGGTTCAGATTGAAAAGACCGAAACCTGCAGAAAAGGTTTCGGCAAGATTGATATGACCTCACAAATTCAGATTTTCGAGCGGAATGTTACTCTCAGTGAAAACGCTCTGAAAATTCTCGACAGCAACTCTCCCGAAAAGAAAAGTATGCTTTCCGCATTTTGCGGACGGCGAGAGATTGATCCCGATGAAATCGGAGTTATCGCATCAAATGCAGGCGAAGTTATTGATGTGTGCAACAGAATTTGTGAGCTTAACAAACAGATTGCCGATAATGCGGCGGAACGGATTCGCATAAAAACCGCTCTTGCACAGCTTGAGCCGTGGAAAAACCTTGACATTCCGCTTAATGCAAAGGACACAAAAACAACGGCTGTTTTCATAGGCTCAATTCAAAAGGAGTACAACGAGGTATCGCTTTCAGAGGCACTTGCCGAGGCTTCTCCGAAGCTTGAATTTGATTTTGAAATTCAATTTGCAAACGAGGGGCTTACCTGTATTGTACTTTTTGCACCGATTGCCCAAAAGGAGCTTGCGGAAAATACTCTGCGTGACATTGGTTTTGCAAAGCCTGTTACGAACTCAAGCCTTACCCCTTTGGCGGAATCAAAAAAGCTTGTTGAAAGAAGTCACAAGCTTGAAGACGACACGGAAAATGCAAAAAAAGAAATCATTTCCTTTGCAGACAGACGAAAAGATATTAAAGATACACAGGATTATTTCAGAATCAGAGCCGATAAATACAGCGTAATCGGTGAACTTCAGCATTCACGGAATGTTTTTGTCATTTCGGGTTACATTCCCGAGGAGGACTGTGAAAAGCTTGAAAGGCTTTGCGAAAGAGTTTCTGTATGCTATGTTGAATTCGGCGATGTTGACGAGGAAAAAGCTCCTGTAAAGCTAAAGAACAGTCGCTTTGCAGCACCGGCAGAGAGCATTGTAAATATGTACTCTCCCCCGTCGCATGACGATATTGATCCAACGCCGTTGCTTGCATTCTTCTTCTACTTTTTCTTTGGAATGATGTTCTCGGATGCAGGCTACGGACTGTTAATGGTAATAGGAACAGGACTTGCAATAAAGCTGTTCAAGCCTGACAAGGAAATGCGAAACACCTTGAAACTGTTCCAGTACTGCGGTATTTCAACATTTTTCTGGGGACTTGTTTTTGCAAGCTTCTTCGGAGATGCCCCCGCAACCCTTTACAACTACTTTACGGGTGCAGACATTACGATGAAGCAAATCTTCCCGTGGCCGACAATTGACCCGCAAAAGGACGCACTTATGCTGATGATTATTTCAATAGCATTCGGTCTTGTACACATTCTTGTCGGTATGGGCTGCAAATTCTATGTTTGCCTCAGGCAGAAGGATTATGGCGGAGCGTTCTTTGACACGGGGCTTTGGATGCTTATGCTTATCGGATTTGCAGTTTTGGCGGCAGGTATGGCGTTCGGTCAGACACTCGTCTATGTCGGAGCAGGCATTGCGATTTTCTGCGCAATCGGTCTTGTTCTCACACAGGGCAGAAACAAAAAGGGATTCGGCAAAGTCATCGGCGGACTTGCCTCTCTCTATGACATCACAGGTTACATCAGTGACCTTCTGAGCTACTCAAGACTTCTTGCTCTCGGACTTACAACGGGAGTTATGGCTCAGGTGTTCAATATGCTTTCAACCATGTTCGGCAAGAGCTGGTTTGGAATTATCTTACTCATTATTGTGTTCATCATCGGACACGCAATCAACATCGGACTCAACGCACTCGGTTCATATGTTCACACAATGCGACTTCAGTATGTTGAAATGTTCGGAAAATTCTATGAGGGCGGCGGCAAACAGTTTAAGCCGTTCAAGCTCAACAGTAAATATATTAAAATTCAGGAGGACAAATCAAAATGA",
      "translation": "MAKLKMKSVRIIALRQDRKRLLEHLQDSGLVQIEKTETCRKGFGKIDMTSQIQIFERNVTLSENALKILDSNSPEKKSMLSAFCGRREIDPDEIGVIASNAGEVIDVCNRICELNKQIADNAAERIRIKTALAQLEPWKNLDIPLNAKDTKTTAVFIGSIQKEYNEVSLSEALAEASPKLEFDFEIQFANEGLTCIVLFAPIAQKELAENTLRDIGFAKPVTNSSLTPLAESKKLVERSHKLEDDTENAKKEIISFADRRKDIKDTQDYFRIRADKYSVIGELQHSRNVFVISGYIPEEDCEKLERLCERVSVCYVEFGDVDEEKAPVKLKNSRFAAPAESIVNMYSPPSHDDIDPTPLLAFFFYFFFGMMFSDAGYGLLMVIGTGLAIKLFKPDKEMRNTLKLFQYCGISTFFWGLVFASFFGDAPATLYNYFTGADITMKQIFPWPTIDPQKDALMLMIISIAFGLVHILVGMGCKFYVCLRQKDYGGAFFDTGLWMLMLIGFAVLAAGMAFGQTLVYVGAGIAIFCAIGLVLTQGRNKKGFGKVIGGLASLYDITGYISDLLSYSRLLALGLTTGVMAQVFNMLSTMFGKSWFGIILLIIVFIIGHAINIGLNALGSYVHTMRLQYVEMFGKFYEGGGKQFKPFKLNSKYIKIQEDKSK",
      "product": ""
     },
     {
      "start": 49858,
      "end": 50169,
      "strand": -1,
      "locus_tag": "ctg67_50",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,858 - 50,169,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAAAGATATGCTGGACGCCATTTACAATGCCGAAGAGGATTGCAGACAGCGTGAGGCAAATGCACGAGCAGAATCAGCAGAAAGGATTGAACAGACAAAGGCAGATGCCAAACAGGTTGTGCTTTCGGCAAAGGAAAAGGCACAGAAGGATGCCGATATGCTTTTTGAAAAGACTGCGAAAGAGGGCAAAAAAGAGCTTGAGAAAGCCTCTGAAAAGGCAAATCTTGAGTGCGACATTCTCTCTCAAACTGCAGACAAAAACCGCAAGCGTGTTATTGACGGGGCTATACAAAGGCTCTCTCTTTAA",
      "translation": "MAKDMLDAIYNAEEDCRQREANARAESAERIEQTKADAKQVVLSAKEKAQKDADMLFEKTAKEGKKELEKASEKANLECDILSQTADKNRKRVIDGAIQRLSL",
      "product": ""
     },
     {
      "start": 50699,
      "end": 51244,
      "strand": 1,
      "locus_tag": "ctg67_51",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,699 - 51,244,\n (total: 546 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGAAAAGTTGTATTATGTGAGGGTAATAACAAGATGGCAATATGCATGGAGGATTGTGTATTTATGAAAGAAATCAAGACAAATGTAATGAGAATTTTAGACAAAGAAAAGGTTGAATATACTCACCATGAATATCCCCACGGCAAGGATGCCGTTGACGGAGTAACGGTTGCAACGCTTATGAATCAAAATCCCGATTATGTTTTCAAAACTCTTGTAACAAAGGGCATGGGCAGAGATTATTATGTTTTCGTAGTTCCTGTTGACCATGAGCTTGACCTTAAAAAATGTGCAAAGAGTGTGGGGGAAAAGTCGGTTGAAATGATTCCCGTAAAGGACATTACAAAGGTCACGGGTTATGTGCGTGGAGGCTGTTCACCTCTCGGAATGAAAAAGCAGTTCAAGACAACCTTCCACATTACAGCAGAGTCAATTCCGAAAATCATTGTCAGTGCAGGAAAAATCGGATATCAAATTGACCTGAAGCCTGAGGATTTAATTCGTCTTACAAACGGTCAATGTGCCGATATTATTAAAAATTAA",
      "translation": "MRKVVLCEGNNKMAICMEDCVFMKEIKTNVMRILDKEKVEYTHHEYPHGKDAVDGVTVATLMNQNPDYVFKTLVTKGMGRDYYVFVVPVDHELDLKKCAKSVGEKSVEMIPVKDITKVTGYVRGGCSPLGMKKQFKTTFHITAESIPKIIVSAGKIGYQIDLKPEDLIRLTNGQCADIIKN",
      "product": ""
     },
     {
      "start": 51258,
      "end": 52046,
      "strand": 1,
      "locus_tag": "ctg67_52",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,258 - 52,046,\n (total: 789 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1089:methyltransferase (Score: 62.6; E-value: 6.7e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGGATATTGTTGACAAAAATATAGACAACGGAAATGCTTTTGACTGGGGCAGAGTGTCAGCCGAATATGCAAAATATCGTGATATTTATCCGCAAAAATTTTATGATCAAATTGTTGACAGAGGGCTTTGTGTAAAAGGTCAGAAAATTCTTGATATTGGCACCGGAACAGGAGTTATTCCGAGAAATATGTATCGCTATGGCGGAGAGTGGGTTGGTACAGATATTTCAAAAGAGCAAGTTGGTCAGGCTCGTTTATTATCAAAAGGTATGAATATAAAATATTTTACTGTAGCAACAGAGAATATAAATTTTCCTGATGAATCGTTTGATGTTATCACAGCTTGTCAGTGCTTTTGGTATTTTGACCACCAAAAGATTATGCCTGAACTTTACAGAATGTTAAAGCCAAATGACAGGTTGTTAATTCTTTATATGGCTTGGTTACCGTATGAAGATGAGATAGCAGGGCAGAGTGAAAAACTTGTATTGAAATACAGTCCCGATTGGAGCGGTGCAGGAGAAACTATTCATCCGATAAATATTCCGAAATGTTATGAAGAAAAGTTTGATTTGATTTATCACAACGAATATCCGCTCAAGGTATATTTTACAAGAGAGTCATGGAACGGCAGAATGAAGGCTTGCCGTGGTGTAGGTGCGTCACTCTCAAAAGAAAAAATTGAATTGTGGGAGAATGAACATAAAAATTTACTCTTAAAAATTGCACCGCCTGAATTTGATGTGTTGCATTATGCCGCAATTGCTGAATTAAAAGTAAAGAAATAA",
      "translation": "MDIVDKNIDNGNAFDWGRVSAEYAKYRDIYPQKFYDQIVDRGLCVKGQKILDIGTGTGVIPRNMYRYGGEWVGTDISKEQVGQARLLSKGMNIKYFTVATENINFPDESFDVITACQCFWYFDHQKIMPELYRMLKPNDRLLILYMAWLPYEDEIAGQSEKLVLKYSPDWSGAGETIHPINIPKCYEEKFDLIYHNEYPLKVYFTRESWNGRMKACRGVGASLSKEKIELWENEHKNLLLKIAPPEFDVLHYAAIAELKVKK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 30440,
      "end": 32639,
      "tool": "rule-based-clusters",
      "neighbouring_start": 10440,
      "neighbouring_end": 52639,
      "product": "HR-T2PKS",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "HR-T2PKS",
    "products": [
     "HR-T2PKS"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS HR-T2PKS",
    "anchor": "r67c1"
   }
  ]
 },
 {
  "length": 4232,
  "seq_id": "NZ_WHCC01000070.1",
  "regions": []
 },
 {
  "length": 4117,
  "seq_id": "NZ_WHCC01000071.1",
  "regions": []
 },
 {
  "length": 3945,
  "seq_id": "NZ_WHCC01000072.1",
  "regions": []
 },
 {
  "length": 3643,
  "seq_id": "NZ_WHCC01000073.1",
  "regions": []
 },
 {
  "length": 3492,
  "seq_id": "NZ_WHCC01000074.1",
  "regions": []
 },
 {
  "length": 3450,
  "seq_id": "NZ_WHCC01000075.1",
  "regions": []
 },
 {
  "length": 3133,
  "seq_id": "NZ_WHCC01000076.1",
  "regions": []
 },
 {
  "length": 3058,
  "seq_id": "NZ_WHCC01000077.1",
  "regions": []
 },
 {
  "length": 2779,
  "seq_id": "NZ_WHCC01000078.1",
  "regions": []
 },
 {
  "length": 2504,
  "seq_id": "NZ_WHCC01000079.1",
  "regions": []
 },
 {
  "length": 56860,
  "seq_id": "NZ_WHCC01000008.1",
  "regions": []
 },
 {
  "length": 2485,
  "seq_id": "NZ_WHCC01000080.1",
  "regions": []
 },
 {
  "length": 2066,
  "seq_id": "NZ_WHCC01000081.1",
  "regions": []
 },
 {
  "length": 2032,
  "seq_id": "NZ_WHCC01000082.1",
  "regions": []
 },
 {
  "length": 1920,
  "seq_id": "NZ_WHCC01000083.1",
  "regions": []
 },
 {
  "length": 1772,
  "seq_id": "NZ_WHCC01000084.1",
  "regions": []
 },
 {
  "length": 52308,
  "seq_id": "NZ_WHCC01000009.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r12c1",
  "r24c1",
  "r49c1",
  "r67c1"
 ],
 "r12c1": {
  "start": 20930,
  "end": 41193,
  "idx": 1,
  "orfs": [
   {
    "start": 22299,
    "end": 23801,
    "strand": -1,
    "locus_tag": "ctg12_16",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,299 - 23,801,\n (total: 1503 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Wzy_C<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGATTTTAAACAAAAGCTCAGAGGATTTTTTTCCGATTCATCGCTTTTTAGAAGAATCTACATTATAGATTTGTTTTTTACAAACATTGCGTTTCTCCAGATTCCTGCGTATGTACTTCTTGTTTTTCTCTTTATATGGGGTGTATGCCTTTCGGTATATAATCAAAAACATAATAATACTTTTTTTAAACTGCGCTTCGGAATATGGATCGGAGCATTTCTTGCCGTAACGGTATTTACGATGCTCATCAATTTTTCACAGACTTTTCTTTTCAGCCTTCTTATGCTTCTGCACGTTGTAATGTGTTTTTTTCTTTTTTACGGAATGCACACAGAGCCTGAATTTGATTACAGAATAGAGCTTTATCACATTGCAAAATTCATAATATACGCAACCACGTTAATGAACATAATCGGGATAACCTGCCTTATGTTCGGCTTTAAATTTGAATGGTACTGGATTAAATTTACCGTTTACGAAAACAGGTTCACCGGTTGTTATGTCAACCCGAATCTCCTCGGCTTCATAGCTGTGGTGTCGATTTTCTGTTGCCATATACTTTCAAAAGGGCATTTTATGCGCAGAATTGCCGAAAAAATTCCTGAACCCGGCATCAGTAAGATATGGATTGTAGCCTGTCTTTCCACAAATGCGTTTTCGCTCATTCTGTGCGATTCAAATGCCTCACTTGTGCTTGCTCTCGGATATGCAATTGTTTATATAGTTTATATGTTCTTTGCCGACAAGGCGGGACTTTCACCTTCAAAAATTATTTTGAAAATTACTGCGCTGTTTCTTGTGGGAGTTTTCCTTACAGGCTCTGCCTTGATGTTCAGAACAATTTGTCAGGAAGGCTTTTCCGTTGTTGTATCAAAGACAACCTCTGTTGTCGATTTGCTTTTAGGCAAAACCGAAAGCGAACTTGTGCAGGAAGGACTGACTCCCGAACAGAGAGAACAGCTTGAAAAGGATAAAATCACCTTTTCACACGAAAACAAAAACATTGACAGCGGAAGAAAGAAGCTTTGGCTTGAATCAATCAATCTTTTCAAACTGTCGCCGATTATCGGAATTTCCAACGGAAATATTGTTCTCTACAGTGCCGAATATTCAAACGGTGCTTTGGAATATTCGTATCACAAAAGTGATTTGCATAACGGTTTTCTTACAATTCTTGTTTCAACGGGTGTAATCGGTTTTGTTCTTTTCGGAATTTTTGGTTTTCGATTTGCAAAACACTCCGCACAGCACCTGTTTTTGCAGAAAAAAACATATCGTGACGATGTTTATCCCTGTCTGTTTGCTTTTCTTTTCGCATATTTGATTTTTGCCTGCTTTGAAAAGGCATTGCTTTATGACATATCGTTTATGGTGGTGTGGTTCTGGCTGATTATGGGATATATGAGTTGCTACATCACAAAGTTTGAACCGACGCTTGAAAGTCAGTATCTTTTTCACGGAAAAAGACTCAGACGGGTAACAAGAACAATGCTCTGA",
    "translation": "MTDFKQKLRGFFSDSSLFRRIYIIDLFFTNIAFLQIPAYVLLVFLFIWGVCLSVYNQKHNNTFFKLRFGIWIGAFLAVTVFTMLINFSQTFLFSLLMLLHVVMCFFLFYGMHTEPEFDYRIELYHIAKFIIYATTLMNIIGITCLMFGFKFEWYWIKFTVYENRFTGCYVNPNLLGFIAVVSIFCCHILSKGHFMRRIAEKIPEPGISKIWIVACLSTNAFSLILCDSNASLVLALGYAIVYIVYMFFADKAGLSPSKIILKITALFLVGVFLTGSALMFRTICQEGFSVVVSKTTSVVDLLLGKTESELVQEGLTPEQREQLEKDKITFSHENKNIDSGRKKLWLESINLFKLSPIIGISNGNIVLYSAEYSNGALEYSYHKSDLHNGFLTILVSTGVIGFVLFGIFGFRFAKHSAQHLFLQKKTYRDDVYPCLFAFLFAYLIFACFEKALLYDISFMVVWFWLIMGYMSCYITKFEPTLESQYLFHGKRLRRVTRTML",
    "product": ""
   },
   {
    "start": 23826,
    "end": 24506,
    "strand": -1,
    "locus_tag": "ctg12_17",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,826 - 24,506,\n (total: 681 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Bac_transf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1146:sugar transferase (Score: 229.5; E-value: 1.3e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATCATTTCAAAAGCTTCCGCCGCAGTTTCAGTGTGCCGAAGTAAAAGAATACTATGACATTCTCTGCAAAAAACAGGGAAGTTTTGTTTTAAAGCGAATTCTTGATATTTTTGCTTCTGTTATTCTTCTTGTGTTTCTCATCATTCCGATTGCAATTATTGCGATTTTAGTTAAAACCGACTCAAAAGGTCCTGTGTTTTACAGACAGGAAAGGGTTACAACCTACGGAAAGAAGTTCAGAATTCTTAAATTCCGTACAATGGTAACGGGAGCTGACAGGCTCGGAACACTTGTCACAACCGACAGCGACTCCCGAGTTACAAAAACAGGAAGAATTTTGCGAAAATATCGTCTTGATGAGCTGCCGCAGATTTTCAATGTTCTTTCGGGCAGTATGTCAATAGTCGGAACCCGTCCGGAGGTTCAGCATTATGTAGATATGTACGAACCCGAATATCTTGCAACACTCCTTATGCCTGCCGGAATAACCTCGTTGGCTTCAATTATGTATAAGGATGAAGAAAAGCTGTTGAAAGGCGAGATAGATGTTGACAGGGTTTATGTTGAAAAAATTCTTCCCGAAAAAATGAAGTTCAATCTTTCATATGTCAAAAATTTCAGCTTTGGTTCCGATATAAAGCTGATGTTCAAAACCGTAAAAGAAGTTTTCAGCTGA",
    "translation": "MKSFQKLPPQFQCAEVKEYYDILCKKQGSFVLKRILDIFASVILLVFLIIPIAIIAILVKTDSKGPVFYRQERVTTYGKKFRILKFRTMVTGADRLGTLVTTDSDSRVTKTGRILRKYRLDELPQIFNVLSGSMSIVGTRPEVQHYVDMYEPEYLATLLMPAGITSLASIMYKDEEKLLKGEIDVDRVYVEKILPEKMKFNLSYVKNFSFGSDIKLMFKTVKEVFS",
    "product": ""
   },
   {
    "start": 24983,
    "end": 25279,
    "strand": 1,
    "locus_tag": "ctg12_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,983 - 25,279,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTAACGAATATACACCCGACCTCATTACCCTTATCGGTGATGACGGTAAAGAAATAGAATTTGAAATACTTGATATCATTGAAAACGATGAGGGTAAGTTTTATGTACTCTACCCGTTCTTTGAAAATCCCGAGGATGCTGTAAATGATTCGGGAGAATATTATATTTTTGAAGTTACCGAAATTGACGGCGAAGAAGAGCTTGCCGAAATTGAGGATGATGACAAGCTCGACAGAATTGCCGCTGTTTTTGAAGAGCGTTACAATGAAGAATTTTATGATGAAGATGACTAA",
    "translation": "MANEYTPDLITLIGDDGKEIEFEILDIIENDEGKFYVLYPFFENPEDAVNDSGEYYIFEVTEIDGEEELAEIEDDDKLDRIAAVFEERYNEEFYDEDD",
    "product": ""
   },
   {
    "start": 25582,
    "end": 26544,
    "strand": 1,
    "locus_tag": "ctg12_19",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,582 - 26,544,\n (total: 963 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATATTTCCGTTTTAGGTTGCGGACGCTGGGGCAGCTGCATTGCCTGGTATCTCGACAAAATCGGTCACAATGTTTTAAGCTGCGGACTTGCCGACGCACCCGAATTTATACAGCTTAAAGAAACACACAAAAACGACTATCTCACCTTTCCAAAGTCAATTGAGGTTTCTTCGGATCTTGAATATGCGATTGAAAGAGCCGAGGTTATTATAATTTCGATTTCATCGCAGTATCTTCGTTCGTATTTTGCAGATATTTCAAAGTACAATCTCGACGGCAAGACAATTGTCCTCTGTATGAAGGGTGTTGAGGCAACTACAGGAAAAAGGCTCAGTGAGGTTGTCGGTGAATTTGTTGACGAAAGCAAGACACCCGTTGCAGTTTGGGTAGGTCCGGGACATCCCCAGGATTATGTAAGAGGTATTCCGAACTGTATGGTTATTGACAGCAATAATCACGATATTAAGGAAAAGCTTGTAAATGAATTCACAAGCGACCTTATCAGATTTTACCTTGGAACGGATCTTATCGGCAGTGAAATCGGTGCTGCCGCAAAGAATGTTATCGGCATCGCCGCAGGTATGCTTGACGGACTTAACTACACCTCACTAAAAGGTGCGTTAATGGCAAGAGGCACACGAGAGATTGCAAGACTCATTAAGGCACTCGGAGGCAATGAGATGAGTGCTTACGGTCTTTGTCATCTCGGCGACTATGAGGCTACCTTGTTTTCAAAATGGAGTCACAACAGAATGTACGGTGAAAGCTTTGCAAAGGGAGACAGATTCACAAAGCTTGCCGAGGGTGTTATGACATCAAAAGCGTTATACAAGCTCGGTCAGGAATATGGTGTTGACCTTCCGATTGTTGAGTCTGTATACAAGGTTTTATTCGACGGAACAGATATCAAAGAGGCACTCGGAACTCTGTTTATGCGTTCTGTCAAGAAAGAATTTTAA",
    "translation": "MNISVLGCGRWGSCIAWYLDKIGHNVLSCGLADAPEFIQLKETHKNDYLTFPKSIEVSSDLEYAIERAEVIIISISSQYLRSYFADISKYNLDGKTIVLCMKGVEATTGKRLSEVVGEFVDESKTPVAVWVGPGHPQDYVRGIPNCMVIDSNNHDIKEKLVNEFTSDLIRFYLGTDLIGSEIGAAAKNVIGIAAGMLDGLNYTSLKGALMARGTREIARLIKALGGNEMSAYGLCHLGDYEATLFSKWSHNRMYGESFAKGDRFTKLAEGVMTSKALYKLGQEYGVDLPIVESVYKVLFDGTDIKEALGTLFMRSVKKEF",
    "product": ""
   },
   {
    "start": 26562,
    "end": 28244,
    "strand": 1,
    "locus_tag": "ctg12_20",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,562 - 28,244,\n (total: 1683 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTAATACTAAAGCTAAGAACAATTCAAATAAACCTAAACAGACTGGGAAAACGGTTACTTCTGTCAAAAAGCAGAATACAGTCGAGTATGTTATTGTAAACATTCTTTGTCTGTTCGTATTCATAGCATTTGCATACATAGCAATTATGAGCTTTGTGCAGACAAGCGTGTTTGATTCGGCAAATTACGGCAGTGAAATAATTTTGTATCAAACGGATAACATTGCGCTGAACATCCTGTTCACTTCCCTGTTTACCGTTTTTATATTCAAAATGAAAAAGCATTGTGACTTTTTTGCAAAAGTCAATCTGAAATATATGCATATAGGTCTTGCGGCGTTCGTCATGATTGTGGGACTTGTCTGGATATTCTCAGTAACCTCTGTTGCCGCGGCTGACAGCTACAACATCTATGAAACAGCGTCACAGGCGGCTAAGGGCAACTATTCGTCATTCAGCAATAACAGCGGTTTTTACAACAGCGATTTTTACAGCGGATATTCTTACTACAACTTCTATCCGTTCCAGCTCGGCTTTGTTTTCATCAGCGAAATTTTTTACAGAATTTTCGGTACTGACAGTACAATGCCGATTCAGGTATTCAATGTAATGTGTACAGCTGCCGCTTATATAGGTATTGTAAACATCACAAAACTTCTTTTCAAAAAGCGTTCGGTTGAATTTATTACAATTCTTCTGCTTGCCGGCTGTTTTCAGCCCGTACTTTTCTGCACATTCGTTTACGGCAACATCATCGGAATGTGCTTTGCAATCTGGGCATCATACTTCCTCATCAAGTATTTTCAGACAAACAAGTACCTGCTCCTCATTCCGTGTGCTGTACTTCTCGTTATTTCAACACTTGCAAAATACAACAACCTGATTTATCTTGTTGCGTTTGTTGTTATGCTGGTTATTCACACAATTAAGGCTAAGAAGTGGCAGAGCATTGCGTTTGCACTTGCAATTTGCATTGTTGTTGTCGGAACAAGCAACCTTGTCATCATGAGTTATGAGAACCGTTCGGGAGTGAAGCTTTCAAGCGGTGTTTCACAGGCTATGTACCTTGATATGGGCATTAACGATTCATATATGGCTCCCGGTTGGTACAACGGAATTGCCCTCAACGATTATAAAAACGCAGGTCTTGACGCAAAAGCCGCAAATGCACAGGCTTGGACCAATATAAAATCAAGAATGAATTACTTTGGTAAAAACACAAACTATATGATTGACTTCTTCTCGAAGAAAATTATCAGCCAATGGAATGAGCCGACATACGAAAGCATATGGGTTAGCAAGGTCAAGTCTCATACAAACGAGCTTAATTGGATCGGCAACGGAATGTATGACGGCAGTATCGGACAGTTCTTTGAACTGTACTTCAACTTCTATATGCAGATTCTTTTCATTGCGTTTGCGGCAGGAATTTACTTCTTGTTCATTAACAGAAAGACAAATATTGAAACCGTACTTCTCCCTCTTGTTATTCTGGGAGCGTTCGGATATCACCTCTTATTTGAAGGCAAGTCGCAGTATGTGCTGACTTACATAATTCTTATGATTCCTACCGCGTCTTTTGCATTTGAGTGTATTCTTAACGGCAAATATACAAAAATCAAAGAATTTGTCGGAAAACTGAAAGAAATTCCCGACGGTAAAGAAAGCGAAAAAGCCTGA",
    "translation": "MGNTKAKNNSNKPKQTGKTVTSVKKQNTVEYVIVNILCLFVFIAFAYIAIMSFVQTSVFDSANYGSEIILYQTDNIALNILFTSLFTVFIFKMKKHCDFFAKVNLKYMHIGLAAFVMIVGLVWIFSVTSVAAADSYNIYETASQAAKGNYSSFSNNSGFYNSDFYSGYSYYNFYPFQLGFVFISEIFYRIFGTDSTMPIQVFNVMCTAAAYIGIVNITKLLFKKRSVEFITILLLAGCFQPVLFCTFVYGNIIGMCFAIWASYFLIKYFQTNKYLLLIPCAVLLVISTLAKYNNLIYLVAFVVMLVIHTIKAKKWQSIAFALAICIVVVGTSNLVIMSYENRSGVKLSSGVSQAMYLDMGINDSYMAPGWYNGIALNDYKNAGLDAKAANAQAWTNIKSRMNYFGKNTNYMIDFFSKKIISQWNEPTYESIWVSKVKSHTNELNWIGNGMYDGSIGQFFELYFNFYMQILFIAFAAGIYFLFINRKTNIETVLLPLVILGAFGYHLLFEGKSQYVLTYIILMIPTASFAFECILNGKYTKIKEFVGKLKEIPDGKESEKA",
    "product": ""
   },
   {
    "start": 28266,
    "end": 29132,
    "strand": -1,
    "locus_tag": "ctg12_21",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,266 - 29,132,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTCAGAATTATTACCGATTCAGCCGCCGATTTTGAACATTCAGAAAGTGAAAAATTCGGAATTTCTACAGTTCCGTTAGCTGTATATATTGACGGAAAAGAATATAAGGATGATTTTTTACATTCAAAGGAACGCTTTTACAGGCTTGCAAAGCTGTCGAAAACTTTGCCGAAAACCTCTCAGCCCTCGCCGTATGTCTACGAATGTGCTTTGAAAAAGGCGAGAGATAACGGCGAATCGGTTGTGGTGATAACTGTTTCTTCGGCATTGAGCGGTTCATATCAGAGTGCAGTTCTTGCAAGAGATTTGCTCGGATATGAGGGGTGTTATGTGATAGACAGCAAATCTGCTTCGGCAGGTCAGAAGCTTCTTGTAAACGAGGCACTTCGCTTGCGTGACAACGGGTTTACAGCAAAAGAAATTGCCGAACATCTTCTGAGGTTCAGAAGCAGAATTATGGTATATGCCTGTATTGACGATATGAAGTACCTCTATGGGGGTGGCAGACATACAAATGCCGCCGCATTACTCGGCTCAACAGGAAGAATAAAGCCCGTAATCAGCATTACGGGTTCGGGCAGTGTAGCATTTGAGGCGAAAACAATCGGAATGCGCCACGGTATGAATCATATGCTGATGTCGCTGAAAAAGCTTGGCATAGACCAAAATTATCCGCTGTATATAATGCACACAAACGCAAAAAATCAGGCATTGTATTTATCAAAGCTCATAATATCAAAAGGAATTCCTTTTGTTGAGGACAGTATTGTCAGCGTGGGTTCTGTTGTCGGCAGTCATATAGGAGAGGGCAGTACGGGTATTGCATTTGTCCAAAAAGAGCAAAGAAAAAGCGGACATGATTAA",
    "translation": "MVRIITDSAADFEHSESEKFGISTVPLAVYIDGKEYKDDFLHSKERFYRLAKLSKTLPKTSQPSPYVYECALKKARDNGESVVVITVSSALSGSYQSAVLARDLLGYEGCYVIDSKSASAGQKLLVNEALRLRDNGFTAKEIAEHLLRFRSRIMVYACIDDMKYLYGGGRHTNAAALLGSTGRIKPVISITGSGSVAFEAKTIGMRHGMNHMLMSLKKLGIDQNYPLYIMHTNAKNQALYLSKLIISKGIPFVEDSIVSVGSVVGSHIGEGSTGIAFVQKEQRKSGHD",
    "product": ""
   },
   {
    "start": 29238,
    "end": 30458,
    "strand": -1,
    "locus_tag": "ctg12_22",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,238 - 30,458,\n (total: 1221 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NTP_transf_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGGAAACATCTTAACGATAACGAAAAAATTGAATTTAAGTATCTGCTTGAGCTTGTTTCATCGTCTGTAAACGGAACAGCACCTCCTATTCCTTATGAGGGGATAAAATGGCAGTCGATAAAAATGCTTGCAAACTATTGCAGTGTTGAATCGCTTGTTGCCAATGCGGTTTTGTCGCTCGACCAAAAGTATGTTTCACCCGAGGTATATGAAAAATTCAAGCAGAATTTGTCGATTGAAATGCTGATTGACGGAAATCTCTCATATGAAACCGAGAAAATTCTCAAGGCTTTTGATGAAAACAAAATCAAGAATATTCCCTTAAAGGGCTATTTTATGAAAAAGGAATATCCTCGTTCCGACTTTCGTTCCGTGTCCGATGTAGATATCCTTTTTGACAGAAAACAGGCTGATTCGGTCAAAAAAGTTTTTGACGGGCTTGGATACACTTTTCTAAATGAAGATGACAACCAGTATCATTTTGAAAAAAAGCCGATGATGAACATTGAAATGCATGCAACTCTTGTCCATGAAAACGAGGAATCTTATCCGTTGCTTGTTAATCAGCTTGACCGTTCAACAAAGCGTGACGGCTACAGCTATTCATATGAAATGAGCCATGAGGACTTTTATATCTATATGCTTGTTCATAACTCGAATCATTTCAGAATCGGCGGAATGGGAGCAAGAATGGTGCTTGACAGCTATGTTTTCTTGAAAAATCATCAATCTGAGCTTGATTATGACTATCTTAATGTGATGCTTGAAAAAATCGGTATTGCAAAGTATGAAAAGCGTGTTCGTGAGATTGCGTTCAACTGGTTCGCAAAGCCACAGGCTGAACTTAAATTTGATGATATCGAAGAATATATTCTGCTCAGCGGTACACTCGGCAGGGTAGATGTTGGCACGATGATAAATTCTCACAAGACAATTACAGAAAATAACAAATCAAAATTCTCATATCTTGTGTCCTCAATATTTCCACCAAAATCCGAAATGCAGTATAAGTATCCATATGTAAAAAAAACACCGTTCCTTTTACCGATTTCATGGTGTCATATGTGGGGAAAAAGGCTTTTTGTAGACAGAAATATCAATTTTAAATCGGGTATCAAAAACCGTATGTCATACACGGATGAAGATGTAAATTTGTACAAGTCCCTTTTGGATGAAATGGGCTTTGACGGTATTGGGATAAATAATTTCGGAAATTGA",
    "translation": "MRKHLNDNEKIEFKYLLELVSSSVNGTAPPIPYEGIKWQSIKMLANYCSVESLVANAVLSLDQKYVSPEVYEKFKQNLSIEMLIDGNLSYETEKILKAFDENKIKNIPLKGYFMKKEYPRSDFRSVSDVDILFDRKQADSVKKVFDGLGYTFLNEDDNQYHFEKKPMMNIEMHATLVHENEESYPLLVNQLDRSTKRDGYSYSYEMSHEDFYIYMLVHNSNHFRIGGMGARMVLDSYVFLKNHQSELDYDYLNVMLEKIGIAKYEKRVREIAFNWFAKPQAELKFDDIEEYILLSGTLGRVDVGTMINSHKTITENNKSKFSYLVSSIFPPKSEMQYKYPYVKKTPFLLPISWCHMWGKRLFVDRNINFKSGIKNRMSYTDEDVNLYKSLLDEMGFDGIGINNFGN",
    "product": ""
   },
   {
    "start": 30455,
    "end": 30943,
    "strand": -1,
    "locus_tag": "ctg12_23",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,455 - 30,943,\n (total: 489 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCTTGAATAAAGAAGTAGGTCTTGATGATGTAATGCAGATTATAGCCGAAAAGCTTGAGGCCGGAGGATCGGTTACTTTCAATCCGAAGGGAACAAGTATGCTCCCAATGCTCCGAGACGGTGACGATACGGTTGTTTTATCAAAACCGAAGGGCAGACTTCATCTTTTTGACTTGCCTTTATACAGACGAAAAGACGGCTCGTATGTATTGCACCGTGTCGTCAATTTCGGAAGTGACGGCAGTTATACTATGTGCGGTGACAATCAGTTTGCCGTTGAAAAAGGTATTACCGATGATGATGTAATCGGAGTGGTAACAGCATTTTACAGAAAGGGCAAGCCATACACGGTTGACTCAATGAAGTACAGAGCATACCTTGAATTTATGTTCTATTCAAAACCGCTAAGAAAGGTTATTGCATCAACTGTGTCAAGAAGTAAAAATGCATTCTCAAAGCTTAAAACGAAAAAAGGGAAAAAATGA",
    "translation": "MSLNKEVGLDDVMQIIAEKLEAGGSVTFNPKGTSMLPMLRDGDDTVVLSKPKGRLHLFDLPLYRRKDGSYVLHRVVNFGSDGSYTMCGDNQFAVEKGITDDDVIGVVTAFYRKGKPYTVDSMKYRAYLEFMFYSKPLRKVIASTVSRSKNAFSKLKTKKGKK",
    "product": ""
   },
   {
    "start": 30930,
    "end": 31193,
    "strand": -1,
    "locus_tag": "ctg12_24",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,930 - 31,193,\n (total: 264 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGATAAAAGAAGATTTTGTTCTGCGAAAGGTTGCAGATTCATATGTTGTAGTTCCCGTAAACAAGCTGACGCTTGATTTTAACGGAATTATCAACCTCAATGAAACGGGTGCATTCCTTTTTGAAAAGCTCCAAAACGATTGCGAAAAGGCTGATTTGCTCAAAGCAATGCTTGATGAGTATGAAGTGAGCGAAGAAAAGGCGAGTGCAGATATTGATACATTTATTCAAAAGCTAAGAGAGGCTGATGTCCTTGAATAA",
    "translation": "MKIKEDFVLRKVADSYVVVPVNKLTLDFNGIINLNETGAFLFEKLQNDCEKADLLKAMLDEYEVSEEKASADIDTFIQKLREADVLE",
    "product": ""
   },
   {
    "start": 31346,
    "end": 32974,
    "strand": -1,
    "locus_tag": "ctg12_25",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,346 - 32,974,\n (total: 1629 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1299:chaperonin GroEL (Score: 814.4; E-value: 5.8e-247)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTAAACAAATCGCATACGGCGAAGATGCAAGAAAAGCTTTAATGAAAGGTATCGACCAGCTCGCTGATACCGTTAAAATCACACTCGGACCTAAGGGCAGAAATGTTGTTCTTGATAAGAAGTTCGGTGCTCCGCTCATCACAAATGACGGTGTAACAATTGCTAAGGAAATTGAACTTGAAGATCCTTTTGAAAATATGGGTGCTCAGCTTGTAAAGGAAGTTTCTATCAAGACTAACGATATTGCAGGCGACGGTACAACAACTGCCACACTTCTTGCTCAGGCTCTCATCAGAGAGGGTATGAAGAATGTAACTGCAGGCGCTAACCCAATGGTACTTAAAAAGGGTATTGCAGACGCTGTAAATGTTGCAGTTGAGGCTGTAAAGAAGAACAGCAAGCAGGTATCCGGTACAGACGATATCGCAAGAGTTGCAACAGTTTCATCACAGGATGAATTCATCGGCAAGCTTATTGCCGAGGCTATGGAAAAGGTTACAACAGACGGTGTTATCACAGTTGAGGAATCAAAGACAGCCGAAACATACAGCGAGGTTGTTGAAGGTATGATGTTTGACAGAGGTTACATCGCTCCTTATATGGTAACAGATACAGATAAGATGGTTGCAGAGCTTGACAATCCGCTTATCCTTATCACAGATAAGAAGATTTCTACTACACAGGAAATTCTCCCACTTCTTGAGCAGATTGTTCAGATGGGTAAGAAGCTCCTTATTATCGCTGAAGATGTTGAAGGCGAGGCTCTTACAACTCTCGTACTTAACAAACTCAGAGGTACATTCACTTGTGTTGCTGTAAAGGCTCCGGGCTTTGGCGACAGAAGAAAAGAAATGCTTCAGGATATCGCAACACTTACAGGCGGTACGGTAATCACATCCGACCTCGGTCTTGAACTCAAGGATACAACAGTTGATCAGCTCGGTACTGCCCGTCAGGTTAAGATTGAAAAGGAAAACACAATCATCGTTGACGGCTCAGGTGACAAGGAAGCTATCAAGGGCAGAGTTGCTCAGATCAGACAGCAGATTGAAACAACAACATCTGACTTTGACCGTGAAAAACTTCAGGAGCGTCTTGCAAAGCTCGCAGGCGGCGTAGCAGTTATCAAGGTTGGTGCTGCAACAGAAGTTGAAATGAAAGAAAAGAAGCTCCGTATTGAGGATGCTCTTGCTGCTACAAAGGCTGCTGTTGAAGAGGGTATCGTAGCAGGCGGCGGTATCGCTTGCATGAACGCTATTCCGGCTGTTGCAGAGTTCGTTGACACTCTCGAGGGTGACGCTAAGACAGGTGCTAAAATTGTTCTTAAAGCACTTGAAGAACCGCTCCGTCAGATTGTTGCTAACGCAGGTCTTGAGGGCAGCGTAATCTGCGATAATGTTAAGAAGGCTAACAAGGTTGGCTATGGCTTCAACGCTCTTACAGAGGAATACACAGATATGGTTTCGGCAGGTATCGTTGACCCAACAAAGGTTACTCGTTCAGCTCTCCAGAACGCAAGCTCTGTTGCAGCAATGGTTCTTACAACAGAATCACTTGTTACAGACATCAAAGAGCCTGCAGCTCCGGCAGCTCCCGCAGCACCTGATATGGGCGGAATGTACTAA",
    "translation": "MAKQIAYGEDARKALMKGIDQLADTVKITLGPKGRNVVLDKKFGAPLITNDGVTIAKEIELEDPFENMGAQLVKEVSIKTNDIAGDGTTTATLLAQALIREGMKNVTAGANPMVLKKGIADAVNVAVEAVKKNSKQVSGTDDIARVATVSSQDEFIGKLIAEAMEKVTTDGVITVEESKTAETYSEVVEGMMFDRGYIAPYMVTDTDKMVAELDNPLILITDKKISTTQEILPLLEQIVQMGKKLLIIAEDVEGEALTTLVLNKLRGTFTCVAVKAPGFGDRRKEMLQDIATLTGGTVITSDLGLELKDTTVDQLGTARQVKIEKENTIIVDGSGDKEAIKGRVAQIRQQIETTTSDFDREKLQERLAKLAGGVAVIKVGAATEVEMKEKKLRIEDALAATKAAVEEGIVAGGGIACMNAIPAVAEFVDTLEGDAKTGAKIVLKALEEPLRQIVANAGLEGSVICDNVKKANKVGYGFNALTEEYTDMVSAGIVDPTKVTRSALQNASSVAAMVLTTESLVTDIKEPAAPAAPAAPDMGGMY",
    "product": ""
   },
   {
    "start": 33003,
    "end": 33287,
    "strand": -1,
    "locus_tag": "ctg12_26",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,003 - 33,287,\n (total: 285 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAATCAAACCATTACTCGACAGAGTCGTTTTAAAAGTTGAAGAGGCTGAAGAGAAAACAAAGAGCGGTATCATTCTTTCATCTGCTGCTCAGGAAAAGCCACAGTTCGCATCAGTTGTTGCTGTTGGCCCCGGCGGTGTTGTTGACGGCAAGGAAGTAAAGATGTATGTCAGCGTAGGCGATAAGGTAATCGCAAGTAAATATGCAGGCACACAGGTAAAGATTGACGGCGAAGAATACACAATCGTAAACCAGTCGGATATACTCGCAACTCTTGAATAA",
    "translation": "MTIKPLLDRVVLKVEEAEEKTKSGIILSSAAQEKPQFASVVAVGPGGVVDGKEVKMYVSVGDKVIASKYAGTQVKIDGEEYTIVNQSDILATLE",
    "product": ""
   },
   {
    "start": 33551,
    "end": 35188,
    "strand": -1,
    "locus_tag": "ctg12_27",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,551 - 35,188,\n (total: 1638 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 81.3; E-value: 1.4e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCATTGTGTATGGGATGCATGCAGGAAATAGGTGACAACAAGATTTGTCCGTCCTGCGGATTTGATACAACTGAAAAACAGCAAGCTCCTTTTTTACCGTACGGAACAATTCTTCAGAACCGCTATATCGTAGGTGCGGGAATTGATACCAACGGCGAAAGCACACGCTATATAAGCCACGACAAGCAGACAGGTGACATTGTAATCATCTGCGAATTTCTTCCTATCGGACTTTTTTCTCGTGAAGAAGGAACTACCGAGGTCAGAATAAATTATGAAAACCGCCTTGTATATAATAAACTCAAGGACGATTTTCTTAACTATTACAGAATTCTTTCAGAACTCCGTGAGCTTTCCGCTCTTATGAATGTTCACAACATTTTTGAAGAAAATAACACAGTTTATGTTGTTGAGGAAAACGAGGATCTTATTCCTTTTGAGGAGTATGTTGAACGTAGTAACGGCCATCTTGAATGGGATATTGCCCGTCCGCTTTTTATGCCTGTAATTTCTGCACTTGAGGCTCTTCACAAGAGAGGTGTTGGTCACTATGCTATCGCACCTAAGAATATGTATATCACAGCATCGGGTAAAATTAAAATTTCAGGCTTTGCGTCGGAAAATGAGCGTAAAAGAGGCACGCCTCTCAAATCTCAGCTTTTTTCAGGCGCTGCGGCTCCCGAACAGTATGACGACAATTTTCCTCTTGACGATATTACGGATATCTACGGATTTTGTGCAACCCTTTTCTATGCCCTCACAGGTCATATGCCAAAGAGTGCGGTAGAACGCCGTAAGGACAGCCGACTTCTTATGAGTACAACAACAGTAAAGAGACTTCCTCCGCATGTTGTTTCGGCTCTTGCTAACGGTTTGCAGGTTGAGCGTGAAAACCGTATTACGGATTTTGACGAGCTTCGTTCACAGCTTTCCGTTGCTCATACAGCAAAGGCAATTCAGGACGAAATTTCAAGAACAGCAAGCATGAACCTCACAAAGTCAGAGCGTACTCGCAAGACTTCAAACGGTATGTCACACGCTTCAATTATTATTATTGCGGCTGCTATCACGGTTCTTGTTCTCGGTATCGCCGGTGTGTTCTGGCTTATGCAGAATCCGCTTGCCGGAATGTTCTCAAATAATACTGATGCGAGTGTAAGCTCAACTCAAAGCACAGAGTGGACAGGTGCTACTGTTCCTAACTATATAGGAATGACATATGAAGAGGCTGTTAAGAGTGTTGACAGCAACAGCAGTATCACAATCTACAGAACTTTTAACGATGAGTACAGCGATGATTATGCAGAAGGTAAGATTATGTCACAGACTCCTGCTGCAGGTTCCAAAATTACTCAGGAAGATTCTGTAGTAGTGAGTGTTTGCGTAAGCAAGGGATCACAGATGAGGACTCTGCCGAAGGTTGAGGGTGAAAAACTTGATACCGTTGCATCCGACATTGCCGCTCAGGGACTTCTTGCAACAGCGGAATATGAGTACAGTGACAAGGTTGCTGAGGGAAGGGTAATCCGCTACAAAGAACATGTTGAGGGTGATACTCTCGAATACGGTTCAACGGTAGTTCTTATTGTCAGCAAGGGCAAGAAACAGACAAGTTCTCAATCATCAAACAGATAA",
    "translation": "MSLCMGCMQEIGDNKICPSCGFDTTEKQQAPFLPYGTILQNRYIVGAGIDTNGESTRYISHDKQTGDIVIICEFLPIGLFSREEGTTEVRINYENRLVYNKLKDDFLNYYRILSELRELSALMNVHNIFEENNTVYVVEENEDLIPFEEYVERSNGHLEWDIARPLFMPVISALEALHKRGVGHYAIAPKNMYITASGKIKISGFASENERKRGTPLKSQLFSGAAAPEQYDDNFPLDDITDIYGFCATLFYALTGHMPKSAVERRKDSRLLMSTTTVKRLPPHVVSALANGLQVERENRITDFDELRSQLSVAHTAKAIQDEISRTASMNLTKSERTRKTSNGMSHASIIIIAAAITVLVLGIAGVFWLMQNPLAGMFSNNTDASVSSTQSTEWTGATVPNYIGMTYEEAVKSVDSNSSITIYRTFNDEYSDDYAEGKIMSQTPAAGSKITQEDSVVVSVCVSKGSQMRTLPKVEGEKLDTVASDIAAQGLLATAEYEYSDKVAEGRVIRYKEHVEGDTLEYGSTVVLIVSKGKKQTSSQSSNR",
    "product": ""
   },
   {
    "start": 35498,
    "end": 36148,
    "strand": -1,
    "locus_tag": "ctg12_28",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,498 - 36,148,\n (total: 651 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGATAAAGGAGTAATTATGCGTTGTGTGATTATTGCAGGCTCGCCTGACACAAATTCGGATTTTTTGTCCGAGGTTATAAAACCTGATGACTATGTGATATGTGCCGACAGAGGTTGCAATTTTGCAAAACAGGCAGGCATTACTCCGAACCTTGTTGTAGGAGATTTTGATTCCGAGCCTGATGTACTGTTTCCAAACTGCGAAACGGTCCGCCTTATTCCCGAAAAGGATGATACCGACACAATGCACTCTGTTGACCTTGCACTTGAAAAAAGGTTTGACGAAATAGCAATTCTCGGTGCATTGGGCGGTCGCTTTGACCACAGCTTTGCAAATGTGGCGGTTCTCTCTTATATTCACGAACACGGAAGTAAGGGCGTTCTCCTTTCTGAAAAAGAGAAAATAGAATTTCTCCCCGTAGGTCATTATGAATATAAAAACTTTAAAGGCAAAACATTTTCGCTTTTCCCTTTCGGATGTCCGAGTGTCTGCGTAAGCTATTCGGGAACAAAGTATCCTCTTGAAAAATACTGTGTTTCGAGCAGCGTTACTCTGGGTGTTTCAAATGTATTCACTTCCGATATGACAACAATTGACATATATGACGGAAATGCAATACTTATAATTAATTTGATAGACTGTTAA",
    "translation": "MADKGVIMRCVIIAGSPDTNSDFLSEVIKPDDYVICADRGCNFAKQAGITPNLVVGDFDSEPDVLFPNCETVRLIPEKDDTDTMHSVDLALEKRFDEIAILGALGGRFDHSFANVAVLSYIHEHGSKGVLLSEKEKIEFLPVGHYEYKNFKGKTFSLFPFGCPSVCVSYSGTKYPLEKYCVSSSVTLGVSNVFTSDMTTIDIYDGNAILIINLIDC",
    "product": ""
   },
   {
    "start": 36130,
    "end": 36993,
    "strand": -1,
    "locus_tag": "ctg12_29",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,130 - 36,993,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATCAATCGGCGGATTTTACTATGTCCGTGCCGATGGCGAGAATTACGAATGTAAGGCAAGGGGGAGCTTTCGCAAAAGCGGAAACTCTCCCGTAGCGGGGGACAGGGTAAATATATCTGTTCCGAATGACGGTTTTTGTGCGATAGAAGAAATTCTTCCACGCAAAAACAAGCTCCGCAGACCTGCTCTTGCAAATCTTGATATTCTTCTTCTCGTGTGTTCAACTGTTGAACCGTTGCCTAATTTTACGATTATTGACAAAATGACTGCGGCGGCGGTAAACAATAATATGGAACCCGTAATTGTCGTTACAAAAAATGATCTGGAAAACGGAGATAAGATTGCCGATATCTACAGACACGCAGGTTTTGAGGTTTTTCTCTGTTCGGAAGATGATTCTTCACAAACCGAAGAACTCAAAAGCTATCTGTCCGGCAAGGTTTCAGCCTTTATCGGTAACAGCGGTGTCGGCAAGTCCACATTGCTCAACAAGCTTTTTCCATCGCTTTCTCTTGAAACAGGGCAGACAAGTAAAAAACTCGGCAGAGGAAGACATACAACAAGAGTTGTTGAACTGTTTGAACTTGACGGTTGTTTTGTGGCAGACACACCCGGATTTTCAACCGTTGATCTTCAGCGTTACGAAATGATTGACAAAAGCCGGCTGCAATATTGCTTTCCTGAATTTGAAAAATATTTAGGGGAGTGTATGTTTACTTCATGTTCGCATACCTGTGAAAAAGGCTGCAGGATTCTTGAGGCGCTATCTGACGGTGAAATTGAAGAAACCCGTCACCGCAGTTATGTTCAGATGTATAACGAGGTCAAGGACATTAAATCATGGCAGATAAAGGAGTAA",
    "translation": "MKSIGGFYYVRADGENYECKARGSFRKSGNSPVAGDRVNISVPNDGFCAIEEILPRKNKLRRPALANLDILLLVCSTVEPLPNFTIIDKMTAAAVNNNMEPVIVVTKNDLENGDKIADIYRHAGFEVFLCSEDDSSQTEELKSYLSGKVSAFIGNSGVGKSTLLNKLFPSLSLETGQTSKKLGRGRHTTRVVELFELDGCFVADTPGFSTVDLQRYEMIDKSRLQYCFPEFEKYLGECMFTSCSHTCEKGCRILEALSDGEIEETRHRSYVQMYNEVKDIKSWQIKE",
    "product": ""
   },
   {
    "start": 37028,
    "end": 39133,
    "strand": -1,
    "locus_tag": "ctg12_30",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,028 - 39,133,\n (total: 2106 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 258.6; E-value: 1.1e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGGATAAATATTTGGGCAAAAGACTTGACGGAAGATATGAAATCCACGAACTTATCGGTGTCGGCGGTATGGCAAATGTTTACCGTTGTACCGACACAGTCGATGACCGTGAAGTTGCCGTAAAAATTCTTAAAGACGAGTATCTCAACAACGAGGAGTTTATCCGCCGTTTCAAAAATGAATCAAAAGCCATCGCAATGCTTTCACATCCGAATATCGTAAAGGTGTATGATGTAAGCTTTGGCGATATGATTCAGTATATCGTAATGGAATATATTGACGGCATTACCCTCAAAGAATATATTGATCAGCAGGGCATTATTGAGTGGAAAGACGCAATCCACCTGACTGCACAAATTCTAAAGGCTTTACAGCACGCTCACGAGTGCGGAATTGTACACCGTGATATAAAGCCGCAAAATATTATGCTGTTGCAGGACGGTACAATCAAAGTTACCGATTTCGGTATTGCAAGATTTTCCGATAAATCAACACGCACAATGACAGAACAGGCAATCGGCTCTGTCCACTACATTGCCCCTGAACAGGCAAGAGGTGATGCAACTGACGGAAAAACAGACATTTATTCTGTCGGTGTAATGCTCTATGAAATGCTTACGGGAAAGCTTCCGTTTGACGGTGATAGTGCCGTTACAATTGCGCTTATGCAGTTGCAGTCAACACCGAAGCATCCTCGTGAAATCAATCCGGGAATCCCGATAGGTCTTGAGCAGATTACTATGAAGGCAATGGAAAAGCTTCCGTCCGACAGATACACTTCTGCCGCAGAAATGCTTTCTAATATCGAAAGATTCAGACTTAATCCGTCAATCGTTTTTGATTACGGCAACAAGTCTTTTGTTGATAATCAGCCCACAAAGTTTGTTCACTCTCTGCGTGACAGCGGGGTAAGAAATAAAATTGACAACGAGGCAACCAAAGTAGTTGATATGCCGCAGGACGATGTTGTTGTTAAAGAAGAACAGTTTGCCGATGAGGATTTTGTAAAGGAACATAAGCCGTCATACTATGCAGTCAAGGGTATTGTAATTGCGGCTGTTGCAGTATGTGCAATTTTCTTTGCACTTGCAATGTTCAGAGGCTGCTCAACCTCACAGGCCAAGGATGTTGAAGTTCCCAATTATGTCGGCAAATCCTTTGTTTCAATAAAAGAAAATAACCCGAATGATTTCAAGTTTGAGGTTAAGAGTGAATATGATGAGTCAAAGGAAATGGGCGTAATTCTTGATCAAGAGCCTAAGGGCGGTTCAATGAAGGTTAAGTCAGGCTCAACAATCACGGTAACCGTAAACGGAACGGACACAGAGGTTTCTGTTCCTTATGTAACCAATTACAGCGAAAAAGAGGCTTCTCAGGCTCTCAAGGAAAAGAATCTTATTCCTGAAATTGTCTATGTAGAAAACACTAAAACACCAAAGGGCTACACAATTGAGTGCTTCCCGAAAGCAGGTGTAAAAACTACAATCGGTTCAACGGTATATGTATATATTGCAAGCGGTGAGAGAACCAAACAGGTTACACTCCCGTCGGTTGACGGACTTATGCTTTCCGAAGCAAAGCAGACTCTTGTTGATCTCGGACTTACCGTTGAAACAGTACAGGATGATGAAAGCAAAGAACCAAAGGATACAGTCCTCGGTATGTCGCCTCTCCAGTACGGCAAGGTTGACGCAGGCTCTGTTGTAACCCTGACTGTAAGCTCAGGACTCGGTGACGAAAACACGGTTAATATCTTCGTTGACCTTCCGTCGGATGTTGAAGATTCAGTCGATATGACTGTAATTGTTGACGGTGCGGTTGATTCCCGTAATTCAAAGACACTTGTTCCGAAATATAACAAGACCTATACTCTTGAGCTCAAGGGCTCAGGCACTTCAACTGTAGTAATTCAGCTTGACGGTCAGGCTTACAGAGAGTATTCGGTTGACTTTGCATCGGCAGCGGTAACCACTACGGCGTCACATGATTATGTCCGTGCGACAACCGCTCCTCCCGAAACCGAACCGCCGACACAGTATTACACAGATCCGTATGTAGCGCCTGACACGACCGTTCAGCCGGTTACGGATGATCCTGAACTTTAA",
    "translation": "MDKYLGKRLDGRYEIHELIGVGGMANVYRCTDTVDDREVAVKILKDEYLNNEEFIRRFKNESKAIAMLSHPNIVKVYDVSFGDMIQYIVMEYIDGITLKEYIDQQGIIEWKDAIHLTAQILKALQHAHECGIVHRDIKPQNIMLLQDGTIKVTDFGIARFSDKSTRTMTEQAIGSVHYIAPEQARGDATDGKTDIYSVGVMLYEMLTGKLPFDGDSAVTIALMQLQSTPKHPREINPGIPIGLEQITMKAMEKLPSDRYTSAAEMLSNIERFRLNPSIVFDYGNKSFVDNQPTKFVHSLRDSGVRNKIDNEATKVVDMPQDDVVVKEEQFADEDFVKEHKPSYYAVKGIVIAAVAVCAIFFALAMFRGCSTSQAKDVEVPNYVGKSFVSIKENNPNDFKFEVKSEYDESKEMGVILDQEPKGGSMKVKSGSTITVTVNGTDTEVSVPYVTNYSEKEASQALKEKNLIPEIVYVENTKTPKGYTIECFPKAGVKTTIGSTVYVYIASGERTKQVTLPSVDGLMLSEAKQTLVDLGLTVETVQDDESKEPKDTVLGMSPLQYGKVDAGSVVTLTVSSGLGDENTVNIFVDLPSDVEDSVDMTVIVDGAVDSRNSKTLVPKYNKTYTLELKGSGTSTVVIQLDGQAYREYSVDFASAAVTTTASHDYVRATTAPPETEPPTQYYTDPYVAPDTTVQPVTDDPEL",
    "product": ""
   },
   {
    "start": 39152,
    "end": 39877,
    "strand": -1,
    "locus_tag": "ctg12_31",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,152 - 39,877,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGGAAGTATTCAGCAAAAGTGATATCGGACTTGTTCGTAATCAGAATCAGGATGACTGTCGCTTCGGAGTTATTTCTCCCAGCTGTGTCTGGGCAGTTGTGTGTGACGGAATGGGCGGTGCAAACGGCGGTAATATTGCCAGCGCAACGGCAGTTGATTATATCAGCACCAAAATTACCGATTTGTACAAAGATGATATGACCAAGGAGCAGATTGGCGAGCTTATGGCAGAAATTGTTGTCAATGCCAATATGAAAGTCTTTGAAATGTCCATGAAAGATCCCGAGCTCACGGGTATGGGAACTACATGTGAATTTGTCTTTGTAAAAGATACAACCGTTCATGTTGTTCATGTCGGTGACAGTCGCACATACGCTATCAGAGGCGGTAAAATCAAGCAGCTTACAGAGGATCATTCCGTTGTTCAGGAAATGGTTAGAAGAGGCGAACTTACATATGAGCAGGCGCAAAATCATCCGAACAAGAACTTTATAACAAGGGCGCTCGGCATAAAACCGTCCGTTCGCCTTGACTATATTGAAGCCAACTTTATTTACGGTGATGTTCTTCTCATCTGTACCGACGGACTTTCAAATTGCGTCACAACAGGAGATATGGTCAAAATTTGCCATGAAAACCGTGGCGAAGGTCTTATCACAAAGCTTGTTGACAAGGCGAAAGACGGCGGAGGTTCTGATAATATCACAGCTACCGTAATTTACTAA",
    "translation": "MEVFSKSDIGLVRNQNQDDCRFGVISPSCVWAVVCDGMGGANGGNIASATAVDYISTKITDLYKDDMTKEQIGELMAEIVVNANMKVFEMSMKDPELTGMGTTCEFVFVKDTTVHVVHVGDSRTYAIRGGKIKQLTEDHSVVQEMVRRGELTYEQAQNHPNKNFITRALGIKPSVRLDYIEANFIYGDVLLICTDGLSNCVTTGDMVKICHENRGEGLITKLVDKAKDGGGSDNITATVIY",
    "product": ""
   },
   {
    "start": 39879,
    "end": 40895,
    "strand": -1,
    "locus_tag": "ctg12_32",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg12_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg12_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,879 - 40,895,\n (total: 1017 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg12_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg12_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCTTGATGAGCTGACTGAATTTGTCACAGAAAACGGTTTTCCAAAGTTCAGAGCAAAGCAGATTTATGATTGGTTGTACAAAAATGTGACCGATTTTGACAATATGCGTAACATTCCTGCCGATTTAAAGGCTTTTTTGAAATCAAGTAGTTACATTTCTGTTGCAAATATTGAAAAAAAACTTGTTTCAAGGTATGATAAAACAGTCAAGTACCTTTTTTCGTTTAATGACGGCGAATGTGTAGAGTCTGTTGTAATGAGTTACAAGCACGGATATTCAATCTGTATCTCAACACAGGTTGGCTGTAAAATGGGTTGTACATTTTGTGCAACAGGCAAAAGCGGTTTTTCACGGAGTCTTGCACCGTCGGAAATGCTCGGACAGATTGAGGCCGCACAGCGTGATCTTAACATAAGAATTTCTAACATTGTTCTTATGGGAATGGGTGAACCGCTTGATAATTTTGATAATGTCGTAAAATTTCTCCGACTTGTTTCGTCCGACAACGGTCTTAACATTGGAATGCGACATATTACTCTCTCAACCTGCGGTATAGTTCCGAAAATTTATGAGCTTGCAAAACTTCATTTCGGAATAACGCTTTCCGTTTCATTACACGCACCGAACGATGAGATAAGGCAGCGAACAATGCCCATTGCAAGAAAGTATTCTATTGAAGAATTATTAAAGGCTTGTTCAGATTATTTCAGAACAACAGGTCGCAGAGTTACATTTGAATACTCTATGATAAGCGGAGTTAATGACAGCGATGAAAACGCAAGAGAGCTTGCAAAACGACTTGAGGGTACACAAAGCCATGTTAATCTGATCCCCGTCAATACTGTTGAGGGAACAGGCTACTTAAAAAGCAATATTAAAAGACAGCAGGCATTCATAAATATTCTTGCTGCTAAAAATATCGGAGCAACCGTGCGCAGGACACTCGGAAGTGACATAAACGCATCGTGCGGTCAGCTCAAAAGAAAGCATATTGAAGAAGGAGGTAAATAA",
    "translation": "MTLDELTEFVTENGFPKFRAKQIYDWLYKNVTDFDNMRNIPADLKAFLKSSSYISVANIEKKLVSRYDKTVKYLFSFNDGECVESVVMSYKHGYSICISTQVGCKMGCTFCATGKSGFSRSLAPSEMLGQIEAAQRDLNIRISNIVLMGMGEPLDNFDNVVKFLRLVSSDNGLNIGMRHITLSTCGIVPKIYELAKLHFGITLSVSLHAPNDEIRQRTMPIARKYSIEELLKACSDYFRTTGRRVTFEYSMISGVNDSDENARELAKRLEGTQSHVNLIPVNTVEGTGYLKSNIKRQQAFINILAAKNIGATVRRTLGSDINASCGQLKRKHIEEGGK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 30929,
    "end": 31193,
    "tool": "rule-based-clusters",
    "neighbouring_start": 20929,
    "neighbouring_end": 41193,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r12c1"
 },
 "r24c1": {
  "start": 796,
  "end": 20597,
  "idx": 1,
  "orfs": [
   {
    "start": 2136,
    "end": 2342,
    "strand": 1,
    "locus_tag": "ctg24_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,136 - 2,342,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTCTGCTGTTCAAAGTCTTGCAAGACGATTTCACAGGTGCAGTTGCGCCGATTGATAATTTGAGTATGGTTGTTTCAATAATCCTTTCGTACATGATTTTCAAAAAAACTGTCCGCAAAATCAAACATAAGTATTCATATAATAATCGCAGACACTTATTTATGCTTTTACGGATTAAATTTAAAATTTACAAATTTGTGTAA",
    "translation": "MTLLFKVLQDDFTGAVAPIDNLSMVVSIILSYMIFKKTVRKIKHKYSYNNRRHLFMLLRIKFKIYKFV",
    "product": ""
   },
   {
    "start": 2779,
    "end": 3066,
    "strand": 1,
    "locus_tag": "ctg24_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,779 - 3,066,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCAACAGGACTTGATTCGGGATTAAGAATAAATGATAACTCAATTCTTGTTGAGTGTGAAGTGGACTCAAAGTATCAATACAAATTAGTTATCTACGACAATACTTTTGACGATAATCCTTTAGAAAAGGTTTATGCAATCCGAAATATAGATTATAATATAACCGATGGCAACAAAATCGCAAATTTTATAATTAAATTAGAGGAAAACAATTATGATAGCAAGAAAGTATTTAGACAATTACTCAGAGATTATACTAAACAGTTTGAACTTATACTCGGATAA",
    "translation": "MSTGLDSGLRINDNSILVECEVDSKYQYKLVIYDNTFDDNPLEKVYAIRNIDYNITDGNKIANFIIKLEENNYDSKKVFRQLLRDYTKQFELILG",
    "product": ""
   },
   {
    "start": 3360,
    "end": 3722,
    "strand": -1,
    "locus_tag": "ctg24_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,360 - 3,722,\n (total: 363 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCATAAATTAACTTGTTGTTACAAAGAAAAAGCTTGTGATAAATGTGTTATTCACGCAGACAGAAAATTCTGTTTTATAGAAGCAACTCAGACGGTGTTCGATAATCTTTTGAGATGCCAACTACAACATTTATTCAGATTAGCTGTTGCTGTCTACCGCTTTACTTGCTTTTGCAGGGCTATTTTGCCAATCACCGAACCATCAGATAAATTGTTTGCTTTGAGTAATATTATTGATTTTTTATTGACACTATCATCAATAGTGCGTATAATGATATTGGAACCCGAATTTTTAAGTCGGCTGGGTAATTGGCACCCTGACTTCTTAAAAATATTCTGGGTTCTTTTTTTGTCTAAATAA",
    "translation": "MHKLTCCYKEKACDKCVIHADRKFCFIEATQTVFDNLLRCQLQHLFRLAVAVYRFTCFCRAILPITEPSDKLFALSNIIDFLLTLSSIVRIMILEPEFLSRLGNWHPDFLKIFWVLFLSK",
    "product": ""
   },
   {
    "start": 3761,
    "end": 4204,
    "strand": 1,
    "locus_tag": "ctg24_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,761 - 4,204,\n (total: 444 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCATTGAGTACAAGAGAATTGCTTGCAAGGCTTTTAAAATGTGAGGCAGGTGGGGAAGGTGAAAACGGAATGCGTGCCGTTGCGTCGGTAATTGTAAACCGAACCCGTGTTCCAAACGGGGAATTTGCAAGAGTCAGCAAGGGCGGAGATTTCCGTGCCATAATGGAACAACCAAATCAATTTACCTGTCTTAAAACAACTGTCGGAGGACAATATAATCCTCAAAATGTTTACAATATACGCCCTGACGAAATTCACTATAATATTGCCGATTGGGCATTGGCGGGCAATACCGATTCATCTGTCGGAAATTCAATTTTCTATTTTAATCCATTTTCAGATACCTGCCCAACATTTTTTCCGTCAAACAACGGAGTAATTTACAACAGGGTAGGGGATCATTGCTTTTATTCGCCTACCGAGGCTTATTCCAAAACATAA",
    "translation": "MALSTRELLARLLKCEAGGEGENGMRAVASVIVNRTRVPNGEFARVSKGGDFRAIMEQPNQFTCLKTTVGGQYNPQNVYNIRPDEIHYNIADWALAGNTDSSVGNSIFYFNPFSDTCPTFFPSNNGVIYNRVGDHCFYSPTEAYSKT",
    "product": ""
   },
   {
    "start": 4219,
    "end": 4926,
    "strand": 1,
    "locus_tag": "ctg24_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,219 - 4,926,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATAATTCTTCAAATATGGCAGTTAATACAACTCCTATGGCAAATCAGATTAATCCCGAACATCATTACGGACTTGACAAAAACAAAGCCTGCCTCAATAATTCTTGTCCGTCAAACACAGCGGATATCGGATGTTATATTCCTGCGATTGACGAAATTATGCGACACAATCAGGGCGCACCGTCTGTTGCACACCCCAATATGACAGAAAAAGTTCAAAAATCAAATGACAATCCCTCGCTTGAACAGGCAGAAATAGCATATGAAGAGGGCGGAAGTACATCAGAAGAACAACCTGAAAATATAAATAAATACAGCGGAAGTCTTCAAAATATACCGTTCATTAAGAACTTAAAAAAAATAGATACATCTATACCTGTTTTGCCTGCAACCCCGGCTACAACGGCGAGCTCCGGAGCCACCGTTGCAACGCCGATAAGGCAGAATATTGGAATGTCGATGAGTGATTATCAATATCCGTTTCCTGTAACAGCCGAAAATCTGAGATATCACAACGGTTTTATGCGAACACAAATTGGAAGACGAATCACCGTTGATTTTCTCATGGGAGCAAACACAATTGTTCAGAAAACAGGCTATCTTTTAGGTGTTGCTCAGGATTATATCCTTATAAATGAGATTGACACCAACGACATCACAACCTGTGATTACTACAATATAAAATTTATAAGGTATTATTACTAA",
    "translation": "MDNSSNMAVNTTPMANQINPEHHYGLDKNKACLNNSCPSNTADIGCYIPAIDEIMRHNQGAPSVAHPNMTEKVQKSNDNPSLEQAEIAYEEGGSTSEEQPENINKYSGSLQNIPFIKNLKKIDTSIPVLPATPATTASSGATVATPIRQNIGMSMSDYQYPFPVTAENLRYHNGFMRTQIGRRITVDFLMGANTIVQKTGYLLGVAQDYILINEIDTNDITTCDYYNIKFIRYYY",
    "product": ""
   },
   {
    "start": 5178,
    "end": 6077,
    "strand": 1,
    "locus_tag": "ctg24_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,178 - 6,077,\n (total: 900 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTCTGTAAATATTGCGGAGCACAGCTTGAAGACAATGCTGTTTGCAACTGCGAAAAGTCAAGAGCCGCTCAAGCACAGGCTCAGCAGGCAAATGCACAGGCACAGCCTCAGTATCAGCAGCCTGTTCAGCCACAACAGCCACAGTATCAGAACCCTGTTCAGCAACAGTATGCACAGCCGCAAAACCCTCAGACACAGCAGTCGCCTTATGCCGTAAATAACACAGCACCTATTGGGGAAAATGCTTTTGTTAAGGCTTTAAAGAACATTCCTGTTGTGTTCACTTCATTCTTTAAGGATTCCAAAACTGTTATCAAAACAGCAAAGGCTGAAAAAGACATCATTCTCGGCGCTCTTTTCTCGGCAATTTTCTTTATTGCACTCATTCTTGGCAATATGTTTCTTATGCTTTCTATGAGCGCACTTGATTTTCCGAAAACACTTCTTGTAAGTCTTGTTACTGCTGTCCTTATCGGCGGCTTCTATTCTGTTATTCTCTTTGCATATGTAAAGAAATACAAAACCGAAGAAAATACAGCCAAAGCATTTATTGATTCATTCATCACATTTTCAATTGAATCTATTCCGGCATCAATCGGTTGGATTCTGGCAGGTCTTTGCGCATTAATCAGCGTATATATGTTCCTGTTTTTCTTCGTAATCGTTATGCTTTACCTTGTTATTTCACTTGTAAATCAGGTAAAAGCTAATGTTCCCGAAGCAAAGAACTCTGCATTATTCACTTTAATTCTCACACTCATCGTTGCCGTTGCATTTATGATTGTATTCTTCATCGGCGCAGAACTTACTATGTGGTCATTTAACACAAGTACATTTGCAACAAGTGTTCTTACATCGCTTATTGGCGGTGGTTCATACCCTTCATGGTATTAA",
    "translation": "MKFCKYCGAQLEDNAVCNCEKSRAAQAQAQQANAQAQPQYQQPVQPQQPQYQNPVQQQYAQPQNPQTQQSPYAVNNTAPIGENAFVKALKNIPVVFTSFFKDSKTVIKTAKAEKDIILGALFSAIFFIALILGNMFLMLSMSALDFPKTLLVSLVTAVLIGGFYSVILFAYVKKYKTEENTAKAFIDSFITFSIESIPASIGWILAGLCALISVYMFLFFFVIVMLYLVISLVNQVKANVPEAKNSALFTLILTLIVAVAFMIVFFIGAELTMWSFNTSTFATSVLTSLIGGGSYPSWY",
    "product": ""
   },
   {
    "start": 6137,
    "end": 7321,
    "strand": -1,
    "locus_tag": "ctg24_9",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,137 - 7,321,\n (total: 1185 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATTTTTCCTATTTTTTCATATACCTTCCAAATCGAGGCAGAAACTTGTGTTTCTGCCTCAAAATCATTTATGAGGTTTTTTATGAGTAATTCTATCGGTCTTTACATTCACATACCGTTTTGTAAGCACAAATGTCCGTATTGTGATTTTTTCAGCGGCAATGCAGATGAAAACGCTTTTGATAATTATGTGATTGAATTAAAAGATAAAATAAAATACTGGTCTGAAAAAGCCAAAAGAGATGTTGCAACCGTATATTTCGGCGGCGGTACGCCGAGTATTTTGGGTGCAGACAGACTTTGTGATATTCTTGATTTTATCAAGTTCAATTTTAATATTCAAAATAATGCCGAGATTACAGTTGAAGTCAATCCCGACTCCGCCAAAACTATTGATTTTGAAAAAATGTATGCCTGCGGATTTAATCGCATTTCAATGGGAATGCAGACTGCTGTTGAAGATGAATTAAGGCTGCTTGGGAGAATTCACAGCATTGATGATGCAAAAACTTCTGTTGAAAGGGCTAAAAGTGCGGGATTTAATAATATTTCACTTGATTTGATGATGGGAATTCCTAATCAGACAATTGAAAGCCTTGAAAAATCAATCAGTTTCTGTGCCGATTGCAAAGTTACTCATATTTCATCATACATTTTGAAAATCGAGGAGAATACTCCGTTTTATAAGGTGCAAAATAAACTTAAGCTTGCCGATGATGATATGCAGGCTGAAATGTATCTGAAAGCTGTTGAAATGCTTGATTCTCTCGGATACAAACAATATGAAATTTCTAATTTTGCAAAACAGGGTTATGAAAGCCGACATAATACCAATTACTGGAGATGCGGTGAATATATCGGAATAGGTCCGTCTGCACACTCATTTTTTGAGGGCAAAAGGTTTTTTTATTCGAGAAGCATGGACGATTTTAATAACAATAAGCTGTCTTTTGAAGGTACGGGCGGAGATGAGGAAGAATTTATTATGCTCTCTCTCAGGCTGAAAAGCGGTCTTAATTATTCTGAATTTGGGGAAAAATTCGGGTACACCCTCCCCTCTTACATTATCAAAAAAGCTAAAGAGTATGAAAAATACGGGTATACAAATGTTACGGACAAGTCGATCAGCTTTACACCGAAAGGTTTTCTTGTTTCAAATTCAATAATCAGTGAACTGATATAA",
    "translation": "MIFPIFSYTFQIEAETCVSASKSFMRFFMSNSIGLYIHIPFCKHKCPYCDFFSGNADENAFDNYVIELKDKIKYWSEKAKRDVATVYFGGGTPSILGADRLCDILDFIKFNFNIQNNAEITVEVNPDSAKTIDFEKMYACGFNRISMGMQTAVEDELRLLGRIHSIDDAKTSVERAKSAGFNNISLDLMMGIPNQTIESLEKSISFCADCKVTHISSYILKIEENTPFYKVQNKLKLADDDMQAEMYLKAVEMLDSLGYKQYEISNFAKQGYESRHNTNYWRCGEYIGIGPSAHSFFEGKRFFYSRSMDDFNNNKLSFEGTGGDEEEFIMLSLRLKSGLNYSEFGEKFGYTLPSYIIKKAKEYEKYGYTNVTDKSISFTPKGFLVSNSIISELI",
    "product": ""
   },
   {
    "start": 7487,
    "end": 9073,
    "strand": 1,
    "locus_tag": "ctg24_10",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,487 - 9,073,\n (total: 1587 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 109.2; E-value: 4e-33)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTTCATTTAAAGAAGAAATCAGCAAGCGCAGAACCTTTGCGATTATTTCGCATCCTGATGCGGGTAAAACAACACTTACGGAAAAGCTCTTGCTCTACGGCGGAGCAATTAACCTTGCGGGTTCGGTAAAAGGCAAAAGAACCGCAAAGCATGCTGTGTCCGACTGGATGGAAATTGAAAAACAGCGTGGTATTTCTGTTACATCATCGGTTTTGCAGTTTAAATATAACGGTTATTGCATAAATATTCTTGATACACCGGGACATGAGGATTTCTCGGAAGATACCTACCGTACACTTATGGCGGCAGACTCTGCCGTAATGGTAATTGACGGTTCAAAGGGTGTTGAGAAACAGACTATCAAACTTTTCAAGGTCTGTGTAATGCGTAATATTCCTATCATTACATTCATCAACAAGATGGACAGAGATGCAAAAAATTCTTTTGACCTTCTTGAAGACATTGAAAATGTTCTCGGAATTCACACCTATCCCGTAAACTGGCCAATCGGTTCAGGTAAAGAATTCAAGGGTGTTTATGACAGAAATTCTAAGAAAATCCTTGCTTTCACCGCTAATAACGGTCAGAAAGAAGTTGAAAAGAAAGAACTTACGCTTGACGATCCTGCCCTTGAAGATACAATAGGCTACTATCATAAGCAGGATTTATTTGATGAAATAGAACTTCTTGACGGTGCAGGCGATGAATTTGACCTTGAAGCAGTCCGCAATGGTCAGCTTACTCCTGTATTCTTCGGTTCGGCTCTTACAAACTTTGGTGTTGAGCCATTCCTTGAACAGTTCTTACAGCTCACAACTCCACCTCTGCCAAGAGAAACAGTTGATGAAAAGGTTGAGCCTATGTCAGACTTTTTCTCTGCATTTGTTTTCAAAATTCAGGCAAACATGAATAAGGCTCACCGTGACAGAGTTGCATTTATGCGCATCTGCAGCGGCAAGTTTGAAAAGAATATGGAAGTGTTCCATGTTCAGGGCAACAAAAAAATGCGTCTTTCACAGCCACAGCAGATTATGGCTCAGGAAAGAGAAATTGTTGACGAGGCATATGCGGGCGACATCATCGGTGTGTTTGATCCGGGCATTTTCTCAATCGGTGACACAATCTGTTCACCGGGACACAAGGTACAGTTCAGGGGAATTCCTACATTTGCTCCCGAACACTTTGCACTTGTCCGTCAGAAAGACACAATGAAGCGCAAACAGTTCATCAAGGGTACAAGTCAGATTGCACAGGAAGGTGCAATTCAGATTTTCCAGGAGCTTGACGCAGGTATGGAGGAAGTTATCGTTGGTGTTGTAGGCGTACTTCAGTTTGATGTTCTTAAATACAGACTTCAAAACGAGTACAACTGTGATATCATTATGGAAACACTCCCATATGAATTTATCCGTTGGATTGTAAACGATGACCTTGATCCGAAAACTCTCGACCTTGCGTCCGATACTAAGAAAATTCAGGATCTTAAAGGCAATCATCTTTTGCTCTTTACAAGCTACTGGAGCATAAACTGGGCGCTTGAACACAACAAGGGACTTGAACTCGCTGAGTTCGGTACAAACTAA",
    "translation": "MSSFKEEISKRRTFAIISHPDAGKTTLTEKLLLYGGAINLAGSVKGKRTAKHAVSDWMEIEKQRGISVTSSVLQFKYNGYCINILDTPGHEDFSEDTYRTLMAADSAVMVIDGSKGVEKQTIKLFKVCVMRNIPIITFINKMDRDAKNSFDLLEDIENVLGIHTYPVNWPIGSGKEFKGVYDRNSKKILAFTANNGQKEVEKKELTLDDPALEDTIGYYHKQDLFDEIELLDGAGDEFDLEAVRNGQLTPVFFGSALTNFGVEPFLEQFLQLTTPPLPRETVDEKVEPMSDFFSAFVFKIQANMNKAHRDRVAFMRICSGKFEKNMEVFHVQGNKKMRLSQPQQIMAQEREIVDEAYAGDIIGVFDPGIFSIGDTICSPGHKVQFRGIPTFAPEHFALVRQKDTMKRKQFIKGTSQIAQEGAIQIFQELDAGMEEVIVGVVGVLQFDVLKYRLQNEYNCDIIMETLPYEFIRWIVNDDLDPKTLDLASDTKKIQDLKGNHLLLFTSYWSINWALEHNKGLELAEFGTN",
    "product": ""
   },
   {
    "start": 9097,
    "end": 10500,
    "strand": 1,
    "locus_tag": "ctg24_11",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,097 - 10,500,\n (total: 1404 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGTACGACAAGCTTAAAAATTATTCAAAAAGCGGCATATATCCTTTTCATATGCCCGGACACAAAAGAACGGACATTACAGAAGAGGGTATAATACCGTATAATATCGACATAACCGAAATTCATGATTTTGACAATCTCCATTCACCAAACGGAGTTATTGATGAAATTCAGGAAAAGGCTGCAAAGCTTTACAATGCAAAAAATGCTTTCATTCTGATTAACGGTTCAACAGGCGGAATACTTTCAGCAATTCGCTCAATGACAAATCAAGGCGACAAGATCTTAATGGCTCGTAACTGCCACAAATCTGTATATAATTCAGCAGAACTGTTTAATCTCAATGTCGATTACATTTTTCCTGATACAGACAGCAGATACAATATTCTTACATCGGTTTTACCTTGCGATATAGAAGATAAACTTACAAAACACAATGATGAAATCAGACTTGTAATCATAACTTCGCCTACATATGAAGGAGTTGTTTCGGATATAAAGTCAATTTCCGAAATCTGTCACAAACACGGAGCAAAATTACTTGTTGACGAAGCTCACGGAGCGCATTTTCCGTTTTCGGACAGTTTTCCCGATGAAGCACTTAACTGCGGTGCAGACGCCGCAGTATTGAGTCTGCACAAAACTTTGCCGTCATTAACTCAAACTGCATTGCTCATAGCAAATGACAGCGAGCTTTCTGAAATTCTTGCCGAAAATTTAGCTGTATTTGAAACAAGCAGTCCGTCATATATTTTAATGAGTTCAATCGAAAAATGTCTTGATTTCTGCGAAAACAGCAAAGATAAATTCAAGGAATATTGTTGCAATCTTAAAACGGTCAGAAAAAAACTTGAAAATCTAAAATATCTGAAAATTTATGATAAAAGCGATACTGATTTTGATTATGATATCAGCAAAATTGTAATTTCAACAGCGAACGCAAATATTTCGGGAACAAAGCTTGCCGAAATACTGCGAAATAATTATCAGATTGAAACCGAAATGGCATATTCGGACTATGTAATTGCCATGACATCTGTTTGTGACACTGAAAAAGCTTTTGATATGCTTTCAGACGCTCTGATTTCAATTGACAGCGAACTTTCAAAAGGAGCCGACACCGAGCGTGTTCCGTTAAAAAATCTCTACACAGGCAAAAATTTCAACGCCTACGAGTTGTACAAATTCAACAAAGAAACTATTCCGTTTCAAAATTCGGAATTCAGAACTTCTGCCGAGTATATCTGGGCATATCCACCCGGAATTCCCCTCATCATACCCGGTGAAATTATAAGCAAGGAACTTATAAATTACATTGAATATCTTTCAGCCTGCAAGGTTGAGATTATGTCAACAAAAGGCGGTATGACGGACAACATAAGCGTAGTTAAAAAAGATTGA",
    "translation": "MLYDKLKNYSKSGIYPFHMPGHKRTDITEEGIIPYNIDITEIHDFDNLHSPNGVIDEIQEKAAKLYNAKNAFILINGSTGGILSAIRSMTNQGDKILMARNCHKSVYNSAELFNLNVDYIFPDTDSRYNILTSVLPCDIEDKLTKHNDEIRLVIITSPTYEGVVSDIKSISEICHKHGAKLLVDEAHGAHFPFSDSFPDEALNCGADAAVLSLHKTLPSLTQTALLIANDSELSEILAENLAVFETSSPSYILMSSIEKCLDFCENSKDKFKEYCCNLKTVRKKLENLKYLKIYDKSDTDFDYDISKIVISTANANISGTKLAEILRNNYQIETEMAYSDYVIAMTSVCDTEKAFDMLSDALISIDSELSKGADTERVPLKNLYTGKNFNAYELYKFNKETIPFQNSEFRTSAEYIWAYPPGIPLIIPGEIISKELINYIEYLSACKVEIMSTKGGMTDNISVVKKD",
    "product": ""
   },
   {
    "start": 10540,
    "end": 10701,
    "strand": -1,
    "locus_tag": "ctg24_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,540 - 10,701,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACTTTTCGCACTGCTGGTTAGCAACGCCGCAAGATGTCTTACAAGCTGACTGGCATGAAGTCTGGCACTCGCCGCAACCGCCTGTCTTAACGCTCTTCTTGAGGTCACGAGTTTCGATAGTTTTAATTCTCTTCATAATAAATCAAACTCCTTGTTAG",
    "translation": "MHFSHCWLATPQDVLQADWHEVWHSPQPPVLTLFLRSRVSIVLILFIINQTPC",
    "product": ""
   },
   {
    "start": 10796,
    "end": 12169,
    "strand": 1,
    "locus_tag": "ctg24_13",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,796 - 12,169,\n (total: 1374 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTCATCAGTATAAACTTAACGGATACAACATAGTTCTTGATGTTTACAGCGGCAGTGTACACGCAGTCGATGACCTTGCTTATGATGTTATTGCAATGTACAAAAACGCAACAAAAGAACAGATAATCAACGAAATGCTTTCAAAATATGCAGACAATCCTGAGATTACAAAAGAAGAAATCTCCGACTGCATTGATGATGTAAAAGAGCTTGAGGAACAAGGAAAGCTCTTTACAGACGACAAATACGAAAACCTTGCATTTGACTTTAAAAAGAGAAACACAGTAATCAAAGCGCTTTGTCTGCACATTGCTCACACCTGTAACCTTAACTGCGAATACTGCTTTGCAAGTCAGGGCAAATACCACGGCGAGAGAGCGCTGATGAGCTTTGAAGTGGGCAAGAGAGCAATTGACTTTCTAATTGAAAATTCAGGCAGCAGAGTAAACCTTGAGGTTGACTTCTTCGGCGGAGAACCTCTTATGAACTTTGATGTTGTAAAGCAGATTGTTGCCTATGCAAGAAGCATTGAAAAGGAACACAACAAAAACTTCCGTTTTACACTTACAACAAACGGTATGCTTGTTGATGACGATGTAATTGAATTTGCAAACAAAGAATGTCATAATGTAGTTCTCAGCCTTGACGGCAGAAAAGAAGTGCATGACCATCTTCGCAAAACTGTAAACGGCAAGGGCAGTTATGACATTATCGTTCCGAAATTTCAGGAATTTGTCAAAAAAAGAGGTAACAAGGGTTACTATGTAAGAGGCACTTATACACATAATAACACAGACTTCACAAACGATATTTTCCATATGGCGGATTTGGGATTTACAGAGCTTTCAATGGAGCCGGTTGTATGTGCTCCCGATGACCCATATGCACTTACATATGACGATTTGCCTATCCTTTTTGAACAGTACGAAATTCTTGCAAAGGAAATGCTCAAGCGTGAAAAAGAGGGCAGACCGCTCACCTTCTATCACTATATGATTGACCTTACAGGCGGTCCGTGCATTTATAAGAGAATCTCGGGTTGCGGTTCGGGTACAGAGTATATGGCTGTAACACCTTGGGGCGACCTTTATCCCTGTCATCAGTTTGTAGGCGATGAAAAGTACAAGCTCGGCGATATCTTTAACGGTGTTTCAAACACGAAAATTCAGGACGAATTTAAGCTTTGTAACGCATACGCCCGTCCCGACTGCAAAGACTGCTGGGCAAGACTTTATTGCAGCGGCGGTTGTGCCGCAAACGCTTATCATGCAACAGGCTCAATCACAGGTATTTACGAATATGGCTGTGAGCTTTTCAGAAAAAGAATGGAATGTGCCATTATGATGAAGGTTGCAGAAGCAGAAGAATAA",
    "translation": "MIHQYKLNGYNIVLDVYSGSVHAVDDLAYDVIAMYKNATKEQIINEMLSKYADNPEITKEEISDCIDDVKELEEQGKLFTDDKYENLAFDFKKRNTVIKALCLHIAHTCNLNCEYCFASQGKYHGERALMSFEVGKRAIDFLIENSGSRVNLEVDFFGGEPLMNFDVVKQIVAYARSIEKEHNKNFRFTLTTNGMLVDDDVIEFANKECHNVVLSLDGRKEVHDHLRKTVNGKGSYDIIVPKFQEFVKKRGNKGYYVRGTYTHNNTDFTNDIFHMADLGFTELSMEPVVCAPDDPYALTYDDLPILFEQYEILAKEMLKREKEGRPLTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDEKYKLGDIFNGVSNTKIQDEFKLCNAYARPDCKDCWARLYCSGGCAANAYHATGSITGIYEYGCELFRKRMECAIMMKVAEAEE",
    "product": ""
   },
   {
    "start": 12235,
    "end": 13044,
    "strand": 1,
    "locus_tag": "ctg24_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,235 - 13,044,\n (total: 810 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACGAAAAAATTATTATGCTCGGCACAGGAAGTGCGATGGTTACCGACTGTTATAATACCTGTTTTCTTCTGAAATCCGAAAACGACTGTCTTCTTGTTGACGCAGGCGGCGGAAACGGAATTTTATCCGCAATTAAGAAATCCGGAATAGCTTGGAACAGCATAAAGACAATGTTTATTACTCATTCTCACACCGACCATATATTAGGTGCCGTGTGGGTAATAAGGCAAATAAGCGCTCTTATGAATTCAGGCAAATATGACGGTAATTTTAATATTTACTGCCACGATGAATGTGTTGATTCAATCACGGCAATTTGCAACCACACACTTGCACCGAAATTTCTCAAAAATATCAATACAAAAATTTTCATCAATGAAGTAAAAGACGGTGAAATGCAAAACGCCGGCAGTATCCGACTCACTTTCTTTGATATATTTTCAGACAAAACAAAGCAATTCGGATTCAAGGCTGTTTTTCCGTCAGGAAAAGTTCTCGCCTGTCTCGGTGATGAACCGTTCAATGAAAAATGCAGAAATTTTGTTCAAAACTGTGATTATCTTATGTGTGAAGCTTTTTGTCTTTACAGTCAAAAAGATATTTTTAAGCCCTACGAAAAATTCCACAGCACAGCGCTTGATGCAGGAAAACTTGCAGAGAGTCTTTTTGCAAAAAATCTTATCCTGTATCACACCGAGGACGAAACACTTCAAACACGCAAAAGTACATATACTTCAGAGGCAAGAACAGTTTTTAACGGAAATATATTTGTTCCCGATGATTTTGAAGTTATTGACTTAAAATAA",
    "translation": "MNEKIIMLGTGSAMVTDCYNTCFLLKSENDCLLVDAGGGNGILSAIKKSGIAWNSIKTMFITHSHTDHILGAVWVIRQISALMNSGKYDGNFNIYCHDECVDSITAICNHTLAPKFLKNINTKIFINEVKDGEMQNAGSIRLTFFDIFSDKTKQFGFKAVFPSGKVLACLGDEPFNEKCRNFVQNCDYLMCEAFCLYSQKDIFKPYEKFHSTALDAGKLAESLFAKNLILYHTEDETLQTRKSTYTSEARTVFNGNIFVPDDFEVIDLK",
    "product": ""
   },
   {
    "start": 13036,
    "end": 14949,
    "strand": -1,
    "locus_tag": "ctg24_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,036 - 14,949,\n (total: 1914 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTTTTCTACGGATAAATCATCTTTTAATAAAAAGGATGTCTCGGATTGTGATTACAAAATTTCACTTGCCGGTAATCCTAATGTCGGCAAGAGTACAATTTTTAACGAACTGACGGGATTAAGGCAGCACACGGGAAATTGGACGGGTAAAACAGTTGAGTTTGCCAGAGGTTGTTGCAAAATCAAAGACGCAAGATTTTGTATTACGGACTTACCCGGATGCTATTCCCTGCTTTCATTTTCGGGCGAAGAGGAGGTAACAAGGGAGTGTCTTATACAAAATCAAAATGACTGCGTTGTAATAGTTGTTGACTGCGGAGTTATTGAAAGAAATCTTTCATTTGCATTGCAGGTGTTATCTGTCACAAAGAATGCTGTTCTTTGTCTTAATCTTTGTGATGAGGCTGAAAAAAACGGTATAAAAATCGACTGCGACGAGTTATCGCTAAATCTTGGAATACCTGTTGTAAAAACCTGTGCAACAGACAAAAAAGGTTTGGATGAGTTAAAAAAAGCGATCTATAATGTATGCACCGGAAAGACAAAATGTTTTAGGGTAGAAAGAAATTTTGAAGGTGTTGATATACTATCCGAAAAAAACTACAAACAGAATATTGAAAAGCTTTCGCAAATTGGTAACAAAATTTCATGTGACTGCGTAAAATATGAAAAATCAGAGTTAAATGCTTGTACAAGAAAGCTTGATAAAATACTTACAAGCAAAACCACGGGAATACCGATTATGCTTGCAATGCTTGGTATATTGTTCTGGATAACAGTTGTCGGTGCAAATTATCCGAGTGAATGGTTAAGCAATTTGTTTGGTTTTATAAAAGAGAAGCTGTATATTCTTTTTGATTTTTTACACGCTCCCGATGTTGTAACGGGACTTTTGATTGACGGAGTTTATACAACTCTGTCATGGGTGGTATCTGTAATGCTGCCGCCTATGGCTATATTCTTTCCGTTGTTTTCGCTTGTTGAGGATTCGGGATATCTGCCGAGAATTGCATTTAATCTTGATAGGTATTTTTCAAAGTGCGGTGCACACGGAAAGCAAAGTCTTGCTATGGCAATGGGTCTTGGCTGTAATGCCTGCGGAGTTACGGGATGCAGAATCATTGAGTCGCCAAAGGAACGACTGATTGCAATTCTTACAAATAATTTTATGCCGTGTAACGGACGGTTTCCCACAATAATTGCATTACTGCTCATGTTCTTTGCAGGTACGGCATTTACGCTGAGCAGTTCGCTTGAGGTAGCGGCATTGTTGATTGGAATAATAGTTTTCTGTGTTTTTATAACACTTGTTATATCTAAGGTACTTTCAGTCACAATATTGAAAGGTGAACAGTCCGGATTTGTGCTTGAACTTCCGCCGTACAGAAAGCCGCAGATTTTAAAAACTATTGTCCGTTCGCTGTTGGACAGAACTTTATTTGTTTTAGGAAGGGCTGTTGCGGTTGCCGCTCCGGCAGGTGCGATAATCTGGATTCTTGCAAATGTGCATATAAGCGATGTTTCACTTTTAAAATATTGTACTGATTTTTTAGATCCGTTCGGCAGATTTATCGGGGTTGACGGCGTTATAATAATGGCATTTATACTTGGATTTCCTGCGAATGAAACCGTTATTCCGATTATAATTATGTCATATATGGCAAGCGGTACTCTTGTTGATTATTCAAGCTACGATCAGCTGTTTCAACTTCTCAGCATGAACGGCTGGACAATTACAACGGCTGTATGTACGATTATTCTTTGCATTCTTCATTATCCGTGTTCAACAACCTGTCTGACAATAAAAAAAGAAACAGGCAGCCTTAAATGGACGCTTGTTTCTATGGCATTGCCTACTGCAATGGGAATTGTACTTTGTATGATTACAGCAGGTGTTATGAGATTATTTTAA",
    "translation": "MFSTDKSSFNKKDVSDCDYKISLAGNPNVGKSTIFNELTGLRQHTGNWTGKTVEFARGCCKIKDARFCITDLPGCYSLLSFSGEEEVTRECLIQNQNDCVVIVVDCGVIERNLSFALQVLSVTKNAVLCLNLCDEAEKNGIKIDCDELSLNLGIPVVKTCATDKKGLDELKKAIYNVCTGKTKCFRVERNFEGVDILSEKNYKQNIEKLSQIGNKISCDCVKYEKSELNACTRKLDKILTSKTTGIPIMLAMLGILFWITVVGANYPSEWLSNLFGFIKEKLYILFDFLHAPDVVTGLLIDGVYTTLSWVVSVMLPPMAIFFPLFSLVEDSGYLPRIAFNLDRYFSKCGAHGKQSLAMAMGLGCNACGVTGCRIIESPKERLIAILTNNFMPCNGRFPTIIALLLMFFAGTAFTLSSSLEVAALLIGIIVFCVFITLVISKVLSVTILKGEQSGFVLELPPYRKPQILKTIVRSLLDRTLFVLGRAVAVAAPAGAIIWILANVHISDVSLLKYCTDFLDPFGRFIGVDGVIIMAFILGFPANETVIPIIIMSYMASGTLVDYSSYDQLFQLLSMNGWTITTAVCTIILCILHYPCSTTCLTIKKETGSLKWTLVSMALPTAMGIVLCMITAGVMRLF",
    "product": ""
   },
   {
    "start": 14965,
    "end": 15201,
    "strand": -1,
    "locus_tag": "ctg24_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,965 - 15,201,\n (total: 237 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGAAAAATGTTCGCTTGACAAGTTACCGCTTGGAGTTACGGGGATTGTCTATCGTGTGAACTGTAATGAAAATATCAAAAACAGAATATTTGATTTCGGTATTATGGAGAACAGTTCTGTTATCCCCTTGTTTACAAGTCCGTTCGGTGATCCGTCTGCGTATCTTGTTAAAAATGCCGTTGTGGCACTGAGAAATAACGATTGCAAAGATATCATTGTTACTCCTGAATAA",
    "translation": "MKEKCSLDKLPLGVTGIVYRVNCNENIKNRIFDFGIMENSSVIPLFTSPFGDPSAYLVKNAVVALRNNDCKDIIVTPE",
    "product": ""
   },
   {
    "start": 15669,
    "end": 17558,
    "strand": 1,
    "locus_tag": "ctg24_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,669 - 17,558,\n (total: 1890 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAAATCTTTTAAAAAAATCCTCTCAATTGTACTTTCTGTAATGATGATTTCGTCACTTATGACGGTTTCACTTTCAGTAAGCGCAGTTGAAGACGGAAAAGTAAGAGTAATTGTCAGAAATGATACATACTCAGTAGAAAACGGCGCTCCGTGGGACGGCGTTCTCGTTGATGAGTGGGTAAGCATTAATAATGACACTACTATGATGTCAGCCGTTGTTGATGCACTCAACAATCACGGCTACACACAGGAAGGTGCTGAGAACAATTACATCTCATCAATTAATGGACTTGCTGCATTTGACGGCGGTACAATGAGCGGTTGGATGGGAACTCTCAATGACTGGTTCACAAATTCAGGTTATGCATCCTATACAGTAGCAGACGGCACACTTGAGAGTGGTGATGAAATCGCTATTATGTATACTTCAAACGGTTACGGCGAGGATATCGGCGGTACATGGGCAAATAACGATACAACTGTTAAATCGGTTGAGATCACAGGTGCCGAGCTTTCGGGCGAATTCGATCCGTCAGTTACAGACTACACACTCACAATCGACACTCCGTCAGCTGATGTAAATGTAGTTCCTACTGCAACTAACAAAAACTTCCAGACAAGAAAATATAAGAATGAATATCATCCTTCTGACGACAGTGCGTTTTACAAGAGAAGTCAGGCTGTTAATGTTTCTGACGGTGACAAAATTATCATAGGTTGCGGTGATACTGCATGGCCGTCAATGAACACAAGTGAAGGCGGTACTGTATATACATTCACAGTTAAATATGCTCCTTCCGCAGCTGACACAGTTTCAAACAAGATTGACGAGGTTGCAAAATATCTCGCATCACAGGATGCCCCCACAGTTTCTTCGGTAGGCGGTGAGTGGACAGTCCTCGGTCTTGCAAGAGCAGGTAAAATCACAGACGAAATTGCAGACAGTTACTATCAGAATGCAGTTAAGTATGTTGAAGAAAAGGGTTCTGCAAAGCTTCACAATACTAAATCAACAGACAATTCAAGAGTAATTCTTGCCCTTACGGCAATCGGTAAGGATGTTACAGATGTTGCATCATATAACCTTCTTGAACCGCTTGCAGATATGGATTATGTTAAGAAGCAGGGTATCAACGGTCCTGTCTTTGCACTCATTGCACTTGATACGGGCGATTATGAAATTCCGCAGACTGACGCCGCAAATCCCACAACAAGAGAAAAGCTCGTACAGACAATTCTTGATGCACAGGTAGCAAACGGTGGCTGGACATTTTTCGGCTCAACTGCAGATCCTGATATGACAGGTATGGCAATTCAGGCACTTGCTCCTTACTACTCAACAAACAGCGATGTTAAAGAGGCAATTGATAAAGCACTCACAGCAATGTCAAACGCACAGAACGAAAACGGCGGATTTGCATCATGGGGTTCTGTAAACAGCGAAAGCTGTGCACAGGTACTCGTTGCACTTACAAGCCTTGGAATTGATCCTACAAATGATGAAAGATTCATCAAAAACGGCAACACACTCATCGATGCTATGATGAGTTTCTCCGCTGAAAACGGATTCGGTCATACAGATACAACATACAATCAGATGGCAACCGAACAGGGTTTCTATGCTTTTGTTTCATTTGACCGTCTTGTAAACGGCAAAACTTCACTCTACAATATGACTGACCGACTTGCAGAAAATTATGCCGTAGGTGATGTTAATCTTGATAACACAGTTTCTGTAATTGACGCAACACTTGTTCAGAAGCAGATTGTAAACCTTGAACAGCTTTCAAAGGTTTCACTTATCAAAGCTGATGTAAATCATGACGGTGTTATCGATGTTGTTGATGCAACAGAAATTCAGAAAATCATCGTTAAGCTCGTTTGA",
    "translation": "MNKSFKKILSIVLSVMMISSLMTVSLSVSAVEDGKVRVIVRNDTYSVENGAPWDGVLVDEWVSINNDTTMMSAVVDALNNHGYTQEGAENNYISSINGLAAFDGGTMSGWMGTLNDWFTNSGYASYTVADGTLESGDEIAIMYTSNGYGEDIGGTWANNDTTVKSVEITGAELSGEFDPSVTDYTLTIDTPSADVNVVPTATNKNFQTRKYKNEYHPSDDSAFYKRSQAVNVSDGDKIIIGCGDTAWPSMNTSEGGTVYTFTVKYAPSAADTVSNKIDEVAKYLASQDAPTVSSVGGEWTVLGLARAGKITDEIADSYYQNAVKYVEEKGSAKLHNTKSTDNSRVILALTAIGKDVTDVASYNLLEPLADMDYVKKQGINGPVFALIALDTGDYEIPQTDAANPTTREKLVQTILDAQVANGGWTFFGSTADPDMTGMAIQALAPYYSTNSDVKEAIDKALTAMSNAQNENGGFASWGSVNSESCAQVLVALTSLGIDPTNDERFIKNGNTLIDAMMSFSAENGFGHTDTTYNQMATEQGFYAFVSFDRLVNGKTSLYNMTDRLAENYAVGDVNLDNTVSVIDATLVQKQIVNLEQLSKVSLIKADVNHDGVIDVVDATEIQKIIVKLV",
    "product": ""
   },
   {
    "start": 17585,
    "end": 18514,
    "strand": 1,
    "locus_tag": "ctg24_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,585 - 18,514,\n (total: 930 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAAAGATAAAAAAGTTTGTTAAAAAAAATCAAATACTTTTAATTGCGGTGTGCGTTTGTATTGCCGCACTTACAGTAGCATTTTTTGCAGGCGGCAACCGATCGGAAAATAAAGTTCAAACTGCATCAACTGCCTCCTCGCTATCGACAACAAATGCAGACACAGAAACAACTTCTGTGTCTGCAACAGAGAAAACCACTCAAAATCCTACCGATTCCACTAAATCAAACAAAGATAAAAAGGACAGGAAAAATTCCGAAGATAAAAAGAACAGTAAGGATAATTCGCAGAACAGTAACGGTTCAGCCGTTGAAAAAAGTGAAAAATCCGAGCAGAGTTCAAACAACAGTTCTTCGGATAAGAAAAAAACGTCTTCTTCATCAAACAGTTCTTCAAAGCCGAACAAAAAGAATGATGTTCAGCCGACAACACAGGATAAGTACAAAACCGATCCCGTACCGTCGGGAAAGCCAAAGCCGGTTGAACCGGAAGAACAGGAAACAAAAGATACAAATCTTTATTGTACCTTTACAATCACCTGTTCAACAATTCTTGACAATATAGATGACCTTGATCCCGAAAAAATTGAACTTGTTCCAAAGGACGGTATAATCCTCAAAAAACAGAAGGTTCAATTCAAAGAGGGTGAATCTGTATATGATGTCCTTGTAAAAGTTTGTAAGGACAACAATATTCATATGGAATCAAGCTGGACTCCTATGTATAATTCCGCTTATATTGAAGGAATTAACAACCTCTACGAATTTGACTGCGGTTCTCTCTCGGGCTGGATGTACAAAGTCAATGAATGGTTTCCAAACTACGGCTGTTCACGATATGTACTCAAGAACGGCGACGATGTGGTCTGGTGCTACACTTGTAACTTAGGCTATGATGTCGGCGGAGGATACGCAACAGGAGAATAA",
    "translation": "MEKIKKFVKKNQILLIAVCVCIAALTVAFFAGGNRSENKVQTASTASSLSTTNADTETTSVSATEKTTQNPTDSTKSNKDKKDRKNSEDKKNSKDNSQNSNGSAVEKSEKSEQSSNNSSSDKKKTSSSSNSSSKPNKKNDVQPTTQDKYKTDPVPSGKPKPVEPEEQETKDTNLYCTFTITCSTILDNIDDLDPEKIELVPKDGIILKKQKVQFKEGESVYDVLVKVCKDNNIHMESSWTPMYNSAYIEGINNLYEFDCGSLSGWMYKVNEWFPNYGCSRYVLKNGDDVVWCYTCNLGYDVGGGYATGE",
    "product": ""
   },
   {
    "start": 18517,
    "end": 19407,
    "strand": 1,
    "locus_tag": "ctg24_19",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,517 - 19,407,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGATACTTTTTCAAATATGCACCCCTTTATCAATTTTATATTTTTTGCACTTACAATAGGGTTCACGATGTTTATCATGAACCCTGTTTGTCTTGCTGTCAGTTTTTTATGTGCGCTTGTAACCGCTTTATACCTTAACGGCAAAAAAGCTGTGAGATTGTCACTTGTTTTTCTTTTACCTATGATACTCTTGATAGTTCTCGTAAATCCTGTTTTTAATCATGAAGGAATGACTATACTCACATATTTTCCGTGGGATAACCCACTAACCCTCGAATCAATCGTTTACGGTATTGCAAGTGCATTTTTGCTTTCGTCAACAGTTTTATGGTTTTCTTCATTCAATGCAGTAATCACTTCCGACAAGGTAGTTTTCCTGTTTGGCAGAATAATGCCGTCATTGAGTCTGGTGATTTCAATGGCATTGCGTTTTGTTCCAAAGTTTTCGGCACAAATGAAGCTTGTGCGTAATGCACAACACACAATAGGCAGAGATATAAACGAGGGAACATTGTTTCAAAGAATAAGAAATGCTGTAAAAATCCTTTCGATTATGATAACATGGTCACTTGAAAATGCAATTGAAACAGCCGATTCAATGAAAAGCAGAGGTCACGGTCTTAAAGGCAGAACATCCTATTCACTTTATAAATTTGACAAAAGAGACGCATTTATGCTTTGCACAATCCTTTTTACCGGATTTGTACTTATGATTTTGCTTTTTACAAACGCAATAAAATTCAGATACTATCCGTCAATCAAGGGCGATTTGTTTACGGTGCAAAGTGTTATTTTTTATATATTCTACACATTTTTAATGTTGATTCCGCTATCGGTAAATATAGGAGAGGGGATAAAATGGAAACATATGCAATCAAGAATCTGA",
    "translation": "MKDTFSNMHPFINFIFFALTIGFTMFIMNPVCLAVSFLCALVTALYLNGKKAVRLSLVFLLPMILLIVLVNPVFNHEGMTILTYFPWDNPLTLESIVYGIASAFLLSSTVLWFSSFNAVITSDKVVFLFGRIMPSLSLVISMALRFVPKFSAQMKLVRNAQHTIGRDINEGTLFQRIRNAVKILSIMITWSLENAIETADSMKSRGHGLKGRTSYSLYKFDKRDAFMLCTILFTGFVLMILLFTNAIKFRYYPSIKGDLFTVQSVIFYIFYTFLMLIPLSVNIGEGIKWKHMQSRI",
    "product": ""
   },
   {
    "start": 19380,
    "end": 20597,
    "strand": 1,
    "locus_tag": "ctg24_20",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg24_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg24_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,380 - 20,597,\n (total: 1218 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 79.9; E-value: 2.8e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg24_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMETYAIKNLSFRYPETGIDVLKDITFSVNEGEFITVCGPSGCGKSTLLRHLKPDLSPHGVLSGEILFEEKPISDLSHREQSSKIGFVMQSPENQIVTDKVWHELAFGLESLGYDNNTIRKRVAETASFFGIQNYFEKSVLELSGGQKQILNLASIMAMQPSVLILDEPTSQLDPIAASEFLHCVSRINHELGTTVIITEHRLDEVLPLSDRVLVIENNGISAFDSPQKVGKILKEKVSKTFLSMPAPMQIWQAVTENDNTDCPVTVPSGKKWLSEYAQNHKMYELKPESIQKHSDKEAVSLNDIWFRYEKSGADVLKGLSLKIYQGEFAAILGGNGMGKSTALSIICSLNKPYRGKVEISPLNKNSFDTLVAVLPQNPQTLFLKKTVLEDLYEVFDGRKISKEEKE\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg24_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAACATATGCAATCAAGAATCTGAGTTTTCGATACCCCGAAACCGGTATTGATGTACTTAAAGATATTACTTTCAGCGTAAATGAAGGCGAGTTTATCACGGTCTGCGGTCCGTCAGGCTGCGGAAAAAGCACACTTCTCAGACATCTGAAACCCGATCTTTCACCGCACGGTGTTCTTTCGGGAGAAATATTATTTGAAGAAAAACCTATATCAGACCTTTCTCACAGGGAGCAAAGCAGTAAAATCGGCTTTGTTATGCAATCACCTGAAAATCAGATTGTTACCGATAAGGTATGGCACGAACTTGCTTTCGGACTTGAAAGTCTTGGTTATGACAACAATACAATCCGAAAAAGAGTTGCCGAAACAGCTTCATTTTTCGGAATCCAAAATTATTTTGAAAAAAGTGTTCTCGAACTTTCGGGCGGACAAAAGCAAATTTTAAACCTTGCTTCAATTATGGCAATGCAACCGTCCGTTCTCATTTTGGATGAACCGACAAGCCAACTCGATCCGATTGCGGCAAGCGAATTTTTGCACTGCGTTTCACGCATAAATCACGAACTGGGGACAACGGTGATAATAACGGAACACAGACTTGATGAGGTGCTTCCGCTTTCAGACAGGGTGCTTGTCATCGAAAACAACGGAATTTCAGCTTTTGACTCTCCTCAAAAGGTCGGAAAAATTCTTAAAGAAAAAGTCAGTAAAACATTTCTTTCTATGCCTGCTCCGATGCAGATATGGCAGGCTGTTACAGAAAATGACAATACCGACTGTCCCGTAACTGTCCCAAGCGGCAAAAAGTGGCTTTCGGAATATGCCCAAAATCATAAAATGTATGAGCTCAAACCCGAAAGCATTCAGAAACATTCTGATAAAGAAGCAGTAAGTCTTAATGATATTTGGTTCAGGTACGAAAAGTCGGGTGCAGATGTACTAAAAGGTCTTTCACTAAAAATATATCAGGGGGAATTTGCGGCTATACTCGGCGGTAACGGAATGGGAAAATCAACCGCTTTGTCAATTATCTGTTCACTTAACAAGCCATACAGAGGCAAAGTTGAAATCTCTCCGCTTAACAAAAATTCTTTTGACACGCTCGTAGCAGTATTACCCCAAAATCCGCAGACACTGTTTTTGAAAAAAACTGTACTTGAAGATTTGTACGAAGTATTTGACGGCAGAAAAATCAGCAAGGAGGAAAAAGAA",
    "translation": "METYAIKNLSFRYPETGIDVLKDITFSVNEGEFITVCGPSGCGKSTLLRHLKPDLSPHGVLSGEILFEEKPISDLSHREQSSKIGFVMQSPENQIVTDKVWHELAFGLESLGYDNNTIRKRVAETASFFGIQNYFEKSVLELSGGQKQILNLASIMAMQPSVLILDEPTSQLDPIAASEFLHCVSRINHELGTTVIITEHRLDEVLPLSDRVLVIENNGISAFDSPQKVGKILKEKVSKTFLSMPAPMQIWQAVTENDNTDCPVTVPSGKKWLSEYAQNHKMYELKPESIQKHSDKEAVSLNDIWFRYEKSGADVLKGLSLKIYQGEFAAILGGNGMGKSTALSIICSLNKPYRGKVEISPLNKNSFDTLVAVLPQNPQTLFLKKTVLEDLYEVFDGRKISKEEKE",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 10795,
    "end": 12169,
    "tool": "rule-based-clusters",
    "neighbouring_start": 795,
    "neighbouring_end": 20597,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r24c1"
 },
 "r49c1": {
  "start": 1,
  "end": 12420,
  "idx": 1,
  "orfs": [
   {
    "start": 1,
    "end": 870,
    "strand": -1,
    "locus_tag": "ctg49_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 870,\n (total: 870 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTATTTTACAGCTATGCGGAGTTTGTAATAGGGCTTGTGGCAATTTTCTATTTTACTTCAAAAATATTTTCCATTACCAAGTACAAACTGTATTTTGCCCTGTCATTGATTTTTATAATTTCAACGGCATCGTTTGCCTGCTTTATAAAAAGCGACCAACGGTATGTAATTCTGCCGGTTTTGCATTTCGTTACATTGACATTTCTTCCGATTTCACTTGGATACAATAAGAAAATGATGTTGCTGTTCTCTTCGCTCTTCTTTTCGGGATTAACATTTTTTATATCCGAAATCTATCAATTGTTGTGTTCAATCTATTCAACCGAATTTGCGAGCAGCACCAGTGTGTTTTTTAATCTGATTTCAAATCTTATTGTTTTGGGAATATTCATACTGCTGTCAAGTCCGCTGAAAATCAAGACCAAGCTTGTGGTTGAGTCAATTACCAAACCGACAATAATTATGATATTGATTTTCCTTTATCTCGGCGGAAGTATGGCGACCTTCGGGGCATATTACATAATTCCGTCATCGGATTACAGAACAGCTGCACTTAAAATTTTGACAATGATTGTGTCGATTGTATTCTCGTTTTCAATACCTATTCTTTTGTACAATCAGATTAAAAAGAGCCAATATATGCACGAAAACGATATCTACGAAAGACAGCTTAACGCACAGATTAATTATTACAAGAGCATTACGACTTCGGGATATGAACTGAGAAAAATCAGGCATGATTATAATGATCTTTCTATCGGGTTGAAGTCGCTTATCAACAGTCGGAAATATGATGAGGTTCTTCCCCTCCTGCAAAAATATGACAGCGAGATTATAAGCTCATTTCAGATTTTGTACAACACGGGC",
    "translation": "MLFYSYAEFVIGLVAIFYFTSKIFSITKYKLYFALSLIFIISTASFACFIKSDQRYVILPVLHFVTLTFLPISLGYNKKMMLLFSSLFFSGLTFFISEIYQLLCSIYSTEFASSTSVFFNLISNLIVLGIFILLSSPLKIKTKLVVESITKPTIIMILIFLYLGGSMATFGAYYIIPSSDYRTAALKILTMIVSIVFSFSIPILLYNQIKKSQYMHENDIYERQLNAQINYYKSITTSGYELRKIRHDYNDLSIGLKSLINSRKYDEVLPLLQKYDSEIISSFQILYNTG",
    "product": ""
   },
   {
    "start": 874,
    "end": 1581,
    "strand": -1,
    "locus_tag": "ctg49_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 874 - 1,581,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTTTGCGGCTTTATGTGATGATGATAAACACATAACCGAAGAGGTTAAAAAACTGCTTTTAGAATATGCAAAGGATAATCGTGTAACTATTGATATTGATGAATTTGAAAGCGGTGAAAAGCTTTTGAATTCCGAGAATAATTACGATATAATCGTGCTTGATTTTCAGCTTGGCAGTACAGACGGACTGACTGTTGCAAAGGAGCTCAGAAAACGCAATGTGCTTTCCTGCATAATTTTTCTGACATCTTACCCCAACTTTATGATTGATGCGTTTGAAGTGAACACATTCAGATTTCTTCTGAAACCGATTGACAAATCAAAATTTTTCAAGGCAATTGATGACTATGTAAAAATTGTAGATGCAAATTATCCGATAACTCTTATTCAAAATAAGGAATTGAAAAAAATTAACTCAAATGAAATTTGCTTTATTGAGGCAGACGGAAAGTACTCAAACATTCATTTAAACACCAAGGTCATGCACTGTTCAAAAACTCTTTCGGGAGTTACAAATCTTCTCCCAAAGTATTGTTTTGTAAAAACTCATCGTTCTTTCGTGGTAAATCTTCACTATATAAAATCATACTCATCAGATACGGTGTATCTGAGTAACGGCGAATCGGCTTATCTCAGTAAAAATTATCAAAAATCCTTTCGGACATCATATATGAATTTTCTTGAAAAAAATTATGTGAGGTTATAA",
    "translation": "MFAALCDDDKHITEEVKKLLLEYAKDNRVTIDIDEFESGEKLLNSENNYDIIVLDFQLGSTDGLTVAKELRKRNVLSCIIFLTSYPNFMIDAFEVNTFRFLLKPIDKSKFFKAIDDYVKIVDANYPITLIQNKELKKINSNEICFIEADGKYSNIHLNTKVMHCSKTLSGVTNLLPKYCFVKTHRSFVVNLHYIKSYSSDTVYLSNGESAYLSKNYQKSFRTSYMNFLEKNYVRL",
    "product": ""
   },
   {
    "start": 2202,
    "end": 9533,
    "strand": -1,
    "locus_tag": "ctg49_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,202 - 9,533,\n (total: 7332 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (rule-based-clusters) NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 148.6; E-value: 5.2e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTAATTTAATCAACTTGCTTGATACATACAAAGGTGAAAAGCGAGAGCTTTATCCGCTTACACCGAGCCAGATGGGTGTTTATCTTTCGTGTATGCACAACCCAAAAGGCACAATGTACAACATTCCCTGCACCTATGTTTTTGACAAGGGCAGTCTTGATACCGACAGGCTGATAAATGCCGTAAGAAAAGCTGTTGACAATCACCCTGTTATGAAAATTTTTATTGACAGTTCAACAGGAAGCCCGATGATGAAGCCTCGTGACAGCGTTGATTTTGACATTCCTGTCGTACAGGTTGACAATCTTGAACAGGCAGGCAAAGATTTTGTTAAGCCGTTTGACCTTGAAAAAGACATTCTGTTCAGATTTGCAATTTTTGAATGCGGTGACAAATCTATGTTTGCAATGGACTTTCACCATATAATCTCTGACGGCACATCTGTTTCGGTTATCTGCAATGACATTGCGCTTGCATATGACGGAAAAGAGCTTGAACCCGAAAAGTTTTCTCAGCTTGATCTTTCTGTTTTTGAGGAAAAGCTTGAAGAAACCGAAGAATATCAAAAATCAAAGAACTACTATGACAGCATTTTTTCGGCTGTTGAGTCAAAGTCGGAAATAACGGAAGATTTTGCAGAGAATTCAGAGGTTGAGGATAAACCGAACGGTTCTTTTGAATTATCCACGAACGGCAAATTCTCCGTTGAGGAAGTTCGCAATTTTGCCTTAGCAAACCAAATTACGCCGTACACTGTTTTCCTCGGTGCATATGAATACGCAGTTGCAAAGTTTACAAATCAGAGCGAAACAACGGTTTGCACGGTTACTCACGGAAGATTTAACAAACAGCTTAAAAATACGGTCGGCATGATGGTTCGCACACTTCCTATCCACGCAAATATTGATGAAGAAGATACAGTTTCGGACTACCTCAAAAAAATACGCAGGAATATAAAGGAAACAGTTGCAAACGATTGGTTTCCGTTTATGAAACTTGCGTCTGACTATGACCTCTCTGCCGACATTATGCTTGCCTATCAGGCTGACATATTCAACACCTTTAAAATAGGCGGTCAGGCTCTAAAATTAAAACTTGTTCCGTTAAAAAGTGCCATTTCAAAATTGAATGTTATGGTATTTGAATCAGAAACAGATTTTGAATTGCGTTTTGAATACAGAAACGATTTATTCAAAGAGGAAACTATTCGTTCGTTTGCCGACAGCTTTTTAAAGATTGTTGAGCAGTTTCTTAAAAAATCCAAGCTCTGCGAAGTTGAGCTTGTAAACGAAAATCAGCTTGCAGAGCTTGATAACTTCAACAAAACGGAATTTCCGTTTGACGACAGCAAAACCGTTGTTGATTTGTTTGAGGAGCAATGCAAAAAAACTCCTGACAAAACAGCGGTTGTATATAAAGAAAAGAAGTTCACCTACGCTGAAATTGATGAGATTACAAACCGAATTGCAGGTTATGTTCACTCAAAGGGTATCGGTAAAGAAGAGGTTGTTTCAATTCTGATTCCGAGATGCGAATATATGCCGATTGCGTCAATCGGTGTGCTGAAATCGGGTGCGGCATATCAACCGCTTGATCCGTCATATCCGCCCGAAAGACTTCAGTTTATGATTAAGGACGCAAACGCAAAGCTGCTTATTGCGGACGAAAATCTGCTTGAACTTTTGCCCGATTACAGCGGTGATATTCTTCTTACAAAGGATATTCCGAATCTTCCGAAATCAGATGCAGTTTTTACAAAACCCTCACCCGATGATTTGTTTATACTTATCTATACATCGGGTTCAACAGGCACTCCAAAGGGTGCTATGCTTGAACACAAAAATGTGCGTTCATTCTGCGATTTTCATATCAGAAACTCTGACATTGACGAACACAGCGTTGTTTCGGCATATGCAAGCTACGGTTTTGACGCCTGTCTCAGTGAAATGTATCCTGCGCTTATCGGCGGTGCCGAGCTTCACATTATTGAGGAGGACATCAGACTTGACCTTGTAAGGCTGAACAGATATTTTGAAGATAACGGAATCACCCACGCATTTATGACAACACAGGTTGCAAGACAGTTTGCAACCGAAATTGACAACCACTCGCTCAAATATCTTCTTACGGGCGGTGAACGGCTTGTTCCCCTTGAACCGCCAAAGAATTTTGAACTCATAAACGGTTACGGTCCGACAGAATGTACGGTTTACATCACAACACAGCCCGTTGACAAGCTCTACCACAGAATTCCTGTCGGCAAGGCTCTTGACAATATCAAGCTTTATGTAACAGACAAATACGGCAGACGGCTTCCGACAGGGGCTTTGGGCGAGCTCTGTGTATCAGGTCAGCAGGTTTCAAGAGGGTATCTTAACCGTCCCGAACAGACTGCAAAGGCATACGAAAAGAACCCATATTGCAATAAAAACGGTTACGAAAGGCTTTATCACACAGGTGACATTGTTCGCCTTACAGATGAGGGCAAGGTTGATTTTATCGGACGAAATGACGGTCAGGTTAAAATCAGAGGATTCCGCATTGAGCTTTCCGAGGTTGACAAGATTATCCGCAAATATGACGGCATTACAAACACAGCTGTAATCGCAAGAAAGCTTGATGGCGGCGGACAATGCATTAACGCATATATTGTTGCCGACAGAAAAATTGACATTCAAAAGCTCAACGAATTTATTCTTGAACACAAGCCGCCGTATATGGTACCCGCCGCTACAATGCAGATTGACAAAATTCCGCTCAATGTAAACGGCAAGGTTGACAAGCGCAAGCTTCCCGAAATCAAGGCAGAATCTTCAAAAAAGAAAAATTCCGCTCCGAGGGAACTAACATTCCTTGAAAAGAAAATTTCCGCAATTATCGAAAAGATTATCGGACACAGCGATTTTGATATTTCCGAAAATCTCATCAACGCAGGTATGACCTCGCTTTCGGTTATCAAGCTTGCAGTTGAACTCAACAAGGCATTCGGCTTTGAGGCACAGGTTAAAAAGATGATGAAGGGCTGTTCGCTTCTTTCGATTGAGGACGAACTTCAGGAGTTTATGTTCAGCGGTACGGCAAATCAGCAAACTGTCAAAAAAGAAGAAAAGAAAGAACATAAGGCTCTCTATCCTCTTTCAAAAACTCAGCTCGGCGTGTATATTGACTGTATGAAAAATCCGTACAGCACACTTTACAATATTCCGTCAATTCTCACATTTTCAAAATCAGTCGATGCACAAAAGCTTGCCGACTGCGTTGTAAAGGTAATCAAGGCTCACCCATATATTATGACTCACCTTTCACTTGAAAACGATGATATTGAGCAGGCATATGTTGACTCTGCAAAACCGAATGTTCCCGTTGAAAAGCTTACGGAAGAACAGCTTGAAGCCTACAAAAAGGATTTTGTAAAACCGCACAATCTTATGAAAGCGCCGCTGTTCAGAATCTCGGTTGCAGAAACCGAAAAGGCGGTATATCTGCTTTCGGATTTCCACCACCTTATCTTTGACGGTGCGTCCGTTGCACTCTTCTTTGAACAGCTTAAAACGCTGTATGAGGGAGGTAATATTGAGCCTGAAAGCTACACCTACTTTGATTATGCAGAGAATGAAATTAAGGCTGAAAGCAGTGATGAATTTAGAAATGCTGAAAAGTTCTTCGACAATATGATGAAAAATTTTGAATCTGCAAGCGAAATCACGGCTGACCTCAGAGGTCATGCAGAGGACGGTGCTCTTGCATCTCAGGCAGTCCCCGTTGATATGGCAAGGGTTGAAAACTTCTGTTCACAGCACGGAATCACTCCCGCCCACCTTTTCCTTGCCGGCACATTCTACGCTGTTTCAAGATTTGTAAACAGCAGAAATGTTTACATCAGCACAATCAGCAACGGCAGAAGCGATATGCGGCTTACAAACTGCTTTGGTATGTTTGTAAAAACTCTTGCGCTCGGCATTGAAATTGAGGACATCACCTCACTTGAATTTGTTGAAAAAAGCAAGGCTGTTTTCACGGATTCAATTGAAAATGAAATTTACCCCTACGCACAGCTTTGTGCAAAATACGGCTATGCACCGAACATTATGTACGAATATCAGCTTGGTGTTGTTGATAACCTTGAAATTGACGGCAAAGCCGTTGTCCGTGATTACCTTGAAATGAATACTGCAAAGTTCAAAACAGCCATTCACATTGAAGATTACAGGGGCAAGCCGAGCGTTGTGGTTCAGTACAATGACGCACTTTACAGCGGTGAGCTTATGAGAACGCTTGCAAAATCCGTTCTCTGTGCTGTTGAACATATTATCGAAAATCCAAACGGCAAAATCAGAAAGGTTTCACTCCTTGACAACGCCGCAATTGCTCAGCTTGAAAGCTTTAAGTCAACAGAAATTGCTCCCGTTAAGACAAAACTTCTTCACAAAATGTTTGAGGAGCAGGTTGCAAAAACTCCCGACAGAATTGCTCTTTCGGCTTGTGACGGCAAACTGACCTATAAAGAGCTTGACCGTCTTGCAAATATCACGGCAAACTCACTCATTGAAAAAGGTCTTGAAAAGGGCGGAAAGGTTCTTATTCTGCTTGAAAGAACCTCAAAATTCTTCATATCACTTTTCGGTATTCTCAAGGCAGGCGGTGCGTTTATTCCGTCATGTCCCGACTATCCGAAGGAGCGAATCGACAGTATTATTGAGGACAGTGACGCAGACTTTGTAATTACCGAGGGCGAACTGCTCAATAAATATGACCGCACGGTTGATGTTTCAAAACTTCTTTCAGGCAATAATGATGAAGACCCGAATGTTCATGTACAGCCTGACGACCTTGCGTACCTCATCTACACCTCGGGTTCAACAGGCAAGCCAAAGGGCGTTATGCTCCGCCACATTGGCATTGCAAACTACCTTGCATACAGCGACTCAAACATTCAGGTTAAAGAGGTTGTTGACAACTGTCACGCATACGGCTCTGTAACTACAATCAGCTTTGATATGTCGCTAAAGGAAACCATGCTGTCGCTCTGCAACGGTCTTACCCTCGTTTTTGCAAGTGATGAACAGGTGGTAAACCCGATGTTACTTGCAGAATTCTTTAAAGAAAACAATGTTGATGCGTTCAACTCTACACCGTCAAGACTTTTGCAGTATATGGAGCTTGACGAATTTGCAGAAGCAATGGCAAACTGCAAGGTTATTCTCTCGGGCGGTGAAAAATATCCCGACAAGCTATTAAGGATACTGCGTGAAAAAACGAACGCAACAATAATCAACACCTACGGTCCGACTGAAATCACGGTTTCTTCAAACGCAAAAAATCTTACGAATGCAGACGAAATTTCAATCGGCAGGCCGTTACGCAACTACACGGAATATATTGTTGACTCAGACAACAATCTCCTTCCAATCGGAGTTGTGGGTGAGCTTCTCATTCAGGGATACGGTGTGGCGCTCGGCTATAATAAACTTCCCGAACAAACTGCAAAGGCTTTCATCGAATTCAACGGTGAACGCACCTACCGTTCGGGTGACTACGCAAAATGGACTACAGACGGCGATGTTATTATTCTCGGCAGAACAGACAATCAGGTTAAGCTGAGAGGATTAAGAATTGAACTCGGCGAAATTGAAAAGTGTCTGACCGCAGTTGACGGAATCAAGAGCGGAATTGCTCTCATCAGAAAGGTCGGCAAGGCTGACGCAATCTGCGTTTACTACACAGCCGACAGACAGCTTGATCCCGATGAAATCAAGTCAGAGCTTGCAAAAACTCTCACAGATTATATGGTTCCGAGTGCGTATGTTCAGCTTGACGAAATGCCTCTCACACCAAACGGCAAGGTCAACACAAAGGTTCTTCCCGAACCTAAGAGCAACAAATCCGAAAGAGGTCGGTTGCCGAAGAATGAACTTGAAAAAACATTCTGCGACATCTTTGCAGAAATTCTTGAACTTGACAATGTTTTTGCAGACGATAACTTCTTTGACCTCGGCGGAACATCGCTTACAGCAACAAGAATTGTAATCTCCGCATCAAAGAAAAACATTGAGGTTGCATACAGCGACATATTTGCAAATCCTACTCCGCAGACTCTTGCAAAATTTGTGAGCAAGGATGATTCAGCCGAAGACGACCTTGAAAATCTTTCGGACTACGATTATACAAATATCAATAAAGTTCTTGAAAAGAATAATATTGATACATTTAAAAACGGTGAGCTTCAAAAACTCGGCAATGTTCTTCTGACAGGCTCTGCCGGCTTCCTCGGAGTACACATTCTCTACGAACTTCTTCACAAGTATAACGGCAAGGTTTACTGCATGATTCGTGACAAAAACAATAATCCTGCCGAAAACAGAATGAACTCAATCTACTATTACTACTTTGAAGAAAGTCTGAAAGAAAGATATCCCGACAGAGTTACCGTTATCAGCGGTGATGTTACAAACCGTGAATCATTCGATAAATTTATTGACGAGGACATTAACACGGTCATCAACTGTGCCGCAAATGTTAAGCACTTCTCAAAGGGTACAGACATTGAAGATGTAAACCTTTACGGTACTCTCAATGTGCTTGACTTCTGCAAAAAGGCTAATGCAAGGCTTGTTCATGTGTCAACAATGAGCGTTGGCGGTATGTTTGTGGGCGAACAAGGTTCTGTTGACAAGCTCAAAGAAAATCAACTTTACTTTGGTCAGCATGAGGGTTCAAAGTACACCCTGTCAAAGTTCCTTGCGGAAAGGGCGATTCTTGAAGAGGTTTCAAAGGGCTTTAACGCAAAGATTATGCGTGTAGGCACACTTGCCGCAAGAAACAGCGACGGTGAATATCAGATTAATTTCACCACCAACACATTTATGGGCAGACTCAAATCTACGCTTCTTATCGGCAAATATCCGTATGAGGCAATGGAAATGCCGTTTGAGCTTTCTCCGATTGATTTTGTGGCAAAGGCAATTCTTCTGCTTGCACAGGCTCCGAAGGATTGTACCGTGTTCCACCCGTTCAACAACCATACTCTCATTATGGGCGACCTCTATACCGAGATGAACAAAATCGGACTTCATTCACAGGGTGCAGAATATGAGGAATATATGATTGCACTTGACAGAGCCGAGCAGGATCCCGAAAAAGCAAAGATTCTTTCAAGTATGATTGCATATCAGAACATGGCTCACGGTCAAAAGACATTTACAGTCGGCAAGAGCAACACATATACAATGCAGGTTCTTTACAGAATGGGATTTGTGTGGCCCGTTACCTCGCTTGACTATATGAAACGATTCATCAACGCATTAAGAGGTCTTGGTTTCTTCGATTAA",
    "translation": "MSNLINLLDTYKGEKRELYPLTPSQMGVYLSCMHNPKGTMYNIPCTYVFDKGSLDTDRLINAVRKAVDNHPVMKIFIDSSTGSPMMKPRDSVDFDIPVVQVDNLEQAGKDFVKPFDLEKDILFRFAIFECGDKSMFAMDFHHIISDGTSVSVICNDIALAYDGKELEPEKFSQLDLSVFEEKLEETEEYQKSKNYYDSIFSAVESKSEITEDFAENSEVEDKPNGSFELSTNGKFSVEEVRNFALANQITPYTVFLGAYEYAVAKFTNQSETTVCTVTHGRFNKQLKNTVGMMVRTLPIHANIDEEDTVSDYLKKIRRNIKETVANDWFPFMKLASDYDLSADIMLAYQADIFNTFKIGGQALKLKLVPLKSAISKLNVMVFESETDFELRFEYRNDLFKEETIRSFADSFLKIVEQFLKKSKLCEVELVNENQLAELDNFNKTEFPFDDSKTVVDLFEEQCKKTPDKTAVVYKEKKFTYAEIDEITNRIAGYVHSKGIGKEEVVSILIPRCEYMPIASIGVLKSGAAYQPLDPSYPPERLQFMIKDANAKLLIADENLLELLPDYSGDILLTKDIPNLPKSDAVFTKPSPDDLFILIYTSGSTGTPKGAMLEHKNVRSFCDFHIRNSDIDEHSVVSAYASYGFDACLSEMYPALIGGAELHIIEEDIRLDLVRLNRYFEDNGITHAFMTTQVARQFATEIDNHSLKYLLTGGERLVPLEPPKNFELINGYGPTECTVYITTQPVDKLYHRIPVGKALDNIKLYVTDKYGRRLPTGALGELCVSGQQVSRGYLNRPEQTAKAYEKNPYCNKNGYERLYHTGDIVRLTDEGKVDFIGRNDGQVKIRGFRIELSEVDKIIRKYDGITNTAVIARKLDGGGQCINAYIVADRKIDIQKLNEFILEHKPPYMVPAATMQIDKIPLNVNGKVDKRKLPEIKAESSKKKNSAPRELTFLEKKISAIIEKIIGHSDFDISENLINAGMTSLSVIKLAVELNKAFGFEAQVKKMMKGCSLLSIEDELQEFMFSGTANQQTVKKEEKKEHKALYPLSKTQLGVYIDCMKNPYSTLYNIPSILTFSKSVDAQKLADCVVKVIKAHPYIMTHLSLENDDIEQAYVDSAKPNVPVEKLTEEQLEAYKKDFVKPHNLMKAPLFRISVAETEKAVYLLSDFHHLIFDGASVALFFEQLKTLYEGGNIEPESYTYFDYAENEIKAESSDEFRNAEKFFDNMMKNFESASEITADLRGHAEDGALASQAVPVDMARVENFCSQHGITPAHLFLAGTFYAVSRFVNSRNVYISTISNGRSDMRLTNCFGMFVKTLALGIEIEDITSLEFVEKSKAVFTDSIENEIYPYAQLCAKYGYAPNIMYEYQLGVVDNLEIDGKAVVRDYLEMNTAKFKTAIHIEDYRGKPSVVVQYNDALYSGELMRTLAKSVLCAVEHIIENPNGKIRKVSLLDNAAIAQLESFKSTEIAPVKTKLLHKMFEEQVAKTPDRIALSACDGKLTYKELDRLANITANSLIEKGLEKGGKVLILLERTSKFFISLFGILKAGGAFIPSCPDYPKERIDSIIEDSDADFVITEGELLNKYDRTVDVSKLLSGNNDEDPNVHVQPDDLAYLIYTSGSTGKPKGVMLRHIGIANYLAYSDSNIQVKEVVDNCHAYGSVTTISFDMSLKETMLSLCNGLTLVFASDEQVVNPMLLAEFFKENNVDAFNSTPSRLLQYMELDEFAEAMANCKVILSGGEKYPDKLLRILREKTNATIINTYGPTEITVSSNAKNLTNADEISIGRPLRNYTEYIVDSDNNLLPIGVVGELLIQGYGVALGYNKLPEQTAKAFIEFNGERTYRSGDYAKWTTDGDVIILGRTDNQVKLRGLRIELGEIEKCLTAVDGIKSGIALIRKVGKADAICVYYTADRQLDPDEIKSELAKTLTDYMVPSAYVQLDEMPLTPNGKVNTKVLPEPKSNKSERGRLPKNELEKTFCDIFAEILELDNVFADDNFFDLGGTSLTATRIVISASKKNIEVAYSDIFANPTPQTLAKFVSKDDSAEDDLENLSDYDYTNINKVLEKNNIDTFKNGELQKLGNVLLTGSAGFLGVHILYELLHKYNGKVYCMIRDKNNNPAENRMNSIYYYYFEESLKERYPDRVTVISGDVTNRESFDKFIDEDINTVINCAANVKHFSKGTDIEDVNLYGTLNVLDFCKKANARLVHVSTMSVGGMFVGEQGSVDKLKENQLYFGQHEGSKYTLSKFLAERAILEEVSKGFNAKIMRVGTLAARNSDGEYQINFTTNTFMGRLKSTLLIGKYPYEAMEMPFELSPIDFVAKAILLLAQAPKDCTVFHPFNNHTLIMGDLYTEMNKIGLHSQGAEYEEYMIALDRAEQDPEKAKILSSMIAYQNMAHGQKTFTVGKSNTYTMQVLYRMGFVWPVTSLDYMKRFINALRGLGFFD",
    "product": ""
   },
   {
    "start": 9552,
    "end": 11312,
    "strand": -1,
    "locus_tag": "ctg49_4",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,552 - 11,312,\n (total: 1761 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1086:MATE efflux family protein (Score: 291.1; E-value: 2.1e-88)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSSTVLGRNAVTVNKKYTEYFLPTVLTAMATNIAMIVDSIIAGNLLGQNSLAAINLMSPISQFYFSITILFGLGASSIISFAKGRRDEKQANRVFTSTFIVLIALSVIFIAIQLPLADSISSLLTKDAELKSLLYQYYVPFIIGTPIYLLLMCSIHFVRADARPAFASNIVIVANAVNLGLDFLFMGAFKMGIAGSSIATVTGYAVGFVMMSTHFIMKKSTLHFDFSILRNPVQFFKFLGKMVTIGLSGALGTMLITVKMLFLNTIIQSIGGSAGMVSYSVCSSSQIFMSMFITGASQTMIPIIGVCLGEKDYDGVRYAFRRAARVLAVSSVVIMLFICIEPEPIIKFFGITSPTDIANTVPAMRINALSFPGLSFSFLLLYYYMATQKRAISTAISIINGIVILIPSALILGKFFGITGVWYSLVVAQVGTLVVVYFIDLAEKRKSGGKYKNFYLLEETEDNELLALSFKGTKENAAGVSLYLSSFLSKNGIEESRANRIAVAVEEMAASCAERMEGKKKFADIDIRIFADKNETIISVRDNGDEFDPLNDDKEFEMSPLTVVKAISDKVEYSRVLGFNRTIIKL\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAGTACCGTACTTGGCAGAAATGCCGTTACCGTCAACAAAAAATACACGGAATATTTTCTTCCGACAGTTCTGACGGCTATGGCAACAAACATTGCGATGATTGTGGACTCAATTATTGCAGGCAATCTTCTGGGGCAAAACTCACTTGCGGCAATCAACCTTATGTCCCCTATTTCGCAGTTTTATTTTTCGATTACTATTCTTTTCGGACTCGGTGCATCCTCGATAATTTCATTTGCAAAGGGCAGGCGTGACGAAAAGCAGGCTAACCGTGTTTTCACTTCAACATTTATCGTACTTATCGCACTCAGCGTAATTTTTATTGCAATTCAGCTGCCGCTTGCCGACTCGATAAGCTCGTTGCTTACAAAGGACGCAGAGCTTAAATCGCTGTTGTATCAATACTATGTTCCGTTCATAATCGGCACACCGATTTACCTTTTGCTCATGTGTTCAATTCACTTTGTAAGAGCAGACGCAAGACCTGCGTTTGCATCAAACATTGTAATTGTGGCAAATGCCGTAAATCTCGGACTTGACTTTCTGTTTATGGGTGCTTTCAAAATGGGCATTGCAGGCTCGTCAATTGCGACCGTAACAGGCTATGCGGTAGGGTTTGTGATGATGTCAACACACTTCATCATGAAGAAAAGCACATTGCACTTTGACTTTTCAATTCTCAGAAATCCCGTTCAATTCTTTAAATTTCTCGGAAAAATGGTTACAATCGGACTTTCGGGAGCATTAGGTACAATGCTGATAACAGTTAAAATGCTGTTTTTAAACACAATTATTCAGAGCATAGGCGGAAGTGCGGGTATGGTTTCATATTCGGTATGCTCGTCAAGCCAAATTTTTATGTCAATGTTCATCACGGGTGCAAGTCAGACAATGATTCCGATTATCGGGGTTTGTCTTGGTGAAAAGGACTATGACGGTGTGCGCTATGCATTCCGCAGAGCCGCAAGGGTGCTTGCTGTTTCAAGCGTTGTAATTATGCTTTTCATCTGTATCGAGCCTGAACCGATAATTAAATTTTTCGGAATTACTTCACCCACAGACATTGCAAACACAGTTCCGGCAATGAGAATCAACGCACTGTCATTCCCCGGACTTTCATTCTCGTTTTTGTTGCTTTACTACTATATGGCAACGCAGAAAAGGGCTATTTCTACTGCAATTTCAATCATCAACGGAATCGTCATACTCATTCCGTCAGCTTTAATTCTCGGCAAATTTTTCGGCATCACAGGTGTATGGTATTCACTCGTGGTTGCACAGGTGGGAACACTTGTAGTTGTGTATTTTATTGACCTTGCCGAAAAGAGAAAATCGGGCGGAAAGTATAAAAACTTTTACCTTCTTGAAGAAACCGAGGACAACGAGCTTCTTGCCCTTTCGTTCAAAGGAACAAAAGAAAATGCGGCAGGCGTTTCGCTCTACCTTTCCTCTTTTCTTTCAAAAAACGGAATTGAAGAAAGCCGTGCAAACAGGATTGCAGTTGCCGTTGAAGAAATGGCTGCAAGCTGTGCCGAAAGAATGGAAGGCAAAAAGAAATTTGCAGACATCGACATCAGAATTTTTGCCGATAAAAACGAAACAATAATTTCCGTTCGTGACAACGGTGACGAATTTGATCCGCTCAATGACGATAAGGAATTTGAGATGAGTCCTCTCACAGTTGTGAAGGCGATTTCGGATAAGGTTGAATATTCAAGAGTGCTTGGTTTCAACCGCACAATAATTAAACTTTAA",
    "translation": "MSSTVLGRNAVTVNKKYTEYFLPTVLTAMATNIAMIVDSIIAGNLLGQNSLAAINLMSPISQFYFSITILFGLGASSIISFAKGRRDEKQANRVFTSTFIVLIALSVIFIAIQLPLADSISSLLTKDAELKSLLYQYYVPFIIGTPIYLLLMCSIHFVRADARPAFASNIVIVANAVNLGLDFLFMGAFKMGIAGSSIATVTGYAVGFVMMSTHFIMKKSTLHFDFSILRNPVQFFKFLGKMVTIGLSGALGTMLITVKMLFLNTIIQSIGGSAGMVSYSVCSSSQIFMSMFITGASQTMIPIIGVCLGEKDYDGVRYAFRRAARVLAVSSVVIMLFICIEPEPIIKFFGITSPTDIANTVPAMRINALSFPGLSFSFLLLYYYMATQKRAISTAISIINGIVILIPSALILGKFFGITGVWYSLVVAQVGTLVVVYFIDLAEKRKSGGKYKNFYLLEETEDNELLALSFKGTKENAAGVSLYLSSFLSKNGIEESRANRIAVAVEEMAASCAERMEGKKKFADIDIRIFADKNETIISVRDNGDEFDPLNDDKEFEMSPLTVVKAISDKVEYSRVLGFNRTIIKL",
    "product": ""
   },
   {
    "start": 11322,
    "end": 11630,
    "strand": -1,
    "locus_tag": "ctg49_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,322 - 11,630,\n (total: 309 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAATCAATAAGGCTATAAGCAATCAGAATGTTATTATCACACTCAAGGGCCGTCTTGACACAATGACAGCACCGCAGCTTGATGACGAGGCAAAGAGCATTGATTTTGACGAGGTTGAAACCGTAACTCTCAACCTTAAAGACCTTGAGTACATTTCAAGCTTGGGACTGAGGGTTATTCTTGCACTTTATAAAAGCCTAAAAAGCAAAGGCGGAAATCTTAAAATTGTCAATGTAAGCAACACAATTATGGAGCTGTTCTCAATGACAGGGATGGCTGACTACCTTGACATTGAGCAGGGATAA",
    "translation": "MKINKAISNQNVIITLKGRLDTMTAPQLDDEAKSIDFDEVETVTLNLKDLEYISSLGLRVILALYKSLKSKGGNLKIVNVSNTIMELFSMTGMADYLDIEQG",
    "product": ""
   },
   {
    "start": 11797,
    "end": 12195,
    "strand": -1,
    "locus_tag": "ctg49_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg49_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg49_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,797 - 12,195,\n (total: 399 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg49_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg49_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAATCGTTTGCGTTGATGCCGTTAAGGAAAATCTGCCGAATGTTATAGAATTTGTGACAAAAATGCTTGGTGAAAATGCAGACGGTAAGCTTGTTTTTGAGCTTGAACTGATTTGCGAGGAAGTGTTTGTAAACATCTGCAACTATGCTTACGGTGAAAATGTCGGCAAGACTGAAATTGAAGTTAGCAAATTTTCAGACTGCATTGTTGTAAAATTCATTGACAGAGGAAAAAAATTCAATCCGCTTGAAATTGCAGAGCCGAACATTCACGCTCCGCTTGAGGAACGAAGCATCGGCGGTCTGGGAATTTTCATGACAAAGAAACTTTCCGACACTCTTTTCTATGAAAGATCTAACGGCAAAAACATTTTTACAATTACAAAGAATTTCTAA",
    "translation": "MPIVCVDAVKENLPNVIEFVTKMLGENADGKLVFELELICEEVFVNICNYAYGENVGKTEIEVSKFSDCIVVKFIDRGKKFNPLEIAEPNIHAPLEERSIGGLGIFMTKKLSDTLFYERSNGKNIFTITKNF",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 2201,
    "end": 9533,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 12420,
    "product": "NRPS",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS",
  "products": [
   "NRPS"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS",
  "anchor": "r49c1"
 },
 "r67c1": {
  "start": 10441,
  "end": 52639,
  "idx": 1,
  "orfs": [
   {
    "start": 11048,
    "end": 11302,
    "strand": -1,
    "locus_tag": "ctg67_11",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,048 - 11,302,\n (total: 255 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1058:ArsR family transcriptional regulator (Score: 66.6; E-value: 2.3e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTCACTGAACGGTACACTTAAAGCACTTTCAGATCCGATAAGAAGAAATATTCTGACAATGCTGAAAGGCAAAAAAATGATTGCAGGCGACATTGCCGAAGAACTTGGAATTTCACCTGCATCGCTTTCATATCACCTCAATCTGTTGAAGAAAAACGACCTGGTGATTGAATCAAAAGAAAAAAATTATGTTTATTATGAGCTTAACACAACCCTGTTTGACGAACTCATAATGTGGCTTAAACAATTTTAG",
    "translation": "MSLNGTLKALSDPIRRNILTMLKGKKMIAGDIAEELGISPASLSYHLNLLKKNDLVIESKEKNYVYYELNTTLFDELIMWLKQF",
    "product": ""
   },
   {
    "start": 11519,
    "end": 11680,
    "strand": 1,
    "locus_tag": "ctg67_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,519 - 11,680,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAATAAATCATGTGGACTTCCCTTGCGGGTACCGAAAGCCTTTACTCGGGAGGATGTGCTTACCTCCCGACAGGGTGTTTCAAAATCAGTTGAAAGTATTAATACAGTAATTAACGATACAGCAGTCGGTACGGACGCTTTCAATGTTAAAAAAGATTGA",
    "translation": "MNKSCGLPLRVPKAFTREDVLTSRQGVSKSVESINTVINDTAVGTDAFNVKKD",
    "product": ""
   },
   {
    "start": 12245,
    "end": 13609,
    "strand": 1,
    "locus_tag": "ctg67_13",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,245 - 13,609,\n (total: 1365 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1086:MATE efflux family protein (Score: 359.7; E-value: 3.2e-109)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNGSKSVRNLTQGKISSQILFFAIPVIIGNLLQELYNVVDTLIVGQTLGEIKLAAVGSTSSLNFFALGFFIGLSAGCSVITSQHFGANDMERVKKSVAAHIIIGVVSAVVLTVSFVLLVNPLLTMLGTTSDTFEYASRYLTIIYLGIPATMLYNLTASLLRSVGDSKTPLYLLLFSSVMNVGLDLLFIIVFRWDVSGAAIATVISQLVSAVLCCVYIFFKVKMLLPNKNSFKNLTSTVRDELKVGFPMGLQNSVISIGMMVLQYFVNQFGSYAVAAYTIGNRVQLLIQNPMNSMSTVIATFAGQNEGAGRYDRIKKGVNFCLLICIVYSIVIGAVSMIFAQPITGIFTSGSSQQTIDYSVQFMFWNCPFEWSLAMLFIYRGTIQGLKNGIVPMIGSLIEVVMRIMTPVIFSSVIGYASICVAGPAAWTGSMLLMIAVYYVKIRKLSKTKTVVAN\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATGGTTCAAAATCTGTTAGAAATCTGACTCAGGGAAAAATTTCAAGTCAGATTTTATTTTTTGCAATTCCCGTAATAATCGGCAACCTTTTACAGGAGCTTTACAATGTTGTCGATACGCTGATTGTCGGTCAGACTCTCGGTGAAATCAAGCTTGCGGCTGTCGGTTCAACGAGTTCGCTCAACTTTTTTGCACTCGGATTTTTCATAGGACTTTCCGCCGGCTGTTCGGTAATCACTTCACAGCATTTCGGTGCAAACGATATGGAACGGGTGAAAAAGAGCGTTGCCGCCCACATAATAATTGGCGTTGTGTCGGCTGTTGTGCTTACTGTTTCGTTTGTACTTCTTGTTAATCCGCTGCTTACAATGCTCGGAACAACCTCGGATACATTCGAGTACGCAAGCAGATATCTTACAATAATTTACCTCGGAATCCCCGCAACCATGCTCTACAACCTTACGGCATCACTTCTGCGTTCGGTTGGTGACAGCAAAACTCCGCTTTATCTGTTGCTCTTTTCATCCGTAATGAATGTGGGACTTGACCTGTTATTTATCATAGTGTTCAGGTGGGATGTTTCGGGTGCGGCAATTGCAACGGTAATCTCTCAGCTTGTGTCGGCAGTTCTCTGTTGCGTGTACATTTTTTTTAAGGTGAAAATGCTCTTGCCGAACAAAAACAGCTTTAAAAATTTGACTTCAACTGTACGGGACGAGCTAAAAGTCGGTTTCCCGATGGGACTTCAAAACTCAGTAATTTCAATCGGCATGATGGTTTTGCAGTATTTCGTAAATCAGTTCGGTTCATATGCCGTTGCCGCCTACACAATCGGCAACCGTGTTCAGCTTCTCATCCAGAATCCGATGAACTCAATGAGTACGGTTATCGCAACATTTGCAGGTCAGAACGAGGGCGCAGGAAGATATGACAGAATCAAAAAAGGCGTCAATTTCTGCCTGTTAATTTGCATTGTATATTCAATTGTAATCGGTGCGGTTTCAATGATTTTTGCTCAGCCGATAACAGGAATCTTCACAAGCGGAAGCTCACAGCAGACTATTGATTATTCCGTTCAGTTTATGTTCTGGAACTGCCCGTTTGAGTGGTCGCTTGCAATGCTGTTTATATACCGTGGAACAATTCAGGGACTTAAAAACGGCATTGTGCCTATGATTGGTTCGCTTATCGAAGTTGTTATGCGAATTATGACGCCCGTCATTTTCAGTTCTGTAATAGGTTACGCATCAATCTGTGTTGCCGGTCCTGCCGCATGGACAGGAAGTATGCTCCTTATGATTGCGGTTTATTATGTTAAAATAAGAAAACTTTCAAAGACGAAAACTGTTGTGGCAAATTAA",
    "translation": "MNGSKSVRNLTQGKISSQILFFAIPVIIGNLLQELYNVVDTLIVGQTLGEIKLAAVGSTSSLNFFALGFFIGLSAGCSVITSQHFGANDMERVKKSVAAHIIIGVVSAVVLTVSFVLLVNPLLTMLGTTSDTFEYASRYLTIIYLGIPATMLYNLTASLLRSVGDSKTPLYLLLFSSVMNVGLDLLFIIVFRWDVSGAAIATVISQLVSAVLCCVYIFFKVKMLLPNKNSFKNLTSTVRDELKVGFPMGLQNSVISIGMMVLQYFVNQFGSYAVAAYTIGNRVQLLIQNPMNSMSTVIATFAGQNEGAGRYDRIKKGVNFCLLICIVYSIVIGAVSMIFAQPITGIFTSGSSQQTIDYSVQFMFWNCPFEWSLAMLFIYRGTIQGLKNGIVPMIGSLIEVVMRIMTPVIFSSVIGYASICVAGPAAWTGSMLLMIAVYYVKIRKLSKTKTVVAN",
    "product": ""
   },
   {
    "start": 13662,
    "end": 14228,
    "strand": 1,
    "locus_tag": "ctg67_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,662 - 14,228,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTTGCTTTAAAAAAGTCACAAAACAACTTGATGATTATAAATCTGTAAAAGAATTATACCTTTCCGCATTTCCGTCCGTTGAGAGAGTACCGTTTTGGCTTTTGATGAAAAAATCAAAGAATGACGGTGCAGATTTCTACGCAATTTATGATGAAGAAAAGTGGATTGGACTTATCTATGCAATCACGGACGGCGAAGTTGTCTATGTGTACTACTATGCAATTTCCGAAAAGGAGAGGGGACACGGAATCGGAGTTGCCGTGCTTGATGAATTTAAAAATTTGTATAAGGGCAAAAAGATTTTCCTTGCAATTGAACAGCTTGAAGAAGAAAATGCTCCCAATCAAAAACAGCGAATGAGCCGTTATAAATTCTATCAGCGTTGCGGATTTTTAAGGCTGAATGCAAAGATTGTTGAGGCGAAAATAACATTTGATGTTATGGCATACGGCGGTGAAGTCAATCCCGAAAGCTATAACAAAATGATGAAAAAATATCTCGGCAAAATTATATCGCCCTTCATCAAAACAGAAATGAAGGGCAGCGGTAAATATTTTGAATAA",
    "translation": "MICFKKVTKQLDDYKSVKELYLSAFPSVERVPFWLLMKKSKNDGADFYAIYDEEKWIGLIYAITDGEVVYVYYYAISEKERGHGIGVAVLDEFKNLYKGKKIFLAIEQLEEENAPNQKQRMSRYKFYQRCGFLRLNAKIVEAKITFDVMAYGGEVNPESYNKMMKKYLGKIISPFIKTEMKGSGKYFE",
    "product": ""
   },
   {
    "start": 14291,
    "end": 15394,
    "strand": -1,
    "locus_tag": "ctg67_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,291 - 15,394,\n (total: 1104 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAAAACCAAACGACAGTCCGGTATTGAGTTACTGCGAATTATTGCAATGATACAGATAATTTTTTTGCATGCGTATCAGTACGGATTACTTCATGACGCATCAAAGGCCGCAGGCGATATTGACGGTATATTGGTGACATTTGTATGGTCATTCTGCAGAACACCTGTTGATGTGTTTATTATGATAAGCGGCTACTTTATGATAACCTCGCAGTTTGATATAAAAAAGACCATACGGCGTGGCGGAAAAATCTACGGTGCAATGATTTTTTACTCGATTATACTTTCGATAATTTTCTTCATAAGCGATCCGTCGCTCATAAATATAAATTCAGTTATAAAGGCGTTCACTCCGCTAATGTCACGAACTTGGTATTTTCTGAGCAATTATTTGATTATTCTTCTGCTCAGCCCATTTCTCAACAAAATGCTTGCGTCACTTTCTAAAAAACATTACCTCTACTTTATGGGAATTGTTTTTGTGGCAGTAAGTCTATGGTCAACGCTTGCGGAAATTCACGGAATAAACAATGTGATCAGCGTCAACAAAATACTTGATCCTTATATGGGCAAGAGTCTTGGCGGATTCCTTTTGATGTACATAATCGGCGGTTATCTGAGGTTGTTTGTAAAGCAGAAACCGCTTGAGGAAAGAAAACCGAATTTCCGCTATCTCGGCATTTTCGTCGGCCTTTGCGTATTAGATTTTGTATTGGCATCTGTTTTTCCACAGTACAAGCCGGCATTCGGTATGTTCAACAACCCGATTGTCCTCGCCGAATCGGCGATGTTGGTTCTCTTTTTCAGAGATTTCAATTTCAGCTCAAAATTTGTCAATACAGTAGCCGGCACAACGCTCGGTATATATGCAATCCACGAAAATCCGTATGTTCGTGATTGTCTGTGGAATGTTGCAAACTTCAGCAATAAGCACCTCTATGACACCCTGATTTACATTCCGATTGTATTTATAACAATCCTCCTCATATTCGCAGGCTGTTGCGTAATTGAGCTTTTAAGACTTAAACTCTTCGAATTTGTCGGCAATAAAATAAACGCCCGCAAATCCATAACATCCGGCAACCGCTGTACAAAATAA",
    "translation": "MSKTKRQSGIELLRIIAMIQIIFLHAYQYGLLHDASKAAGDIDGILVTFVWSFCRTPVDVFIMISGYFMITSQFDIKKTIRRGGKIYGAMIFYSIILSIIFFISDPSLININSVIKAFTPLMSRTWYFLSNYLIILLLSPFLNKMLASLSKKHYLYFMGIVFVAVSLWSTLAEIHGINNVISVNKILDPYMGKSLGGFLLMYIIGGYLRLFVKQKPLEERKPNFRYLGIFVGLCVLDFVLASVFPQYKPAFGMFNNPIVLAESAMLVLFFRDFNFSSKFVNTVAGTTLGIYAIHENPYVRDCLWNVANFSNKHLYDTLIYIPIVFITILLIFAGCCVIELLRLKLFEFVGNKINARKSITSGNRCTK",
    "product": ""
   },
   {
    "start": 15698,
    "end": 18412,
    "strand": -1,
    "locus_tag": "ctg67_16",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,698 - 18,412,\n (total: 2715 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGGTATAATTGTTTCTGTTATTGTCCCCTTTCTTGAGAGCAATAACAAATTAATAGATACTCTGTCATCAATATCCGAGCAAAAGAATATTAATCAAGAGAACATTGAAGTGCTTATTGTTGACGCAACAGACAAAACTTCAGGCAAAATTGCAAACGGCAATATGTCAATGTGCAAGGTGATTTATGCAAAGTCGGTTAAAAGCTTTGCCGATGCCTGCAACCTTGCTGCGTCAAAAGCAACAGGCAAATATATCACGGTGTGCAATTGCGGCGACACTTTCAGCTATAACTATTTTGAAAGCTGCATTAAGGTGTTCAATAAAAAGGAAAAAATTCCTTTTGTTGCCGGTCACAGATTTTGCGTAAACCCTGTTTTCAGAGAGAAAAAGGAATTCAGACTTAACAAAGGGCAGCTTGAATCAAGCGTTGTCAACCTTTTTGATAATCCCAACCTCATCAATCTTGAGCTTACGGGTACTTTTTACAGAACTGAAATTTTCAAATCATACAAAATGAACAACAAGCTCAAGTACGAAAGTGCAGACGATTTTGCACTCAGAATTCAGCTTGATTATCCGGAGTATGTATATCTTGATGAGATTGAATTTGACTACTTTATGCCTGTAAGCGATGACTTTATGTACTATGTTCCCACAAACTACAAGGACTGGTACACAGATTCGCTTAACAACTTCTTAAAGCCTCTCATCAATGACAGCAAGGACAGGGACGGAAATATTCCGCTGTTTATTCAGTTCTATATTGTTTTCAATATTACAACAAAGTTCCTCGCAAATATGAACAACCGCAACAAGCGTAATATGAACGATGAAGAGCTTGCGGTTTTCTTTGAAACAGCAAGAGAATGTTTTAAGTTTGCAAATGACGGTTTTGTTCTTAACAAAGACAAGTATGTTTCTCTCGGCTACAGCGAGGAAGCCGCCGAGATGTTCTATATGATAAAGCACAATTGTGTTTTCAAGGATATGCCTTTTGAATATTCCGAGGGCAAAAAAGAGGTTTACCTCAACTGCAACAATGTCTATATTTCTAAGCTTACAGACCAGAGAGTCGGTATGCATGTTATGGACTACCGCGACGGCAAGCTTGTTATTGACGGCTCGTTCAGACAGGTTTTTGACCTTGAAGATTTTGAGCTTTATGTTCAGTTTGGCGACAAAAAACAGGTTCTTACAAACACAGACCGTTATTCTCTGACAAAATATTTCGGCATCAGTGCGTACAAGAAATTCACCTTCCACCTTGAGCTTGAGCTTGATCCCGAAAAGCCTCAGCAAACGGTTGCATTCTTTGCAAGATACAAGGATTCAATTATTCCGCTCAAGCTTTCATTCCTGCACCATTGGTCTAAGTTTACAATCAAGCCAAAGAACTCCTACTGGAGATTCAACAAGTATGTTGCCTATATTGACAACTCAAGCACAATTGTAATCTGTCACGCATCTGCTATGGATACATTCAAGAGAGAACTCAAGTTTCTCCCATATGTTTTCATGGAGAGTAAACGCAGCTTCATTACAAGAATTCAGTATTGGCTTACAAGACCTTTCTTCAAGAACAAGAAAATCTGGCTCATGTACGATAAGCTGTACAAGGGCGGTGACAGCTGTGAATATCTTTACAGATATTGTGCAGACAAAAAGGACGGCATTTCAAGATACTATATCATTGATAAAAACACTTCCGATTACAAGCGACTAAAGGCTGACGGACTCAAGCCTGTCAAGAACCGTTCATTCAAGCACAAAATGCTGTTTCTCAATACCGATATTGCGCTCATTACAAACTCAAATGTATTCCCGTTCAACGGCTACAGTATGGATCGTTCAAGATTCATCAGAGGTTTGTGCAACTTCCCTTCAATGTGCTTACAGCACGGACTTTCGGTTCAAAAGTGCGCAATGGCTCAGCAGAGAATTGTTGACAACACACAGATGTACTTCCTTGCGTCAAAGTATGAGTACAAAAACCTGAGCAACCATGTTTACAACTATCAGGATTTTGATATTCTCAAGATGACAGGCATCGGCAGATATGACGGACTTATCAATAACGATAAAAAGCAGATTCTGCTTTCACCCACCTGGCGTATGTACAATGCAATGCCTGTTACAACAAGCGAGGGTGAACAGAGAGCTTACAATCCCGAATTCAAGCACACAACCTATTATAAAATCTACAACGACCTTATCAATAATAAAAAGTTGATTGATACGGCAAAGCGTACAGGCTATAAGATTAAGTATGTTCTTCATCCGATTTTAAGCTCACAGGTTAACGACTTTATCCCCGATCCGTATGTTGAGGTTGTTTCATCGGTTGGCGATTTCAACTACGAAACAGCTTTTCAGGAGTCAAGCCTTATGGTAACAGACTATTCGGGCGTTCAGTTTGACTTTGCTTATATGAAGAAACCGCTTGTATATTTCCATCCGTCACAGCTTCCTGCACACTATGATGACGGCGGATTCTTCTATGATACAATGGGATTCGGAGAAATTTGTACCGAAAGCGACCAGCTTGTTGACCTGCTCTGCGAGTATATGGAAAACGGCTGTAAAATGAAGCCAAAGTATGTTGAAAGAGTTGAAGATTTCTATCAGTTTGACGATCACAACAACTGTGAAAGAATTTACAACGAAATCATCAAGTATCAGCAACAGGTTAACAAAGACAAATTAAAATAA",
    "translation": "MSGIIVSVIVPFLESNNKLIDTLSSISEQKNINQENIEVLIVDATDKTSGKIANGNMSMCKVIYAKSVKSFADACNLAASKATGKYITVCNCGDTFSYNYFESCIKVFNKKEKIPFVAGHRFCVNPVFREKKEFRLNKGQLESSVVNLFDNPNLINLELTGTFYRTEIFKSYKMNNKLKYESADDFALRIQLDYPEYVYLDEIEFDYFMPVSDDFMYYVPTNYKDWYTDSLNNFLKPLINDSKDRDGNIPLFIQFYIVFNITTKFLANMNNRNKRNMNDEELAVFFETARECFKFANDGFVLNKDKYVSLGYSEEAAEMFYMIKHNCVFKDMPFEYSEGKKEVYLNCNNVYISKLTDQRVGMHVMDYRDGKLVIDGSFRQVFDLEDFELYVQFGDKKQVLTNTDRYSLTKYFGISAYKKFTFHLELELDPEKPQQTVAFFARYKDSIIPLKLSFLHHWSKFTIKPKNSYWRFNKYVAYIDNSSTIVICHASAMDTFKRELKFLPYVFMESKRSFITRIQYWLTRPFFKNKKIWLMYDKLYKGGDSCEYLYRYCADKKDGISRYYIIDKNTSDYKRLKADGLKPVKNRSFKHKMLFLNTDIALITNSNVFPFNGYSMDRSRFIRGLCNFPSMCLQHGLSVQKCAMAQQRIVDNTQMYFLASKYEYKNLSNHVYNYQDFDILKMTGIGRYDGLINNDKKQILLSPTWRMYNAMPVTTSEGEQRAYNPEFKHTTYYKIYNDLINNKKLIDTAKRTGYKIKYVLHPILSSQVNDFIPDPYVEVVSSVGDFNYETAFQESSLMVTDYSGVQFDFAYMKKPLVYFHPSQLPAHYDDGGFFYDTMGFGEICTESDQLVDLLCEYMENGCKMKPKYVERVEDFYQFDDHNNCERIYNEIIKYQQQVNKDKLK",
    "product": ""
   },
   {
    "start": 18594,
    "end": 19136,
    "strand": -1,
    "locus_tag": "ctg67_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,594 - 19,136,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTATGAAGAAATTTATGCTCAGGCAAAACAGGCTTGTAATGAGCTTTGCGATGTTGCCAAGCTTAAAGAGGGCAGTATTGTTGTAATCGGCTGTTCTTCAAGCGAGGTTGCAGGCGGAACTATCGGACACAATTCAAGTCTTGAAACCGCTCAGGCTGTTTTCAAGGGTATATACGAAGTGCTTTGCGAAAGAAAAATTTACCTTGCCGCACAATGCTGTGAACACCTCAATCGTGCAATCATCGTTGAGCGAGAGGCTGTTCCGAACGCTGAAATCGTGAATGTTGTTCCACAGCCAAAGGCAGGCGGTTCGTTTGCCACAACAGCATACAAAACATTCAAAGATCCCGTTGCGCTTGAAGAAATCAAGGCTGACGCAGGTCTTGACATCGGCGGAACACTTATCGGCATGCACCTTAAAAGAGTTGCCGTACCCGTAAGACTCGGCATTGACCATATCGGACAGGCAATTCTGCTTGCCGCAAGAACCCGTCCTAAATTCATCGGCGGTTGCCGTGCCGTTTATGACGACAGCTTTTAA",
    "translation": "MYEEIYAQAKQACNELCDVAKLKEGSIVVIGCSSSEVAGGTIGHNSSLETAQAVFKGIYEVLCERKIYLAAQCCEHLNRAIIVEREAVPNAEIVNVVPQPKAGGSFATTAYKTFKDPVALEEIKADAGLDIGGTLIGMHLKRVAVPVRLGIDHIGQAILLAARTRPKFIGGCRAVYDDSF",
    "product": ""
   },
   {
    "start": 19529,
    "end": 20005,
    "strand": 1,
    "locus_tag": "ctg67_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,529 - 20,005,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTGTGAAGTAACAATAAGACGGGCAAAATTTAAAGACATACCGCAGCTTGACAAGCTCCTTTTTGAGGTTCACAAGATTCACAGCGATATCCGCCCCGACCTTTTTACAGTCGGTGAGAAGAAATACACAGACGAGGAGCTTGAGCGAATAATTGTTGATGAGCAAAAGCCGATTTTTGTTGCAGAACATAACGGAAAAGTAAAAGGATATGCTTTTTGTATTTTCAAGCAGGATCTTGAAAGCAAGTCGGTCACAAATATAAAAACACTGTATATTGATGATTTGTGTGTTGACGAGGATACAAGAGGGATGCATATCGGCACAAAGCTGTATAACCATGTTATTGATTTTGCCCGAAAAAGCGGTTGCTATAATGTTACGCTAAATGTGTGGGCAGGCAATGACGGTGCAATGAAATTTTACGAGCGTATCGGTTTTAAGGTTCAAAAAATCGGTATGGAAACAATTCTCTAA",
    "translation": "MCEVTIRRAKFKDIPQLDKLLFEVHKIHSDIRPDLFTVGEKKYTDEELERIIVDEQKPIFVAEHNGKVKGYAFCIFKQDLESKSVTNIKTLYIDDLCVDEDTRGMHIGTKLYNHVIDFARKSGCYNVTLNVWAGNDGAMKFYERIGFKVQKIGMETIL",
    "product": ""
   },
   {
    "start": 20040,
    "end": 22649,
    "strand": 1,
    "locus_tag": "ctg67_19",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,040 - 22,649,\n (total: 2610 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 145.7; E-value: 3.5e-44)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAAATTGCAGTCGGTATTCTGGCTCATGTCGATTCGGGAAAGACTACGCTTTCAGAGGCTCTGATGTACTCCTCAGGCAACATAACAAAGCTTGGTCGGGTTGACCACAGGGATTCGTTTCTTGACACTTTTTCGCTTGAGCGTGACCGTGGAATTACAATTTTTTCAAAACAGGCGGTTATGAAGTACAACAACACGGAATTTACTCTGCTTGACACACCCGGTCATGTTGATTTTTCGGCAGAAGCAGAGCGTACACTTCAGGTGCTTGACTACGCAATTCTTGTAATCAGCGGAACTGACGGTGTTCAGAGTCACACCTGCACACTTTGGAAGCTGCTCAAAAAGTACAATGTGCCGTGTTTTATCTTCGTCAACAAAATGGATCTTGACGGTGCGGACAAGCTTTCCGTTATGACACAGCTGCGTACAGGGCTTGACGAAAACTGCGTTGATTTTACCTATCCGAACTCCGACGGCTTTCGTGAAAGTGTTGCCGTATGTGATGAAAAAATTCTTGAAAAATATTATGAAACAGATTCCGTTGAAAAGACCGACATAACAGGTGCGATTAAGGAACGCAAAATTTTTCCGTGTATGTTCGGTTCGGCACTCAAACTTGACGGTGTAAAGGCATTTTTGAATCTGCTTGACGAATACACGGTTATGCCCTCTTACGGTGCTGAGTTTGGTGCAAAGGTCTATAAAATTGCAGAGGACAATCAGGGCAACCGCCTTACATTTATGAAAATTACGGGCGGAAGTCTTAAAGTGCGTGAAATTCTCCAAAGCGAAAAAAATACCAATGCCGAAAAGGTAAACAGAATAAGAATTTATTCGGGCGAGAAATTCACAGCCGTTGAGGAGGCTGTTGCAGGAACCGTTTGTGCGGTAACAGGAATAACATTCACTTCATCGGGTGACGGCTTGGGTGTTGAGAAAAATTCCGGAGTTCCCGTACTCGAACCTGTTCTGACTTACAAGGTTGAATTAGAGGATGGGACAGACGCCCACACGGCTCTCACAAAGCTGAAAACGCTTGAAAACGAAGATCCTCAGCTAAATGTTGTGTGGAACAGCAGACTCGGTGAAATCCACATCCGCCTTATGGGTGAAATTCAGCTTGAGGTGCTGAGGTGCATAATAAAAGAGCGTTTCGGTATGAATGTATCGTTCAGTACAGGCAGTATAATCTATAAAGAAACAATCGAAAATACGGTTGAGGGTGTCGGTCATTTTGAGCCGTTAAGACACTATGCAGAGGTTCATCTCCTTTTGAAACCTGCAAAGCGTGGCAGCGGAATTACAATAAATTCCCGTTGCAAAGAGGACTTGCTCGACCGAAACTGGCAAAGGCTGATTCTTACTCACCTCTGCGAAAAAACACATCTCGGTGTGCTGACAGGCTCGCCGATTACAGATATTGAAATCACACTTGTTTCGGGAAAAGCTCACGCAAAGCATACCGAGGGCGGAGATTTCAGACAAGCAACCTACCGTGCCGTAAGACAGGGACTGCGTTGTGCAAAGAGCATTCTGCTTGAGCCTGTTTATGATTTCACGCTTGAAGTGCCTAACGAAAATGTGGGACGGGCAATGTCAGATATTCAGCGGATGAGCGGTACTTTCAATTCTCCCGAAGCCAAAGGCGAGAATTCCGTTCTCACGGGTACTGCACCCGTGTCCGAAATGGGCAACTACACAAAAGAAGTTATGCAGTACACTCACGGCAGAGGCAGACTTTCGTGCAGTCTTAAAGGCTATGAGCCGTGTCACAACAGTGATGAAGTTATTGCACAAATCGGCTACGATTGTGATGCCGATGTTGACAATCCGTGCGGTTCTGTGTTCTGTTCTCACGGAGCAGGCTACAATGTGCCGTGGAATGAGGTCGGCGAGCATATGCATCTGCCGAGTATTCTCGATGCTCCGAAAGACGATGAAATCGGCACAAACAGCGAAAATGCTTTTGCAAAGTGCAAAACTCAGGACGATATTTTTGCTCTCGACAAGGAGCTTATGCAGATTTTTGAACAGACCTACGGTCCTGTGACACGCAGAAAACACGCTCCCGAAAAGCGTCATGTCAAGGCGGTTTCGTCAATTGACAAGGCGGCTGAAAAGTATAAAAAATCCCCCGTGTATGACGGCACGGAGTATCTGCTTGTTGACGGCTACAATGTTATTTTTGCGTGGGAACACCTCAAAGAGCTTTCCGAAAGAAGTCTTGACGGTGCAAGGCACGCTCTGATAAACATTCTCTGCAACTATCAGGGCTACAGCAAGTGCAACCTTATTCTCGTGTTTGATGCGTACAAGGTAAAGGGCGAACACAGAGAGGTTGAAACCGTGAATAATATCAGTATTGTATATACCAAAGAGGCAGAAACCGCCGATATGTTCATTGAGAAAACTTCTCACAAGCTTGCCAAAACCAACAAGGTGCGTGTTGTAACATCCGATGCACTCGAACAGATGATAATTCTGGGCAACGGTGCGTTGCGTGTTTCATCAAGAGCATTTTTAGAAGAAGTCAGACAAGCCGAAAATGAAATCAGAGAAATAATAAATTCTTCAAACGAATTAAACAATAATATGAATTAG",
    "translation": "MKKIAVGILAHVDSGKTTLSEALMYSSGNITKLGRVDHRDSFLDTFSLERDRGITIFSKQAVMKYNNTEFTLLDTPGHVDFSAEAERTLQVLDYAILVISGTDGVQSHTCTLWKLLKKYNVPCFIFVNKMDLDGADKLSVMTQLRTGLDENCVDFTYPNSDGFRESVAVCDEKILEKYYETDSVEKTDITGAIKERKIFPCMFGSALKLDGVKAFLNLLDEYTVMPSYGAEFGAKVYKIAEDNQGNRLTFMKITGGSLKVREILQSEKNTNAEKVNRIRIYSGEKFTAVEEAVAGTVCAVTGITFTSSGDGLGVEKNSGVPVLEPVLTYKVELEDGTDAHTALTKLKTLENEDPQLNVVWNSRLGEIHIRLMGEIQLEVLRCIIKERFGMNVSFSTGSIIYKETIENTVEGVGHFEPLRHYAEVHLLLKPAKRGSGITINSRCKEDLLDRNWQRLILTHLCEKTHLGVLTGSPITDIEITLVSGKAHAKHTEGGDFRQATYRAVRQGLRCAKSILLEPVYDFTLEVPNENVGRAMSDIQRMSGTFNSPEAKGENSVLTGTAPVSEMGNYTKEVMQYTHGRGRLSCSLKGYEPCHNSDEVIAQIGYDCDADVDNPCGSVFCSHGAGYNVPWNEVGEHMHLPSILDAPKDDEIGTNSENAFAKCKTQDDIFALDKELMQIFEQTYGPVTRRKHAPEKRHVKAVSSIDKAAEKYKKSPVYDGTEYLLVDGYNVIFAWEHLKELSERSLDGARHALINILCNYQGYSKCNLILVFDAYKVKGEHREVETVNNISIVYTKEAETADMFIEKTSHKLAKTNKVRVVTSDALEQMIILGNGALRVSSRAFLEEVRQAENEIREIINSSNELNNNMN",
    "product": ""
   },
   {
    "start": 22727,
    "end": 22981,
    "strand": -1,
    "locus_tag": "ctg67_20",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,727 - 22,981,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAAAAATTTGTATCGTTTTTGCTTGCTCTTATGATGATTTTCTGGAGCAGTACCCTTGCTTTTGCAACTGACAAAACAGACACACAAAATAGCTCCACCTCCGATGAATCGGACGGCGGTTCAATGCCTACGGATTTTGCGATAATTCTTCTGCTTATCGCCGGCGGTACGGCAGTCGCAAGCTTTAAACGCCACAGAAATGACCGTGACGATTACGATGAACCCGATGATGACACGGAAGAAGAAATTTGA",
    "translation": "MKKFVSFLLALMMIFWSSTLAFATDKTDTQNSSTSDESDGGSMPTDFAIILLLIAGGTAVASFKRHRNDRDDYDEPDDDTEEEI",
    "product": ""
   },
   {
    "start": 23187,
    "end": 23723,
    "strand": -1,
    "locus_tag": "ctg67_21",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,187 - 23,723,\n (total: 537 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAACAAATAACATGCTTAAAGTTACGGGAATTATTCAGAGTGTTCTCATCGGCATATTGCTGTTGTTTGCGATTTGCATTGAGGTAATGAGCCGTATGAATTTTTATACATACGACTATTCACTCAATTTTGATTATTCTTCTTTTTGGGCAATCCACGGCGACTACCCGTTCCTATTCATTTTCAACACTCTTTTTACAACCTTTGCATCTTTCTCAAGCTTGTTAGAAAATTATGTTTTATATGTTATTTTTGAAATTATGGATATTGCATCGTTGGTATTGCCCGTATATCTCGTTTACAAATCCATACGCAGTAAAAGCACGATGGCAAACGGATTGATTATTATATCATCTGCTGTTACTTTTATGATTATGGTTGCTTACGGAGTTTATACCCTTCTTGACATAATTCGCGGTGCTGAAACATTCAATATTTACAGCATAATTTTCATCTTCATAATGTTGATAAAAGTTACTCTGTGCATTGTTTCACCGCTCAGAATAAGGGCAATTAACAACGCAGTCGAATAG",
    "translation": "MKTNNMLKVTGIIQSVLIGILLLFAICIEVMSRMNFYTYDYSLNFDYSSFWAIHGDYPFLFIFNTLFTTFASFSSLLENYVLYVIFEIMDIASLVLPVYLVYKSIRSKSTMANGLIIISSAVTFMIMVAYGVYTLLDIIRGAETFNIYSIIFIFIMLIKVTLCIVSPLRIRAINNAVE",
    "product": ""
   },
   {
    "start": 23743,
    "end": 24297,
    "strand": -1,
    "locus_tag": "ctg67_22",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,743 - 24,297,\n (total: 555 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAACAATAAAACTCTCAAGTACACAGGAATTATACAAGGTGTACTCATTGCAACTCTGTTACTGCTTGCCATTTGGATTCAAGTGACATTTTTATATAACACATACTATTGTGAAGATTATACTTTTGATTTTCTTAGAAATATGGGCATTGGTTATTGGGATTTACGGAATAATTCTTCAGCGTTTTTCCTCATAAATTCCATTGCGGAAACTATAGCTTATTTTTTAGGTTTGATGCGTCTTTATGTTCTTAAAATAATTTTTCAGATTATTGCCGCTGCAGCGTTAACCTTGCCTGTTATTTTAGGCTATCTGTCAATATTCCGCAAAAACATAGTTGCAAACGGATTGATTATTGCAGGATCGGCATTGACTTTGTTATCCGCATGTCGGAGTCTTTTCTCTACCCTATTTGAACTTGCCCGTGGATTTGGCGAATTTACTTTGGTTCAAGTAGTTTTAATAATTGTGATACTGATAAAAATAGAATTGATTGCCGTTTCAATACTGCGGATAAAACAGATTAAAAAATCAAATCAGTTACAGTAA",
    "translation": "MKNNKTLKYTGIIQGVLIATLLLLAIWIQVTFLYNTYYCEDYTFDFLRNMGIGYWDLRNNSSAFFLINSIAETIAYFLGLMRLYVLKIIFQIIAAAALTLPVILGYLSIFRKNIVANGLIIAGSALTLLSACRSLFSTLFELARGFGEFTLVQVVLIIVILIKIELIAVSILRIKQIKKSNQLQ",
    "product": ""
   },
   {
    "start": 24313,
    "end": 24804,
    "strand": -1,
    "locus_tag": "ctg67_23",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,313 - 24,804,\n (total: 492 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAAAAGTTCAAAAATAATTGCCGCAATTTTTATTACTCTCCTCTCCCTTATTCTGATTGTGTCGGCATTTTTGCTCCTGTTTGAGGGAATAAAATTAAGCTACGATCCGTCCGATGAAAGCAAATCGTTGGATTACTATGACATTGACGATGTAAAATACTATGTTTATCAGCAGAAAGTTGCCGTCACTATGAACGGTGACAACGACAGTCTTGATGTGAGAACGGGAAAATATCGTGACAACTGGCTGAATGACAGTTCCGAAAATGTGCTTAAAGGCAAGTTTGAAAAGGTCGGCTGGAATGACGATAAGCTCTATATTTTATCGGATGATAAGTATTATGAGTTTGACATCAACAGCTACGAAATTCCGAAAAATTATAACGGCAGTTCGTTAGAAACTGCCTATTCGTTAAAAGAACGTTCAAAATCACAGTTTGAGAAAAACTTTAAAAATTTCGATTCATTTGATTGGTATGACAATTAA",
    "translation": "MKKSSKIIAAIFITLLSLILIVSAFLLLFEGIKLSYDPSDESKSLDYYDIDDVKYYVYQQKVAVTMNGDNDSLDVRTGKYRDNWLNDSSENVLKGKFEKVGWNDDKLYILSDDKYYEFDINSYEIPKNYNGSSLETAYSLKERSKSQFEKNFKNFDSFDWYDN",
    "product": ""
   },
   {
    "start": 24818,
    "end": 25399,
    "strand": -1,
    "locus_tag": "ctg67_24",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,818 - 25,399,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTAAGAAAAGCTCAAAAATTATTATGATTGTTTCAATAACACTTGCAAGCATAATGCTTTTAACGGCAATTGCATTTATAGCACAAAGGATTTACATAAACAAAGACATACTTTCAGAATCTCCCGAAAAAATAATTGACATAATTATGGACGGTGATGAATACCATGACGGAATTCGTTCGAGTTCAGCCATTGACGGTACAGACTATACCTGTTTTGACAAAGTCTATATTTCCATAGCACTTGCCGACCGTTATCAAGACAGCGTTTACATGAAAGTTCCCTACAATGAGGGCGACGATTCTTTCTATATCGGTGATGAAAACAAAATAATCACGGGCAAAATCAACGCACTTTATAAATTTGACAAAACGGTTATTGTAATGTGTGACGATGTGTACTATGTGATTGACACGGACGAATACACAGTTCCTCAGAATTTTGAGGAAGGTAAAAATATTGATTACAAGCCCGATCAATATTCCGAAAAAGAATTTAGAAATAAATATCCGAACTATAAAAGTTTTGAATGTTTTTACAGCCGTTTGTGTCAGCCTGTTGCCGATGATTTCGATTGA",
    "translation": "MIKKSSKIIMIVSITLASIMLLTAIAFIAQRIYINKDILSESPEKIIDIIMDGDEYHDGIRSSSAIDGTDYTCFDKVYISIALADRYQDSVYMKVPYNEGDDSFYIGDENKIITGKINALYKFDKTVIVMCDDVYYVIDTDEYTVPQNFEEGKNIDYKPDQYSEKEFRNKYPNYKSFECFYSRLCQPVADDFD",
    "product": ""
   },
   {
    "start": 25646,
    "end": 26056,
    "strand": -1,
    "locus_tag": "ctg67_25",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,646 - 26,056,\n (total: 411 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1275:peptide deformylase (Score: 127.6; E-value: 5.4e-39)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAAGAGAAATTGTACATGATCCTATGTTTTTACAGAGAAAGTCGGAGGACGCAACACAGGCAGATTTGCAGACGGCACAGGATTTGCTTGACACACTCAGGGCAAATTTTGACCGTTGCGTGGGCATGGCGGCTAACATGATAGGGGTTGCAAAGAGGATAATCGCAATTAATGACAACGGAAAATATCTTGTTATGTTCAATCCCGAAATCATTAGCAAATTCGGTGAATTTGAAACCGAGGAGGGCTGTCTTTCGCTTGACGGCGAACGCAAAACAGTTCGTTACAAAACGATAAAAGTAAAATATTTCAACGAAAATTTCAAGCAGATAAAACGCAGTTTTTCAGACTTTACCGCACAGATTATTCAACATGAAATTGACCATTGCAACGGGATTCTGATTTAA",
    "translation": "MVREIVHDPMFLQRKSEDATQADLQTAQDLLDTLRANFDRCVGMAANMIGVAKRIIAINDNGKYLVMFNPEIISKFGEFETEEGCLSLDGERKTVRYKTIKVKYFNENFKQIKRSFSDFTAQIIQHEIDHCNGILI",
    "product": ""
   },
   {
    "start": 26160,
    "end": 26351,
    "strand": 1,
    "locus_tag": "ctg67_26",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,160 - 26,351,\n (total: 192 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAATATCCGGAGTTATCGTGCAATTTTTATGCTGAGGTTGACGGTGAGAATGTTTTGCTGATTGAAATTGACAGAGAGGGCAGAGCAAAGGTTTATCATGAAAATTTAAGAATTGACGGGGTGAAGAAAATTTTTGAAGAAATCAACGGAAATATTGAAAGCTACATAAAATATTTCGGAACAAAATAA",
    "translation": "MKYPELSCNFYAEVDGENVLLIEIDREGRAKVYHENLRIDGVKKIFEEINGNIESYIKYFGTK",
    "product": ""
   },
   {
    "start": 26424,
    "end": 26867,
    "strand": -1,
    "locus_tag": "ctg67_27",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,424 - 26,867,\n (total: 444 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1171:transcriptional regulator, MerR family (Score: 81.4; E-value: 1.7e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTACACAATCGGTCAGGTATCTCAGATGTGCGGTATTCCTGTTTCAACCCTGCGTTACTACGATAAAGAGGGACTTTTTCCGCATATGGAGAGGGTGTCGGGTATCCGCAGATTTTCCGACAGAGAGCTTGAAACACTCCGCATAATTGACTGTCTCAAAAAATCGGGACTTGAAATCAGGGAAATAAGAAAATTTATGCAATGGTGCGCCGAGGGCAGTTCGTCCTATCCGCAAAGGCGAGAGCTTTTTGAAAATCAGAAAAAAACCGTAGAAAAGGAAATTGAGCGTCTTCAAAAGGCGCTTGATATGCTCCGCTTTAAGTGCTGGTACTACGATACTGCCATTGCTGACGGCAACGAGGACAGAATCAACGAAATGCTCCCGAACAATCTTCCCGATGATATTCAAAAGCTGTATGACCATGCCCACAGCGATGACTAA",
    "translation": "MYTIGQVSQMCGIPVSTLRYYDKEGLFPHMERVSGIRRFSDRELETLRIIDCLKKSGLEIREIRKFMQWCAEGSSSYPQRRELFENQKKTVEKEIERLQKALDMLRFKCWYYDTAIADGNEDRINEMLPNNLPDDIQKLYDHAHSDD",
    "product": ""
   },
   {
    "start": 27045,
    "end": 27884,
    "strand": -1,
    "locus_tag": "ctg67_28",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,045 - 27,884,\n (total: 840 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAGGTCTGATAATTGAAGGCGGAGCAAGGCGAGGAATTTTTACCGCCGGTATAACCGACTGTCTGCTTGAAAACAAAATACACTTTGACTATGTTGCAGGAGTTTCGGCGGGAGCTGAGGTTGCCCTTGATTTTACCGCAAAACAGGAAGGTCGTTCCCGCAGGGTTATTATGCCCCACAGAACAGGCGATTTTTCAGTTCTCGGTTTTCTTTCAATGGATCTTGACAATATGATTTACAGATTTCCTTATCAGGACTATCCGTTCGATTTTGATACATTTTTTGCGTCAGATACAAACTGCGAATTTGTGGCAACCGACTGCGTAACAGGCAAGGCAAAATATTTTTCCGAGAACAAAAGCGAACAGCGATTGCTTGACTCCGTAAGAGCGTCCTGCACAGTTCCTATTCTCTATCAGATAAGCGAATTTGAGGGCGGAAAGTATGTTGACGGCAGTATTGCCGACGCTGTTCCCTTTGACCGTGCGTTTGAACAGGGCTGTTCCCGTGTGCTTGTGCTTTTGACAAAGCCCGAAAATGAGCCTTGCACGGACTATCGCAAGTTTGAATTTTTAATCAACAAAAAATACAAGGACTATCCGAACCTCATCAACGCTCTTATGACGAGATTTGACCGCTATAATGAGCAATGCAAAAGAATGAAACAGCTTGAGGAGGACGGCATACTTATGGTACTCCGCCCGTCACACAAGTATGTAAAATCATTTGAGATGAACACGGATGTGCTTGACGAGGCATATAACGCCGGCAAGAATCTTGCCAAAGAAAAGCTTGCCGAAATTGAAGATTTTCTCAATGTTCTCGAAAAGAAATAA",
    "translation": "MTGLIIEGGARRGIFTAGITDCLLENKIHFDYVAGVSAGAEVALDFTAKQEGRSRRVIMPHRTGDFSVLGFLSMDLDNMIYRFPYQDYPFDFDTFFASDTNCEFVATDCVTGKAKYFSENKSEQRLLDSVRASCTVPILYQISEFEGGKYVDGSIADAVPFDRAFEQGCSRVLVLLTKPENEPCTDYRKFEFLINKKYKDYPNLINALMTRFDRYNEQCKRMKQLEEDGILMVLRPSHKYVKSFEMNTDVLDEAYNAGKNLAKEKLAEIEDFLNVLEKK",
    "product": ""
   },
   {
    "start": 28075,
    "end": 28557,
    "strand": 1,
    "locus_tag": "ctg67_29",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,075 - 28,557,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTAACCGCAAAACCTTTTACCGTCACTACAACACGGTTCAGGATGTTGTCGATGATATCAACTACGATATAATCAACGATGTTATCAGCCATGCGAAAAAATCCGACCGTGACGGCAACAATCTTGTGAATCAGCTGAATTTTATCGGTCTTTCCATTGTTGAAAATAAAGAACAGATTAATAAAATTCTGAAAAATTCTCCCGAGGTGTTCGGCTCTGGACGCTCTGTTGAGCTTTTGAAAAGATTTATCGAGGTTTCAATAAGACCTGTGCTTAATTTTAAAAATGAAACAAAACTCAAATACCTTGTTGAGTTTGTCGTTTCGGGATTTATCTCGGTTTATGTCCGTTGGTTCAATGACGGCTGTGCAGAAAGCTCCGAAAAACTTGCAGACGCTGTCAACGAGTTCGTTCTCGGAGCATTGTCCGAATATGTTCCACCCAAAAAGCTGATTAACTCATTTTCCAATGAGCCTTAG",
    "translation": "MINRKTFYRHYNTVQDVVDDINYDIINDVISHAKKSDRDGNNLVNQLNFIGLSIVENKEQINKILKNSPEVFGSGRSVELLKRFIEVSIRPVLNFKNETKLKYLVEFVVSGFISVYVRWFNDGCAESSEKLADAVNEFVLGALSEYVPPKKLINSFSNEP",
    "product": ""
   },
   {
    "start": 28532,
    "end": 29236,
    "strand": -1,
    "locus_tag": "ctg67_30",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,532 - 29,236,\n (total: 705 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGTTCTCGTATTAAACGGTAGTCCAAAGGGCGAAAAAAGCAATACTCTCAACATTACAAAAGCATTTCTTGACGGCTTTTCAGCCGATACGGAAGTTGAATATATCACGGTTAAAAAGGAAACAATCAAGCCGTGTATGGGTTGCTTTTCGTGTTGGAGCAGAACACCCGGCAAATGTGTTATAAAGGACGATATGCAGAAAATCTACGAAAAGATTAATTCTGCCGATATTATCATTGAGAGCTTTCCGCTCTACTTTTTCGGTATGCCGTCACAGATGAAAGCATTAACCGACAGATGTCTGCCGTATATGCTCCCCTATTCGGGAAATGTTGCCGAGGACAAAGAAGCCTCTTTCCATGAACTGCGTGATGAAGCAATGCACGAAAAGAGACTTTTGGTTATTACAACTTGTGGCTATGTGAGTGCCGAACCGATGTATCCCGCACTTATAAAACAGCTTGATTTGATTTGCGGTAACGGCAATTACACGATGATAAAATGTCCCGAGGGCGAGCTTTTTATTGCAGAAAAAGCTGAAAGGCAGAGAAAAGCATACCTTGATTCAATCACGGAGGCAGGCAGGGAATTCTGCGAAAACCGTTGTCTTTGCGATGAAACAATGAAAAAAATTTCAAAGCCTATTCTCTCCCCCAAAGGATTCGAGGCAATTACTAAGGCTCATTGGAAAATGAGTTAA",
    "translation": "MKVLVLNGSPKGEKSNTLNITKAFLDGFSADTEVEYITVKKETIKPCMGCFSCWSRTPGKCVIKDDMQKIYEKINSADIIIESFPLYFFGMPSQMKALTDRCLPYMLPYSGNVAEDKEASFHELRDEAMHEKRLLVITTCGYVSAEPMYPALIKQLDLICGNGNYTMIKCPEGELFIAEKAERQRKAYLDSITEAGREFCENRCLCDETMKKISKPILSPKGFEAITKAHWKMS",
    "product": ""
   },
   {
    "start": 29239,
    "end": 29694,
    "strand": -1,
    "locus_tag": "ctg67_31",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,239 - 29,694,\n (total: 456 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1270:UDP-3-O-[3-hydroxymyristoyl] N-acetylglucosamine (Score: 94.1; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGAATCTGCTTGAAATCAATCAAAGAATAAAACAAAGACCACCCTTTCAGATGATTGAGAGGGTGACCGAGCTTGAGCCGAATGTTTCGGCAACAGGTATAAAAAATGTGTCGGTGAACGAGCCGTATTTTGCAGGTCATTTTCCCGACACACCGATTATGCCGGGAGTATTGCTCATTGAATCTGCGGCACAGCTTTGCAGTCTTGTATTTGCTCCCGAAAGCGTTGAGGAGGACAAGCTGTATGTTCTTCTAAAAGTCAAGGATTTCAAAATGCTCCGCCCCGTTATTCCGGGTGATACGCTTATTATCAGCGTAAATGTTACAATGTCAACAAAGTCGGCATTTGAATTTGCGTGTGTCATCAAGGTTGACGGTGAAGTGAGGGCAAAGGGAAGTCTTTTGTTTACCACAATGGATAAAAATGCGGTTTACAAGCCGTCACAGGAGTGA",
    "translation": "MMNLLEINQRIKQRPPFQMIERVTELEPNVSATGIKNVSVNEPYFAGHFPDTPIMPGVLLIESAAQLCSLVFAPESVEEDKLYVLLKVKDFKMLRPVIPGDTLIISVNVTMSTKSAFEFACVIKVDGEVRAKGSLLFTTMDKNAVYKPSQE",
    "product": ""
   },
   {
    "start": 29691,
    "end": 30425,
    "strand": -1,
    "locus_tag": "ctg67_32",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,691 - 30,425,\n (total: 735 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 227.2; E-value: 3.6e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAAAACCGCTCTTGTAACAGGTTCATCAAGGGGCATTGGCAAGGCTTGCGCTTTAAAGCTTGCAGAGCTTGGATATGACATTGCCGTGAACTGCAATTCAAATTTGGAAATGGCTCAAAAGGCTGTTGACGAAATTACATCACTCGGCAGAAAAGCCGTTGCCTACAAGGCAAACACGGCAGATATTGACGAAGTAAAGGATATGTTCCGCAGTATTCAGCAGGACTTCGGCGGAATTGATGTGCTTGTCAACAACGCAGGTGTGGTTGACGACGCTTACCTTTTGATGATTAAGGACGAGTCGCTTGAAAGAAGTCTTGACATTAATATCAAAGGATATTTCAATTGTGCAAGACAGGCATCGCTTAAAATGCTCCGCAAAAAGAGCGGAATCATCATCAACATTTCTTCCGTAAGCTCTGTTCTTGCAGTTGAAGGTCAGTCGGTTTACAGTGCAACAAAGGGTGCGGTAAACGCTATGACTCACACGCTTGCAAAGGAACTTGCAAAGTACGGAATCAGAGTAAACGCAGTTGCACCCGGTTTTATCGAAACCGAAATGATGAACGGCATTCCCGAAGAGTTGCAAAAAAAGTATCTTGAGGCTATTCCCGAAAAGAGATTCGGCACAGTTCAGGATGTCGCAAATGTAGTCGGACAGCTTTGCAGTGACGATTTTTCATATATGACAGGTCAGGTGCTTGTGCTTGACGGAGGACTCAGCTTATGA",
    "translation": "MSKTALVTGSSRGIGKACALKLAELGYDIAVNCNSNLEMAQKAVDEITSLGRKAVAYKANTADIDEVKDMFRSIQQDFGGIDVLVNNAGVVDDAYLLMIKDESLERSLDINIKGYFNCARQASLKMLRKKSGIIINISSVSSVLAVEGQSVYSATKGAVNAMTHTLAKELAKYGIRVNAVAPGFIETEMMNGIPEELQKKYLEAIPEKRFGTVQDVANVVGQLCSDDFSYMTGQVLVLDGGLSL",
    "product": ""
   },
   {
    "start": 30441,
    "end": 32639,
    "strand": -1,
    "locus_tag": "ctg67_33",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,441 - 32,639,\n (total: 2199 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) HR-T2PKS: t2fas<br>\n \n  biosynthetic (rule-based-clusters) HR-T2PKS: hr-t2pks-ksa<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 78.6; E-value: 7.8e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGACAAAAAGAGATGTGTTGTCACAGGACTCGGACTTATCTGCGGCGTCGGTGACAATGTAAAGGATTGCTGGGATGCCGTAACACTCGGTCACTCCGGCATTGATGAGGTTAAGTCGGTTGACACCTCAAACTGTTATGCACACAAGGGTGCAGAGGTTGACAAGGCATCGTCAGAGCTTTCTCCCGAAAACTATGACCGTTCTTCCCTTCTCTGTATTCATGCCGCAAACGAGGCTTTTGAAGATGCAAACATTGACGCATCCGAAAAGAACATCGGTGTTATTCTTGGCAGTTGTGTAGGCGGTGCGGCAAGCATTGACAAATATTACACAGACGAAATCAAGGGTGACGGCGGTAAAAAAGAAGATATTTTCAAAATGGGTGCTTCGGCAATTGCCAACAATGTTTCCGCTCATTTCGGACTTGAGGGCATTACCGCAAACATCGTCAACGCTTGTGCGGCAGGCACAATGAGCATCGGCTATGCCTGTGACCTTATCCGTGAGGGCAAGGGGGATGTGTTCATTGCAGGCGGTTCGGACAGTTTTTCTTCACTTGCATTCAGCGGTTTCCACGCTCTCCATGCGCTTGACGAAAACGCCTGTTCCCCGTTCAATCACAGCACAGGTATCACGCTCGGCGAGGGTTCGGGTATTCTTGTAATCGAAAGCTACGAACACGCTGTTGAACGAGGTGCAAAGATTTACTGTGAAATTCTCGGTTCGGGTGTAAGCAGTGACGCTTACCACATTACCGCTCCCCGTCCCGACGGTGAAGGTCAGATGAGTGCAATCAGAAGGGCTGTTGAAAGCTCTGCTCTTAGTTTTGACGATATCGACTACATAAACGCACACGGAACGGGTACTGCCAAAAATGACGAGGCTGAATTTCTTTCACTTCACACACTTTTTGACGGCAACGACCACCTTTCTGTCAGCTCAACAAAATCTATGACAGGTCATTGCCTCGGTGCGGCAGGCTCAATTGAGGCTGTATTTTCCGTAAAAGCAATAAAAGAGAACCTCGTTCCGCCTACAATCGGCTACTCCGATGAGGATTTGAAGGTGCTTTCCGAAAAGGCTGGCAACATTGACTTTATTCCGAACAAGAGCCACACAAAAGATGTTCACTATGCAATGTCAAACTCATTTGCATTCGGCGGCAACAACGCAAGCATCATTTTCTCGGACAACGAGCATGATATTCCCGACAACAGTAAAAATGAAAAAATTTACATTACGGGCATTTCAAAGCTTACAGGCACAAGGACTGACGAACACAGCCTTAACTGCAATCTTACCTCCGAGGATTATGACAAACACGGAATCAAGGTTGCATTTTACAGAAAGCTTGACCGTTTCAGCCAGCTCCAGCTTTTGAGCGGTATGGACGCACTTGCAGACGCTGACATTAAAATTGACAAAGACAACGAATATAAAACAGGTATTGTAATCGGCACGGCTGACGGTCCTATGACCGAAATTGTTGATTTCCAGAAAAAGGCAATCACAAGAGGTACCGAAAAGGGCAGTGCTTTTTCATTCCCGAATACGGTTTACAATGCCGCAGGCGGTTATCTGAGCATTTTCTCAGGTATCAAGGGCTACAACGCAACTGTTGCAAACGGCAATCAGGCAGGACTGCAAAGTATTTGCTATGCCGCTGATATTCTTGCAGACGGCAACGAAAGCGTTATGCTTGCCGCAGGTACCGATGAAAATACAAAGACAAACCTTGAACTCTATACAAAGGCCGAATTGCTTGAAAAACCACTCGGTGAGGGCTCTGTAACTCTCGTTCTTGAAACAGAGGAAAGTGCAAACGGCAGAAATGCACGCAAGTATGCAGAAATTAAGGGCTATGCACAGGCTCACCGCCCTGTATCTTATGACAACTCAGAGGTTGACAGCAAGGCTGTTGTTGAGGTTATCGAAAAGGCTTGTGTGAATGCCGACATTGAGGCAGACAATATCGACTTTGTATGCTGTGATGACAGGAAGATTATCAAGACGCTTATGCCCTGCTATGATGTATCGCAGGAAATCGGCAATGCAAGAGCCGCAGCAAGCGCAATGACAGCGGCATATGCGGCTGAGATTCTTTCTGACAGCGAGAAAAATTACGAATACGGACTTGCTCTTTCAATGGGTGCGGGCGGAACATACTCTGCCGTAATCCTGAAGAAAGCGTAA",
    "translation": "MADKKRCVVTGLGLICGVGDNVKDCWDAVTLGHSGIDEVKSVDTSNCYAHKGAEVDKASSELSPENYDRSSLLCIHAANEAFEDANIDASEKNIGVILGSCVGGAASIDKYYTDEIKGDGGKKEDIFKMGASAIANNVSAHFGLEGITANIVNACAAGTMSIGYACDLIREGKGDVFIAGGSDSFSSLAFSGFHALHALDENACSPFNHSTGITLGEGSGILVIESYEHAVERGAKIYCEILGSGVSSDAYHITAPRPDGEGQMSAIRRAVESSALSFDDIDYINAHGTGTAKNDEAEFLSLHTLFDGNDHLSVSSTKSMTGHCLGAAGSIEAVFSVKAIKENLVPPTIGYSDEDLKVLSEKAGNIDFIPNKSHTKDVHYAMSNSFAFGGNNASIIFSDNEHDIPDNSKNEKIYITGISKLTGTRTDEHSLNCNLTSEDYDKHGIKVAFYRKLDRFSQLQLLSGMDALADADIKIDKDNEYKTGIVIGTADGPMTEIVDFQKKAITRGTEKGSAFSFPNTVYNAAGGYLSIFSGIKGYNATVANGNQAGLQSICYAADILADGNESVMLAAGTDENTKTNLELYTKAELLEKPLGEGSVTLVLETEESANGRNARKYAEIKGYAQAHRPVSYDNSEVDSKAVVEVIEKACVNADIEADNIDFVCCDDRKIIKTLMPCYDVSQEIGNARAAASAMTAAYAAEILSDSEKNYEYGLALSMGAGGTYSAVILKKA",
    "product": ""
   },
   {
    "start": 32641,
    "end": 32883,
    "strand": -1,
    "locus_tag": "ctg67_34",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,641 - 32,883,\n (total: 243 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAATGCTATTGCAGATCAGATTAAGGAAATGCTCGTAGAAAACCTTAGAATTCCCGAAAACATTCTTACATACGATTCAGAACTTTTCGGTGACGAAATCGGTCTTGACTCAATCGACTCAATCGAAATCGTTGCAGGCATCGACACACTTTTCGGTATTGATATGACAGGTGCAGACCGTGAGCACTTCCAATCAATCAGAGCACTTACAGAATATGTAGAAAGCAAGCAGGGTTAA",
    "translation": "MNNAIADQIKEMLVENLRIPENILTYDSELFGDEIGLDSIDSIEIVAGIDTLFGIDMTGADREHFQSIRALTEYVESKQG",
    "product": ""
   },
   {
    "start": 32924,
    "end": 33610,
    "strand": -1,
    "locus_tag": "ctg67_35",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,924 - 33,610,\n (total: 687 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 84.3; E-value: 1.3e-25)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGTACAATTATCATAAAAATGCAGGACAGCTTGCATTCATAAAATTTGTAAAAGGTCTTGTGCATCTTCTTATTCGCCCTAAGGTTGAATGGAAGGACAAGAGCCTTAAAAAGAACCTCAAGGGCAAGCCTGTTGTGTTTGTATGCAACCACACTCACCACTTTGACGGAGTTGTGATAAGCTCTGTACTCAGCAGATACAAGCCGTATATGCTTGTTAAAAAAAGCTGGTACGACAAGAGCGGGACAGGCTCGTTTATCCGAATTTGCCGCAGTATTCCCGTTGACTTTGACACCATGGACACAAACTGGTATGCACAAAGTGAGGGTGCGGTTGAAAACGGATATTCAATGCTTATCTTCCCCGAGGGCGGAATTGCAAGAGATGGCAAAATGCTCCCGTTCAAGCCCGGTGCGGCATTGCTTGCGGCAAAAAAAGGTCTTGACATAATCCCGATTGCATCTTTGGGTGAGTATAAAATTCTTTTCGGAAAAAGGCAGAAAATTTTAATCGGCAATCCGATAAAATCCGAATGTCCCGAAAATGTTCGCTACTCAAAATATGCAAAAGAAATAAGTGCCGAAGCCGAAAAGCAGGTTAAAAAGCTTTATCTTGAGCTTGAAGAAAAATACGGCAAAGGCAAGGTTTATTACAAAGAAGATTTTTCTTCGGAAAATTTATAA",
    "translation": "MEYNYHKNAGQLAFIKFVKGLVHLLIRPKVEWKDKSLKKNLKGKPVVFVCNHTHHFDGVVISSVLSRYKPYMLVKKSWYDKSGTGSFIRICRSIPVDFDTMDTNWYAQSEGAVENGYSMLIFPEGGIARDGKMLPFKPGAALLAAKKGLDIIPIASLGEYKILFGKRQKILIGNPIKSECPENVRYSKYAKEISAEAEKQVKKLYLELEEKYGKGKVYYKEDFSSENL",
    "product": ""
   },
   {
    "start": 33852,
    "end": 34913,
    "strand": 1,
    "locus_tag": "ctg67_36",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,852 - 34,913,\n (total: 1062 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAAGTAATTTTAACAGGTGACCGTCCTACGGGCAGACTTCATGTCGGTCACTATGCAGGTTCGCTCAAGGAGAGAGTAAAGCTCCAGAATTCGGGCGAATATGATGATATATACCTTATGATTGCAGACGCTCAGGCTCTTACCGACAATGCCGAGCATCCCGAAAAGGTAAGACAGAATATTTTGCAGGTTGCGCTCGACTACCTTGCCTGCGGAATAGATCCGAACAAGTCAACAATTTTTGTTCAGTCAATGATTCCTGAGCTTACAGAGCTTACTTTCTATTATATGAACCTCGTAACCGTGTCTCGTGTTCAGCGTAACCCCACCGTTAAGGCAGAAATTCAGATGCGTAATTTTGAGGCAAGCATTCCTGTGGGATTTTTCTGTTATCCAATCAGTCAGGCGGCTGATATCACGGCATTCCGTGCAACTGCCGTTCCTGTCGGCGAGGATCAGCTTCCGATGCTTGAACAATGCAAGGAGATTGTTCACAAGTTCAATTCCGTTTACGGCGAAACTCTTACGGAACCGCAGATTATTCTTCCGAGCAACAAGGCTTGTCTGCGACTGCCCGGTATTGACGGCAAGGCAAAGATGAGCAAATCCCTCGGCAACTGCATTTATCTTGCAGAAGAACCCGAGGATATCAAGAAAAAGGTTATGTCAATGTTTACCGACCCGAATCATCTTCGTGTTGAGGATCCGGGCAAGGTTGAGGGCAATCCCGTGTTTATCTACCTTGACGCATTCTGCCGTGATGAGCATTTTGCGGAATTTTGGAATGATTACAGCTGTCTTGACGAACTCAAGGCTCATTATCAGCGTGGCGGACTCGGTGATGTCAAGGTTAAGAAATTCCTTAACAATGTTATGCAGGAGGAGCTTCGTCCTATTCGTGAACGCAGAAAAGAATGGGAAAATCATCTTCCCGATGTTCTCGATATTCTCAAAGAGGGCAGTAAGGTTGCAAAGGAAACTGCCGCAAAAACACTTGAGGATGTCCGTCATTCTATGAGAATCGATTATTTTACAGACAATAATCTTCTTAAATAA",
    "translation": "MKKVILTGDRPTGRLHVGHYAGSLKERVKLQNSGEYDDIYLMIADAQALTDNAEHPEKVRQNILQVALDYLACGIDPNKSTIFVQSMIPELTELTFYYMNLVTVSRVQRNPTVKAEIQMRNFEASIPVGFFCYPISQAADITAFRATAVPVGEDQLPMLEQCKEIVHKFNSVYGETLTEPQIILPSNKACLRLPGIDGKAKMSKSLGNCIYLAEEPEDIKKKVMSMFTDPNHLRVEDPGKVEGNPVFIYLDAFCRDEHFAEFWNDYSCLDELKAHYQRGGLGDVKVKKFLNNVMQEELRPIRERRKEWENHLPDVLDILKEGSKVAKETAAKTLEDVRHSMRIDYFTDNNLLK",
    "product": ""
   },
   {
    "start": 35083,
    "end": 36105,
    "strand": 1,
    "locus_tag": "ctg67_37",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,083 - 36,105,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTGACGCAAGAAAGCATACGTTCGATTCTGTTAAAAAGCTGACCGATTACAGCGATTTTAACCTTTATAAAATGGATATATGCTACGATTACAGCATTGATAAAATCATTGACAGAGGGATTTTTGATGATGAGTCGGCTCTCGGTGCAATTTTGCAGGAGGTTCTGCCCGATTATCCCGTCAATCTTAAAATGCCGAATTTCGGGTGCAGTGCCTTTACAATGAAAAATCCCGACAGCGTAATGATGGGGCGAAACTATGATTTTAAGAACGACACCTCGTCAATGCTTGTATATTGTTCGCCAAAGGACGGCTACAGGTCGGTTGCGTTTGCGGCACTTGATAATGTAGGTGCAAACAACCCCGAGTTGAGTGATGAAACAAGGCTTGCAACCTTGCTCTCACCGTTTATCAGCCTTGACGGAATCAATGAAAAGGGCGTGTCAATCGCAGTTCTCACACTTGACAGCAAGCCGGTTCGTCAGCAAAGCGGAAAGCCTGTTATCGCCACAACGCTTGCAATCCGTCTTATACTTGACAGAGCTGCGTCAACCGAAGAGGCGGTTACACTTTTTGAAAAATACGATATGTTCGCCTCAAGCGGAAGAGATTATCACTTTTATGTTACCGATTCAAACGGTGACGGTCGTGTTATTGAGTACGATTGCAACAGCGATGACCGAAAGCTTGTTGTTACAAAATCGCCTGCCGTTACAAACTTTTTTGTGATGTACAAAAATTTTGTAAAGCCTTATCAGAAAAACGGTGTTTACGGTCACGGCAGAGAGCGGTATGATAAGATAATTAATGTTCTTGAAAAGAATAATAGTTACACAAAAGAAACAGCATGGGAGGCTCTTGTTTCGGCGTCACAAGCACCGAATCCGAACGATATAACAAGCAATACTCAATGGTCGATTGTTTATGACAACACAAACCTTACCGCTGATATTTCAATCCGCCGAGATTGGAACACGGTGACAAAATATTCGCTAAAAGAAAATAAAATTACGGAATAA",
    "translation": "MIDARKHTFDSVKKLTDYSDFNLYKMDICYDYSIDKIIDRGIFDDESALGAILQEVLPDYPVNLKMPNFGCSAFTMKNPDSVMMGRNYDFKNDTSSMLVYCSPKDGYRSVAFAALDNVGANNPELSDETRLATLLSPFISLDGINEKGVSIAVLTLDSKPVRQQSGKPVIATTLAIRLILDRAASTEEAVTLFEKYDMFASSGRDYHFYVTDSNGDGRVIEYDCNSDDRKLVVTKSPAVTNFFVMYKNFVKPYQKNGVYGHGRERYDKIINVLEKNNSYTKETAWEALVSASQAPNPNDITSNTQWSIVYDNTNLTADISIRRDWNTVTKYSLKENKITE",
    "product": ""
   },
   {
    "start": 36156,
    "end": 37469,
    "strand": -1,
    "locus_tag": "ctg67_38",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,156 - 37,469,\n (total: 1314 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGACAAATGTTTTCTGTCCGATGATTGAACTCGGTGCAATCATCCCCGGTGTTGTACTTGCATATTTTCCAATAAAAAAACATCTCAAACTATCAAAGCTCAGGCTGTTTCCTGTGATGATTTTATCACTTGCGTGCCTTTGTACATTGTGCGGTTTTGTTTGTTACAGATACAATCTGAAATCGTTTGTGCTTGCAATACCAATAGTGCTTGCTCTTTCGGCAGCATACTGTTGTTCACTCAAAACATCCATGTGGAAATCGGTGAGTGTGTTACTTGCGGTATGCGGAGTGTTTGCCTGCATTGCGAGCATTACACGGGCGTTTGATTCGATAACATTTCCGCAGAACACAACGCCGTGGTTTGAAATTAAATCGGCTGTGCTGTTCAATATTCTATGCTGGATGTTTGTAATTCTTGCATGGTATCCTGCAACACACGGTGTGAGTGAACTGCTCGATGATGAAAACATTGCCCAGACATGGTATATATTCTGGATTTTACCGATAATATTCATCTTGCTCAACTTTTTTATAATCCCATGGAATCCTAACATTCTACATACAGGAAGAATTATGCAGGGTTACATTGTTATCAGTGTATCACTTCTTGTGCTGTTGCTCATTTTCTACGCTTTGCTGTATTTTATTGCAAAAAGTCTGAACCGCAATAACAAACTTGCTCAGAAAAATCAATTTTTGAATATGCAGAGGGCACAGTATGACGCATTAAAAGTCGCTATTGAAGAAACCCGTCAGGCACGGCATGATATGCGACATCACTTTGCCGTACTTAATGCTCTTGCCGAGCAAAAGAACTGGGAAGAACTTGAAAAATACCTTTCGTCAGCATCGCAGAATATTCCCGACACAGAGCTTGTACTCTGTAAAAACCACGCTGTTAATGCGATTATCGGACATTATTATTCAAAATACAAGAGCAATGGTATTCCGTTTAAACTAAAAATTGACATTCCCGAAAAGTTGACAGTTTCGGAATCCGATATCTGTCTTGTAATCGCAAATTTGCTTGAAAATGCATTTGAGGCGAGCATGAAGCTTGACAGAGATAAACGGCAGATTAAAATGTATGCCCGTCCGCATTCCGAAAAGATATTGCTTATTTCCGTAGAGAATGCTTTCAATGGAGAGATTACCGAAAAGGATGGATTTTTCGGTTCGTCAAAGCGAAACGGTAACGGTATCGGTACGCAGTCGGTACGCAGAATTGCCGAAAAAGACGGCGGTTATTGCAGATTTTCTCACGAAAATGGGATTTTCACGGCGGATGTTATGCTGCACAGCAAAAACTGA",
    "translation": "MTNVFCPMIELGAIIPGVVLAYFPIKKHLKLSKLRLFPVMILSLACLCTLCGFVCYRYNLKSFVLAIPIVLALSAAYCCSLKTSMWKSVSVLLAVCGVFACIASITRAFDSITFPQNTTPWFEIKSAVLFNILCWMFVILAWYPATHGVSELLDDENIAQTWYIFWILPIIFILLNFFIIPWNPNILHTGRIMQGYIVISVSLLVLLLIFYALLYFIAKSLNRNNKLAQKNQFLNMQRAQYDALKVAIEETRQARHDMRHHFAVLNALAEQKNWEELEKYLSSASQNIPDTELVLCKNHAVNAIIGHYYSKYKSNGIPFKLKIDIPEKLTVSESDICLVIANLLENAFEASMKLDRDKRQIKMYARPHSEKILLISVENAFNGEITEKDGFFGSSKRNGNGIGTQSVRRIAEKDGGYCRFSHENGIFTADVMLHSKN",
    "product": ""
   },
   {
    "start": 37466,
    "end": 38188,
    "strand": -1,
    "locus_tag": "ctg67_39",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,466 - 38,188,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGGATTGCAATAGTTGATGATTGCGAAAATGAGCGAAATGAACTTTGCAAAAGACTTTCTCAAAGCTCATTTTCAAGGTCATATGATATTGAAATTTGCGGATACGGTAACGGAACGGATTTCCTGAATGAGGCAATGCAAAACAGATTTGACCTTGTTTTTATGGATATATATATGGAAAAGGAAAACGGAATTGATGCGGCACAAAAGCTGAGGAAGTTTGACAAAGATTGTCTGCTTGTTTTCACAACCACATCAACTGACCACGCACTTGAAGGTTTTAGGGTTCGGGCATTGCACTATCTTGTGAAGCCGTACAGCGATGACGAGCTTGATATGTTGCTTGATGAGATTTCGCAGAAAATTTCCGTTGAAGAAAAATACATTGAAATACCCTCTGCAAGTGACTCGTTGCGTATAAAGCTTTGCGACATTTTGTATGCCGAGCATTTTAAGCACTGCATACATATTCATTGTACGGACAAATCCGAAAAGTCTGTGCGCAGTACATTTGCCGAATTTGTAATGCTGTTTGATGACGGAGATAATTTCTTTGTGTGCAACCGAGGAATCATAGTAAATCTTGAACACATCAGGGATATGAACGGCAATGAATTTGTTCTTGACAACGGTGAAAGAATCTCCATAAGTCGAAGTCTTGTAAAAAGCGCAAAAAGCACCTTTGGCGAATATATTTTCGGCAGGAGGGATTTGCATTGA",
    "translation": "MRIAIVDDCENERNELCKRLSQSSFSRSYDIEICGYGNGTDFLNEAMQNRFDLVFMDIYMEKENGIDAAQKLRKFDKDCLLVFTTTSTDHALEGFRVRALHYLVKPYSDDELDMLLDEISQKISVEEKYIEIPSASDSLRIKLCDILYAEHFKHCIHIHCTDKSEKSVRSTFAEFVMLFDDGDNFFVCNRGIIVNLEHIRDMNGNEFVLDNGERISISRSLVKSAKSTFGEYIFGRRDLH",
    "product": ""
   },
   {
    "start": 38376,
    "end": 40406,
    "strand": 1,
    "locus_tag": "ctg67_40",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,376 - 40,406,\n (total: 2031 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTAACAAAAAGAAAACGGGACTTTGCCTTGCTTTGGCGGCAACATTGATTGCCTCGTCTGCACTTTGCGGATGTCAGCAGAGCGACAGCAGTACATCCGCAAAATTCAACAGCGATGTAAAGGATGCGTCAAAATATACGGCTGACGAAAACGCACAGGTGTATAAGACCCTTGACTTTTCCGATGAACAGGAAAAGGAATTTGCAAAAAAGGGCTTTATAACAGCACCCGACAAACTCGAAATCAAAACCGAGAATGGTACTGTTGCATGGAGCCAGACAGCATATGATTTTATCAGAAACTCGTCAACTCCCGACAGTGCAAACCCAAGCCTTTGGAGAAACACGGAGCTTAACTCGCTTTATGGACTTTTTGAAGTTGTTGATGGTGTTTATCAGGTCAGAGGCTACGATGTTGCCAATGTAACCTTTGTAAAGAGCGACAACGGCTGGATTGTTTTTGACTGTACAACAAGCTCCGAAACTGCAAAGGCGGCACTTGAACTTCTTGAATCAAAGTTCGGCAAGGCGCATATTGCCGCTGTTGTTGTAAGCCACGCCCACATTGACCACTACGGCGGTATCGGCGGACTTATTGACGAAAAGGATGTTGCCGATTCATCACTTCCGCTTGATGAACAGATTAAGTCCGGCAAAACGCTCATTATCGTTCCCGAAGGCTACGAAAAGGCTGTTATGGAAGAAAATGTTTTTGCAGGAAACGCAATGAAACGCAGAACCAACTTTCAGTACGGATCATTGCTTGATAAGGGCGGTAAGGGCAGTTTGTCGGTAGGTATCGGCCTTACCCCTTCAAGCGGCACAACAACATACATTTCACCGTCTTATGAGGTAAAGAAAGCTACCGAAACTATCAAGGTTGACGGTGTTGAAATGGTGTTCCAGCTTACTCCCAACACAGAATCGCCTGCCGAGATGAATACCTATATTCCAAAATACAAGGCGTTGTGGATGGCAGAAAACTGTTCCGGCACAATGCACAACCTCTACACACTCAGAGGCGCAGAGGTTCGTGACGGCAATGCGTGGGCGCAGTACATTATGGAGGCAAAGGAGCTTTTCGGAGATAAGGCCGAAGTAGTTTTCCAGGCTCACAACTGGCCGCATTGGGGCAACGATGTAATCAATGACTACATGGCAAACACAGCCTCTGTCTATAAGTACATATTCTCACAGACACTTATGTACATCAATCAGGGCTATACTTCAACCGAGATTGCAAATATGATTGAACTCCCCGATGAACTCAACAAGGTTTGGTACACACGCCAGTATTACGGAACTCTCAAGCACAATGTAAAGGCAGTTTATCAGAAGTATATGGGTTGGTATGACGAAAACCCCATTCACCTTGACGAGCTTGAACCGACAGAATATTCAAAGAAGCTTGTTGAGTATCTCGGCGATACAGACAAGGTTCTTGAAATGGCTAAAAAAGACTTTGACAAGGGAGAGTATCAGTGGGTTGCACAGATTACAAACACACTTGTATATGCAGATCCCGAAAATAAAGACGCCCGCTATCTTTGCGCAGACGCACTCGAACAGCTCGGCTATCAGGCTGAAAGTGGTGCATGGAGAAACGCTTATCTTACAGGTGCTTATGAGCTTCGTAACGGTACAAAAAATTATCCGAATTCCGAAGGTTCAGGTGCAACAGCTCTCGGTATGAGTACCGAAACAATGTTGGATTATCTCGGAATCTGTCTTGACGAAAAGAAGCTTGAAGATCAGAACCTTGTAATCAATCTTGAAGTGACCGATAAAAACGCAAAATATCTTCTTCGCATAAATCACGGTGTGCTTATCTATTCACAGGAAAAGTGGAGCGATAAGGCTGACGCAACAATCAAAACCAAGAGCGCAGGTATTCTCGGCATTGCACAGAACAATCAGAAACTTATGGACGCCGGCATTGAAAAGGTTGAGGGCAACAGTGACATCATCAAAACCCTTACATCAAGCGTTGCCGAATTCCCGCTGTATTTCAATATTATTGAACCCTAA",
    "translation": "MINKKKTGLCLALAATLIASSALCGCQQSDSSTSAKFNSDVKDASKYTADENAQVYKTLDFSDEQEKEFAKKGFITAPDKLEIKTENGTVAWSQTAYDFIRNSSTPDSANPSLWRNTELNSLYGLFEVVDGVYQVRGYDVANVTFVKSDNGWIVFDCTTSSETAKAALELLESKFGKAHIAAVVVSHAHIDHYGGIGGLIDEKDVADSSLPLDEQIKSGKTLIIVPEGYEKAVMEENVFAGNAMKRRTNFQYGSLLDKGGKGSLSVGIGLTPSSGTTTYISPSYEVKKATETIKVDGVEMVFQLTPNTESPAEMNTYIPKYKALWMAENCSGTMHNLYTLRGAEVRDGNAWAQYIMEAKELFGDKAEVVFQAHNWPHWGNDVINDYMANTASVYKYIFSQTLMYINQGYTSTEIANMIELPDELNKVWYTRQYYGTLKHNVKAVYQKYMGWYDENPIHLDELEPTEYSKKLVEYLGDTDKVLEMAKKDFDKGEYQWVAQITNTLVYADPENKDARYLCADALEQLGYQAESGAWRNAYLTGAYELRNGTKNYPNSEGSGATALGMSTETMLDYLGICLDEKKLEDQNLVINLEVTDKNAKYLLRINHGVLIYSQEKWSDKADATIKTKSAGILGIAQNNQKLMDAGIEKVEGNSDIIKTLTSSVAEFPLYFNIIEP",
    "product": ""
   },
   {
    "start": 40425,
    "end": 40970,
    "strand": 1,
    "locus_tag": "ctg67_41",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,425 - 40,970,\n (total: 546 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGTATTTAATTGTATTTTCGGCATATTGTCGATAATAGGCGCAATTTATTGTATGTTCTATCCGGGACTTACCTTCCTTAATACCGGTTGGATAGTGACAATCCTTCTCGGAGTATGGGGAATATGCTCCGTGATTGACTACTTTGCAAAACGCAAAAAGGCAAAGGCTGAACAGAGTGAAGCAATAATGGGAACACTCGGCCTTGTTGTCGGCATTGCAGCGGCAGTAATTTCAATTCTTGCTATGTTTATGCCGGGCATAAGACTTATGTTTGATGTTATCATTCTCTGCATTTTCTCAGGTTGGCTTGTAGTGGACGGTATCTCGTCCGTTGCAATGTCACTCAAGGTCAAAAAAGCATCTTCCTCAGGTGCATGGCTTATTCCGCTTTTCTGCGGAATACTCGTCATAATCGGCGGTATCTACGGATTTTTCCACCTTATATTTGCCGCACAGACAATCGGATTTATGATTGGTGTCCTTTTGTCAATCTACGGTGTAAAGCTTATTCTTTCGGCATTTGAAAAGCCGAGCGTGTAA",
    "translation": "MKVFNCIFGILSIIGAIYCMFYPGLTFLNTGWIVTILLGVWGICSVIDYFAKRKKAKAEQSEAIMGTLGLVVGIAAAVISILAMFMPGIRLMFDVIILCIFSGWLVVDGISSVAMSLKVKKASSSGAWLIPLFCGILVIIGGIYGFFHLIFAAQTIGFMIGVLLSIYGVKLILSAFEKPSV",
    "product": ""
   },
   {
    "start": 41608,
    "end": 42270,
    "strand": -1,
    "locus_tag": "ctg67_42",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,608 - 42,270,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGTTATGAATGTTAATCCCACCCGTATGCAGTTGACAAAGCTGAGAAAACAGCTTGCAACAGCTACCCGTGGTCATAAAATGTTAAAAGACAAGCGTGACGAACTGATGCGCCGATTTCTTGACCTTGTAAGAGAAAACAAGGAGCTTCGTGAGAAGATTGAAAGAGAGCTTGCAGAGTGCAACAACCACTTTGTGAACGCAAGTGCGGTTATGTCAAAAGAGGCTCTGGACGCCTCATTGATGTCACCGAAGCAGAGAATTGACCTTGAGCTTTCTTCAAAAAATGTTATGAGCGTTGATATTCCGCAGTTTTCATCAAGCACACGAACAAGCAACGAGGGCGATATTTTTCCCTACGGTTTTGCGTTTACTTCGTTTGAACTTGATGATGCGGTTATGTCGCTCAACGAGCTTTTGCCCGACCTGATAAGGCTTGCTGAAATTGAAAAAAGCTGTGAGCTTATGTCGGCAGAAATTGAAAAGACACGCCGCCGTGTTAATTCGCTTGAGCATGTTATGATTCCGAGATATCAGGAAACAATCAAGTATATCTCGATGAAACTTGAAGAAAATGACCGCAGCAGTCGTACAAGGCTGATGAAGGTTAAGGATATGCTTCTTGACAAGGCACATCATTATTCGGAACACTATAATTAA",
    "translation": "MAVMNVNPTRMQLTKLRKQLATATRGHKMLKDKRDELMRRFLDLVRENKELREKIERELAECNNHFVNASAVMSKEALDASLMSPKQRIDLELSSKNVMSVDIPQFSSSTRTSNEGDIFPYGFAFTSFELDDAVMSLNELLPDLIRLAEIEKSCELMSAEIEKTRRRVNSLEHVMIPRYQETIKYISMKLEENDRSSRTRLMKVKDMLLDKAHHYSEHYN",
    "product": ""
   },
   {
    "start": 42292,
    "end": 43665,
    "strand": -1,
    "locus_tag": "ctg67_43",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,292 - 43,665,\n (total: 1374 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAAAGGAATACCGCACAATACGAGAGGTTGCAGGTCCTCTTATGATGGTAAGTGATGTTGAGGGCGTAACATATGACGAACTCGGCGAAATTGAACTTCCGAACGGTGAAACACGCCGTTGCAAGGTTCTTGAGGTTGACGGCTCAAACGCACTTGTTCAGCTTTTTGAATCAGCCGCAGGCATTAACCTTGCAAATTCAAAGGTAAGATTTTTAGGTCGTTCAATGGAACTTCCCGTATCTCCCGATATGCTTTCACGAGTATTTGACGGTCTTGGAAATCCGATTGACGGCGGTCCTGCTCTTATTCCCGAAAAAAGACTTGACATCAACGGAACCCCTATGAACCCTGCCGCAAGAAACTATCCGCAGGAATTTATTCAGACAGGTATTTCAGCAATTGACGGACTTAACACACTTGTAAGGGGACAGAAGCTGCCTATCTTCTCGGCATCGGGTCTGCCCCATGCCCAGCTTGCCGCTCAGATTGCAAGACAGGCGGCTGTAAGAGGCAAGGACGAACAGTTTGCCGTTGTATTTGCCGCAATGGGTATTACATTTGAAGAGTCCGACTACTTTGTTCAGTCGTTTAAAGAAACAGGCGCTATTGACAGAACCGTAATGTTTGTAAACCTTGCAAACGATCCTGCCATTGAGCGTATTGCAACTCCTAAAATGGCACTCACGGCGGCTGAATATCTTGCATTTGACAGAGGAATGCATGTTCTCGTTATTATGACCGACATCACAAACTATGCCGATGCGCTCCGTGAGGTTTCTGCCGCAAGAAAAGAAGTTCCGGGCAGACGAGGCTATCCGGGTTATATGTACACAGACCTTGCAACATTGTATGAAAGAGCCGGCAGACTTAAAGGCAAAGAGGGTTCAATCACTCTTATTCCGATTCTTACAATGCCCGAAGATGACAAGACTCACCCGATTCCTGACCTTACAGGCTACATTACAGAAGGTCAGATTATCCTATCCCGTGAGCTTTACAGAAAGGGAATTACTCCGCCGATTGATGTTCTTCCGTCACTTTCAAGACTTAAAGACAAGGGTATCGGCCCTGACAGAACCCGTAAAGACCACGCCGCAACCATGAACCAGCTTTTTGCCGCTTATGCAAGAGGTAAAGACGCAAGAGAACTTATGATAATTCTCGGTGAGGCGGCTCTTACCGATATGGATAAAAAGTACGCTGAATTTGCCGAGGCATTTGAGCGTGAGTATGTTTCACAGGGTTATGACGCAAACCGTTCAATTGAAGAAACACTTGACATCGGCTGGAAGCTTTTGCATATTCTTCCCAGAAGTGAACTTAAACGAATTAAGGACGATATGCTTGACGAGTTTTACGGTAAAGAATAA",
    "translation": "MPKEYRTIREVAGPLMMVSDVEGVTYDELGEIELPNGETRRCKVLEVDGSNALVQLFESAAGINLANSKVRFLGRSMELPVSPDMLSRVFDGLGNPIDGGPALIPEKRLDINGTPMNPAARNYPQEFIQTGISAIDGLNTLVRGQKLPIFSASGLPHAQLAAQIARQAAVRGKDEQFAVVFAAMGITFEESDYFVQSFKETGAIDRTVMFVNLANDPAIERIATPKMALTAAEYLAFDRGMHVLVIMTDITNYADALREVSAARKEVPGRRGYPGYMYTDLATLYERAGRLKGKEGSITLIPILTMPEDDKTHPIPDLTGYITEGQIILSRELYRKGITPPIDVLPSLSRLKDKGIGPDRTRKDHAATMNQLFAAYARGKDARELMIILGEAALTDMDKKYAEFAEAFEREYVSQGYDANRSIEETLDIGWKLLHILPRSELKRIKDDMLDEFYGKE",
    "product": ""
   },
   {
    "start": 43665,
    "end": 45431,
    "strand": -1,
    "locus_tag": "ctg67_44",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,665 - 45,431,\n (total: 1767 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAAATCTGGAATTATAACTAAGGTAGCAGGCCCTCTGGTAATTGCCGAGGGTATGCGTGATGCCGATATGTTCGATGTTGTGCGTGTAAGCAGTCAGCGACTTATCGGTGAAATAATCGAGATGCACGGTGACAGGGCATCAATTCAGGTATATGAAGAAACTTCGGGACTCGGACCCGGTGAGATTGTTGAATCCACAGGCGCTCCGCTTTCCGTTGAACTCGGTCCGGGACTTATCGGTTCAATTTATGACGGTATTCAGCGACCGCTTAACGAGATTATGAAGGTTGCCGGCACAAACCTCAAAAGAGGTGTTGATGTTCCGTCACTTGACCACAAAAAGAAGTGGCACTTTACTCCCCTTGTTAAAAAGGGCGACACAGTTGCGGCAGGCGACACACTCGGTACTGTTCAGGAAACACACGCTGTTCTTCACAGGATCCTTGTTCCGAACAAAACAGGCGGTGTTGTTGAAAGCATCAGCGAGGGTGATTTTACAATTGACGAAACGGTTGCCGTTCTCAAAACAGACAAGGGCAATGTTGAGATTAATATGTGTACAAAATGGCCTGTTCGTGTTGGCAGACCGTACAAAAGAAAGCTCTCCCCCGACATTCTTCTTACCACAGGTCAAAGACCTATTGACACACTCTTTCCGCTTGCAAAGGGCGGTGTAGCCGCAGTTCCGGGACCGTTCGGTTCGGGCAAAACTGTTGTTCAGCATCAGCTTGCAAAGTGGGCGGCTGCCGATATTATCGTATATATCGGTTGCGGTGAGCGTGGCAACGAGATGACCGATGTTCTTAACGAGTTCCCCGAACTTAAAGATCCACGCACAGGCAACTCTCTTATGGAGAGAACCGTGCTTATTGCAAACACATCCGATATGCCTGTTGCCGCCCGTGAGGCATCTATCTACACAGGCATTACTATTGCCGAGTATTTCCGTGATATGGGTTACACGGTTGCACTTATGGCTGACTCAACATCCCGCTGGGCAGAGGCTCTCCGTGAAATGTCCGGCCGTCTTGAAGAAATGCCGGGTGAAGAGGGTTATCCCGCATACCTCGGCAGCCGACTTGCACAGTTCTATGAAAGAGCAGGCCGTGTTATCGTAAACGGCAGTGACGACACGGAAGGCGCACTCTCGGTTATAGGTGCTGTATCACCTCCGGGCGGTGATATTTCAGAGCCTGTATCACAGGCAACACTCAGAATCGTTAAGGTATTCTGGGGACTTGACGCAAACCTTGCTTACAAACGACACTTCCCTGCAATTAACTGGCTGACAAGTTATTCGCTTTATACAGACCGACTTGCAGATTGGTTCTCAAAGAATGCCGCTCCCGACTTTATGGAGCTTCGTGGCAAACTTATGACATTATTACAGGAAGAAAGCGAGCTTCAGGAAATCGTAAACCTTGTCGGTATGGACGCACTTTCCGCACCCGACAGACTTAAGCTTGAAACCTCCCGTTCAATCCGTGAGGATTATCTGCACCAAAACGCATTTGACCCGACAGACACATACACATCTCTCGGCAAGCAGGTGCTTATGATGCGTGCAATTCTTGTTTACTATGACAAAGCAAAAGAGGCTCTTGCAAACGGTGCAGACATTGAAATGCTTGTCAACCTTCCTGTTCGTGAACGCATAGGAAGATATAAATATGTACCCGAGGATAAGGTTCGGGACGAGTTCGAGTCAATCAAGGCTCTGCTTGATTCGGAAATTAAGGATGTACTTGAAAGGAGTGAGGACTGA",
    "translation": "MKSGIITKVAGPLVIAEGMRDADMFDVVRVSSQRLIGEIIEMHGDRASIQVYEETSGLGPGEIVESTGAPLSVELGPGLIGSIYDGIQRPLNEIMKVAGTNLKRGVDVPSLDHKKKWHFTPLVKKGDTVAAGDTLGTVQETHAVLHRILVPNKTGGVVESISEGDFTIDETVAVLKTDKGNVEINMCTKWPVRVGRPYKRKLSPDILLTTGQRPIDTLFPLAKGGVAAVPGPFGSGKTVVQHQLAKWAAADIIVYIGCGERGNEMTDVLNEFPELKDPRTGNSLMERTVLIANTSDMPVAAREASIYTGITIAEYFRDMGYTVALMADSTSRWAEALREMSGRLEEMPGEEGYPAYLGSRLAQFYERAGRVIVNGSDDTEGALSVIGAVSPPGGDISEPVSQATLRIVKVFWGLDANLAYKRHFPAINWLTSYSLYTDRLADWFSKNAAPDFMELRGKLMTLLQEESELQEIVNLVGMDALSAPDRLKLETSRSIREDYLHQNAFDPTDTYTSLGKQVLMMRAILVYYDKAKEALANGADIEMLVNLPVRERIGRYKYVPEDKVRDEFESIKALLDSEIKDVLERSED",
    "product": ""
   },
   {
    "start": 45443,
    "end": 45766,
    "strand": -1,
    "locus_tag": "ctg67_45",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,443 - 45,766,\n (total: 324 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTAAAAATATTGCCGTTATCGGCGACAGCGAAAGCATAAAGGGCTTTGCGGCAATCGGCATGGACATTTATCCGTGTGATGACAACGAAAACGCACCGCATCTTTTCAGAAAGATTGCTGACGGTGACAACTATGCGGTAATTTTTATTACCGAGGAAATGTTCGGACTTGTTGAAAAAGAGCGAAAAAGATATGAAGAAAGGCTCATTCCTGCCGTTATTCCTATCCCCGGAGTAAAAGGCAATACGGGAATCGGCATAAAAAGACTGTCGTCATTTGTTGAAAAGGCAGTCGGTTCGGACATTATCTTCAATGATTGA",
    "translation": "MAKNIAVIGDSESIKGFAAIGMDIYPCDDNENAPHLFRKIADGDNYAVIFITEEMFGLVEKERKRYEERLIPAVIPIPGVKGNTGIGIKRLSSFVEKAVGSDIIFND",
    "product": ""
   },
   {
    "start": 45759,
    "end": 46730,
    "strand": -1,
    "locus_tag": "ctg67_46",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,759 - 46,730,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCATTATCTTATGAATTTTCCATCGGCTCCGTCCGTGCTAAAGAAAAAAATCTGTTTACAAACAGCGACATTGAGCATATGCTCGGTTGTGAAAATGTGAACGAGCTTTGCAGATACCTCTCGGACAAGGGTTACGGCGAGGGTGATGACATTGAAGAGATTTTGAAATCACACAGCAAAAATGTGTGGGAATATCTTAAAAGAACCGCACCCGATTTTGCAATATTCACACCGTTCTTCTATCTTAACGACCTTCACAACCTTAAAGCTGTTTTAAAGGGAACGCTTTCAAACAGACCGTATTCACAGCTTTTGGTAAAGCCGTGTACTTTCTCTGAAGAAACGCTTAAACAGGCGGTTGAGAACAGAAAGTTTTCACTTTTAGGCGAAGAACTTTCCGCACCTTGTGACAAGGCATATGAAATTCTTGCACACACAGGTGACGCAAGACTCAGCGATGCGGTTCTTGACAGAGCTTTTATGGAGCTTGTTCTGAAAACATCCGAAAAATCCGACAGCGAATTTATGTCCGAATATTTTAAAGCTACAGTATTTTATAATAATGTAAAGACAGCCATAAGAGGTGCAAAAGCCGATTGCGACAGGGATTTTCTTGAAATTGCAATCTGTGATGTGCAGGACTTCCCCCGTTCAAGGGTTATTGAGGCAAGCGTAAAGGGACTTGAACCAACGCTTGATGTGCTGTCAAAAATCTCGGCATACGGCTGTAACAAGGCTGTTGAAGAGTACAAGGCTTCTCCGTCGGCATTTGAAAAATTTGTTGACAACAAGCTTATGAGCCTTGCAAAAGAAAAATGCAAAAGAAGCGGTGACGGTGCAGATCCGATTACAGGCTATCTGATTGCAAGTGAAACAGAGAAAAAAGTTATTCACATTATTGCAAGCGGAATCCGCACCAAGACAAATTATGAAACCGTAAAAGAAAGGTTGCGTGAAGTTTATGGCTAA",
    "translation": "MALSYEFSIGSVRAKEKNLFTNSDIEHMLGCENVNELCRYLSDKGYGEGDDIEEILKSHSKNVWEYLKRTAPDFAIFTPFFYLNDLHNLKAVLKGTLSNRPYSQLLVKPCTFSEETLKQAVENRKFSLLGEELSAPCDKAYEILAHTGDARLSDAVLDRAFMELVLKTSEKSDSEFMSEYFKATVFYNNVKTAIRGAKADCDRDFLEIAICDVQDFPRSRVIEASVKGLEPTLDVLSKISAYGCNKAVEEYKASPSAFEKFVDNKLMSLAKEKCKRSGDGADPITGYLIASETEKKVIHIIASGIRTKTNYETVKERLREVYG",
    "product": ""
   },
   {
    "start": 46742,
    "end": 47323,
    "strand": -1,
    "locus_tag": "ctg67_47",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,742 - 47,323,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAGCAGCGGTGATAAAATTTTAAATCGCATAAGTCTTGACTGTGACGAAAGAATCAGCCAAATAGGTGCTGAAACCGATGAAAAATGCGCACAGATTATGGCACAGGCAAAGCTTGATGCCGACAAGATTTCTGCCGAAATTGCCGACAGGGCACAGTCAAAGGTCAAGCAGATGCAGGCGGCTTCAAAGAGCCGTTGCGACCTTGAAACACGCAACGCTTTCCTGAAGAGAAGGCGTGAAGAAATTGACAAGACATACAGTGAAATTCTTAATAAAATGAAAAATCTTCCCGATGAAGATTACTTTGAACTGATTTACACATTTGCAAAAAAGTTAAACGGAATGAGCGGTGTTGTGCTTTTGAATGAAAAGGATATGAACCGACTTCCGAAGGATTTTCTTGCAAGGCTTGAAGAATGCGGTGTAAAAGCAGAGCTTTCAAAAACGCCGTGTGACATTGAAAGCGGATTTATTCTTAAATGCGGTGACATTGAAGAAAACATGGACTTCTCGGCAATATTGTCCGAAAAGTGTGACGCTATCGAGGATTTTATAAATCAGGAACTTTTTAAGGCATAG",
    "translation": "MSSGDKILNRISLDCDERISQIGAETDEKCAQIMAQAKLDADKISAEIADRAQSKVKQMQAASKSRCDLETRNAFLKRRREEIDKTYSEILNKMKNLPDEDYFELIYTFAKKLNGMSGVVLLNEKDMNRLPKDFLARLEECGVKAELSKTPCDIESGFILKCGDIEENMDFSAILSEKCDAIEDFINQELFKA",
    "product": ""
   },
   {
    "start": 47365,
    "end": 47838,
    "strand": -1,
    "locus_tag": "ctg67_48",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,365 - 47,838,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATGGAATATTTTTCGCACTTTTAGGCGCATCAATAGCAACAGCACTTGCAGGCGTAGGTTCTGCTCGAGGTGTAGGCTCTGCCGCACAGGCAGCTATGGGAGTTCTTTCCGAGGACTCATCAAAATTCGGTAAAATGCTCGTTCTCACACTTCTCCCGGGTACTCAGGGACTTTACGGATTTATCGTAGGCTTCCTTATTCTCGTAAGCGGCGGCGTTCTCGGCGGCACAGCTCCGACAATCGGACAGGGACTTGCATACTTTGCAGCATCGCTTGCTATCGGTATCGGCGGTATGATTTCAGGTTTTGCACAGGGCAAGGCAGCCGTTTCGGGTATTGCACTCAGCGCAAAGGATGATTCAAACTTCTCAAAGGCAATGGTTTCCGTAACTCTCGTTGAGATTTACGCTCTCCTTTCATTCATCGTTTCACTTCTCGTTGTTATCACAGTTCCAAACCTTAACATCTGA",
    "translation": "MNGIFFALLGASIATALAGVGSARGVGSAAQAAMGVLSEDSSKFGKMLVLTLLPGTQGLYGFIVGFLILVSGGVLGGTAPTIGQGLAYFAASLAIGIGGMISGFAQGKAAVSGIALSAKDDSNFSKAMVSVTLVEIYALLSFIVSLLVVITVPNLNI",
    "product": ""
   },
   {
    "start": 47835,
    "end": 49823,
    "strand": -1,
    "locus_tag": "ctg67_49",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,835 - 49,823,\n (total: 1989 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGGCAAAACTTAAAATGAAGTCGGTTCGGATTATTGCCCTAAGACAGGACAGAAAGCGACTTCTTGAACATTTGCAGGATTCGGGTTTGGTTCAGATTGAAAAGACCGAAACCTGCAGAAAAGGTTTCGGCAAGATTGATATGACCTCACAAATTCAGATTTTCGAGCGGAATGTTACTCTCAGTGAAAACGCTCTGAAAATTCTCGACAGCAACTCTCCCGAAAAGAAAAGTATGCTTTCCGCATTTTGCGGACGGCGAGAGATTGATCCCGATGAAATCGGAGTTATCGCATCAAATGCAGGCGAAGTTATTGATGTGTGCAACAGAATTTGTGAGCTTAACAAACAGATTGCCGATAATGCGGCGGAACGGATTCGCATAAAAACCGCTCTTGCACAGCTTGAGCCGTGGAAAAACCTTGACATTCCGCTTAATGCAAAGGACACAAAAACAACGGCTGTTTTCATAGGCTCAATTCAAAAGGAGTACAACGAGGTATCGCTTTCAGAGGCACTTGCCGAGGCTTCTCCGAAGCTTGAATTTGATTTTGAAATTCAATTTGCAAACGAGGGGCTTACCTGTATTGTACTTTTTGCACCGATTGCCCAAAAGGAGCTTGCGGAAAATACTCTGCGTGACATTGGTTTTGCAAAGCCTGTTACGAACTCAAGCCTTACCCCTTTGGCGGAATCAAAAAAGCTTGTTGAAAGAAGTCACAAGCTTGAAGACGACACGGAAAATGCAAAAAAAGAAATCATTTCCTTTGCAGACAGACGAAAAGATATTAAAGATACACAGGATTATTTCAGAATCAGAGCCGATAAATACAGCGTAATCGGTGAACTTCAGCATTCACGGAATGTTTTTGTCATTTCGGGTTACATTCCCGAGGAGGACTGTGAAAAGCTTGAAAGGCTTTGCGAAAGAGTTTCTGTATGCTATGTTGAATTCGGCGATGTTGACGAGGAAAAAGCTCCTGTAAAGCTAAAGAACAGTCGCTTTGCAGCACCGGCAGAGAGCATTGTAAATATGTACTCTCCCCCGTCGCATGACGATATTGATCCAACGCCGTTGCTTGCATTCTTCTTCTACTTTTTCTTTGGAATGATGTTCTCGGATGCAGGCTACGGACTGTTAATGGTAATAGGAACAGGACTTGCAATAAAGCTGTTCAAGCCTGACAAGGAAATGCGAAACACCTTGAAACTGTTCCAGTACTGCGGTATTTCAACATTTTTCTGGGGACTTGTTTTTGCAAGCTTCTTCGGAGATGCCCCCGCAACCCTTTACAACTACTTTACGGGTGCAGACATTACGATGAAGCAAATCTTCCCGTGGCCGACAATTGACCCGCAAAAGGACGCACTTATGCTGATGATTATTTCAATAGCATTCGGTCTTGTACACATTCTTGTCGGTATGGGCTGCAAATTCTATGTTTGCCTCAGGCAGAAGGATTATGGCGGAGCGTTCTTTGACACGGGGCTTTGGATGCTTATGCTTATCGGATTTGCAGTTTTGGCGGCAGGTATGGCGTTCGGTCAGACACTCGTCTATGTCGGAGCAGGCATTGCGATTTTCTGCGCAATCGGTCTTGTTCTCACACAGGGCAGAAACAAAAAGGGATTCGGCAAAGTCATCGGCGGACTTGCCTCTCTCTATGACATCACAGGTTACATCAGTGACCTTCTGAGCTACTCAAGACTTCTTGCTCTCGGACTTACAACGGGAGTTATGGCTCAGGTGTTCAATATGCTTTCAACCATGTTCGGCAAGAGCTGGTTTGGAATTATCTTACTCATTATTGTGTTCATCATCGGACACGCAATCAACATCGGACTCAACGCACTCGGTTCATATGTTCACACAATGCGACTTCAGTATGTTGAAATGTTCGGAAAATTCTATGAGGGCGGCGGCAAACAGTTTAAGCCGTTCAAGCTCAACAGTAAATATATTAAAATTCAGGAGGACAAATCAAAATGA",
    "translation": "MAKLKMKSVRIIALRQDRKRLLEHLQDSGLVQIEKTETCRKGFGKIDMTSQIQIFERNVTLSENALKILDSNSPEKKSMLSAFCGRREIDPDEIGVIASNAGEVIDVCNRICELNKQIADNAAERIRIKTALAQLEPWKNLDIPLNAKDTKTTAVFIGSIQKEYNEVSLSEALAEASPKLEFDFEIQFANEGLTCIVLFAPIAQKELAENTLRDIGFAKPVTNSSLTPLAESKKLVERSHKLEDDTENAKKEIISFADRRKDIKDTQDYFRIRADKYSVIGELQHSRNVFVISGYIPEEDCEKLERLCERVSVCYVEFGDVDEEKAPVKLKNSRFAAPAESIVNMYSPPSHDDIDPTPLLAFFFYFFFGMMFSDAGYGLLMVIGTGLAIKLFKPDKEMRNTLKLFQYCGISTFFWGLVFASFFGDAPATLYNYFTGADITMKQIFPWPTIDPQKDALMLMIISIAFGLVHILVGMGCKFYVCLRQKDYGGAFFDTGLWMLMLIGFAVLAAGMAFGQTLVYVGAGIAIFCAIGLVLTQGRNKKGFGKVIGGLASLYDITGYISDLLSYSRLLALGLTTGVMAQVFNMLSTMFGKSWFGIILLIIVFIIGHAINIGLNALGSYVHTMRLQYVEMFGKFYEGGGKQFKPFKLNSKYIKIQEDKSK",
    "product": ""
   },
   {
    "start": 49858,
    "end": 50169,
    "strand": -1,
    "locus_tag": "ctg67_50",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,858 - 50,169,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAAAGATATGCTGGACGCCATTTACAATGCCGAAGAGGATTGCAGACAGCGTGAGGCAAATGCACGAGCAGAATCAGCAGAAAGGATTGAACAGACAAAGGCAGATGCCAAACAGGTTGTGCTTTCGGCAAAGGAAAAGGCACAGAAGGATGCCGATATGCTTTTTGAAAAGACTGCGAAAGAGGGCAAAAAAGAGCTTGAGAAAGCCTCTGAAAAGGCAAATCTTGAGTGCGACATTCTCTCTCAAACTGCAGACAAAAACCGCAAGCGTGTTATTGACGGGGCTATACAAAGGCTCTCTCTTTAA",
    "translation": "MAKDMLDAIYNAEEDCRQREANARAESAERIEQTKADAKQVVLSAKEKAQKDADMLFEKTAKEGKKELEKASEKANLECDILSQTADKNRKRVIDGAIQRLSL",
    "product": ""
   },
   {
    "start": 50699,
    "end": 51244,
    "strand": 1,
    "locus_tag": "ctg67_51",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,699 - 51,244,\n (total: 546 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGAAAAGTTGTATTATGTGAGGGTAATAACAAGATGGCAATATGCATGGAGGATTGTGTATTTATGAAAGAAATCAAGACAAATGTAATGAGAATTTTAGACAAAGAAAAGGTTGAATATACTCACCATGAATATCCCCACGGCAAGGATGCCGTTGACGGAGTAACGGTTGCAACGCTTATGAATCAAAATCCCGATTATGTTTTCAAAACTCTTGTAACAAAGGGCATGGGCAGAGATTATTATGTTTTCGTAGTTCCTGTTGACCATGAGCTTGACCTTAAAAAATGTGCAAAGAGTGTGGGGGAAAAGTCGGTTGAAATGATTCCCGTAAAGGACATTACAAAGGTCACGGGTTATGTGCGTGGAGGCTGTTCACCTCTCGGAATGAAAAAGCAGTTCAAGACAACCTTCCACATTACAGCAGAGTCAATTCCGAAAATCATTGTCAGTGCAGGAAAAATCGGATATCAAATTGACCTGAAGCCTGAGGATTTAATTCGTCTTACAAACGGTCAATGTGCCGATATTATTAAAAATTAA",
    "translation": "MRKVVLCEGNNKMAICMEDCVFMKEIKTNVMRILDKEKVEYTHHEYPHGKDAVDGVTVATLMNQNPDYVFKTLVTKGMGRDYYVFVVPVDHELDLKKCAKSVGEKSVEMIPVKDITKVTGYVRGGCSPLGMKKQFKTTFHITAESIPKIIVSAGKIGYQIDLKPEDLIRLTNGQCADIIKN",
    "product": ""
   },
   {
    "start": 51258,
    "end": 52046,
    "strand": 1,
    "locus_tag": "ctg67_52",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg67_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg67_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,258 - 52,046,\n (total: 789 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1089:methyltransferase (Score: 62.6; E-value: 6.7e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg67_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg67_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGGATATTGTTGACAAAAATATAGACAACGGAAATGCTTTTGACTGGGGCAGAGTGTCAGCCGAATATGCAAAATATCGTGATATTTATCCGCAAAAATTTTATGATCAAATTGTTGACAGAGGGCTTTGTGTAAAAGGTCAGAAAATTCTTGATATTGGCACCGGAACAGGAGTTATTCCGAGAAATATGTATCGCTATGGCGGAGAGTGGGTTGGTACAGATATTTCAAAAGAGCAAGTTGGTCAGGCTCGTTTATTATCAAAAGGTATGAATATAAAATATTTTACTGTAGCAACAGAGAATATAAATTTTCCTGATGAATCGTTTGATGTTATCACAGCTTGTCAGTGCTTTTGGTATTTTGACCACCAAAAGATTATGCCTGAACTTTACAGAATGTTAAAGCCAAATGACAGGTTGTTAATTCTTTATATGGCTTGGTTACCGTATGAAGATGAGATAGCAGGGCAGAGTGAAAAACTTGTATTGAAATACAGTCCCGATTGGAGCGGTGCAGGAGAAACTATTCATCCGATAAATATTCCGAAATGTTATGAAGAAAAGTTTGATTTGATTTATCACAACGAATATCCGCTCAAGGTATATTTTACAAGAGAGTCATGGAACGGCAGAATGAAGGCTTGCCGTGGTGTAGGTGCGTCACTCTCAAAAGAAAAAATTGAATTGTGGGAGAATGAACATAAAAATTTACTCTTAAAAATTGCACCGCCTGAATTTGATGTGTTGCATTATGCCGCAATTGCTGAATTAAAAGTAAAGAAATAA",
    "translation": "MDIVDKNIDNGNAFDWGRVSAEYAKYRDIYPQKFYDQIVDRGLCVKGQKILDIGTGTGVIPRNMYRYGGEWVGTDISKEQVGQARLLSKGMNIKYFTVATENINFPDESFDVITACQCFWYFDHQKIMPELYRMLKPNDRLLILYMAWLPYEDEIAGQSEKLVLKYSPDWSGAGETIHPINIPKCYEEKFDLIYHNEYPLKVYFTRESWNGRMKACRGVGASLSKEKIELWENEHKNLLLKIAPPEFDVLHYAAIAELKVKK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 30440,
    "end": 32639,
    "tool": "rule-based-clusters",
    "neighbouring_start": 10440,
    "neighbouring_end": 52639,
    "product": "HR-T2PKS",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "HR-T2PKS",
  "products": [
   "HR-T2PKS"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS HR-T2PKS",
  "anchor": "r67c1"
 }
};
var details_data = {
 "nrpspks": {
  "r49c1": {
   "id": "r49c1",
   "orfs": [
    {
     "id": "ctg49_3",
     "sequence": "MSNLINLLDTYKGEKRELYPLTPSQMGVYLSCMHNPKGTMYNIPCTYVFDKGSLDTDRLINAVRKAVDNHPVMKIFIDSSTGSPMMKPRDSVDFDIPVVQVDNLEQAGKDFVKPFDLEKDILFRFAIFECGDKSMFAMDFHHIISDGTSVSVICNDIALAYDGKELEPEKFSQLDLSVFEEKLEETEEYQKSKNYYDSIFSAVESKSEITEDFAENSEVEDKPNGSFELSTNGKFSVEEVRNFALANQITPYTVFLGAYEYAVAKFTNQSETTVCTVTHGRFNKQLKNTVGMMVRTLPIHANIDEEDTVSDYLKKIRRNIKETVANDWFPFMKLASDYDLSADIMLAYQADIFNTFKIGGQALKLKLVPLKSAISKLNVMVFESETDFELRFEYRNDLFKEETIRSFADSFLKIVEQFLKKSKLCEVELVNENQLAELDNFNKTEFPFDDSKTVVDLFEEQCKKTPDKTAVVYKEKKFTYAEIDEITNRIAGYVHSKGIGKEEVVSILIPRCEYMPIASIGVLKSGAAYQPLDPSYPPERLQFMIKDANAKLLIADENLLELLPDYSGDILLTKDIPNLPKSDAVFTKPSPDDLFILIYTSGSTGTPKGAMLEHKNVRSFCDFHIRNSDIDEHSVVSAYASYGFDACLSEMYPALIGGAELHIIEEDIRLDLVRLNRYFEDNGITHAFMTTQVARQFATEIDNHSLKYLLTGGERLVPLEPPKNFELINGYGPTECTVYITTQPVDKLYHRIPVGKALDNIKLYVTDKYGRRLPTGALGELCVSGQQVSRGYLNRPEQTAKAYEKNPYCNKNGYERLYHTGDIVRLTDEGKVDFIGRNDGQVKIRGFRIELSEVDKIIRKYDGITNTAVIARKLDGGGQCINAYIVADRKIDIQKLNEFILEHKPPYMVPAATMQIDKIPLNVNGKVDKRKLPEIKAESSKKKNSAPRELTFLEKKISAIIEKIIGHSDFDISENLINAGMTSLSVIKLAVELNKAFGFEAQVKKMMKGCSLLSIEDELQEFMFSGTANQQTVKKEEKKEHKALYPLSKTQLGVYIDCMKNPYSTLYNIPSILTFSKSVDAQKLADCVVKVIKAHPYIMTHLSLENDDIEQAYVDSAKPNVPVEKLTEEQLEAYKKDFVKPHNLMKAPLFRISVAETEKAVYLLSDFHHLIFDGASVALFFEQLKTLYEGGNIEPESYTYFDYAENEIKAESSDEFRNAEKFFDNMMKNFESASEITADLRGHAEDGALASQAVPVDMARVENFCSQHGITPAHLFLAGTFYAVSRFVNSRNVYISTISNGRSDMRLTNCFGMFVKTLALGIEIEDITSLEFVEKSKAVFTDSIENEIYPYAQLCAKYGYAPNIMYEYQLGVVDNLEIDGKAVVRDYLEMNTAKFKTAIHIEDYRGKPSVVVQYNDALYSGELMRTLAKSVLCAVEHIIENPNGKIRKVSLLDNAAIAQLESFKSTEIAPVKTKLLHKMFEEQVAKTPDRIALSACDGKLTYKELDRLANITANSLIEKGLEKGGKVLILLERTSKFFISLFGILKAGGAFIPSCPDYPKERIDSIIEDSDADFVITEGELLNKYDRTVDVSKLLSGNNDEDPNVHVQPDDLAYLIYTSGSTGKPKGVMLRHIGIANYLAYSDSNIQVKEVVDNCHAYGSVTTISFDMSLKETMLSLCNGLTLVFASDEQVVNPMLLAEFFKENNVDAFNSTPSRLLQYMELDEFAEAMANCKVILSGGEKYPDKLLRILREKTNATIINTYGPTEITVSSNAKNLTNADEISIGRPLRNYTEYIVDSDNNLLPIGVVGELLIQGYGVALGYNKLPEQTAKAFIEFNGERTYRSGDYAKWTTDGDVIILGRTDNQVKLRGLRIELGEIEKCLTAVDGIKSGIALIRKVGKADAICVYYTADRQLDPDEIKSELAKTLTDYMVPSAYVQLDEMPLTPNGKVNTKVLPEPKSNKSERGRLPKNELEKTFCDIFAEILELDNVFADDNFFDLGGTSLTATRIVISASKKNIEVAYSDIFANPTPQTLAKFVSKDDSAEDDLENLSDYDYTNINKVLEKNNIDTFKNGELQKLGNVLLTGSAGFLGVHILYELLHKYNGKVYCMIRDKNNNPAENRMNSIYYYYFEESLKERYPDRVTVISGDVTNRESFDKFIDEDINTVINCAANVKHFSKGTDIEDVNLYGTLNVLDFCKKANARLVHVSTMSVGGMFVGEQGSVDKLKENQLYFGQHEGSKYTLSKFLAERAILEEVSKGFNAKIMRVGTLAARNSDGEYQINFTTNTFMGRLKSTLLIGKYPYEAMEMPFELSPIDFVAKAILLLAQAPKDCTVFHPFNNHTLIMGDLYTEMNKIGLHSQGAEYEEYMIALDRAEQDPEKAKILSSMIAYQNMAHGQKTFTVGKSNTYTMQVLYRMGFVWPVTSLDYMKRFINALRGLGFFD",
     "domains": [
      {
       "type": "Condensation_LCL",
       "start": 17,
       "end": 303,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_C_190411_273.faa&amp;Sequence=%3Eall_C_190411_273.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LYPLTPSQMGVYLSCMHNPKGTMYNIPCTYVFDKGSLDTDRLINAVRKAVDNHPVMKIFIDSSTGSPMMKPRDSVDFDIPVVQVDNLEQAGKDFVKPFDLEKDILFRFAIFECGDKSMFAMDFHHIISDGTSVSVICNDIALAYDGKELEPEKFSQLDLSVFEEKLEETEEYQKSKNYYDSIFSAVESKSEITEDFAENSEVEDKPNGSFELSTNGKFSVEEVRNFALANQITPYTVFLGAYEYAVAKFTNQSETTVCTVTHGRFNKQLKNTVGMMVRTLPIHANI",
       "dna_sequence": "CTTTATCCGCTTACACCGAGCCAGATGGGTGTTTATCTTTCGTGTATGCACAACCCAAAAGGCACAATGTACAACATTCCCTGCACCTATGTTTTTGACAAGGGCAGTCTTGATACCGACAGGCTGATAAATGCCGTAAGAAAAGCTGTTGACAATCACCCTGTTATGAAAATTTTTATTGACAGTTCAACAGGAAGCCCGATGATGAAGCCTCGTGACAGCGTTGATTTTGACATTCCTGTCGTACAGGTTGACAATCTTGAACAGGCAGGCAAAGATTTTGTTAAGCCGTTTGACCTTGAAAAAGACATTCTGTTCAGATTTGCAATTTTTGAATGCGGTGACAAATCTATGTTTGCAATGGACTTTCACCATATAATCTCTGACGGCACATCTGTTTCGGTTATCTGCAATGACATTGCGCTTGCATATGACGGAAAAGAGCTTGAACCCGAAAAGTTTTCTCAGCTTGATCTTTCTGTTTTTGAGGAAAAGCTTGAAGAAACCGAAGAATATCAAAAATCAAAGAACTACTATGACAGCATTTTTTCGGCTGTTGAGTCAAAGTCGGAAATAACGGAAGATTTTGCAGAGAATTCAGAGGTTGAGGATAAACCGAACGGTTCTTTTGAATTATCCACGAACGGCAAATTCTCCGTTGAGGAAGTTCGCAATTTTGCCTTAGCAAACCAAATTACGCCGTACACTGTTTTCCTCGGTGCATATGAATACGCAGTTGCAAAGTTTACAAATCAGAGCGAAACAACGGTTTGCACGGTTACTCACGGAAGATTTAACAAACAGCTTAAAAATACGGTCGGCATGATGGTTCGCACACTTCCTATCCACGCAAATATT",
       "abbreviation": "C",
       "html_class": "jsdomain-condensation"
      },
      {
       "type": "AMP-binding",
       "start": 457,
       "end": 845,
       "predictions": [
        [
         "substrate consensus",
         "Ile"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FEEQCKKTPDKTAVVYKEKKFTYAEIDEITNRIAGYVHSKGIGKEEVVSILIPRCEYMPIASIGVLKSGAAYQPLDPSYPPERLQFMIKDANAKLLIADENLLELLPDYSGDILLTKDIPNLPKSDAVFTKPSPDDLFILIYTSGSTGTPKGAMLEHKNVRSFCDFHIRNSDIDEHSVVSAYASYGFDACLSEMYPALIGGAELHIIEEDIRLDLVRLNRYFEDNGITHAFMTTQVARQFATEIDNHSLKYLLTGGERLVPLEPPKNFELINGYGPTECTVYITTQPVDKLYHRIPVGKALDNIKLYVTDKYGRRLPTGALGELCVSGQQVSRGYLNRPEQTAKAYEKNPYCNKNGYERLYHTGDIVRLTDEGKVDFIGRNDGQVKIR",
       "dna_sequence": "TTTGAGGAGCAATGCAAAAAAACTCCTGACAAAACAGCGGTTGTATATAAAGAAAAGAAGTTCACCTACGCTGAAATTGATGAGATTACAAACCGAATTGCAGGTTATGTTCACTCAAAGGGTATCGGTAAAGAAGAGGTTGTTTCAATTCTGATTCCGAGATGCGAATATATGCCGATTGCGTCAATCGGTGTGCTGAAATCGGGTGCGGCATATCAACCGCTTGATCCGTCATATCCGCCCGAAAGACTTCAGTTTATGATTAAGGACGCAAACGCAAAGCTGCTTATTGCGGACGAAAATCTGCTTGAACTTTTGCCCGATTACAGCGGTGATATTCTTCTTACAAAGGATATTCCGAATCTTCCGAAATCAGATGCAGTTTTTACAAAACCCTCACCCGATGATTTGTTTATACTTATCTATACATCGGGTTCAACAGGCACTCCAAAGGGTGCTATGCTTGAACACAAAAATGTGCGTTCATTCTGCGATTTTCATATCAGAAACTCTGACATTGACGAACACAGCGTTGTTTCGGCATATGCAAGCTACGGTTTTGACGCCTGTCTCAGTGAAATGTATCCTGCGCTTATCGGCGGTGCCGAGCTTCACATTATTGAGGAGGACATCAGACTTGACCTTGTAAGGCTGAACAGATATTTTGAAGATAACGGAATCACCCACGCATTTATGACAACACAGGTTGCAAGACAGTTTGCAACCGAAATTGACAACCACTCGCTCAAATATCTTCTTACGGGCGGTGAACGGCTTGTTCCCCTTGAACCGCCAAAGAATTTTGAACTCATAAACGGTTACGGTCCGACAGAATGTACGGTTTACATCACAACACAGCCCGTTGACAAGCTCTACCACAGAATTCCTGTCGGCAAGGCTCTTGACAATATCAAGCTTTATGTAACAGACAAATACGGCAGACGGCTTCCGACAGGGGCTTTGGGCGAGCTCTGTGTATCAGGTCAGCAGGTTTCAAGAGGGTATCTTAACCGTCCCGAACAGACTGCAAAGGCATACGAAAAGAACCCATATTGCAATAAAAACGGTTACGAAAGGCTTTATCACACAGGTGACATTGTTCGCCTTACAGATGAGGGCAAGGTTGATTTTATCGGACGAAATGACGGTCAGGTTAAAATCAGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 955,
       "end": 1008,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "KISAIIEKIIGHSDFDISENLINAGMTSLSVIKLAVELNKAFGFEAQVKKMMK",
       "dna_sequence": "AAAATTTCCGCAATTATCGAAAAGATTATCGGACACAGCGATTTTGATATTTCCGAAAATCTCATCAACGCAGGTATGACCTCGCTTTCGGTTATCAAGCTTGCAGTTGAACTCAACAAGGCATTCGGCTTTGAGGCACAGGTTAAAAAGATGATGAAG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "Condensation_LCL",
       "start": 1044,
       "end": 1324,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_C_190411_273.faa&amp;Sequence=%3Eall_C_190411_273.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YPLSKTQLGVYIDCMKNPYSTLYNIPSILTFSKSVDAQKLADCVVKVIKAHPYIMTHLSLENDDIEQAYVDSAKPNVPVEKLTEEQLEAYKKDFVKPHNLMKAPLFRISVAETEKAVYLLSDFHHLIFDGASVALFFEQLKTLYEGGNIEPESYTYFDYAENEIKAESSDEFRNAEKFFDNMMKNFESASEITADLRGHAEDGALASQAVPVDMARVENFCSQHGITPAHLFLAGTFYAVSRFVNSRNVYISTISNGRSDMRLTNCFGMFVKTLALGIEI",
       "dna_sequence": "TATCCTCTTTCAAAAACTCAGCTCGGCGTGTATATTGACTGTATGAAAAATCCGTACAGCACACTTTACAATATTCCGTCAATTCTCACATTTTCAAAATCAGTCGATGCACAAAAGCTTGCCGACTGCGTTGTAAAGGTAATCAAGGCTCACCCATATATTATGACTCACCTTTCACTTGAAAACGATGATATTGAGCAGGCATATGTTGACTCTGCAAAACCGAATGTTCCCGTTGAAAAGCTTACGGAAGAACAGCTTGAAGCCTACAAAAAGGATTTTGTAAAACCGCACAATCTTATGAAAGCGCCGCTGTTCAGAATCTCGGTTGCAGAAACCGAAAAGGCGGTATATCTGCTTTCGGATTTCCACCACCTTATCTTTGACGGTGCGTCCGTTGCACTCTTCTTTGAACAGCTTAAAACGCTGTATGAGGGAGGTAATATTGAGCCTGAAAGCTACACCTACTTTGATTATGCAGAGAATGAAATTAAGGCTGAAAGCAGTGATGAATTTAGAAATGCTGAAAAGTTCTTCGACAATATGATGAAAAATTTTGAATCTGCAAGCGAAATCACGGCTGACCTCAGAGGTCATGCAGAGGACGGTGCTCTTGCATCTCAGGCAGTCCCCGTTGATATGGCAAGGGTTGAAAACTTCTGTTCACAGCACGGAATCACTCCCGCCCACCTTTTCCTTGCCGGCACATTCTACGCTGTTTCAAGATTTGTAAACAGCAGAAATGTTTACATCAGCACAATCAGCAACGGCAGAAGCGATATGCGGCTTACAAACTGCTTTGGTATGTTTGTAAAAACTCTTGCGCTCGGCATTGAAATT",
       "abbreviation": "C",
       "html_class": "jsdomain-condensation"
      },
      {
       "type": "AMP-binding",
       "start": 1479,
       "end": 1869,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FEEQVAKTPDRIALSACDGKLTYKELDRLANITANSLIEKGLEKGGKVLILLERTSKFFISLFGILKAGGAFIPSCPDYPKERIDSIIEDSDADFVITEGELLNKYDRTVDVSKLLSGNNDEDPNVHVQPDDLAYLIYTSGSTGKPKGVMLRHIGIANYLAYSDSNIQVKEVVDNCHAYGSVTTISFDMSLKETMLSLCNGLTLVFASDEQVVNPMLLAEFFKENNVDAFNSTPSRLLQYMELDEFAEAMANCKVILSGGEKYPDKLLRILREKTNATIINTYGPTEITVSSNAKNLTNADEISIGRPLRNYTEYIVDSDNNLLPIGVVGELLIQGYGVALGYNKLPEQTAKAFIEFNGERTYRSGDYAKWTTDGDVIILGRTDNQVKLR",
       "dna_sequence": "TTTGAGGAGCAGGTTGCAAAAACTCCCGACAGAATTGCTCTTTCGGCTTGTGACGGCAAACTGACCTATAAAGAGCTTGACCGTCTTGCAAATATCACGGCAAACTCACTCATTGAAAAAGGTCTTGAAAAGGGCGGAAAGGTTCTTATTCTGCTTGAAAGAACCTCAAAATTCTTCATATCACTTTTCGGTATTCTCAAGGCAGGCGGTGCGTTTATTCCGTCATGTCCCGACTATCCGAAGGAGCGAATCGACAGTATTATTGAGGACAGTGACGCAGACTTTGTAATTACCGAGGGCGAACTGCTCAATAAATATGACCGCACGGTTGATGTTTCAAAACTTCTTTCAGGCAATAATGATGAAGACCCGAATGTTCATGTACAGCCTGACGACCTTGCGTACCTCATCTACACCTCGGGTTCAACAGGCAAGCCAAAGGGCGTTATGCTCCGCCACATTGGCATTGCAAACTACCTTGCATACAGCGACTCAAACATTCAGGTTAAAGAGGTTGTTGACAACTGTCACGCATACGGCTCTGTAACTACAATCAGCTTTGATATGTCGCTAAAGGAAACCATGCTGTCGCTCTGCAACGGTCTTACCCTCGTTTTTGCAAGTGATGAACAGGTGGTAAACCCGATGTTACTTGCAGAATTCTTTAAAGAAAACAATGTTGATGCGTTCAACTCTACACCGTCAAGACTTTTGCAGTATATGGAGCTTGACGAATTTGCAGAAGCAATGGCAAACTGCAAGGTTATTCTCTCGGGCGGTGAAAAATATCCCGACAAGCTATTAAGGATACTGCGTGAAAAAACGAACGCAACAATAATCAACACCTACGGTCCGACTGAAATCACGGTTTCTTCAAACGCAAAAAATCTTACGAATGCAGACGAAATTTCAATCGGCAGGCCGTTACGCAACTACACGGAATATATTGTTGACTCAGACAACAATCTCCTTCCAATCGGAGTTGTGGGTGAGCTTCTCATTCAGGGATACGGTGTGGCGCTCGGCTATAATAAACTTCCCGAACAAACTGCAAAGGCTTTCATCGAATTCAACGGTGAACGCACCTACCGTTCGGGTGACTACGCAAAATGGACTACAGACGGCGATGTTATTATTCTCGGCAGAACAGACAATCAGGTTAAGCTGAGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 1973,
       "end": 2041,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EKTFCDIFAEILELDNVFADDNFFDLGGTSLTATRIVISASKKNIEVAYSDIFANPTPQTLAKFVSKD",
       "dna_sequence": "GAAAAAACATTCTGCGACATCTTTGCAGAAATTCTTGAACTTGACAATGTTTTTGCAGACGATAACTTCTTTGACCTCGGCGGAACATCGCTTACAGCAACAAGAATTGTAATCTCCGCATCAAAGAAAAACATTGAGGTTGCATACAGCGACATATTTGCAAATCCTACTCCGCAGACTCTTGCAAAATTTGTGAGCAAGGAT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 2083,
       "end": 2323,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGSAGFLGVHILYELLHKYNGKVYCMIRDKNNNPAENRMNSIYYYYFEESLKERYPDRVTVISGDVTNRESFDKFIDEDINTVINCAANVKHFSKGTDIEDVNLYGTLNVLDFCKKANARLVHVSTMSVGGMFVGEQGSVDKLKENQLYFGQHEGSKYTLSKFLAERAILEEVSKGFNAKIMRVGTLAARNSDGEYQINFTTNTFMGRLKSTLLIGKYPYEAMEMPFELSPIDFVAKAI",
       "dna_sequence": "CTGACAGGCTCTGCCGGCTTCCTCGGAGTACACATTCTCTACGAACTTCTTCACAAGTATAACGGCAAGGTTTACTGCATGATTCGTGACAAAAACAATAATCCTGCCGAAAACAGAATGAACTCAATCTACTATTACTACTTTGAAGAAAGTCTGAAAGAAAGATATCCCGACAGAGTTACCGTTATCAGCGGTGATGTTACAAACCGTGAATCATTCGATAAATTTATTGACGAGGACATTAACACGGTCATCAACTGTGCCGCAAATGTTAAGCACTTCTCAAAGGGTACAGACATTGAAGATGTAAACCTTTACGGTACTCTCAATGTGCTTGACTTCTGCAAAAAGGCTAATGCAAGGCTTGTTCATGTGTCAACAATGAGCGTTGGCGGTATGTTTGTGGGCGAACAAGGTTCTGTTGACAAGCTCAAAGAAAATCAACTTTACTTTGGTCAGCATGAGGGTTCAAAGTACACCCTGTCAAAGTTCCTTGCGGAAAGGGCGATTCTTGAAGAGGTTTCAAAGGGCTTTAACGCAAAGATTATGCGTGTAGGCACACTTGCCGCAAGAAACAGCGACGGTGAATATCAGATTAATTTCACCACCAACACATTTATGGGCAGACTCAAATCTACGCTTCTTATCGGCAAATATCCGTATGAGGCAATGGAAATGCCGTTTGAGCTTTCTCCGATTGATTTTGTGGCAAAGGCAATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 17,
       "end": 1008,
       "complete": true,
       "iterative": false,
       "monomer": "Ile",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 1044,
       "end": 2323,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r67c1": {
   "id": "r67c1",
   "orfs": [
    {
     "id": "ctg67_32",
     "sequence": "MSKTALVTGSSRGIGKACALKLAELGYDIAVNCNSNLEMAQKAVDEITSLGRKAVAYKANTADIDEVKDMFRSIQQDFGGIDVLVNNAGVVDDAYLLMIKDESLERSLDINIKGYFNCARQASLKMLRKKSGIIINISSVSSVLAVEGQSVYSATKGAVNAMTHTLAKELAKYGIRVNAVAPGFIETEMMNGIPEELQKKYLEAIPEKRFGTVQDVANVVGQLCSDDFSYMTGQVLVLDGGLSL",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 3,
       "end": 167,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C2"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "TALVTGSSRGIGKACALKLAELGYDIAVNCNSNLEMAQKAVDEITSLGRKAVAYKANTADIDEVKDMFRSIQQDFGGIDVLVNNAGVVDDAYLLMIKDESLERSLDINIKGYFNCARQASLKMLRKKSGIIINISSVSSVLAVEGQSVYSATKGAVNAMTHTLA",
       "dna_sequence": "ACCGCTCTTGTAACAGGTTCATCAAGGGGCATTGGCAAGGCTTGCGCTTTAAAGCTTGCAGAGCTTGGATATGACATTGCCGTGAACTGCAATTCAAATTTGGAAATGGCTCAAAAGGCTGTTGACGAAATTACATCACTCGGCAGAAAAGCCGTTGCCTACAAGGCAAACACGGCAGATATTGACGAAGTAAAGGATATGTTCCGCAGTATTCAGCAGGACTTCGGCGGAATTGATGTGCTTGTCAACAACGCAGGTGTGGTTGACGACGCTTACCTTTTGATGATTAAGGACGAGTCGCTTGAAAGAAGTCTTGACATTAATATCAAAGGATATTTCAATTGTGCAAGACAGGCATCGCTTAAAATGCTCCGCAAAAAGAGCGGAATCATCATCAACATTTCTTCCGTAAGCTCTGTTCTTGCAGTTGAAGGTCAGTCGGTTTACAGTGCAACAAAGGGTGCGGTAAACGCTATGACTCACACGCTTGCA",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg67_33",
     "sequence": "MADKKRCVVTGLGLICGVGDNVKDCWDAVTLGHSGIDEVKSVDTSNCYAHKGAEVDKASSELSPENYDRSSLLCIHAANEAFEDANIDASEKNIGVILGSCVGGAASIDKYYTDEIKGDGGKKEDIFKMGASAIANNVSAHFGLEGITANIVNACAAGTMSIGYACDLIREGKGDVFIAGGSDSFSSLAFSGFHALHALDENACSPFNHSTGITLGEGSGILVIESYEHAVERGAKIYCEILGSGVSSDAYHITAPRPDGEGQMSAIRRAVESSALSFDDIDYINAHGTGTAKNDEAEFLSLHTLFDGNDHLSVSSTKSMTGHCLGAAGSIEAVFSVKAIKENLVPPTIGYSDEDLKVLSEKAGNIDFIPNKSHTKDVHYAMSNSFAFGGNNASIIFSDNEHDIPDNSKNEKIYITGISKLTGTRTDEHSLNCNLTSEDYDKHGIKVAFYRKLDRFSQLQLLSGMDALADADIKIDKDNEYKTGIVIGTADGPMTEIVDFQKKAITRGTEKGSAFSFPNTVYNAAGGYLSIFSGIKGYNATVANGNQAGLQSICYAADILADGNESVMLAAGTDENTKTNLELYTKAELLEKPLGEGSVTLVLETEESANGRNARKYAEIKGYAQAHRPVSYDNSEVDSKAVVEVIEKACVNADIEADNIDFVCCDDRKIIKTLMPCYDVSQEIGNARAAASAMTAAYAAEILSDSEKNYEYGLALSMGAGGTYSAVILKKA",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 66,
       "end": 399,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YDRSSLLCIHAANEAFEDANIDASEKNIGVILGSCVGGAASIDKYYTDEIKGDGGKKEDIFKMGASAIANNVSAHFGLEGITANIVNACAAGTMSIGYACDLIREGKGDVFIAGGSDSFSSLAFSGFHALHALDENACSPFNHSTGITLGEGSGILVIESYEHAVERGAKIYCEILGSGVSSDAYHITAPRPDGEGQMSAIRRAVESSALSFDDIDYINAHGTGTAKNDEAEFLSLHTLFDGNDHLSVSSTKSMTGHCLGAAGSIEAVFSVKAIKENLVPPTIGYSDEDLKVLSEKAGNIDFIPNKSHTKDVHYAMSNSFAFGGNNASIIFSD",
       "dna_sequence": "TATGACCGTTCTTCCCTTCTCTGTATTCATGCCGCAAACGAGGCTTTTGAAGATGCAAACATTGACGCATCCGAAAAGAACATCGGTGTTATTCTTGGCAGTTGTGTAGGCGGTGCGGCAAGCATTGACAAATATTACACAGACGAAATCAAGGGTGACGGCGGTAAAAAAGAAGATATTTTCAAAATGGGTGCTTCGGCAATTGCCAACAATGTTTCCGCTCATTTCGGACTTGAGGGCATTACCGCAAACATCGTCAACGCTTGTGCGGCAGGCACAATGAGCATCGGCTATGCCTGTGACCTTATCCGTGAGGGCAAGGGGGATGTGTTCATTGCAGGCGGTTCGGACAGTTTTTCTTCACTTGCATTCAGCGGTTTCCACGCTCTCCATGCGCTTGACGAAAACGCCTGTTCCCCGTTCAATCACAGCACAGGTATCACGCTCGGCGAGGGTTCGGGTATTCTTGTAATCGAAAGCTACGAACACGCTGTTGAACGAGGTGCAAAGATTTACTGTGAAATTCTCGGTTCGGGTGTAAGCAGTGACGCTTACCACATTACCGCTCCCCGTCCCGACGGTGAAGGTCAGATGAGTGCAATCAGAAGGGCTGTTGAAAGCTCTGCTCTTAGTTTTGACGATATCGACTACATAAACGCACACGGAACGGGTACTGCCAAAAATGACGAGGCTGAATTTCTTTCACTTCACACACTTTTTGACGGCAACGACCACCTTTCTGTCAGCTCAACAAAATCTATGACAGGTCATTGCCTCGGTGCGGCAGGCTCAATTGAGGCTGTATTTTCCGTAAAAGCAATAAAAGAGAACCTCGTTCCGCCTACAATCGGCTACTCCGATGAGGATTTGAAGGTGCTTTCCGAAAAGGCTGGCAACATTGACTTTATTCCGAACAAGAGCCACACAAAAGATGTTCACTATGCAATGTCAAACTCATTTGCATTCGGCGGCAACAACGCAAGCATCATTTTCTCGGAC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg67_34",
     "sequence": "MNNAIADQIKEMLVENLRIPENILTYDSELFGDEIGLDSIDSIEIVAGIDTLFGIDMTGADREHFQSIRALTEYVESKQG",
     "domains": [
      {
       "type": "PP-binding",
       "start": 6,
       "end": 75,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "DQIKEMLVENLRIPENILTYDSELFGDEIGLDSIDSIEIVAGIDTLFGIDMTGADREHFQSIRALTEYV",
       "dna_sequence": "GATCAGATTAAGGAAATGCTCGTAGAAAACCTTAGAATTCCCGAAAACATTCTTACATACGATTCAGAACTTTTCGGTGACGAAATCGGTCTTGACTCAATCGACTCAATCGAAATCGTTGCAGGCATCGACACACTTTTCGGTATTGATATGACAGGTGCAGACCGTGAGCACTTCCAATCAATCAGAGCACTTACAGAATATGTA",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg67_52",
     "sequence": "MDIVDKNIDNGNAFDWGRVSAEYAKYRDIYPQKFYDQIVDRGLCVKGQKILDIGTGTGVIPRNMYRYGGEWVGTDISKEQVGQARLLSKGMNIKYFTVATENINFPDESFDVITACQCFWYFDHQKIMPELYRMLKPNDRLLILYMAWLPYEDEIAGQSEKLVLKYSPDWSGAGETIHPINIPKCYEEKFDLIYHNEYPLKVYFTRESWNGRMKACRGVGASLSKEKIELWENEHKNLLLKIAPPEFDVLHYAAIAELKVKK",
     "domains": [
      {
       "type": "oMT",
       "start": 45,
       "end": 142,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "KGQKILDIGTGTGVIPRNMYRYGGEWVGTDISKEQVGQARLLSKGMNIKYFTVATENINFPDESFDVITACQCFWYFDHQKIMPELYRMLKPNDRLL",
       "dna_sequence": "AAAGGTCAGAAAATTCTTGATATTGGCACCGGAACAGGAGTTATTCCGAGAAATATGTATCGCTATGGCGGAGAGTGGGTTGGTACAGATATTTCAAAAGAGCAAGTTGGTCAGGCTCGTTTATTATCAAAAGGTATGAATATAAAATATTTTACTGTAGCAACAGAGAATATAAATTTTCCTGATGAATCGTTTGATGTTATCACAGCTTGTCAGTGCTTTTGGTATTTTGACCACCAAAAGATTATGCCTGAACTTTACAGAATGTTAAAGCCAAATGACAGGTTGTTA",
       "abbreviation": "oMT",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r12c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg12_16": {
     "functions": [
      {
       "description": "Wzy_C",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg12_17": {
     "functions": [
      {
       "description": "Bac_transf",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1146:sugar transferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg12_18": {
     "functions": []
    },
    "ctg12_19": {
     "functions": []
    },
    "ctg12_20": {
     "functions": []
    },
    "ctg12_21": {
     "functions": []
    },
    "ctg12_22": {
     "functions": [
      {
       "description": "NTP_transf_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg12_23": {
     "functions": []
    },
    "ctg12_24": {
     "functions": [
      {
       "description": "Stand_Alone_Lasso_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF05402",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg12_25": {
     "functions": [
      {
       "description": "SMCOG1299:chaperonin GroEL ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg12_26": {
     "functions": []
    },
    "ctg12_27": {
     "functions": [
      {
       "description": "Pkinase",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1030:serine/threonine protein kinase ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg12_28": {
     "functions": []
    },
    "ctg12_29": {
     "functions": []
    },
    "ctg12_30": {
     "functions": [
      {
       "description": "Pkinase",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1030:serine/threonine protein kinase ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg12_31": {
     "functions": []
    },
    "ctg12_32": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  }
 },
 "r24c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg24_3": {
     "functions": []
    },
    "ctg24_4": {
     "functions": []
    },
    "ctg24_5": {
     "functions": []
    },
    "ctg24_6": {
     "functions": []
    },
    "ctg24_7": {
     "functions": []
    },
    "ctg24_8": {
     "functions": []
    },
    "ctg24_9": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg24_10": {
     "functions": [
      {
       "description": "SMCOG1190:GTP-binding protein LepA ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg24_11": {
     "functions": [
      {
       "description": "Aminotran_1_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "DegT_DnrJ_EryC1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Aminotran_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg24_12": {
     "functions": []
    },
    "ctg24_13": {
     "functions": [
      {
       "description": "Ranthipeptide_rSAM_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF04055",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR04085",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Fer4_12",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg24_14": {
     "functions": []
    },
    "ctg24_15": {
     "functions": []
    },
    "ctg24_16": {
     "functions": []
    },
    "ctg24_17": {
     "functions": []
    },
    "ctg24_18": {
     "functions": []
    },
    "ctg24_19": {
     "functions": []
    },
    "ctg24_20": {
     "functions": [
      {
       "description": "SMCOG1288:ABC transporter related protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 },
 "r49c1": {
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "C",
        "description": "Condensation_LCL",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-condensation",
        "inactive": false,
        "start": 17,
        "terminalDocking": ""
       },
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 457,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 955,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Ile"
     },
     {
      "domains": [
       {
        "name": "C",
        "description": "Condensation_LCL",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-condensation",
        "inactive": false,
        "start": 1044,
        "terminalDocking": ""
       },
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 1479,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 1973,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "ctg49_3",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 2083,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg49_1": {
     "functions": []
    },
    "ctg49_2": {
     "functions": []
    },
    "ctg49_3": {
     "functions": [
      {
       "description": "Condensation",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "RmlD_sub_bind",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1127:condensation domain-containing protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg49_4": {
     "functions": [
      {
       "description": "SMCOG1086:MATE efflux family protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg49_5": {
     "functions": []
    },
    "ctg49_6": {
     "functions": []
    }
   }
  }
 },
 "r67c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg67_11": {
     "functions": [
      {
       "description": "SMCOG1058:ArsR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_12": {
     "functions": []
    },
    "ctg67_13": {
     "functions": [
      {
       "description": "SMCOG1086:MATE efflux family protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_14": {
     "functions": []
    },
    "ctg67_15": {
     "functions": []
    },
    "ctg67_16": {
     "functions": [
      {
       "description": "Glycos_transf_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg67_17": {
     "functions": []
    },
    "ctg67_18": {
     "functions": []
    },
    "ctg67_19": {
     "functions": [
      {
       "description": "SMCOG1190:GTP-binding protein LepA ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_20": {
     "functions": []
    },
    "ctg67_21": {
     "functions": []
    },
    "ctg67_22": {
     "functions": []
    },
    "ctg67_23": {
     "functions": []
    },
    "ctg67_24": {
     "functions": []
    },
    "ctg67_25": {
     "functions": [
      {
       "description": "SMCOG1275:peptide deformylase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_26": {
     "functions": []
    },
    "ctg67_27": {
     "functions": [
      {
       "description": "SMCOG1171:transcriptional regulator, MerR family ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_28": {
     "functions": []
    },
    "ctg67_29": {
     "functions": []
    },
    "ctg67_30": {
     "functions": []
    },
    "ctg67_31": {
     "functions": [
      {
       "description": "SMCOG1270:UDP-3-O-[3-hydroxymyristoyl] N-acetylglucosamine ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_32": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "adh_short_C2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_33": {
     "functions": [
      {
       "description": "t2fas",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "hr-t2pks-ksa",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_34": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg67_35": {
     "functions": [
      {
       "description": "SMCOG1141:acyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg67_36": {
     "functions": []
    },
    "ctg67_37": {
     "functions": []
    },
    "ctg67_38": {
     "functions": []
    },
    "ctg67_39": {
     "functions": []
    },
    "ctg67_40": {
     "functions": []
    },
    "ctg67_41": {
     "functions": []
    },
    "ctg67_42": {
     "functions": []
    },
    "ctg67_43": {
     "functions": []
    },
    "ctg67_44": {
     "functions": []
    },
    "ctg67_45": {
     "functions": []
    },
    "ctg67_46": {
     "functions": []
    },
    "ctg67_47": {
     "functions": []
    },
    "ctg67_48": {
     "functions": []
    },
    "ctg67_49": {
     "functions": []
    },
    "ctg67_50": {
     "functions": []
    },
    "ctg67_51": {
     "functions": []
    },
    "ctg67_52": {
     "functions": [
      {
       "description": "SMCOG1089:methyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 }
};
