var recordData = [
 {
  "length": 197417,
  "seq_id": "NZ_JAYBHY010000001.1",
  "regions": []
 },
 {
  "length": 59752,
  "seq_id": "NZ_JAYBHY010000002.1",
  "regions": []
 },
 {
  "length": 55599,
  "seq_id": "NZ_JAYBHY010000003.1",
  "regions": [
   {
    "start": 31061,
    "end": 52500,
    "idx": 1,
    "orfs": [
     {
      "start": 33702,
      "end": 34592,
      "strand": -1,
      "locus_tag": "ctg3_36",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,702 - 34,592,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATTCTTCCGCTAAAAATCTATTATTGGAAAAAGCACGCTCCCTCCTGCTGGACGCCGTAGGATGCATGTCCTGCCCTATCGCCCCCCAGCTTTCCGAAAAACTGGAAAAAGCGGGTCCCGTTCCTTTCGCGCCGGCAGAGATAGAAAAGCGGCTGGCGCCTGAAGAAATTCTCGCGGATACGAAGTCCATTGCTGTTATTCTCTTCCCTTACCGGTACCCCGAGGAAAAGAATGCAAATATCGCCCTTTATGCACGAGCCAAAGATTATCACCACGTTGTCCGCGCGTATCTTGCAAAAATTATCGGATATATGGAAGAGCAGTATCCCGATGAAAAGTTCCATGCTATTACCGACACATCCCCCATGGCAGACCGCTGGCTCGCTTACCAGGCAGGACTCGGTTTTTTCGGCAGGAACCACTGCCTCATCCATCCGAAGTACGGTTCTTACTTTACCATCGGAGCCATACTGACCACTTTGGCACTTCCTCCGGACACCCCGCTTGCAATGAACTGCGGCAGCTGCACCCGCTGCTTCGCGGCATGCCCCGGAAAAGCGCTTTCCCACGAACGGTTCAATCCGTGGCGATGCAAATCGTACCTCACGCAAAAGAAAGAAGTCTTAAATGAAGAAGAAAAAAATATTCTTCGTAAGACGCCGCTTATCTTCGGATGTGATGAGTGCCAGAAATGCTGTCCCTTTAATGAAAATGCAGCATACTCTCCCCTTCCGGAAACGGGTGCAGACCGGATCCCCCGTCTGGAAAGAGAAACACTGGAACAGATTTCAAACCGCCGATTTACAAAAGAATATGGAGAATATGCTTTTTCCTGGCGGGGCAGGCCCGTCTTACTCCGAAATATGGATATCATCGAAAAAAAATAA",
      "translation": "MNSSAKNLLLEKARSLLLDAVGCMSCPIAPQLSEKLEKAGPVPFAPAEIEKRLAPEEILADTKSIAVILFPYRYPEEKNANIALYARAKDYHHVVRAYLAKIIGYMEEQYPDEKFHAITDTSPMADRWLAYQAGLGFFGRNHCLIHPKYGSYFTIGAILTTLALPPDTPLAMNCGSCTRCFAACPGKALSHERFNPWRCKSYLTQKKEVLNEEEKNILRKTPLIFGCDECQKCCPFNENAAYSPLPETGADRIPRLERETLEQISNRRFTKEYGEYAFSWRGRPVLLRNMDIIEKK",
      "product": ""
     },
     {
      "start": 34635,
      "end": 35621,
      "strand": -1,
      "locus_tag": "ctg3_37",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,635 - 35,621,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGAATCCAGTTGGAAGTGAACGCGGAAATATTCACCACGATTTACAATCTGCTTTCCAATATGAGAAGTGAAGAAGGAATCCAACAGGAGGATGAAAAACGCCTTCTCCATTTATGGCGGAAAACGGTTCGCGCCATGGCCAAGGTGGAACTCCGCAAAGGTCATGGGATTTCTATGGAAAAACAGATTGAAATGCTCAAAGAGGCATATGCCATCGAAACGAAGTACACGGCAGACCAGCTTTTTTCTTCCGTGAGCTCCTCCAAACTGACAAAAGAAGAGTTGGAAGAAGTCCGACGTTTTTCCGCCGAAGAGATGAATACCCTTTTCAACTCGGTTATCTGGCCTGCCATGATAAAGGGCAAAACAGGGGCGCAGGAGAATCCGACAGCCTTCATTATCGCAGGCCAGCCAGGTTCCGGAAAGACACGGATGTCCTCCGTGATCATCGATGACTACGACGGCGACATTATCCAGTCCATGAGTGACAACTTCCGCGGGTTTCATCCCCGGGCAAAAGAAGTTTTTCAGAAATACGGACGCTATTGTACCTATTTTTCCACAAAGGAAGGGAAATATCTTTCTGACTTAGCCATGCGGAAAGCAGCAGAAGAGAAGTATCACATTCTCCAGGAAGGCTCTCTTGATGACTCCGCCCACACCATGGCGCTCATCAGTTATCTGAAAGAAAAAGGATATACTATCTGCGTACTTCTCCGTGCCTGCCCGAAGAAAGACAGCTGGAAAGCCATCCACCAGCTTTACCTGCAGCAGCGGTTAAAAGCGCCGGGCCTGTCCAGACTCATTTCAAAAGAACAGCATGATAAGGCCTGCCTCTCTTTCCTGTCAGCCACCAATGATTTGATTAACCAAAACTTCATGGACCGGCTCATTATCAAAAGTCCGAAAGGCCTTCTGTATGACAGCGATGATATGCCGACAGAGCGGGTAAGCGACGTCCTGTCCAAACGTATCGGCAAGTAA",
      "translation": "MGIQLEVNAEIFTTIYNLLSNMRSEEGIQQEDEKRLLHLWRKTVRAMAKVELRKGHGISMEKQIEMLKEAYAIETKYTADQLFSSVSSSKLTKEELEEVRRFSAEEMNTLFNSVIWPAMIKGKTGAQENPTAFIIAGQPGSGKTRMSSVIIDDYDGDIIQSMSDNFRGFHPRAKEVFQKYGRYCTYFSTKEGKYLSDLAMRKAAEEKYHILQEGSLDDSAHTMALISYLKEKGYTICVLLRACPKKDSWKAIHQLYLQQRLKAPGLSRLISKEQHDKACLSFLSATNDLINQNFMDRLIIKSPKGLLYDSDDMPTERVSDVLSKRIGK",
      "product": ""
     },
     {
      "start": 35744,
      "end": 36529,
      "strand": -1,
      "locus_tag": "ctg3_38",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,744 - 36,529,\n (total: 786 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACACAACGATTACACTGCCGGCGGGAGGGAAACTGCATGCATCACGTTCCCACCTTTGTCTGGCTTTTGAAAAAACACGTTTTTCCCTTTCCACTGCCATTTACGGCGGCGGTTTTAAAGAAATCAATTATGCAGTCAACCAGAAACTGGAAACCTTTTACCCATCGGAAGATCGATTTCCCGGAGGGTCTGTCCCTGAATTTTTACGTCTTTCCATTTTGGAAAACGGATATGATCCGGCAAAGGCCTGCGCCCTTCTTACAGCGGCAAAAATGGAATGGCGTTCCGTGAAAACATTTTCCCATAAGGAGCTTCTTCTTGACGCAGTTACTACGGGCGGTGCGGAAAAAACGGCGGCCCGCGCAGGTTCTCCGCCGCTCTATACAGAAAAAGACGGTCACTTCTTTCCTGTAGGTACGATCAATATCATGATCAGTCTGAATATTTCCCTTCCTTCCGCCATCATGACGCGGGCCATCATCACGATCACTGAAGGGAAGACGGCAGCCCTGCAGGATCTGGGTATCGCCGATGTGAATAACGGCCTGCCTGCTACTGGAACGGGAACGGACGGCATCACGCTCATCACCGATCCGGATGCCCCGCGTTATACGGACGCAGGCACTTTCTCCGTCCTCGGTTCGCTTCTCGCTTCCGCAGCGTATGAAACAGTCCGCGAATGTCTGGAGCTCTATGACAAGCCATGGAACCGGGATGATTCTCTCGCTACGCCGCCCGCCGTCGATTTGTCCCGCTTAAGGAATAAAGAATGCGGTCATTAG",
      "translation": "MDTTITLPAGGKLHASRSHLCLAFEKTRFSLSTAIYGGGFKEINYAVNQKLETFYPSEDRFPGGSVPEFLRLSILENGYDPAKACALLTAAKMEWRSVKTFSHKELLLDAVTTGGAEKTAARAGSPPLYTEKDGHFFPVGTINIMISLNISLPSAIMTRAIITITEGKTAALQDLGIADVNNGLPATGTGTDGITLITDPDAPRYTDAGTFSVLGSLLASAAYETVRECLELYDKPWNRDDSLATPPAVDLSRLRNKECGH",
      "product": ""
     },
     {
      "start": 36638,
      "end": 38020,
      "strand": 1,
      "locus_tag": "ctg3_39",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,638 - 38,020,\n (total: 1383 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTTATTGTGCCTTATATGGTGGTAGCTGCAGTTGCTATCCTGTTTTTTATTGTATGCCGGTTTATGGTGTACGGCATTGGCGGTAAATCGCGGCACGCCGGGGTGAAAGCGGAAGTGACCGCGAAAATTCCTGTGCGTCCCCGCCGTAAAAAGGTGCCGGTCCGGCAGGCAGTGCCTGAGACGACCGCGGAATTTCCTTTGAGGAAAAAATCGGCTGGTGCCGGAAAATCCGCCGGTGAGACTACACAGATTTTGCCTGTAAAGGAAATTATAAAAAAGGCTGATGCCGCTATGGGTGTTGATGGCGCTACCCGTGTTTTCGACCGGGGTGAACTGGAAAAGACGCTGCCGCCTGCTAAAATGCCTTCAGGAAAGGTATCTGCCTTTACCGCGGAGAAAGCTCCTGAGATTTTGGAAGGCGCACCGACACTCCAATCTCTGGAAGAACGGTTTGTCCGGCATTTCCTGAACCGGTACGGCGCGGTTTCTTCTGTCGTGGAACAGGATACAAGGATGGTAACGGGCCACTTAATCCGTAATATGGATATGGATCCTAAAGATATGGCAGACAGTCTGACACATATCATGGTACAGGAAGCGTTACAGAACGCCCAGCGTACGTATGTGCTGATGCCGAACGATACGGTTCTTTCCATGGTGACTGATGCATTTGCGGATGTGGCCAGGGGCCGCCGTTCCGAAACGAGGACAACCCTTGCCTATGATGCGCTGAAAGCGATGCCCCGCATGGAAGAAACACAATTCAATGCGTTGTCGCTCCTTCTTCTTTTTCACTATTCAAGAAATACGGATAATGTGGATATGGAAGCCTTCCGCAAGTATACAAGGAAGTACATTACTCCGTTTCTTAAAGAGCTGCCTGATGAATACAGCGGTTATCAGCAGATGGAATATATTCGCTGCGTGTCTTTGGAAAACAGGGAAATCTCTTTTGGCAGGGTGCTTCATGATTCATACCCTCTTATTTTTGCTTACCGCGGCGCCATGAAGAGCGAACTTTCTTCTGTGAAATCCGACTGGCCTGAAGATGCTCTTGTCCCCAGTCTGTACAATTCATACTATAAACCGGCGGTGGTGGATGATTCCCTCTTTGCGGATTTTTGTGCTGATATGGGGATTACCAAAGAGGAAGACAAGACTTACCTTCTGAAAGTTCTCCATTCCCGTCCGGTGGATTATGACAGAAAGGAATTATCATACATCCTGGAAAAGATTTCTCCCGACCTGGCAAGTATGCAGGAAGTATGGGACACCAGTCTGCTCCGCAGATCTTCGCTGACCCTTATGGGGATGTACATCGCCCGTGCCTGCATCAAGGCAACCATCGGCGAGGAATTTGACTTGTCCCATTGGATGTAA",
      "translation": "MFIVPYMVVAAVAILFFIVCRFMVYGIGGKSRHAGVKAEVTAKIPVRPRRKKVPVRQAVPETTAEFPLRKKSAGAGKSAGETTQILPVKEIIKKADAAMGVDGATRVFDRGELEKTLPPAKMPSGKVSAFTAEKAPEILEGAPTLQSLEERFVRHFLNRYGAVSSVVEQDTRMVTGHLIRNMDMDPKDMADSLTHIMVQEALQNAQRTYVLMPNDTVLSMVTDAFADVARGRRSETRTTLAYDALKAMPRMEETQFNALSLLLLFHYSRNTDNVDMEAFRKYTRKYITPFLKELPDEYSGYQQMEYIRCVSLENREISFGRVLHDSYPLIFAYRGAMKSELSSVKSDWPEDALVPSLYNSYYKPAVVDDSLFADFCADMGITKEEDKTYLLKVLHSRPVDYDRKELSYILEKISPDLASMQEVWDTSLLRRSSLTLMGMYIARACIKATIGEEFDLSHWM",
      "product": ""
     },
     {
      "start": 38136,
      "end": 38798,
      "strand": 1,
      "locus_tag": "ctg3_40",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,136 - 38,798,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGATATTTGATATTATAGGACCGGTCATGATCGGCCCTTCCAGCTCACATACGGCAGGCGCCGCGCGTATCGGAAAAATAGCACGGGAAATATTAAATGACGAACCGGTTTCAGCGGAGATTACGCTGTACGGTTCTTTTGCAACCACAGGAAAGGGGCACGGTACGGATAAGGCGCTCGTGGCGGGTCTTATGGGCTATGCCCCCGACAGCGGCACGATCCGTGATGCGATTACTACCGCGGAGGAACGGGGGCTTTCTGTTTCCTTTCAGGCATCTTCCCTGGATAAGGGACATCCCAATGTGGCGGAAATCAAAATGAAAGGGAAGAGTGGAAGAATGGCGACAGTGGTAGGGCGGTCTTTAGGCGGCGGCCGGGTCATGATTACGGGAATTGACGGGTTCCCTGTGGAAATCACGGGGGAGGAGTATACACTCCTCACAAATCATAATGACGTGCCCGGTATTGTTGCCGATGTAGGGAAGATTCTTGCAGAAGAACATGTAAATATTTCCAATATGCGTGTGTTCCGCAAAGGGAAAGGAACGGAAGCGGTGATGATCATCCATTCCGACCAAAAGGTTCCCGAATCTGTTATTTGCAGGATCAAAGAAGGAAATAAAAATATCAACAGTGTTATGACACTGGATATTATTTAA",
      "translation": "MGIFDIIGPVMIGPSSSHTAGAARIGKIAREILNDEPVSAEITLYGSFATTGKGHGTDKALVAGLMGYAPDSGTIRDAITTAEERGLSVSFQASSLDKGHPNVAEIKMKGKSGRMATVVGRSLGGGRVMITGIDGFPVEITGEEYTLLTNHNDVPGIVADVGKILAEEHVNISNMRVFRKGKGTEAVMIIHSDQKVPESVICRIKEGNKNINSVMTLDII",
      "product": ""
     },
     {
      "start": 38810,
      "end": 39697,
      "strand": 1,
      "locus_tag": "ctg3_41",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,810 - 39,697,\n (total: 888 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAACATATCATTCCGTAAAGGAACTTTTTGCGCTGGCAGAAGAAAACCATTGCTCTCCCGGTGTTATTGCATGCCGGCTGGAGTCGGAAGAAAGCGGAAAAGACTTTGATGAAGTATGGGAAAAGATGAAAAAAACCATTCCCGTTTTCCGTCAGTCTATCCAGCGCGGACTGGCGGATACGAAAAAATCTGCCAGCGGACTTGTGGGCGGTGATGCCAATACCATTTTCATGCGGGAAAGCCGTTTTTTGAGTCCTGTATGCCGCCGTGCCTGTGCTTATGCTATAGCAACAGCGGAAGCAAATGCTAAAATGTTCCGTATCGTGGCGTGTCCGACAGCAGGATCCTGCGGGATTGTACCGGCTGTTTTGGCGGCAGTGGCGGAAGAAGAAAATTCTACTCTCAATGATGTGACCCGCGCGTTATTTACAGCGGGAGCCATCGGACGGATTACTGCGGAGAATGCTTCGATTTCGGGGGCAGTTGGCGGCTGCCAGGCGGAATGCGGCACAGCGGCGGCGATGGCTGCGGCTGCGGCAGTGGATTTACTCCATGGTACGACAGAGGAAATGGGGAACGCTATGGCGCTGGCGATGAAAAATATTTTGGGGCTTGCCTGTGATCCTGTGGCGGGTCTTGTGGAGGTTCCCTGCGTGAAAAGAAATGGATTCCATGCGGTACATGCCCTTGTGGCGGTGGAAATGGCAATGATGGGGATCCGTTCCGTCATCCCTCCTGATGATGTGATTGACGCTATGGGAAGAATCGGGCGCCTTATGCCTGTGTCCCTTCGTGAAACCAGCCTTGCAGGTCTTGCCATGACGGAAGAAGGAAAGCATATTTCCGAAAGACTGATGAAACAAAATGCTATGCCGGCAGAATAG",
      "translation": "MKTYHSVKELFALAEENHCSPGVIACRLESEESGKDFDEVWEKMKKTIPVFRQSIQRGLADTKKSASGLVGGDANTIFMRESRFLSPVCRRACAYAIATAEANAKMFRIVACPTAGSCGIVPAVLAAVAEEENSTLNDVTRALFTAGAIGRITAENASISGAVGGCQAECGTAAAMAAAAAVDLLHGTTEEMGNAMALAMKNILGLACDPVAGLVEVPCVKRNGFHAVHALVAVEMAMMGIRSVIPPDDVIDAMGRIGRLMPVSLRETSLAGLAMTEEGKHISERLMKQNAMPAE",
      "product": ""
     },
     {
      "start": 40060,
      "end": 40731,
      "strand": 1,
      "locus_tag": "ctg3_42",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,060 - 40,731,\n (total: 672 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCTTTTTTGACAGAAGTAATGAATCTGCCAGTCCGATTGGCCTTTTGCGGGCGCATATCGGCACGTTTATGTACTGCGTGAAAATGGGAAAAAAGAAATTTCAAAATAAAGAAGATGTAGGAGATATCTTTTTTGATATGGACCAGACGAAGTTTCTTTTGGATCAGGCGACACGAGGCTCACTTTATGATTTTCGACAGCGTATCGATTCTGCTCTTTGGGATGCTGCTGTCCATAAATATTCGGAAGATTTGGACAAGCTGAAAAAAGCGCTCTTGAAAGCAGTGGATCAAGGAGCAGCGAAAGCGGCGGATACTGCGGAAGAAGAACCGGAGGAAATTGTTCTCGAAAAGGAAGAAGAAAAATCGGGAAATTGGCGGGATCATATCCTTGATGAAATGAAGGAAGCGGAAGAAGCAGCGAAGAAGAAAGTGCCGTCAAAAGAAGAAAAAAGAGTAAAGACGGATGACTCTAAAGAGATGTCTGAATCCGATTGCCGGGAGCTGTGGAAACTCATTAAGGAGATGGATAAGGAATTCCGCGAAATGAAACAAATTGCTGATGAATGGCTCATGGTGAACGGGAGAAAAGACGGATGTTTAGGAGCAGTTCTTGCGGTAATGCTCCTGCCTGCGGGTGCCATTTACGGAATCTGGTCGCTTTTTTAA",
      "translation": "MGFFDRSNESASPIGLLRAHIGTFMYCVKMGKKKFQNKEDVGDIFFDMDQTKFLLDQATRGSLYDFRQRIDSALWDAAVHKYSEDLDKLKKALLKAVDQGAAKAADTAEEEPEEIVLEKEEEKSGNWRDHILDEMKEAEEAAKKKVPSKEEKRVKTDDSKEMSESDCRELWKLIKEMDKEFREMKQIADEWLMVNGRKDGCLGAVLAVMLLPAGAIYGIWSLF",
      "product": ""
     },
     {
      "start": 41061,
      "end": 42500,
      "strand": 1,
      "locus_tag": "ctg3_43",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,061 - 42,500,\n (total: 1440 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATTATAATGTAAAGCCCATGATTCATCGTTTCCGTCAAAATGATATGAATATCGTCATGGATGTGAACAGCGGCATTGTCCATGTCGTTGATGATGTGACATACAGGGTTCTGGAGTTTTATAAAGGAGAGGGCAGAGAAGAAACTTTGTCCGCTCTCGAAAAAGAATACGGCGCTGAAGAGCTGAATGAAGTCATGGATGATTTGGATGAACTCATCGGGGCTCAGTCTCTTTATGCGCCCATGGATAAGAATTATGAAATGGCGATCGAAGATAAACCGATTGTCAAGGCGCTGTGTATCAATATCGCCCACGACTGCAATCTCCGCTGCAAGTACTGCTTTGCCGGACAGGGAGGATATGGACAGTGGCGTATGCTCATGAGCTTCGATGTGGCGCGCCGGGCTGTTGATTTCCTCATCGCCCACAGCGGACACCGTGAACATTGCGAGCTGGACTTTTTCGGCGGTGAACCGCTCATGAACTGGCATGTGGTGCAGCAGACGGTGACCTATGTTCGCCAGCAGGAGAAGAAACACGATAAAAAAATCAAGATGTCTCTTACGACGAACGGAATGCTTCTGGATAAGGAGAAGGTGAAGTATCTGACGGATAACCATATTAGCCTGATCCTGTCACTGGACGGCCGTAAGGAAATGCATGACTCCATGCGTCCCGGTGTGAATAATGAAGGTACTTATGACCGCATTATGAAAAATCTCCAGTACTGCATCAAGCATCGCAATGGAGAAGAATACTATGTCCGTGGTACTTTCACCAGGCAGAATCTGGATTTCACTACTGATGTGGAAGATATGCTCAATCATGGATTTCCCGCGGTTTCTATGGAACCGGTTGTCGGCGATGACACGGCGGATTATTCCATCAAAGAGTCGGATCTGCCTCGGGTGAAGGATGAATATGATAAATTGGCGAAGTTTTTCATCAAGCGTGAAGAGGAAGGAAATCCCTTTTTTTTCTTCCATTTCAATATGGATCTTTGGAGAGGCCCCTGCCTGCCGAAGCGTCTTCGCGGATGTGGAGCGGGGCATGAATATCTGGCGGTCGTGCCCAATGGAGATATTTACCCGTGCCACCAGTTTGTTGGTCGTGAAGGATATGTGATCGGCAATGTTTTTGAGGGACTCAAGAACATGAAGATGATGCGCGATTTCCGTGTGAACCATGTGTTCAGCAAGCCTGAATGTGTGGACTGCTGGGCGAAATTTTTCTGCTCCGGCGGCTGCCATGCAAATAATGAAGCTTATGCCGGCGATATCCATAAGCCTTACGGGATTACCTGTGAAATTCAAAAGAAGCGTGTGGAATGTGCCATGATGATTCAGGCATATAATAAGTTGAAAGCTCCGAAAGTCATGCACCAGCCGGGAACAAAAGCGGCGAGGAAGGCGGAAGGCTTATCCTCCGGTACCTGA",
      "translation": "MDYNVKPMIHRFRQNDMNIVMDVNSGIVHVVDDVTYRVLEFYKGEGREETLSALEKEYGAEELNEVMDDLDELIGAQSLYAPMDKNYEMAIEDKPIVKALCINIAHDCNLRCKYCFAGQGGYGQWRMLMSFDVARRAVDFLIAHSGHREHCELDFFGGEPLMNWHVVQQTVTYVRQQEKKHDKKIKMSLTTNGMLLDKEKVKYLTDNHISLILSLDGRKEMHDSMRPGVNNEGTYDRIMKNLQYCIKHRNGEEYYVRGTFTRQNLDFTTDVEDMLNHGFPAVSMEPVVGDDTADYSIKESDLPRVKDEYDKLAKFFIKREEEGNPFFFFHFNMDLWRGPCLPKRLRGCGAGHEYLAVVPNGDIYPCHQFVGREGYVIGNVFEGLKNMKMMRDFRVNHVFSKPECVDCWAKFFCSGGCHANNEAYAGDIHKPYGITCEIQKKRVECAMMIQAYNKLKAPKVMHQPGTKAARKAEGLSSGT",
      "product": ""
     },
     {
      "start": 42652,
      "end": 43098,
      "strand": 1,
      "locus_tag": "ctg3_44",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,652 - 43,098,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCATATAAAAAGAGTTGGAGTCGCCCTTATGGCGGCTGCCATGATTGGTACAGGTGTGTTTTCCGGGGTTTCTGCATCTGGATTGGGCAGTATTCTCGGCGGTATTGTGAAAGTAGGCGGTATAGGGTTCCTTGTGGATAAGTATGGTGAATCGCTGAACAGTGCCATCAATTCTGTTATGATGAAAGAAGGCGCGGGTACGAACTATGCCACAAAGGTTGTTCCTATCGTCAGCATTGGTAACAGAGGATATATCGGAGCAGCGCAGGTTATCGGCGATGCGGACCAGGTGGAAAAGGTGGAAGCGGTAGGCCAGCTTGAAATCAGCTGGAATAACAAGCTTTTCCGCATCAAAGGCTTAATCCCAATGGACAGTAAGAATCCGATGAGTTTCAGTCGTGTACAGGGTGTAGGTGTTTCCGCCGTTATTGATGTAAGAGTTTAA",
      "translation": "MHIKRVGVALMAAAMIGTGVFSGVSASGLGSILGGIVKVGGIGFLVDKYGESLNSAINSVMMKEGAGTNYATKVVPIVSIGNRGYIGAAQVIGDADQVEKVEAVGQLEISWNNKLFRIKGLIPMDSKNPMSFSRVQGVGVSAVIDVRV",
      "product": ""
     },
     {
      "start": 43113,
      "end": 44309,
      "strand": 1,
      "locus_tag": "ctg3_45",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,113 - 44,309,\n (total: 1197 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAATCTATTCTTGCAGCAGGTATTTCTTTGTTGCTTGTATTTCCGGGAGCAGCAGCTGAACCAACGACCCTAAACGGACGTATGGAACGGGTGGAAGATGTCCTTTATGGGGAAACGCGCAGCGGCTCCCTTACCGAACGGATTACTTCCGCCGATAATTTAATTTATGGCACAGGCAGTTCGACAGGCGTGGGGCTTGATGACCGGGTCGGGAATCTTTATGCTGATGTGGTAAACAGCGGTAATGATGCTGCACCGTCCATCTCTTCCCGGACGAATGCCCTGGAGTACTACCTGACTGATGAAATTAAGCGGGAACCGCTTGCCGGCCGTATCGGTGATATGGAAAAAAGCGTTTTCGGCAGCGTGAAATCAGGCGCATTGGATAAGCGTACCGCGGAATTGGAAAAAGCTATTTATGGAGATCAACATTCGGAAATGAAGGATGTTGTTCTTCCTGAAAAGACGGTATTCAAGATTTCTTTAAATGATAATATCAGCAGCAAAACAAACCTTGTGGGTGACCCTGTAGAATTTACCGTGCAGGAAGATGTGAAGGTCGGTGACATTCTTGTGCTGCCCCGCGGTTCCAGAGGAAGCGGCGTGGTGACGAAAGTATCCCGGCCGAAGAGCTTTGGACGCAGCGGTAAACTGGATATTTCATTTGATCAGGTATTTTCTTTGGATGATGAACCGATTCCGACCGTTCTCGGACCAGAAGCAAAAGATAAGCTGAAGATGGAAGCTGCTGCTGTAGGCGCTTCTACTATCGGCGCATTGGCGCTGGGGCCGGTCGGCCTGGTAGGCGGTTTTTTTGTTAAAGGCAAAGATGTGGAACTTCCTGCAGGATCTGAATTGTATATACAAACGCAGAAAGATGTTACCACGAAAGGTCTTGTTACCGCTTCCGGCGCACCGAACATGGTACTTCGCAAGAGAGTGGCCAAGTCGGCTGTTGCGGGAGAAGTAGGGAATAAAGTGGCTTCTGATACCGGTTCTACTGTGAATACTGTGGAAAATATGCGGAATGAGTTGAAGTTTGTTAATGAGGATGGAAATGAAATAGATACCACTACGAAAACAGTAAAATCCGGTGCGGAAGAAACAAAAACGGAGGTTTCAGAGGCAGCGGAAAAGGTTGCTGATGAAGGAGAAGAAAATGCATCGGTGGTTATTGTAAGAAATGAATAA",
      "translation": "MKKSILAAGISLLLVFPGAAAEPTTLNGRMERVEDVLYGETRSGSLTERITSADNLIYGTGSSTGVGLDDRVGNLYADVVNSGNDAAPSISSRTNALEYYLTDEIKREPLAGRIGDMEKSVFGSVKSGALDKRTAELEKAIYGDQHSEMKDVVLPEKTVFKISLNDNISSKTNLVGDPVEFTVQEDVKVGDILVLPRGSRGSGVVTKVSRPKSFGRSGKLDISFDQVFSLDDEPIPTVLGPEAKDKLKMEAAAVGASTIGALALGPVGLVGGFFVKGKDVELPAGSELYIQTQKDVTTKGLVTASGAPNMVLRKRVAKSAVAGEVGNKVASDTGSTVNTVENMRNELKFVNEDGNEIDTTTKTVKSGAEETKTEVSEAAEKVADEGEENASVVIVRNE",
      "product": ""
     },
     {
      "start": 44302,
      "end": 45951,
      "strand": 1,
      "locus_tag": "ctg3_46",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 44,302 - 45,951,\n (total: 1650 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATAAATCGAGACTAAAGAGAGCATTGATTTTAGGATGTGTTCTTTTCCTGGGAACAATTCCGGAAGGATATGCTTTGGCGGTGGATGGTATAACTTATGAAGAAGGGTTCGTTGTTGATGAAGAGCATAAAGGTATAGTACGTCCGGTTCGCCCCGCGGAAGTTTTTATGAGACGAAGCAATGCGGAAATAAAGGAATCGGCAAAATCCGGTACTCTGTCTTTGGAAGCTAAAAAAGGAAAAAAGGGAGGAGAGGATACGGGAATTTCTCCCGAACATCCTTTAACTTTTACTGCGGACTATATCCGTTATAACCATTCTACAGGGGATGTCATGGCAGAAGGGCGTATTGATATGCGCCAGATGATGGATCAGTACACCACAGAGTATGTCTATGGAAACACGGTCACCCAGCAGTATGTTATTCCGGGTGCGGTACACTGGAAAAACGCTACTACCGATATGACGGCACAGCGGGCGGAATATGATGGTGCCGCATCCATAGGAAAGTTCTATGACTTTTCAGGCTGGGATTCAGGCCTTTACTATTTTAAAGGGGATAAAGGGACTTATTATCGTAAGGACAATAAAATGGTCGCGGATAGAGGCTACTTCACGACGAAGCATGCTGTTGCCAAAGTACCTGACTATCGGATTGAAGCAGATACCATCGAAATTTATCCGGGAGATCATTACACGGCTTATGATGTGAAATTAAAAGTGAAGAATACAACCCTTATTTCTTTTCCCAAGTACAGGGCTTCTTTGAAAAATGATAATGCGATCAGCCCGTGGTCGCTCCTTCCCCGCCCGAAGTATGACAGCGATAACGGATGGGGATGGCATAATGGGCTTGAATTACCTGTAGCGCATAATGACGATCTGTATTTTTATATCCGCAATGAATGGTACACGAAATCAGGATACAAGCCGGATGTCGGTTTTAGCTACAGCACACCTTTCGGGTGGTTCAATTTCCATTATGCTGAAAAAGAAAGTTCCATCAATGATGAGGGCGGTTTGTGGATTAAAAAGCGGCCGGCTCTTGAGTTTAAGTCTAATCGGTATTACCTGTTTAAATCGCCCTTCTATGCAGGTATAAACGGAGAAATCGGTTATTGGGATGAGGAAAGGGCAGGCGGTAACCGTAAGGGCAGTTATAAAGGCTTCGACGTGTATATTTCCGGTGATCCCGTAAAGCTGGGCAAGTTTCTGACTTTTAACTGGAGAGCAGGGTTTTCCAAAGATTACTACGGATACAAATACGAAGGGAACAATTTAAGGAAGAAGAGACTTTTTGATAGAAATGAGACACGTGAAAATAAATACTATTCCCTAGGACTTATGGGAAAATACAGAGCGGTTTCCGCATGGATTAATTATACAAACCGTTCAATTACAGGCTATACACCGTACCTTTATGATACCTTTAGTACGACGAAACCGCTCAATATGGGCTTCAGGATTGAACTGACGCCCAAAGATGCCATAAGCATTTCCTGGACGATTGATGTAAAAAATGGTGATGTGGATCATCGCTACTATACTTACTATCGGGATATGCACTCATTTTATAGCTGGATTCGGTATGATACGGTAGGGAAGAAGACAACATTTATGATTATGCCGAAAGATTTCAGATTCTGA",
      "translation": "MNKSRLKRALILGCVLFLGTIPEGYALAVDGITYEEGFVVDEEHKGIVRPVRPAEVFMRRSNAEIKESAKSGTLSLEAKKGKKGGEDTGISPEHPLTFTADYIRYNHSTGDVMAEGRIDMRQMMDQYTTEYVYGNTVTQQYVIPGAVHWKNATTDMTAQRAEYDGAASIGKFYDFSGWDSGLYYFKGDKGTYYRKDNKMVADRGYFTTKHAVAKVPDYRIEADTIEIYPGDHYTAYDVKLKVKNTTLISFPKYRASLKNDNAISPWSLLPRPKYDSDNGWGWHNGLELPVAHNDDLYFYIRNEWYTKSGYKPDVGFSYSTPFGWFNFHYAEKESSINDEGGLWIKKRPALEFKSNRYYLFKSPFYAGINGEIGYWDEERAGGNRKGSYKGFDVYISGDPVKLGKFLTFNWRAGFSKDYYGYKYEGNNLRKKRLFDRNETRENKYYSLGLMGKYRAVSAWINYTNRSITGYTPYLYDTFSTTKPLNMGFRIELTPKDAISISWTIDVKNGDVDHRYYTYYRDMHSFYSWIRYDTVGKKTTFMIMPKDFRF",
      "product": ""
     },
     {
      "start": 45980,
      "end": 47371,
      "strand": 1,
      "locus_tag": "ctg3_47",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,980 - 47,371,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAATTCTCTTTAGGCAAGCATTTAAATGTCGATTTACAATATATTTTTGGCAGTAAATGGAATGTAAATGCGGAAGATCTGCAAAATTATGAAGCAGTTATTTCCAATGCGGCAAAGCGTGTACAACAGATAAGAAAAACGGGAAAAGGCCCGGGAGGCAAAGCGGTTCTTTTTTCCCGCCTTCCTTATATTTTAGATGAAAATGTTCTCATGACGGCAGAAGAGCGGCTGCGGTTGGAACGGCTGGACGGAATCGGGAAAGAACAGGATGTTCTGATTTCTATCGGGATAGGAGGATCTTATCTGGGAAATCAGGCGATTTTTGATATTTTTTATGGTCCGTACTGGAATATGCGTTCCCGCGGGGAAAGAAACGGGTACCCGCAGGTATTCTTTGCGGGACAGAATGCCGACCCGGCAGCGCTTATGGATCTCGTCCGCCAGCTTCGAAGGGAACGGGACCGCTGCGGCCGTAAATTGAGAGTGCTGCTCCTGATAATTTCCAAGTCGGGGACAACTGTGGAACCGATGGCGGCTTTCCATGTATTGAGACGGGAATTATCCGATTTTTGCGAGCTTTCTTTTATTACAGTCACTGACAGAAATACCGGTAAGCTCCATGAATTGGCCGAACGGGAAGGATGGGAACAGTTTGCCGTACCTGAAGGTATCGGCGGCCGTTTCAGTGTCTTTTCCCAAGTCGGTTTGGTCTGGGGGAAGTTGGTCGGTCTGGATATAAGGGCTTTTCTTGACGGTGCGAGATTTGTGGAAGAGCATTGCCGGGGGAAAATTTCGGATAACCCGGCACTTATGCTGGCTGCGGTCAAGTTTATCGCCATGAAAGAGTATGGAGCGGCAGCAGAGGTCATTATGCCTTATGGTGCAGGCCTCCGTGCGTTAGGCTGGTGGTATGCCCAGTTGCTGGGAGAGTCTTTGGGGAAAAAATTTGATACCCATGGGAATATCATTTACAACGGCCGCATTCCGGTTGCCTGTGTAGGCACGACAGATATGCATTCCCTTACGCAGGAACACCAGCAGGGGAAGAAGAATAAAATTGTACAGTTTATTTCCGTGAGAAATCTTCCCGATAAAGCGGATTTCTTTTGTGATGACGGCCGCGCAGGCGGAATGGTGGATTTGGGGATGCTGCTTAATGCCGCTGCCTGGTCTAATCAGGAGGCTCTGGCACAGGAAGAAAGGATGAGCTGTGCGATAGAAATTGAAAAGCTGACAGAATTCCATATAGGAATGCTGATGTACTTCTTTTTCCTTGCTACCGCCTATGAAGGCGCTATGGCGGATATCAATACATACGACCAGCCGGGGGTGGAGGATTACAAGAAAATCCTCCGCAAGTATTTACAAAAATATATGAAAGAGGCATGA",
      "translation": "MKFSLGKHLNVDLQYIFGSKWNVNAEDLQNYEAVISNAAKRVQQIRKTGKGPGGKAVLFSRLPYILDENVLMTAEERLRLERLDGIGKEQDVLISIGIGGSYLGNQAIFDIFYGPYWNMRSRGERNGYPQVFFAGQNADPAALMDLVRQLRRERDRCGRKLRVLLLIISKSGTTVEPMAAFHVLRRELSDFCELSFITVTDRNTGKLHELAEREGWEQFAVPEGIGGRFSVFSQVGLVWGKLVGLDIRAFLDGARFVEEHCRGKISDNPALMLAAVKFIAMKEYGAAAEVIMPYGAGLRALGWWYAQLLGESLGKKFDTHGNIIYNGRIPVACVGTTDMHSLTQEHQQGKKNKIVQFISVRNLPDKADFFCDDGRAGGMVDLGMLLNAAAWSNQEALAQEERMSCAIEIEKLTEFHIGMLMYFFFLATAYEGAMADINTYDQPGVEDYKKILRKYLQKYMKEA",
      "product": ""
     },
     {
      "start": 47376,
      "end": 47885,
      "strand": 1,
      "locus_tag": "ctg3_48",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,376 - 47,885,\n (total: 510 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGGGGGCGCGCAGGAGATGGATAGTCCCGGTGACAGGGGCAGTGGCGGCCGTTTTAACGGTGTGGGGCATTCTTGGTGTCGGTAAAGCGTCAACCGTTATTCCTGAAGAGGCAAACGGTACAACTCCTGCTGCTGTAAATGAAAGTGAAATGAAATTTGGAAAAATATCGGGCGGCGTTAAAAAATATGACGCGGCTCTTTATTTGCGGGGAAAACCGTTGAAAGATCCGTTTTATGCGGTGCGGTCTTATGATTCAAAGAGGGAGAATGAAGAAGCGCCGCAGATGCCGGCAGCAGAAGGGACAACGGGGACTATCCATCTCGCCCCGGTTTTACAGGGAGTCATGGAGTATGGAGGGAACCGGCGGGCCATGCTTGCCGTGAATGGAGAATCAGTTACAGTTCGGAAAGGGGATCGGGTGGGTATATGGTCAGTCGTTTCAATCGGAGAAAAAACAGTCCAGTTATCATCGGCAGCAGGAAATCTTTTTTTGGAACTGCCTTGA",
      "translation": "MEGARRRWIVPVTGAVAAVLTVWGILGVGKASTVIPEEANGTTPAAVNESEMKFGKISGGVKKYDAALYLRGKPLKDPFYAVRSYDSKRENEEAPQMPAAEGTTGTIHLAPVLQGVMEYGGNRRAMLAVNGESVTVRKGDRVGIWSVVSIGEKTVQLSSAAGNLFLELP",
      "product": ""
     },
     {
      "start": 47957,
      "end": 49306,
      "strand": 1,
      "locus_tag": "ctg3_49",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,957 - 49,306,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGGAGATGAAACTGGAAACGAGTGCTCACGAAACGATGGAAGCGACACTCCGCCAATCCATGGAAGGACGAAAAGAGGAAAAGGCAAAAAGTTATTTAACGAAACATGCTGTTACGGAAGAAAAAGAACCTTCCGATTTCAGTCTTCATGTAAAGAATGCGCCTATCCAGGAGGTCCTCCGGAGTCTGGCGGAACTTACAGGGAAAAATATTGTCTTCGGCGGTACAGTTACAGGAAGTGTGACGGCTGATCTGGATCACGTCACGCCGAAAGAAGCGCTCCATGCCATGCTGGTTTCCCAGGGGCTCATAGCGCGGGAAGAAGGAAGCATGCTTATCGTCGTTGGTGAATCCGCCATGAAAAATGGGGGAAGAGCAACGAAATCCTATAAATTGTCTTATGCGGAAGCAAAAGAAGTGGCGGAAGGGCTTCGCCAGCTTTCCGACAGTGTCCATGTAGCATATAACCAGACGGCAAACGCGGTCATTCTGAGCGGAACACCTTTGGAAATCATGGAAACCGCTGCGGTTCTCCGCTCTCTTGATGTTCCTGAAAAACAGGTAAAAGTAGAGGCGGAAGTTATTGCCGTGAACCGATCCCATTCCAAAGAACTTGGGATCGACTGGGATTTTAAATCTCTTACCGGCAGCGGCGAGTATCACAGGGAAAGCTGGAGTGAACAGCGGTATGTCACCGATGATGCGGGAAATATAAAGTATGATAAAAATGGAAATCCGCGGATGCGGAATATCGAACATAACGGATGGAATGTGAAGATTCCTGAAGGCTACGCAGGTATTTCCTACGGCAGATCCGTGGCAGGGCATCCCTACACCGCTTTTTTCAGGGCTAACCTGAATGCTCTTGTTTCTACAGGCAAAGCGAGAATCCTTGCCCGGCCGAATGTGGTCACCATGAACGGGCGGGAAGCGGAAATACTTATAGGAAATAAAATTCCGGTTATCGTGGAGCACGTGGATAACGGCGTTCGGACAACGACCACGGAATACCGCGACGCAGGCATCAAGCTTACCTACACGCCCCGAATCAGTGCGGACGGGGAAATCACCGCAAATGTGAATGCTGAGGTTTCCACGCCGTACCTTGTGCCTGAAATGCGGGCTTACCGTATCATTACCCGCCAGGCAAATACGCTGGTCCGTCTCCGGTCGGGCGATATGCTTACTATCGGGGGTCTGATAGATAAGGAAGAAAATAAAACCTTTAGGAAAGTTCCTATTCTGGGAGATATCCCCTTACTGGGGAAACTTTTCCAGAGCAAGAGCCGATCCGTGGAGGAGTCGGAAATAGTCATCATCATAAAAGCGGAAATACTGGACAGATGA",
      "translation": "MPEMKLETSAHETMEATLRQSMEGRKEEKAKSYLTKHAVTEEKEPSDFSLHVKNAPIQEVLRSLAELTGKNIVFGGTVTGSVTADLDHVTPKEALHAMLVSQGLIAREEGSMLIVVGESAMKNGGRATKSYKLSYAEAKEVAEGLRQLSDSVHVAYNQTANAVILSGTPLEIMETAAVLRSLDVPEKQVKVEAEVIAVNRSHSKELGIDWDFKSLTGSGEYHRESWSEQRYVTDDAGNIKYDKNGNPRMRNIEHNGWNVKIPEGYAGISYGRSVAGHPYTAFFRANLNALVSTGKARILARPNVVTMNGREAEILIGNKIPVIVEHVDNGVRTTTTEYRDAGIKLTYTPRISADGEITANVNAEVSTPYLVPEMRAYRIITRQANTLVRLRSGDMLTIGGLIDKEENKTFRKVPILGDIPLLGKLFQSKSRSVEESEIVIIIKAEILDR",
      "product": ""
     },
     {
      "start": 49335,
      "end": 51218,
      "strand": 1,
      "locus_tag": "ctg3_50",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,335 - 51,218,\n (total: 1884 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 117.1; E-value: 1.7e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAVLRVNGLTKYFGINSVFENVSFELKSGEHIGLVGANGAGKTTLLKCIMGREEADRGTIKASDGAVIGYLRQDFDYAGETIRDEMEEAWKDVLFYKDRMERLAAELEFHKDDADLVLEYGKTEARFEFLGGYDYESATKKILTGLGFTEEDWDRDIHSFSGGQKVRINLAAAFVRHPDFLLLDEPTNHLDMGMLEWLEDYLRSYKGGVLMISHDRYFLDAAATGIIDLENHRIHSYRGGYTRYMDTKTQETAAYEKAYEKQQEHIHETEEYIRRYKAGIKSKQARGRQSQLNRLERLEKSNRQATLRFHFTPPDDCADKVLDILHGTAGYNGTPLFKDIEMHIKKGETVGLIGPNGAGKTTLLKMITGELAGEKTLIHMGSHVQVGYYSQEQEWLSPDRTVIDEVRDLFNYGEAEARNVLGMFLFRGEDVFKKISLLSGGEKARLSLLCLFLKRPNFLILDEPTNHLDIPTREIMEEAIQAFGGTCLIVSHDRYFLDKVVTRTLELDNGRLTEYLGNYTYYKEKKKDLEEFEKDRGNAKTAKTPAKMTVSKAEPKKAEKKEISIAAAKKLEQVEMEIARQEATVKMYTFRMNSEPENYAALTEEYKAAEEKLAKLYERWDAIAEDM\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGTACTTAGAGTCAATGGTTTAACTAAATATTTCGGCATTAACAGCGTTTTTGAAAATGTTTCTTTCGAATTGAAAAGCGGCGAACATATTGGGCTTGTAGGGGCGAACGGCGCAGGGAAAACGACACTCCTGAAATGTATCATGGGAAGGGAAGAGGCTGACAGGGGAACGATAAAAGCCAGTGATGGTGCAGTAATCGGCTACCTTCGCCAAGATTTCGATTATGCCGGTGAAACGATACGTGATGAAATGGAAGAAGCATGGAAAGACGTTCTCTTTTATAAAGACAGAATGGAACGGCTGGCAGCCGAATTGGAATTTCATAAAGATGACGCTGATCTTGTTTTGGAATATGGAAAAACGGAAGCCCGTTTTGAATTTCTCGGCGGTTATGATTATGAATCTGCCACGAAAAAAATTTTAACGGGTCTCGGTTTTACGGAAGAGGACTGGGATCGGGATATTCATTCTTTTTCCGGCGGTCAGAAGGTCAGGATTAATTTGGCGGCTGCTTTCGTGCGTCATCCGGATTTCCTTCTTCTTGACGAACCGACAAACCATTTGGACATGGGCATGCTGGAATGGCTGGAGGATTATCTTCGCTCCTATAAAGGGGGCGTGCTTATGATTTCTCATGACCGTTATTTTCTTGATGCTGCGGCGACAGGCATTATCGATCTGGAGAATCACCGCATTCATTCTTACCGCGGCGGCTATACGCGGTATATGGATACGAAGACACAGGAAACGGCGGCTTATGAAAAAGCGTATGAAAAGCAGCAGGAGCATATCCATGAAACGGAAGAATATATAAGAAGATACAAAGCGGGGATCAAGTCAAAACAGGCACGGGGACGGCAGTCGCAGCTGAACCGCTTGGAACGGCTGGAAAAATCGAACAGGCAGGCCACACTTCGTTTTCATTTCACACCGCCTGATGACTGTGCGGATAAGGTTCTTGATATCCTTCATGGTACGGCAGGATATAATGGGACTCCTTTATTTAAAGATATAGAAATGCATATAAAAAAAGGGGAGACGGTAGGACTTATCGGACCGAACGGTGCGGGGAAGACGACCCTCCTGAAAATGATTACAGGAGAACTGGCGGGAGAGAAAACGCTTATCCATATGGGCAGCCATGTACAGGTGGGTTACTACTCCCAGGAGCAGGAGTGGCTTTCACCGGATCGAACCGTTATTGATGAGGTGCGGGATCTTTTCAATTATGGCGAAGCGGAAGCAAGAAATGTGCTGGGCATGTTCCTCTTTCGGGGAGAAGATGTTTTCAAAAAAATATCTCTTCTTTCCGGCGGTGAAAAGGCGAGGCTGTCCTTGTTATGTCTCTTTCTGAAACGGCCGAACTTTCTCATCCTTGATGAACCGACAAACCATCTGGATATTCCTACGAGGGAAATCATGGAAGAAGCCATACAGGCTTTTGGCGGAACCTGTCTGATCGTTTCCCATGACCGGTATTTTCTTGATAAAGTTGTGACGCGCACACTGGAACTGGACAATGGCAGGCTTACTGAGTACCTTGGCAACTACACTTACTATAAAGAAAAGAAAAAAGACCTGGAAGAATTTGAAAAGGACAGGGGAAATGCAAAGACGGCAAAGACGCCTGCCAAAATGACAGTATCCAAGGCGGAACCGAAAAAGGCAGAAAAGAAGGAAATTTCTATAGCGGCAGCAAAAAAGCTGGAGCAGGTGGAAATGGAAATTGCACGGCAGGAAGCAACCGTGAAAATGTACACTTTCCGTATGAACAGCGAGCCTGAAAATTATGCCGCCCTTACGGAAGAGTATAAGGCCGCGGAAGAAAAGCTGGCAAAACTTTATGAACGATGGGATGCCATCGCAGAAGATATGTAA",
      "translation": "MAVLRVNGLTKYFGINSVFENVSFELKSGEHIGLVGANGAGKTTLLKCIMGREEADRGTIKASDGAVIGYLRQDFDYAGETIRDEMEEAWKDVLFYKDRMERLAAELEFHKDDADLVLEYGKTEARFEFLGGYDYESATKKILTGLGFTEEDWDRDIHSFSGGQKVRINLAAAFVRHPDFLLLDEPTNHLDMGMLEWLEDYLRSYKGGVLMISHDRYFLDAAATGIIDLENHRIHSYRGGYTRYMDTKTQETAAYEKAYEKQQEHIHETEEYIRRYKAGIKSKQARGRQSQLNRLERLEKSNRQATLRFHFTPPDDCADKVLDILHGTAGYNGTPLFKDIEMHIKKGETVGLIGPNGAGKTTLLKMITGELAGEKTLIHMGSHVQVGYYSQEQEWLSPDRTVIDEVRDLFNYGEAEARNVLGMFLFRGEDVFKKISLLSGGEKARLSLLCLFLKRPNFLILDEPTNHLDIPTREIMEEAIQAFGGTCLIVSHDRYFLDKVVTRTLELDNGRLTEYLGNYTYYKEKKKDLEEFEKDRGNAKTAKTPAKMTVSKAEPKKAEKKEISIAAAKKLEQVEMEIARQEATVKMYTFRMNSEPENYAALTEEYKAAEEKLAKLYERWDAIAEDM",
      "product": ""
     },
     {
      "start": 51230,
      "end": 51592,
      "strand": 1,
      "locus_tag": "ctg3_51",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,230 - 51,592,\n (total: 363 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGATACGGCACTGGCGGCAGCCAAGGAAATGATTAAGACGATGGAAGGCTTAGCGGATAGTTTGCAGGAACGGGTGCGCAGAACGGAAGCGGAAAATGAAGCGCTTCGGAAAGAATTGGAAAAGTACCGTGAAGAACGGAAAATGACGGAAGAGGTTTTTCGGGGAGGCTCCGGTGAATTCAGCGGCTGTGATGACAGAAAGATATTAGAAGATTTAAGCGGGAAACTCAGCTGTTACTATCGGGATTTAGATCTTTATGACGAAAAGCGGATTACTGCTGAAGACGGGGAAACGCTCTATCACACGATAAAGTACATTTTCAAACAATTAAAAAAAGCAGGTGTCCGCTTTAAGTGA",
      "translation": "MKDTALAAAKEMIKTMEGLADSLQERVRRTEAENEALRKELEKYREERKMTEEVFRGGSGEFSGCDDRKILEDLSGKLSCYYRDLDLYDEKRITAEDGETLYHTIKYIFKQLKKAGVRFK",
      "product": ""
     },
     {
      "start": 51632,
      "end": 52447,
      "strand": -1,
      "locus_tag": "ctg3_52",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,632 - 52,447,\n (total: 816 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAATACAAATTCCTGACGACTTTGATCCGGAAAAAATCATACGGAGCGGACAATGTTTCCGTGCCTCCGCACAGCCCGACGGCTCCTTCCACTTCATCACAAGGAAAAACATGTTGTCTCTATCCCCGCTTGGAACGGATACCTGGGAAGCGGACTGCACCCCTTACGCATGGAAGCGGGTGTGGACTCCTTATTTTGATTTATCTGTTTCTTACAAGTCGCTTAGACGCTCCATTCCCGCAAAAGATCATTTTCTCAGGGCTGCGGCCGAATATGGAAAAGGTATCCGCATCTTGCGGCAGGATCCTTTTGAAATGCTCATCACCTTTATCATCTCCCAAAGGAAATCCATTCCCGCTATACGGAGTTCCGTGGAAAAACTTTGTCTTGCCGCAGGAAAGGAAATTACAAAAAATGGGCGAACTTTTTACACATTTCCCTCCCCGTCAGCGCTCGGGAAATTATCTGTCAATGAATTGAAAAACTGTTCTCTCGGGTACCGGGCCGCCTATATTCATGCCACAGCCCGCATGATTGCGAGAGAAAAGATCAGCTTCACCAAAATGGAAACATTGTCTGATAAGGAACTCACGGAAAAACTTCTTCTGTTTCCCGGAGCAGGCATCAAAGTGGTAAATTGTATTTCCCTATTCGCTTACCACCGCACGGCAGCCGCACCTGTAGATGTGTGGATCGGGCGGGTCATTCAGAAACATTATGGCGGAGTCAGCCCGTTCCCATCTTATGGCCATGCAGCAGGCATTTTTCAGCAGTATATGTTCTTCTACGCGCAGGCAAAGAAATTAAAATAG",
      "translation": "MKIQIPDDFDPEKIIRSGQCFRASAQPDGSFHFITRKNMLSLSPLGTDTWEADCTPYAWKRVWTPYFDLSVSYKSLRRSIPAKDHFLRAAAEYGKGIRILRQDPFEMLITFIISQRKSIPAIRSSVEKLCLAAGKEITKNGRTFYTFPSPSALGKLSVNELKNCSLGYRAAYIHATARMIAREKISFTKMETLSDKELTEKLLLFPGAGIKVVNCISLFAYHRTAAAPVDVWIGRVIQKHYGGVSPFPSYGHAAGIFQQYMFFYAQAKKLK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 41060,
      "end": 42500,
      "tool": "rule-based-clusters",
      "neighbouring_start": 31060,
      "neighbouring_end": 52500,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r3c1"
   }
  ]
 },
 {
  "length": 53120,
  "seq_id": "NZ_JAYBHY010000004.1",
  "regions": []
 },
 {
  "length": 46876,
  "seq_id": "NZ_JAYBHY010000005.1",
  "regions": []
 },
 {
  "length": 46134,
  "seq_id": "NZ_JAYBHY010000006.1",
  "regions": []
 },
 {
  "length": 45813,
  "seq_id": "NZ_JAYBHY010000007.1",
  "regions": []
 },
 {
  "length": 41578,
  "seq_id": "NZ_JAYBHY010000008.1",
  "regions": []
 },
 {
  "length": 33433,
  "seq_id": "NZ_JAYBHY010000009.1",
  "regions": []
 },
 {
  "length": 32223,
  "seq_id": "NZ_JAYBHY010000010.1",
  "regions": []
 },
 {
  "length": 30781,
  "seq_id": "NZ_JAYBHY010000011.1",
  "regions": []
 },
 {
  "length": 29232,
  "seq_id": "NZ_JAYBHY010000012.1",
  "regions": []
 },
 {
  "length": 28712,
  "seq_id": "NZ_JAYBHY010000013.1",
  "regions": []
 },
 {
  "length": 27600,
  "seq_id": "NZ_JAYBHY010000014.1",
  "regions": []
 },
 {
  "length": 25931,
  "seq_id": "NZ_JAYBHY010000015.1",
  "regions": []
 },
 {
  "length": 22996,
  "seq_id": "NZ_JAYBHY010000016.1",
  "regions": []
 },
 {
  "length": 22403,
  "seq_id": "NZ_JAYBHY010000017.1",
  "regions": []
 },
 {
  "length": 22149,
  "seq_id": "NZ_JAYBHY010000018.1",
  "regions": []
 },
 {
  "length": 22010,
  "seq_id": "NZ_JAYBHY010000019.1",
  "regions": []
 },
 {
  "length": 21975,
  "seq_id": "NZ_JAYBHY010000020.1",
  "regions": []
 },
 {
  "length": 21965,
  "seq_id": "NZ_JAYBHY010000021.1",
  "regions": []
 },
 {
  "length": 21556,
  "seq_id": "NZ_JAYBHY010000022.1",
  "regions": []
 },
 {
  "length": 21257,
  "seq_id": "NZ_JAYBHY010000023.1",
  "regions": []
 },
 {
  "length": 20277,
  "seq_id": "NZ_JAYBHY010000024.1",
  "regions": []
 },
 {
  "length": 20125,
  "seq_id": "NZ_JAYBHY010000025.1",
  "regions": []
 },
 {
  "length": 19598,
  "seq_id": "NZ_JAYBHY010000026.1",
  "regions": []
 },
 {
  "length": 19586,
  "seq_id": "NZ_JAYBHY010000027.1",
  "regions": []
 },
 {
  "length": 19418,
  "seq_id": "NZ_JAYBHY010000028.1",
  "regions": []
 },
 {
  "length": 18954,
  "seq_id": "NZ_JAYBHY010000029.1",
  "regions": []
 },
 {
  "length": 18792,
  "seq_id": "NZ_JAYBHY010000030.1",
  "regions": []
 },
 {
  "length": 18574,
  "seq_id": "NZ_JAYBHY010000031.1",
  "regions": []
 },
 {
  "length": 18042,
  "seq_id": "NZ_JAYBHY010000032.1",
  "regions": []
 },
 {
  "length": 17742,
  "seq_id": "NZ_JAYBHY010000033.1",
  "regions": []
 },
 {
  "length": 17579,
  "seq_id": "NZ_JAYBHY010000034.1",
  "regions": []
 },
 {
  "length": 17423,
  "seq_id": "NZ_JAYBHY010000035.1",
  "regions": []
 },
 {
  "length": 16536,
  "seq_id": "NZ_JAYBHY010000036.1",
  "regions": []
 },
 {
  "length": 16262,
  "seq_id": "NZ_JAYBHY010000037.1",
  "regions": []
 },
 {
  "length": 15980,
  "seq_id": "NZ_JAYBHY010000038.1",
  "regions": []
 },
 {
  "length": 15843,
  "seq_id": "NZ_JAYBHY010000039.1",
  "regions": []
 },
 {
  "length": 15462,
  "seq_id": "NZ_JAYBHY010000040.1",
  "regions": []
 },
 {
  "length": 15176,
  "seq_id": "NZ_JAYBHY010000041.1",
  "regions": []
 },
 {
  "length": 15150,
  "seq_id": "NZ_JAYBHY010000042.1",
  "regions": []
 },
 {
  "length": 14954,
  "seq_id": "NZ_JAYBHY010000043.1",
  "regions": []
 },
 {
  "length": 14694,
  "seq_id": "NZ_JAYBHY010000044.1",
  "regions": []
 },
 {
  "length": 14316,
  "seq_id": "NZ_JAYBHY010000045.1",
  "regions": []
 },
 {
  "length": 14267,
  "seq_id": "NZ_JAYBHY010000046.1",
  "regions": []
 },
 {
  "length": 14208,
  "seq_id": "NZ_JAYBHY010000047.1",
  "regions": []
 },
 {
  "length": 14002,
  "seq_id": "NZ_JAYBHY010000048.1",
  "regions": []
 },
 {
  "length": 13230,
  "seq_id": "NZ_JAYBHY010000049.1",
  "regions": []
 },
 {
  "length": 13059,
  "seq_id": "NZ_JAYBHY010000050.1",
  "regions": []
 },
 {
  "length": 13033,
  "seq_id": "NZ_JAYBHY010000051.1",
  "regions": []
 },
 {
  "length": 11918,
  "seq_id": "NZ_JAYBHY010000052.1",
  "regions": []
 },
 {
  "length": 11890,
  "seq_id": "NZ_JAYBHY010000053.1",
  "regions": []
 },
 {
  "length": 11713,
  "seq_id": "NZ_JAYBHY010000054.1",
  "regions": []
 },
 {
  "length": 10517,
  "seq_id": "NZ_JAYBHY010000055.1",
  "regions": []
 },
 {
  "length": 10073,
  "seq_id": "NZ_JAYBHY010000056.1",
  "regions": []
 },
 {
  "length": 10003,
  "seq_id": "NZ_JAYBHY010000057.1",
  "regions": []
 },
 {
  "length": 9871,
  "seq_id": "NZ_JAYBHY010000058.1",
  "regions": []
 },
 {
  "length": 9712,
  "seq_id": "NZ_JAYBHY010000059.1",
  "regions": []
 },
 {
  "length": 9303,
  "seq_id": "NZ_JAYBHY010000060.1",
  "regions": []
 },
 {
  "length": 8881,
  "seq_id": "NZ_JAYBHY010000061.1",
  "regions": []
 },
 {
  "length": 8775,
  "seq_id": "NZ_JAYBHY010000062.1",
  "regions": []
 },
 {
  "length": 8761,
  "seq_id": "NZ_JAYBHY010000063.1",
  "regions": []
 },
 {
  "length": 8416,
  "seq_id": "NZ_JAYBHY010000064.1",
  "regions": []
 },
 {
  "length": 8339,
  "seq_id": "NZ_JAYBHY010000065.1",
  "regions": []
 },
 {
  "length": 8295,
  "seq_id": "NZ_JAYBHY010000066.1",
  "regions": []
 },
 {
  "length": 8061,
  "seq_id": "NZ_JAYBHY010000067.1",
  "regions": []
 },
 {
  "length": 7823,
  "seq_id": "NZ_JAYBHY010000068.1",
  "regions": []
 },
 {
  "length": 7377,
  "seq_id": "NZ_JAYBHY010000069.1",
  "regions": []
 },
 {
  "length": 7206,
  "seq_id": "NZ_JAYBHY010000070.1",
  "regions": []
 },
 {
  "length": 6677,
  "seq_id": "NZ_JAYBHY010000071.1",
  "regions": []
 },
 {
  "length": 6571,
  "seq_id": "NZ_JAYBHY010000072.1",
  "regions": []
 },
 {
  "length": 5952,
  "seq_id": "NZ_JAYBHY010000073.1",
  "regions": []
 },
 {
  "length": 5897,
  "seq_id": "NZ_JAYBHY010000074.1",
  "regions": []
 },
 {
  "length": 5670,
  "seq_id": "NZ_JAYBHY010000075.1",
  "regions": []
 },
 {
  "length": 5573,
  "seq_id": "NZ_JAYBHY010000076.1",
  "regions": []
 },
 {
  "length": 5547,
  "seq_id": "NZ_JAYBHY010000077.1",
  "regions": []
 },
 {
  "length": 5512,
  "seq_id": "NZ_JAYBHY010000078.1",
  "regions": []
 },
 {
  "length": 5505,
  "seq_id": "NZ_JAYBHY010000079.1",
  "regions": []
 },
 {
  "length": 5139,
  "seq_id": "NZ_JAYBHY010000080.1",
  "regions": []
 },
 {
  "length": 5133,
  "seq_id": "NZ_JAYBHY010000081.1",
  "regions": []
 },
 {
  "length": 5047,
  "seq_id": "NZ_JAYBHY010000082.1",
  "regions": []
 },
 {
  "length": 5035,
  "seq_id": "NZ_JAYBHY010000083.1",
  "regions": []
 },
 {
  "length": 4945,
  "seq_id": "NZ_JAYBHY010000084.1",
  "regions": []
 },
 {
  "length": 4286,
  "seq_id": "NZ_JAYBHY010000085.1",
  "regions": []
 },
 {
  "length": 4177,
  "seq_id": "NZ_JAYBHY010000086.1",
  "regions": []
 },
 {
  "length": 4097,
  "seq_id": "NZ_JAYBHY010000087.1",
  "regions": []
 },
 {
  "length": 3537,
  "seq_id": "NZ_JAYBHY010000088.1",
  "regions": []
 },
 {
  "length": 3518,
  "seq_id": "NZ_JAYBHY010000089.1",
  "regions": []
 },
 {
  "length": 3444,
  "seq_id": "NZ_JAYBHY010000090.1",
  "regions": []
 },
 {
  "length": 3408,
  "seq_id": "NZ_JAYBHY010000091.1",
  "regions": []
 },
 {
  "length": 3305,
  "seq_id": "NZ_JAYBHY010000092.1",
  "regions": []
 },
 {
  "length": 3189,
  "seq_id": "NZ_JAYBHY010000093.1",
  "regions": []
 },
 {
  "length": 2919,
  "seq_id": "NZ_JAYBHY010000094.1",
  "regions": []
 },
 {
  "length": 2914,
  "seq_id": "NZ_JAYBHY010000095.1",
  "regions": []
 },
 {
  "length": 2861,
  "seq_id": "NZ_JAYBHY010000096.1",
  "regions": []
 },
 {
  "length": 2863,
  "seq_id": "NZ_JAYBHY010000097.1",
  "regions": []
 },
 {
  "length": 2842,
  "seq_id": "NZ_JAYBHY010000098.1",
  "regions": []
 },
 {
  "length": 2796,
  "seq_id": "NZ_JAYBHY010000099.1",
  "regions": []
 },
 {
  "length": 2738,
  "seq_id": "NZ_JAYBHY010000100.1",
  "regions": []
 },
 {
  "length": 2617,
  "seq_id": "NZ_JAYBHY010000101.1",
  "regions": []
 },
 {
  "length": 2616,
  "seq_id": "NZ_JAYBHY010000102.1",
  "regions": []
 },
 {
  "length": 2524,
  "seq_id": "NZ_JAYBHY010000103.1",
  "regions": []
 },
 {
  "length": 2386,
  "seq_id": "NZ_JAYBHY010000104.1",
  "regions": []
 },
 {
  "length": 2374,
  "seq_id": "NZ_JAYBHY010000105.1",
  "regions": []
 },
 {
  "length": 2354,
  "seq_id": "NZ_JAYBHY010000106.1",
  "regions": []
 },
 {
  "length": 2304,
  "seq_id": "NZ_JAYBHY010000107.1",
  "regions": []
 },
 {
  "length": 2031,
  "seq_id": "NZ_JAYBHY010000108.1",
  "regions": []
 },
 {
  "length": 2027,
  "seq_id": "NZ_JAYBHY010000109.1",
  "regions": []
 },
 {
  "length": 1999,
  "seq_id": "NZ_JAYBHY010000110.1",
  "regions": []
 },
 {
  "length": 1945,
  "seq_id": "NZ_JAYBHY010000111.1",
  "regions": []
 },
 {
  "length": 1686,
  "seq_id": "NZ_JAYBHY010000112.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r3c1"
 ],
 "r3c1": {
  "start": 31061,
  "end": 52500,
  "idx": 1,
  "orfs": [
   {
    "start": 33702,
    "end": 34592,
    "strand": -1,
    "locus_tag": "ctg3_36",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,702 - 34,592,\n (total: 891 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATTCTTCCGCTAAAAATCTATTATTGGAAAAAGCACGCTCCCTCCTGCTGGACGCCGTAGGATGCATGTCCTGCCCTATCGCCCCCCAGCTTTCCGAAAAACTGGAAAAAGCGGGTCCCGTTCCTTTCGCGCCGGCAGAGATAGAAAAGCGGCTGGCGCCTGAAGAAATTCTCGCGGATACGAAGTCCATTGCTGTTATTCTCTTCCCTTACCGGTACCCCGAGGAAAAGAATGCAAATATCGCCCTTTATGCACGAGCCAAAGATTATCACCACGTTGTCCGCGCGTATCTTGCAAAAATTATCGGATATATGGAAGAGCAGTATCCCGATGAAAAGTTCCATGCTATTACCGACACATCCCCCATGGCAGACCGCTGGCTCGCTTACCAGGCAGGACTCGGTTTTTTCGGCAGGAACCACTGCCTCATCCATCCGAAGTACGGTTCTTACTTTACCATCGGAGCCATACTGACCACTTTGGCACTTCCTCCGGACACCCCGCTTGCAATGAACTGCGGCAGCTGCACCCGCTGCTTCGCGGCATGCCCCGGAAAAGCGCTTTCCCACGAACGGTTCAATCCGTGGCGATGCAAATCGTACCTCACGCAAAAGAAAGAAGTCTTAAATGAAGAAGAAAAAAATATTCTTCGTAAGACGCCGCTTATCTTCGGATGTGATGAGTGCCAGAAATGCTGTCCCTTTAATGAAAATGCAGCATACTCTCCCCTTCCGGAAACGGGTGCAGACCGGATCCCCCGTCTGGAAAGAGAAACACTGGAACAGATTTCAAACCGCCGATTTACAAAAGAATATGGAGAATATGCTTTTTCCTGGCGGGGCAGGCCCGTCTTACTCCGAAATATGGATATCATCGAAAAAAAATAA",
    "translation": "MNSSAKNLLLEKARSLLLDAVGCMSCPIAPQLSEKLEKAGPVPFAPAEIEKRLAPEEILADTKSIAVILFPYRYPEEKNANIALYARAKDYHHVVRAYLAKIIGYMEEQYPDEKFHAITDTSPMADRWLAYQAGLGFFGRNHCLIHPKYGSYFTIGAILTTLALPPDTPLAMNCGSCTRCFAACPGKALSHERFNPWRCKSYLTQKKEVLNEEEKNILRKTPLIFGCDECQKCCPFNENAAYSPLPETGADRIPRLERETLEQISNRRFTKEYGEYAFSWRGRPVLLRNMDIIEKK",
    "product": ""
   },
   {
    "start": 34635,
    "end": 35621,
    "strand": -1,
    "locus_tag": "ctg3_37",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,635 - 35,621,\n (total: 987 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGAATCCAGTTGGAAGTGAACGCGGAAATATTCACCACGATTTACAATCTGCTTTCCAATATGAGAAGTGAAGAAGGAATCCAACAGGAGGATGAAAAACGCCTTCTCCATTTATGGCGGAAAACGGTTCGCGCCATGGCCAAGGTGGAACTCCGCAAAGGTCATGGGATTTCTATGGAAAAACAGATTGAAATGCTCAAAGAGGCATATGCCATCGAAACGAAGTACACGGCAGACCAGCTTTTTTCTTCCGTGAGCTCCTCCAAACTGACAAAAGAAGAGTTGGAAGAAGTCCGACGTTTTTCCGCCGAAGAGATGAATACCCTTTTCAACTCGGTTATCTGGCCTGCCATGATAAAGGGCAAAACAGGGGCGCAGGAGAATCCGACAGCCTTCATTATCGCAGGCCAGCCAGGTTCCGGAAAGACACGGATGTCCTCCGTGATCATCGATGACTACGACGGCGACATTATCCAGTCCATGAGTGACAACTTCCGCGGGTTTCATCCCCGGGCAAAAGAAGTTTTTCAGAAATACGGACGCTATTGTACCTATTTTTCCACAAAGGAAGGGAAATATCTTTCTGACTTAGCCATGCGGAAAGCAGCAGAAGAGAAGTATCACATTCTCCAGGAAGGCTCTCTTGATGACTCCGCCCACACCATGGCGCTCATCAGTTATCTGAAAGAAAAAGGATATACTATCTGCGTACTTCTCCGTGCCTGCCCGAAGAAAGACAGCTGGAAAGCCATCCACCAGCTTTACCTGCAGCAGCGGTTAAAAGCGCCGGGCCTGTCCAGACTCATTTCAAAAGAACAGCATGATAAGGCCTGCCTCTCTTTCCTGTCAGCCACCAATGATTTGATTAACCAAAACTTCATGGACCGGCTCATTATCAAAAGTCCGAAAGGCCTTCTGTATGACAGCGATGATATGCCGACAGAGCGGGTAAGCGACGTCCTGTCCAAACGTATCGGCAAGTAA",
    "translation": "MGIQLEVNAEIFTTIYNLLSNMRSEEGIQQEDEKRLLHLWRKTVRAMAKVELRKGHGISMEKQIEMLKEAYAIETKYTADQLFSSVSSSKLTKEELEEVRRFSAEEMNTLFNSVIWPAMIKGKTGAQENPTAFIIAGQPGSGKTRMSSVIIDDYDGDIIQSMSDNFRGFHPRAKEVFQKYGRYCTYFSTKEGKYLSDLAMRKAAEEKYHILQEGSLDDSAHTMALISYLKEKGYTICVLLRACPKKDSWKAIHQLYLQQRLKAPGLSRLISKEQHDKACLSFLSATNDLINQNFMDRLIIKSPKGLLYDSDDMPTERVSDVLSKRIGK",
    "product": ""
   },
   {
    "start": 35744,
    "end": 36529,
    "strand": -1,
    "locus_tag": "ctg3_38",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,744 - 36,529,\n (total: 786 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACACAACGATTACACTGCCGGCGGGAGGGAAACTGCATGCATCACGTTCCCACCTTTGTCTGGCTTTTGAAAAAACACGTTTTTCCCTTTCCACTGCCATTTACGGCGGCGGTTTTAAAGAAATCAATTATGCAGTCAACCAGAAACTGGAAACCTTTTACCCATCGGAAGATCGATTTCCCGGAGGGTCTGTCCCTGAATTTTTACGTCTTTCCATTTTGGAAAACGGATATGATCCGGCAAAGGCCTGCGCCCTTCTTACAGCGGCAAAAATGGAATGGCGTTCCGTGAAAACATTTTCCCATAAGGAGCTTCTTCTTGACGCAGTTACTACGGGCGGTGCGGAAAAAACGGCGGCCCGCGCAGGTTCTCCGCCGCTCTATACAGAAAAAGACGGTCACTTCTTTCCTGTAGGTACGATCAATATCATGATCAGTCTGAATATTTCCCTTCCTTCCGCCATCATGACGCGGGCCATCATCACGATCACTGAAGGGAAGACGGCAGCCCTGCAGGATCTGGGTATCGCCGATGTGAATAACGGCCTGCCTGCTACTGGAACGGGAACGGACGGCATCACGCTCATCACCGATCCGGATGCCCCGCGTTATACGGACGCAGGCACTTTCTCCGTCCTCGGTTCGCTTCTCGCTTCCGCAGCGTATGAAACAGTCCGCGAATGTCTGGAGCTCTATGACAAGCCATGGAACCGGGATGATTCTCTCGCTACGCCGCCCGCCGTCGATTTGTCCCGCTTAAGGAATAAAGAATGCGGTCATTAG",
    "translation": "MDTTITLPAGGKLHASRSHLCLAFEKTRFSLSTAIYGGGFKEINYAVNQKLETFYPSEDRFPGGSVPEFLRLSILENGYDPAKACALLTAAKMEWRSVKTFSHKELLLDAVTTGGAEKTAARAGSPPLYTEKDGHFFPVGTINIMISLNISLPSAIMTRAIITITEGKTAALQDLGIADVNNGLPATGTGTDGITLITDPDAPRYTDAGTFSVLGSLLASAAYETVRECLELYDKPWNRDDSLATPPAVDLSRLRNKECGH",
    "product": ""
   },
   {
    "start": 36638,
    "end": 38020,
    "strand": 1,
    "locus_tag": "ctg3_39",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,638 - 38,020,\n (total: 1383 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTTATTGTGCCTTATATGGTGGTAGCTGCAGTTGCTATCCTGTTTTTTATTGTATGCCGGTTTATGGTGTACGGCATTGGCGGTAAATCGCGGCACGCCGGGGTGAAAGCGGAAGTGACCGCGAAAATTCCTGTGCGTCCCCGCCGTAAAAAGGTGCCGGTCCGGCAGGCAGTGCCTGAGACGACCGCGGAATTTCCTTTGAGGAAAAAATCGGCTGGTGCCGGAAAATCCGCCGGTGAGACTACACAGATTTTGCCTGTAAAGGAAATTATAAAAAAGGCTGATGCCGCTATGGGTGTTGATGGCGCTACCCGTGTTTTCGACCGGGGTGAACTGGAAAAGACGCTGCCGCCTGCTAAAATGCCTTCAGGAAAGGTATCTGCCTTTACCGCGGAGAAAGCTCCTGAGATTTTGGAAGGCGCACCGACACTCCAATCTCTGGAAGAACGGTTTGTCCGGCATTTCCTGAACCGGTACGGCGCGGTTTCTTCTGTCGTGGAACAGGATACAAGGATGGTAACGGGCCACTTAATCCGTAATATGGATATGGATCCTAAAGATATGGCAGACAGTCTGACACATATCATGGTACAGGAAGCGTTACAGAACGCCCAGCGTACGTATGTGCTGATGCCGAACGATACGGTTCTTTCCATGGTGACTGATGCATTTGCGGATGTGGCCAGGGGCCGCCGTTCCGAAACGAGGACAACCCTTGCCTATGATGCGCTGAAAGCGATGCCCCGCATGGAAGAAACACAATTCAATGCGTTGTCGCTCCTTCTTCTTTTTCACTATTCAAGAAATACGGATAATGTGGATATGGAAGCCTTCCGCAAGTATACAAGGAAGTACATTACTCCGTTTCTTAAAGAGCTGCCTGATGAATACAGCGGTTATCAGCAGATGGAATATATTCGCTGCGTGTCTTTGGAAAACAGGGAAATCTCTTTTGGCAGGGTGCTTCATGATTCATACCCTCTTATTTTTGCTTACCGCGGCGCCATGAAGAGCGAACTTTCTTCTGTGAAATCCGACTGGCCTGAAGATGCTCTTGTCCCCAGTCTGTACAATTCATACTATAAACCGGCGGTGGTGGATGATTCCCTCTTTGCGGATTTTTGTGCTGATATGGGGATTACCAAAGAGGAAGACAAGACTTACCTTCTGAAAGTTCTCCATTCCCGTCCGGTGGATTATGACAGAAAGGAATTATCATACATCCTGGAAAAGATTTCTCCCGACCTGGCAAGTATGCAGGAAGTATGGGACACCAGTCTGCTCCGCAGATCTTCGCTGACCCTTATGGGGATGTACATCGCCCGTGCCTGCATCAAGGCAACCATCGGCGAGGAATTTGACTTGTCCCATTGGATGTAA",
    "translation": "MFIVPYMVVAAVAILFFIVCRFMVYGIGGKSRHAGVKAEVTAKIPVRPRRKKVPVRQAVPETTAEFPLRKKSAGAGKSAGETTQILPVKEIIKKADAAMGVDGATRVFDRGELEKTLPPAKMPSGKVSAFTAEKAPEILEGAPTLQSLEERFVRHFLNRYGAVSSVVEQDTRMVTGHLIRNMDMDPKDMADSLTHIMVQEALQNAQRTYVLMPNDTVLSMVTDAFADVARGRRSETRTTLAYDALKAMPRMEETQFNALSLLLLFHYSRNTDNVDMEAFRKYTRKYITPFLKELPDEYSGYQQMEYIRCVSLENREISFGRVLHDSYPLIFAYRGAMKSELSSVKSDWPEDALVPSLYNSYYKPAVVDDSLFADFCADMGITKEEDKTYLLKVLHSRPVDYDRKELSYILEKISPDLASMQEVWDTSLLRRSSLTLMGMYIARACIKATIGEEFDLSHWM",
    "product": ""
   },
   {
    "start": 38136,
    "end": 38798,
    "strand": 1,
    "locus_tag": "ctg3_40",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,136 - 38,798,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGATATTTGATATTATAGGACCGGTCATGATCGGCCCTTCCAGCTCACATACGGCAGGCGCCGCGCGTATCGGAAAAATAGCACGGGAAATATTAAATGACGAACCGGTTTCAGCGGAGATTACGCTGTACGGTTCTTTTGCAACCACAGGAAAGGGGCACGGTACGGATAAGGCGCTCGTGGCGGGTCTTATGGGCTATGCCCCCGACAGCGGCACGATCCGTGATGCGATTACTACCGCGGAGGAACGGGGGCTTTCTGTTTCCTTTCAGGCATCTTCCCTGGATAAGGGACATCCCAATGTGGCGGAAATCAAAATGAAAGGGAAGAGTGGAAGAATGGCGACAGTGGTAGGGCGGTCTTTAGGCGGCGGCCGGGTCATGATTACGGGAATTGACGGGTTCCCTGTGGAAATCACGGGGGAGGAGTATACACTCCTCACAAATCATAATGACGTGCCCGGTATTGTTGCCGATGTAGGGAAGATTCTTGCAGAAGAACATGTAAATATTTCCAATATGCGTGTGTTCCGCAAAGGGAAAGGAACGGAAGCGGTGATGATCATCCATTCCGACCAAAAGGTTCCCGAATCTGTTATTTGCAGGATCAAAGAAGGAAATAAAAATATCAACAGTGTTATGACACTGGATATTATTTAA",
    "translation": "MGIFDIIGPVMIGPSSSHTAGAARIGKIAREILNDEPVSAEITLYGSFATTGKGHGTDKALVAGLMGYAPDSGTIRDAITTAEERGLSVSFQASSLDKGHPNVAEIKMKGKSGRMATVVGRSLGGGRVMITGIDGFPVEITGEEYTLLTNHNDVPGIVADVGKILAEEHVNISNMRVFRKGKGTEAVMIIHSDQKVPESVICRIKEGNKNINSVMTLDII",
    "product": ""
   },
   {
    "start": 38810,
    "end": 39697,
    "strand": 1,
    "locus_tag": "ctg3_41",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,810 - 39,697,\n (total: 888 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAACATATCATTCCGTAAAGGAACTTTTTGCGCTGGCAGAAGAAAACCATTGCTCTCCCGGTGTTATTGCATGCCGGCTGGAGTCGGAAGAAAGCGGAAAAGACTTTGATGAAGTATGGGAAAAGATGAAAAAAACCATTCCCGTTTTCCGTCAGTCTATCCAGCGCGGACTGGCGGATACGAAAAAATCTGCCAGCGGACTTGTGGGCGGTGATGCCAATACCATTTTCATGCGGGAAAGCCGTTTTTTGAGTCCTGTATGCCGCCGTGCCTGTGCTTATGCTATAGCAACAGCGGAAGCAAATGCTAAAATGTTCCGTATCGTGGCGTGTCCGACAGCAGGATCCTGCGGGATTGTACCGGCTGTTTTGGCGGCAGTGGCGGAAGAAGAAAATTCTACTCTCAATGATGTGACCCGCGCGTTATTTACAGCGGGAGCCATCGGACGGATTACTGCGGAGAATGCTTCGATTTCGGGGGCAGTTGGCGGCTGCCAGGCGGAATGCGGCACAGCGGCGGCGATGGCTGCGGCTGCGGCAGTGGATTTACTCCATGGTACGACAGAGGAAATGGGGAACGCTATGGCGCTGGCGATGAAAAATATTTTGGGGCTTGCCTGTGATCCTGTGGCGGGTCTTGTGGAGGTTCCCTGCGTGAAAAGAAATGGATTCCATGCGGTACATGCCCTTGTGGCGGTGGAAATGGCAATGATGGGGATCCGTTCCGTCATCCCTCCTGATGATGTGATTGACGCTATGGGAAGAATCGGGCGCCTTATGCCTGTGTCCCTTCGTGAAACCAGCCTTGCAGGTCTTGCCATGACGGAAGAAGGAAAGCATATTTCCGAAAGACTGATGAAACAAAATGCTATGCCGGCAGAATAG",
    "translation": "MKTYHSVKELFALAEENHCSPGVIACRLESEESGKDFDEVWEKMKKTIPVFRQSIQRGLADTKKSASGLVGGDANTIFMRESRFLSPVCRRACAYAIATAEANAKMFRIVACPTAGSCGIVPAVLAAVAEEENSTLNDVTRALFTAGAIGRITAENASISGAVGGCQAECGTAAAMAAAAAVDLLHGTTEEMGNAMALAMKNILGLACDPVAGLVEVPCVKRNGFHAVHALVAVEMAMMGIRSVIPPDDVIDAMGRIGRLMPVSLRETSLAGLAMTEEGKHISERLMKQNAMPAE",
    "product": ""
   },
   {
    "start": 40060,
    "end": 40731,
    "strand": 1,
    "locus_tag": "ctg3_42",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,060 - 40,731,\n (total: 672 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCTTTTTTGACAGAAGTAATGAATCTGCCAGTCCGATTGGCCTTTTGCGGGCGCATATCGGCACGTTTATGTACTGCGTGAAAATGGGAAAAAAGAAATTTCAAAATAAAGAAGATGTAGGAGATATCTTTTTTGATATGGACCAGACGAAGTTTCTTTTGGATCAGGCGACACGAGGCTCACTTTATGATTTTCGACAGCGTATCGATTCTGCTCTTTGGGATGCTGCTGTCCATAAATATTCGGAAGATTTGGACAAGCTGAAAAAAGCGCTCTTGAAAGCAGTGGATCAAGGAGCAGCGAAAGCGGCGGATACTGCGGAAGAAGAACCGGAGGAAATTGTTCTCGAAAAGGAAGAAGAAAAATCGGGAAATTGGCGGGATCATATCCTTGATGAAATGAAGGAAGCGGAAGAAGCAGCGAAGAAGAAAGTGCCGTCAAAAGAAGAAAAAAGAGTAAAGACGGATGACTCTAAAGAGATGTCTGAATCCGATTGCCGGGAGCTGTGGAAACTCATTAAGGAGATGGATAAGGAATTCCGCGAAATGAAACAAATTGCTGATGAATGGCTCATGGTGAACGGGAGAAAAGACGGATGTTTAGGAGCAGTTCTTGCGGTAATGCTCCTGCCTGCGGGTGCCATTTACGGAATCTGGTCGCTTTTTTAA",
    "translation": "MGFFDRSNESASPIGLLRAHIGTFMYCVKMGKKKFQNKEDVGDIFFDMDQTKFLLDQATRGSLYDFRQRIDSALWDAAVHKYSEDLDKLKKALLKAVDQGAAKAADTAEEEPEEIVLEKEEEKSGNWRDHILDEMKEAEEAAKKKVPSKEEKRVKTDDSKEMSESDCRELWKLIKEMDKEFREMKQIADEWLMVNGRKDGCLGAVLAVMLLPAGAIYGIWSLF",
    "product": ""
   },
   {
    "start": 41061,
    "end": 42500,
    "strand": 1,
    "locus_tag": "ctg3_43",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,061 - 42,500,\n (total: 1440 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATTATAATGTAAAGCCCATGATTCATCGTTTCCGTCAAAATGATATGAATATCGTCATGGATGTGAACAGCGGCATTGTCCATGTCGTTGATGATGTGACATACAGGGTTCTGGAGTTTTATAAAGGAGAGGGCAGAGAAGAAACTTTGTCCGCTCTCGAAAAAGAATACGGCGCTGAAGAGCTGAATGAAGTCATGGATGATTTGGATGAACTCATCGGGGCTCAGTCTCTTTATGCGCCCATGGATAAGAATTATGAAATGGCGATCGAAGATAAACCGATTGTCAAGGCGCTGTGTATCAATATCGCCCACGACTGCAATCTCCGCTGCAAGTACTGCTTTGCCGGACAGGGAGGATATGGACAGTGGCGTATGCTCATGAGCTTCGATGTGGCGCGCCGGGCTGTTGATTTCCTCATCGCCCACAGCGGACACCGTGAACATTGCGAGCTGGACTTTTTCGGCGGTGAACCGCTCATGAACTGGCATGTGGTGCAGCAGACGGTGACCTATGTTCGCCAGCAGGAGAAGAAACACGATAAAAAAATCAAGATGTCTCTTACGACGAACGGAATGCTTCTGGATAAGGAGAAGGTGAAGTATCTGACGGATAACCATATTAGCCTGATCCTGTCACTGGACGGCCGTAAGGAAATGCATGACTCCATGCGTCCCGGTGTGAATAATGAAGGTACTTATGACCGCATTATGAAAAATCTCCAGTACTGCATCAAGCATCGCAATGGAGAAGAATACTATGTCCGTGGTACTTTCACCAGGCAGAATCTGGATTTCACTACTGATGTGGAAGATATGCTCAATCATGGATTTCCCGCGGTTTCTATGGAACCGGTTGTCGGCGATGACACGGCGGATTATTCCATCAAAGAGTCGGATCTGCCTCGGGTGAAGGATGAATATGATAAATTGGCGAAGTTTTTCATCAAGCGTGAAGAGGAAGGAAATCCCTTTTTTTTCTTCCATTTCAATATGGATCTTTGGAGAGGCCCCTGCCTGCCGAAGCGTCTTCGCGGATGTGGAGCGGGGCATGAATATCTGGCGGTCGTGCCCAATGGAGATATTTACCCGTGCCACCAGTTTGTTGGTCGTGAAGGATATGTGATCGGCAATGTTTTTGAGGGACTCAAGAACATGAAGATGATGCGCGATTTCCGTGTGAACCATGTGTTCAGCAAGCCTGAATGTGTGGACTGCTGGGCGAAATTTTTCTGCTCCGGCGGCTGCCATGCAAATAATGAAGCTTATGCCGGCGATATCCATAAGCCTTACGGGATTACCTGTGAAATTCAAAAGAAGCGTGTGGAATGTGCCATGATGATTCAGGCATATAATAAGTTGAAAGCTCCGAAAGTCATGCACCAGCCGGGAACAAAAGCGGCGAGGAAGGCGGAAGGCTTATCCTCCGGTACCTGA",
    "translation": "MDYNVKPMIHRFRQNDMNIVMDVNSGIVHVVDDVTYRVLEFYKGEGREETLSALEKEYGAEELNEVMDDLDELIGAQSLYAPMDKNYEMAIEDKPIVKALCINIAHDCNLRCKYCFAGQGGYGQWRMLMSFDVARRAVDFLIAHSGHREHCELDFFGGEPLMNWHVVQQTVTYVRQQEKKHDKKIKMSLTTNGMLLDKEKVKYLTDNHISLILSLDGRKEMHDSMRPGVNNEGTYDRIMKNLQYCIKHRNGEEYYVRGTFTRQNLDFTTDVEDMLNHGFPAVSMEPVVGDDTADYSIKESDLPRVKDEYDKLAKFFIKREEEGNPFFFFHFNMDLWRGPCLPKRLRGCGAGHEYLAVVPNGDIYPCHQFVGREGYVIGNVFEGLKNMKMMRDFRVNHVFSKPECVDCWAKFFCSGGCHANNEAYAGDIHKPYGITCEIQKKRVECAMMIQAYNKLKAPKVMHQPGTKAARKAEGLSSGT",
    "product": ""
   },
   {
    "start": 42652,
    "end": 43098,
    "strand": 1,
    "locus_tag": "ctg3_44",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,652 - 43,098,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCATATAAAAAGAGTTGGAGTCGCCCTTATGGCGGCTGCCATGATTGGTACAGGTGTGTTTTCCGGGGTTTCTGCATCTGGATTGGGCAGTATTCTCGGCGGTATTGTGAAAGTAGGCGGTATAGGGTTCCTTGTGGATAAGTATGGTGAATCGCTGAACAGTGCCATCAATTCTGTTATGATGAAAGAAGGCGCGGGTACGAACTATGCCACAAAGGTTGTTCCTATCGTCAGCATTGGTAACAGAGGATATATCGGAGCAGCGCAGGTTATCGGCGATGCGGACCAGGTGGAAAAGGTGGAAGCGGTAGGCCAGCTTGAAATCAGCTGGAATAACAAGCTTTTCCGCATCAAAGGCTTAATCCCAATGGACAGTAAGAATCCGATGAGTTTCAGTCGTGTACAGGGTGTAGGTGTTTCCGCCGTTATTGATGTAAGAGTTTAA",
    "translation": "MHIKRVGVALMAAAMIGTGVFSGVSASGLGSILGGIVKVGGIGFLVDKYGESLNSAINSVMMKEGAGTNYATKVVPIVSIGNRGYIGAAQVIGDADQVEKVEAVGQLEISWNNKLFRIKGLIPMDSKNPMSFSRVQGVGVSAVIDVRV",
    "product": ""
   },
   {
    "start": 43113,
    "end": 44309,
    "strand": 1,
    "locus_tag": "ctg3_45",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,113 - 44,309,\n (total: 1197 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAATCTATTCTTGCAGCAGGTATTTCTTTGTTGCTTGTATTTCCGGGAGCAGCAGCTGAACCAACGACCCTAAACGGACGTATGGAACGGGTGGAAGATGTCCTTTATGGGGAAACGCGCAGCGGCTCCCTTACCGAACGGATTACTTCCGCCGATAATTTAATTTATGGCACAGGCAGTTCGACAGGCGTGGGGCTTGATGACCGGGTCGGGAATCTTTATGCTGATGTGGTAAACAGCGGTAATGATGCTGCACCGTCCATCTCTTCCCGGACGAATGCCCTGGAGTACTACCTGACTGATGAAATTAAGCGGGAACCGCTTGCCGGCCGTATCGGTGATATGGAAAAAAGCGTTTTCGGCAGCGTGAAATCAGGCGCATTGGATAAGCGTACCGCGGAATTGGAAAAAGCTATTTATGGAGATCAACATTCGGAAATGAAGGATGTTGTTCTTCCTGAAAAGACGGTATTCAAGATTTCTTTAAATGATAATATCAGCAGCAAAACAAACCTTGTGGGTGACCCTGTAGAATTTACCGTGCAGGAAGATGTGAAGGTCGGTGACATTCTTGTGCTGCCCCGCGGTTCCAGAGGAAGCGGCGTGGTGACGAAAGTATCCCGGCCGAAGAGCTTTGGACGCAGCGGTAAACTGGATATTTCATTTGATCAGGTATTTTCTTTGGATGATGAACCGATTCCGACCGTTCTCGGACCAGAAGCAAAAGATAAGCTGAAGATGGAAGCTGCTGCTGTAGGCGCTTCTACTATCGGCGCATTGGCGCTGGGGCCGGTCGGCCTGGTAGGCGGTTTTTTTGTTAAAGGCAAAGATGTGGAACTTCCTGCAGGATCTGAATTGTATATACAAACGCAGAAAGATGTTACCACGAAAGGTCTTGTTACCGCTTCCGGCGCACCGAACATGGTACTTCGCAAGAGAGTGGCCAAGTCGGCTGTTGCGGGAGAAGTAGGGAATAAAGTGGCTTCTGATACCGGTTCTACTGTGAATACTGTGGAAAATATGCGGAATGAGTTGAAGTTTGTTAATGAGGATGGAAATGAAATAGATACCACTACGAAAACAGTAAAATCCGGTGCGGAAGAAACAAAAACGGAGGTTTCAGAGGCAGCGGAAAAGGTTGCTGATGAAGGAGAAGAAAATGCATCGGTGGTTATTGTAAGAAATGAATAA",
    "translation": "MKKSILAAGISLLLVFPGAAAEPTTLNGRMERVEDVLYGETRSGSLTERITSADNLIYGTGSSTGVGLDDRVGNLYADVVNSGNDAAPSISSRTNALEYYLTDEIKREPLAGRIGDMEKSVFGSVKSGALDKRTAELEKAIYGDQHSEMKDVVLPEKTVFKISLNDNISSKTNLVGDPVEFTVQEDVKVGDILVLPRGSRGSGVVTKVSRPKSFGRSGKLDISFDQVFSLDDEPIPTVLGPEAKDKLKMEAAAVGASTIGALALGPVGLVGGFFVKGKDVELPAGSELYIQTQKDVTTKGLVTASGAPNMVLRKRVAKSAVAGEVGNKVASDTGSTVNTVENMRNELKFVNEDGNEIDTTTKTVKSGAEETKTEVSEAAEKVADEGEENASVVIVRNE",
    "product": ""
   },
   {
    "start": 44302,
    "end": 45951,
    "strand": 1,
    "locus_tag": "ctg3_46",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 44,302 - 45,951,\n (total: 1650 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATAAATCGAGACTAAAGAGAGCATTGATTTTAGGATGTGTTCTTTTCCTGGGAACAATTCCGGAAGGATATGCTTTGGCGGTGGATGGTATAACTTATGAAGAAGGGTTCGTTGTTGATGAAGAGCATAAAGGTATAGTACGTCCGGTTCGCCCCGCGGAAGTTTTTATGAGACGAAGCAATGCGGAAATAAAGGAATCGGCAAAATCCGGTACTCTGTCTTTGGAAGCTAAAAAAGGAAAAAAGGGAGGAGAGGATACGGGAATTTCTCCCGAACATCCTTTAACTTTTACTGCGGACTATATCCGTTATAACCATTCTACAGGGGATGTCATGGCAGAAGGGCGTATTGATATGCGCCAGATGATGGATCAGTACACCACAGAGTATGTCTATGGAAACACGGTCACCCAGCAGTATGTTATTCCGGGTGCGGTACACTGGAAAAACGCTACTACCGATATGACGGCACAGCGGGCGGAATATGATGGTGCCGCATCCATAGGAAAGTTCTATGACTTTTCAGGCTGGGATTCAGGCCTTTACTATTTTAAAGGGGATAAAGGGACTTATTATCGTAAGGACAATAAAATGGTCGCGGATAGAGGCTACTTCACGACGAAGCATGCTGTTGCCAAAGTACCTGACTATCGGATTGAAGCAGATACCATCGAAATTTATCCGGGAGATCATTACACGGCTTATGATGTGAAATTAAAAGTGAAGAATACAACCCTTATTTCTTTTCCCAAGTACAGGGCTTCTTTGAAAAATGATAATGCGATCAGCCCGTGGTCGCTCCTTCCCCGCCCGAAGTATGACAGCGATAACGGATGGGGATGGCATAATGGGCTTGAATTACCTGTAGCGCATAATGACGATCTGTATTTTTATATCCGCAATGAATGGTACACGAAATCAGGATACAAGCCGGATGTCGGTTTTAGCTACAGCACACCTTTCGGGTGGTTCAATTTCCATTATGCTGAAAAAGAAAGTTCCATCAATGATGAGGGCGGTTTGTGGATTAAAAAGCGGCCGGCTCTTGAGTTTAAGTCTAATCGGTATTACCTGTTTAAATCGCCCTTCTATGCAGGTATAAACGGAGAAATCGGTTATTGGGATGAGGAAAGGGCAGGCGGTAACCGTAAGGGCAGTTATAAAGGCTTCGACGTGTATATTTCCGGTGATCCCGTAAAGCTGGGCAAGTTTCTGACTTTTAACTGGAGAGCAGGGTTTTCCAAAGATTACTACGGATACAAATACGAAGGGAACAATTTAAGGAAGAAGAGACTTTTTGATAGAAATGAGACACGTGAAAATAAATACTATTCCCTAGGACTTATGGGAAAATACAGAGCGGTTTCCGCATGGATTAATTATACAAACCGTTCAATTACAGGCTATACACCGTACCTTTATGATACCTTTAGTACGACGAAACCGCTCAATATGGGCTTCAGGATTGAACTGACGCCCAAAGATGCCATAAGCATTTCCTGGACGATTGATGTAAAAAATGGTGATGTGGATCATCGCTACTATACTTACTATCGGGATATGCACTCATTTTATAGCTGGATTCGGTATGATACGGTAGGGAAGAAGACAACATTTATGATTATGCCGAAAGATTTCAGATTCTGA",
    "translation": "MNKSRLKRALILGCVLFLGTIPEGYALAVDGITYEEGFVVDEEHKGIVRPVRPAEVFMRRSNAEIKESAKSGTLSLEAKKGKKGGEDTGISPEHPLTFTADYIRYNHSTGDVMAEGRIDMRQMMDQYTTEYVYGNTVTQQYVIPGAVHWKNATTDMTAQRAEYDGAASIGKFYDFSGWDSGLYYFKGDKGTYYRKDNKMVADRGYFTTKHAVAKVPDYRIEADTIEIYPGDHYTAYDVKLKVKNTTLISFPKYRASLKNDNAISPWSLLPRPKYDSDNGWGWHNGLELPVAHNDDLYFYIRNEWYTKSGYKPDVGFSYSTPFGWFNFHYAEKESSINDEGGLWIKKRPALEFKSNRYYLFKSPFYAGINGEIGYWDEERAGGNRKGSYKGFDVYISGDPVKLGKFLTFNWRAGFSKDYYGYKYEGNNLRKKRLFDRNETRENKYYSLGLMGKYRAVSAWINYTNRSITGYTPYLYDTFSTTKPLNMGFRIELTPKDAISISWTIDVKNGDVDHRYYTYYRDMHSFYSWIRYDTVGKKTTFMIMPKDFRF",
    "product": ""
   },
   {
    "start": 45980,
    "end": 47371,
    "strand": 1,
    "locus_tag": "ctg3_47",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,980 - 47,371,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAATTCTCTTTAGGCAAGCATTTAAATGTCGATTTACAATATATTTTTGGCAGTAAATGGAATGTAAATGCGGAAGATCTGCAAAATTATGAAGCAGTTATTTCCAATGCGGCAAAGCGTGTACAACAGATAAGAAAAACGGGAAAAGGCCCGGGAGGCAAAGCGGTTCTTTTTTCCCGCCTTCCTTATATTTTAGATGAAAATGTTCTCATGACGGCAGAAGAGCGGCTGCGGTTGGAACGGCTGGACGGAATCGGGAAAGAACAGGATGTTCTGATTTCTATCGGGATAGGAGGATCTTATCTGGGAAATCAGGCGATTTTTGATATTTTTTATGGTCCGTACTGGAATATGCGTTCCCGCGGGGAAAGAAACGGGTACCCGCAGGTATTCTTTGCGGGACAGAATGCCGACCCGGCAGCGCTTATGGATCTCGTCCGCCAGCTTCGAAGGGAACGGGACCGCTGCGGCCGTAAATTGAGAGTGCTGCTCCTGATAATTTCCAAGTCGGGGACAACTGTGGAACCGATGGCGGCTTTCCATGTATTGAGACGGGAATTATCCGATTTTTGCGAGCTTTCTTTTATTACAGTCACTGACAGAAATACCGGTAAGCTCCATGAATTGGCCGAACGGGAAGGATGGGAACAGTTTGCCGTACCTGAAGGTATCGGCGGCCGTTTCAGTGTCTTTTCCCAAGTCGGTTTGGTCTGGGGGAAGTTGGTCGGTCTGGATATAAGGGCTTTTCTTGACGGTGCGAGATTTGTGGAAGAGCATTGCCGGGGGAAAATTTCGGATAACCCGGCACTTATGCTGGCTGCGGTCAAGTTTATCGCCATGAAAGAGTATGGAGCGGCAGCAGAGGTCATTATGCCTTATGGTGCAGGCCTCCGTGCGTTAGGCTGGTGGTATGCCCAGTTGCTGGGAGAGTCTTTGGGGAAAAAATTTGATACCCATGGGAATATCATTTACAACGGCCGCATTCCGGTTGCCTGTGTAGGCACGACAGATATGCATTCCCTTACGCAGGAACACCAGCAGGGGAAGAAGAATAAAATTGTACAGTTTATTTCCGTGAGAAATCTTCCCGATAAAGCGGATTTCTTTTGTGATGACGGCCGCGCAGGCGGAATGGTGGATTTGGGGATGCTGCTTAATGCCGCTGCCTGGTCTAATCAGGAGGCTCTGGCACAGGAAGAAAGGATGAGCTGTGCGATAGAAATTGAAAAGCTGACAGAATTCCATATAGGAATGCTGATGTACTTCTTTTTCCTTGCTACCGCCTATGAAGGCGCTATGGCGGATATCAATACATACGACCAGCCGGGGGTGGAGGATTACAAGAAAATCCTCCGCAAGTATTTACAAAAATATATGAAAGAGGCATGA",
    "translation": "MKFSLGKHLNVDLQYIFGSKWNVNAEDLQNYEAVISNAAKRVQQIRKTGKGPGGKAVLFSRLPYILDENVLMTAEERLRLERLDGIGKEQDVLISIGIGGSYLGNQAIFDIFYGPYWNMRSRGERNGYPQVFFAGQNADPAALMDLVRQLRRERDRCGRKLRVLLLIISKSGTTVEPMAAFHVLRRELSDFCELSFITVTDRNTGKLHELAEREGWEQFAVPEGIGGRFSVFSQVGLVWGKLVGLDIRAFLDGARFVEEHCRGKISDNPALMLAAVKFIAMKEYGAAAEVIMPYGAGLRALGWWYAQLLGESLGKKFDTHGNIIYNGRIPVACVGTTDMHSLTQEHQQGKKNKIVQFISVRNLPDKADFFCDDGRAGGMVDLGMLLNAAAWSNQEALAQEERMSCAIEIEKLTEFHIGMLMYFFFLATAYEGAMADINTYDQPGVEDYKKILRKYLQKYMKEA",
    "product": ""
   },
   {
    "start": 47376,
    "end": 47885,
    "strand": 1,
    "locus_tag": "ctg3_48",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,376 - 47,885,\n (total: 510 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGGGGGCGCGCAGGAGATGGATAGTCCCGGTGACAGGGGCAGTGGCGGCCGTTTTAACGGTGTGGGGCATTCTTGGTGTCGGTAAAGCGTCAACCGTTATTCCTGAAGAGGCAAACGGTACAACTCCTGCTGCTGTAAATGAAAGTGAAATGAAATTTGGAAAAATATCGGGCGGCGTTAAAAAATATGACGCGGCTCTTTATTTGCGGGGAAAACCGTTGAAAGATCCGTTTTATGCGGTGCGGTCTTATGATTCAAAGAGGGAGAATGAAGAAGCGCCGCAGATGCCGGCAGCAGAAGGGACAACGGGGACTATCCATCTCGCCCCGGTTTTACAGGGAGTCATGGAGTATGGAGGGAACCGGCGGGCCATGCTTGCCGTGAATGGAGAATCAGTTACAGTTCGGAAAGGGGATCGGGTGGGTATATGGTCAGTCGTTTCAATCGGAGAAAAAACAGTCCAGTTATCATCGGCAGCAGGAAATCTTTTTTTGGAACTGCCTTGA",
    "translation": "MEGARRRWIVPVTGAVAAVLTVWGILGVGKASTVIPEEANGTTPAAVNESEMKFGKISGGVKKYDAALYLRGKPLKDPFYAVRSYDSKRENEEAPQMPAAEGTTGTIHLAPVLQGVMEYGGNRRAMLAVNGESVTVRKGDRVGIWSVVSIGEKTVQLSSAAGNLFLELP",
    "product": ""
   },
   {
    "start": 47957,
    "end": 49306,
    "strand": 1,
    "locus_tag": "ctg3_49",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,957 - 49,306,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGGAGATGAAACTGGAAACGAGTGCTCACGAAACGATGGAAGCGACACTCCGCCAATCCATGGAAGGACGAAAAGAGGAAAAGGCAAAAAGTTATTTAACGAAACATGCTGTTACGGAAGAAAAAGAACCTTCCGATTTCAGTCTTCATGTAAAGAATGCGCCTATCCAGGAGGTCCTCCGGAGTCTGGCGGAACTTACAGGGAAAAATATTGTCTTCGGCGGTACAGTTACAGGAAGTGTGACGGCTGATCTGGATCACGTCACGCCGAAAGAAGCGCTCCATGCCATGCTGGTTTCCCAGGGGCTCATAGCGCGGGAAGAAGGAAGCATGCTTATCGTCGTTGGTGAATCCGCCATGAAAAATGGGGGAAGAGCAACGAAATCCTATAAATTGTCTTATGCGGAAGCAAAAGAAGTGGCGGAAGGGCTTCGCCAGCTTTCCGACAGTGTCCATGTAGCATATAACCAGACGGCAAACGCGGTCATTCTGAGCGGAACACCTTTGGAAATCATGGAAACCGCTGCGGTTCTCCGCTCTCTTGATGTTCCTGAAAAACAGGTAAAAGTAGAGGCGGAAGTTATTGCCGTGAACCGATCCCATTCCAAAGAACTTGGGATCGACTGGGATTTTAAATCTCTTACCGGCAGCGGCGAGTATCACAGGGAAAGCTGGAGTGAACAGCGGTATGTCACCGATGATGCGGGAAATATAAAGTATGATAAAAATGGAAATCCGCGGATGCGGAATATCGAACATAACGGATGGAATGTGAAGATTCCTGAAGGCTACGCAGGTATTTCCTACGGCAGATCCGTGGCAGGGCATCCCTACACCGCTTTTTTCAGGGCTAACCTGAATGCTCTTGTTTCTACAGGCAAAGCGAGAATCCTTGCCCGGCCGAATGTGGTCACCATGAACGGGCGGGAAGCGGAAATACTTATAGGAAATAAAATTCCGGTTATCGTGGAGCACGTGGATAACGGCGTTCGGACAACGACCACGGAATACCGCGACGCAGGCATCAAGCTTACCTACACGCCCCGAATCAGTGCGGACGGGGAAATCACCGCAAATGTGAATGCTGAGGTTTCCACGCCGTACCTTGTGCCTGAAATGCGGGCTTACCGTATCATTACCCGCCAGGCAAATACGCTGGTCCGTCTCCGGTCGGGCGATATGCTTACTATCGGGGGTCTGATAGATAAGGAAGAAAATAAAACCTTTAGGAAAGTTCCTATTCTGGGAGATATCCCCTTACTGGGGAAACTTTTCCAGAGCAAGAGCCGATCCGTGGAGGAGTCGGAAATAGTCATCATCATAAAAGCGGAAATACTGGACAGATGA",
    "translation": "MPEMKLETSAHETMEATLRQSMEGRKEEKAKSYLTKHAVTEEKEPSDFSLHVKNAPIQEVLRSLAELTGKNIVFGGTVTGSVTADLDHVTPKEALHAMLVSQGLIAREEGSMLIVVGESAMKNGGRATKSYKLSYAEAKEVAEGLRQLSDSVHVAYNQTANAVILSGTPLEIMETAAVLRSLDVPEKQVKVEAEVIAVNRSHSKELGIDWDFKSLTGSGEYHRESWSEQRYVTDDAGNIKYDKNGNPRMRNIEHNGWNVKIPEGYAGISYGRSVAGHPYTAFFRANLNALVSTGKARILARPNVVTMNGREAEILIGNKIPVIVEHVDNGVRTTTTEYRDAGIKLTYTPRISADGEITANVNAEVSTPYLVPEMRAYRIITRQANTLVRLRSGDMLTIGGLIDKEENKTFRKVPILGDIPLLGKLFQSKSRSVEESEIVIIIKAEILDR",
    "product": ""
   },
   {
    "start": 49335,
    "end": 51218,
    "strand": 1,
    "locus_tag": "ctg3_50",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,335 - 51,218,\n (total: 1884 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 117.1; E-value: 1.7e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAVLRVNGLTKYFGINSVFENVSFELKSGEHIGLVGANGAGKTTLLKCIMGREEADRGTIKASDGAVIGYLRQDFDYAGETIRDEMEEAWKDVLFYKDRMERLAAELEFHKDDADLVLEYGKTEARFEFLGGYDYESATKKILTGLGFTEEDWDRDIHSFSGGQKVRINLAAAFVRHPDFLLLDEPTNHLDMGMLEWLEDYLRSYKGGVLMISHDRYFLDAAATGIIDLENHRIHSYRGGYTRYMDTKTQETAAYEKAYEKQQEHIHETEEYIRRYKAGIKSKQARGRQSQLNRLERLEKSNRQATLRFHFTPPDDCADKVLDILHGTAGYNGTPLFKDIEMHIKKGETVGLIGPNGAGKTTLLKMITGELAGEKTLIHMGSHVQVGYYSQEQEWLSPDRTVIDEVRDLFNYGEAEARNVLGMFLFRGEDVFKKISLLSGGEKARLSLLCLFLKRPNFLILDEPTNHLDIPTREIMEEAIQAFGGTCLIVSHDRYFLDKVVTRTLELDNGRLTEYLGNYTYYKEKKKDLEEFEKDRGNAKTAKTPAKMTVSKAEPKKAEKKEISIAAAKKLEQVEMEIARQEATVKMYTFRMNSEPENYAALTEEYKAAEEKLAKLYERWDAIAEDM\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGTACTTAGAGTCAATGGTTTAACTAAATATTTCGGCATTAACAGCGTTTTTGAAAATGTTTCTTTCGAATTGAAAAGCGGCGAACATATTGGGCTTGTAGGGGCGAACGGCGCAGGGAAAACGACACTCCTGAAATGTATCATGGGAAGGGAAGAGGCTGACAGGGGAACGATAAAAGCCAGTGATGGTGCAGTAATCGGCTACCTTCGCCAAGATTTCGATTATGCCGGTGAAACGATACGTGATGAAATGGAAGAAGCATGGAAAGACGTTCTCTTTTATAAAGACAGAATGGAACGGCTGGCAGCCGAATTGGAATTTCATAAAGATGACGCTGATCTTGTTTTGGAATATGGAAAAACGGAAGCCCGTTTTGAATTTCTCGGCGGTTATGATTATGAATCTGCCACGAAAAAAATTTTAACGGGTCTCGGTTTTACGGAAGAGGACTGGGATCGGGATATTCATTCTTTTTCCGGCGGTCAGAAGGTCAGGATTAATTTGGCGGCTGCTTTCGTGCGTCATCCGGATTTCCTTCTTCTTGACGAACCGACAAACCATTTGGACATGGGCATGCTGGAATGGCTGGAGGATTATCTTCGCTCCTATAAAGGGGGCGTGCTTATGATTTCTCATGACCGTTATTTTCTTGATGCTGCGGCGACAGGCATTATCGATCTGGAGAATCACCGCATTCATTCTTACCGCGGCGGCTATACGCGGTATATGGATACGAAGACACAGGAAACGGCGGCTTATGAAAAAGCGTATGAAAAGCAGCAGGAGCATATCCATGAAACGGAAGAATATATAAGAAGATACAAAGCGGGGATCAAGTCAAAACAGGCACGGGGACGGCAGTCGCAGCTGAACCGCTTGGAACGGCTGGAAAAATCGAACAGGCAGGCCACACTTCGTTTTCATTTCACACCGCCTGATGACTGTGCGGATAAGGTTCTTGATATCCTTCATGGTACGGCAGGATATAATGGGACTCCTTTATTTAAAGATATAGAAATGCATATAAAAAAAGGGGAGACGGTAGGACTTATCGGACCGAACGGTGCGGGGAAGACGACCCTCCTGAAAATGATTACAGGAGAACTGGCGGGAGAGAAAACGCTTATCCATATGGGCAGCCATGTACAGGTGGGTTACTACTCCCAGGAGCAGGAGTGGCTTTCACCGGATCGAACCGTTATTGATGAGGTGCGGGATCTTTTCAATTATGGCGAAGCGGAAGCAAGAAATGTGCTGGGCATGTTCCTCTTTCGGGGAGAAGATGTTTTCAAAAAAATATCTCTTCTTTCCGGCGGTGAAAAGGCGAGGCTGTCCTTGTTATGTCTCTTTCTGAAACGGCCGAACTTTCTCATCCTTGATGAACCGACAAACCATCTGGATATTCCTACGAGGGAAATCATGGAAGAAGCCATACAGGCTTTTGGCGGAACCTGTCTGATCGTTTCCCATGACCGGTATTTTCTTGATAAAGTTGTGACGCGCACACTGGAACTGGACAATGGCAGGCTTACTGAGTACCTTGGCAACTACACTTACTATAAAGAAAAGAAAAAAGACCTGGAAGAATTTGAAAAGGACAGGGGAAATGCAAAGACGGCAAAGACGCCTGCCAAAATGACAGTATCCAAGGCGGAACCGAAAAAGGCAGAAAAGAAGGAAATTTCTATAGCGGCAGCAAAAAAGCTGGAGCAGGTGGAAATGGAAATTGCACGGCAGGAAGCAACCGTGAAAATGTACACTTTCCGTATGAACAGCGAGCCTGAAAATTATGCCGCCCTTACGGAAGAGTATAAGGCCGCGGAAGAAAAGCTGGCAAAACTTTATGAACGATGGGATGCCATCGCAGAAGATATGTAA",
    "translation": "MAVLRVNGLTKYFGINSVFENVSFELKSGEHIGLVGANGAGKTTLLKCIMGREEADRGTIKASDGAVIGYLRQDFDYAGETIRDEMEEAWKDVLFYKDRMERLAAELEFHKDDADLVLEYGKTEARFEFLGGYDYESATKKILTGLGFTEEDWDRDIHSFSGGQKVRINLAAAFVRHPDFLLLDEPTNHLDMGMLEWLEDYLRSYKGGVLMISHDRYFLDAAATGIIDLENHRIHSYRGGYTRYMDTKTQETAAYEKAYEKQQEHIHETEEYIRRYKAGIKSKQARGRQSQLNRLERLEKSNRQATLRFHFTPPDDCADKVLDILHGTAGYNGTPLFKDIEMHIKKGETVGLIGPNGAGKTTLLKMITGELAGEKTLIHMGSHVQVGYYSQEQEWLSPDRTVIDEVRDLFNYGEAEARNVLGMFLFRGEDVFKKISLLSGGEKARLSLLCLFLKRPNFLILDEPTNHLDIPTREIMEEAIQAFGGTCLIVSHDRYFLDKVVTRTLELDNGRLTEYLGNYTYYKEKKKDLEEFEKDRGNAKTAKTPAKMTVSKAEPKKAEKKEISIAAAKKLEQVEMEIARQEATVKMYTFRMNSEPENYAALTEEYKAAEEKLAKLYERWDAIAEDM",
    "product": ""
   },
   {
    "start": 51230,
    "end": 51592,
    "strand": 1,
    "locus_tag": "ctg3_51",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,230 - 51,592,\n (total: 363 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGATACGGCACTGGCGGCAGCCAAGGAAATGATTAAGACGATGGAAGGCTTAGCGGATAGTTTGCAGGAACGGGTGCGCAGAACGGAAGCGGAAAATGAAGCGCTTCGGAAAGAATTGGAAAAGTACCGTGAAGAACGGAAAATGACGGAAGAGGTTTTTCGGGGAGGCTCCGGTGAATTCAGCGGCTGTGATGACAGAAAGATATTAGAAGATTTAAGCGGGAAACTCAGCTGTTACTATCGGGATTTAGATCTTTATGACGAAAAGCGGATTACTGCTGAAGACGGGGAAACGCTCTATCACACGATAAAGTACATTTTCAAACAATTAAAAAAAGCAGGTGTCCGCTTTAAGTGA",
    "translation": "MKDTALAAAKEMIKTMEGLADSLQERVRRTEAENEALRKELEKYREERKMTEEVFRGGSGEFSGCDDRKILEDLSGKLSCYYRDLDLYDEKRITAEDGETLYHTIKYIFKQLKKAGVRFK",
    "product": ""
   },
   {
    "start": 51632,
    "end": 52447,
    "strand": -1,
    "locus_tag": "ctg3_52",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg3_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg3_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,632 - 52,447,\n (total: 816 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg3_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg3_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAATACAAATTCCTGACGACTTTGATCCGGAAAAAATCATACGGAGCGGACAATGTTTCCGTGCCTCCGCACAGCCCGACGGCTCCTTCCACTTCATCACAAGGAAAAACATGTTGTCTCTATCCCCGCTTGGAACGGATACCTGGGAAGCGGACTGCACCCCTTACGCATGGAAGCGGGTGTGGACTCCTTATTTTGATTTATCTGTTTCTTACAAGTCGCTTAGACGCTCCATTCCCGCAAAAGATCATTTTCTCAGGGCTGCGGCCGAATATGGAAAAGGTATCCGCATCTTGCGGCAGGATCCTTTTGAAATGCTCATCACCTTTATCATCTCCCAAAGGAAATCCATTCCCGCTATACGGAGTTCCGTGGAAAAACTTTGTCTTGCCGCAGGAAAGGAAATTACAAAAAATGGGCGAACTTTTTACACATTTCCCTCCCCGTCAGCGCTCGGGAAATTATCTGTCAATGAATTGAAAAACTGTTCTCTCGGGTACCGGGCCGCCTATATTCATGCCACAGCCCGCATGATTGCGAGAGAAAAGATCAGCTTCACCAAAATGGAAACATTGTCTGATAAGGAACTCACGGAAAAACTTCTTCTGTTTCCCGGAGCAGGCATCAAAGTGGTAAATTGTATTTCCCTATTCGCTTACCACCGCACGGCAGCCGCACCTGTAGATGTGTGGATCGGGCGGGTCATTCAGAAACATTATGGCGGAGTCAGCCCGTTCCCATCTTATGGCCATGCAGCAGGCATTTTTCAGCAGTATATGTTCTTCTACGCGCAGGCAAAGAAATTAAAATAG",
    "translation": "MKIQIPDDFDPEKIIRSGQCFRASAQPDGSFHFITRKNMLSLSPLGTDTWEADCTPYAWKRVWTPYFDLSVSYKSLRRSIPAKDHFLRAAAEYGKGIRILRQDPFEMLITFIISQRKSIPAIRSSVEKLCLAAGKEITKNGRTFYTFPSPSALGKLSVNELKNCSLGYRAAYIHATARMIAREKISFTKMETLSDKELTEKLLLFPGAGIKVVNCISLFAYHRTAAAPVDVWIGRVIQKHYGGVSPFPSYGHAAGIFQQYMFFYAQAKKLK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 41060,
    "end": 42500,
    "tool": "rule-based-clusters",
    "neighbouring_start": 31060,
    "neighbouring_end": 52500,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r3c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {
 "r3c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg3_36": {
     "functions": []
    },
    "ctg3_37": {
     "functions": []
    },
    "ctg3_38": {
     "functions": []
    },
    "ctg3_39": {
     "functions": []
    },
    "ctg3_40": {
     "functions": []
    },
    "ctg3_41": {
     "functions": []
    },
    "ctg3_42": {
     "functions": []
    },
    "ctg3_43": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Ranthipeptide_rSAM_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SPASM",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TIGR04085",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Fer4_12",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg3_44": {
     "functions": []
    },
    "ctg3_45": {
     "functions": []
    },
    "ctg3_46": {
     "functions": []
    },
    "ctg3_47": {
     "functions": []
    },
    "ctg3_48": {
     "functions": []
    },
    "ctg3_49": {
     "functions": []
    },
    "ctg3_50": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg3_51": {
     "functions": []
    },
    "ctg3_52": {
     "functions": []
    }
   }
  }
 }
};
